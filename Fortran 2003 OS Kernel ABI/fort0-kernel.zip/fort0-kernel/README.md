# fort0-kernel

A standalone x86-64 kernel written in Fortran above a minimal asm
floor, following the discipline established by the sibling userspace
project `fort0` (`libfort0/docs/CALL-BRIDGE-SPEC.md`): gfortran's
by-reference calling convention bridged to raw hardware/privileged
instructions by hand-written `.s` files, one named entry point per
register-passing shape, every claim about compiler codegen verified
with `nm`/`objdump` rather than assumed.

Historical precedent for "OS kernel mostly in Fortran, thin asm
floor": PRIMOS (Prime Computer, 1969-) and Sintran (Norsk Data, 1968)
both shipped this way for two decades. Neither achieved 100% Fortran
either — see `kernel/docs/RING0-BRIDGE-SPEC.md` section 0 for why a
fixed asm floor is structural, not a shortcut.

## Status: Stage 5 complete, scheduler checkpoints 1 & 2 complete,
user mode (ring 3) working, scheduled ring-3 tasks working end to end

**User mode is real and verified.** A hand-written ring-3 program
enters via a genuine `iretq` transition, executes, calls syscalls
through a dedicated DPL=3 IDT gate, and exits cleanly — confirmed 4/4
clean boots with zero faults of any kind. Getting there required
finding and fixing several real, independent bugs: a missing TSS (long
mode requires one via `LTR` even without hardware task-switching), a
genuine gfortran calling-convention bug from a missing `USE RING0`,
every page in the kernel's history lacking the `PTE_USER` bit (nothing
before this needed ring-3-accessible memory), the PIC being remapped
*after* the first ring-3 boot test ran (causing the timer IRQ to
misdeliver as the CPU's own double-fault vector), and a "safe"
fallback loop that used `hlt` — itself a privileged instruction that
faults at ring 3. See `kernel/docs/RING0-BRIDGE-SPEC.md` sections
31-33 for the full, honest account, including the dead ends.

**Wiring ring 3 into the real scheduler is now working end to end.**
`TCB_REGS_T` carries `CS`/`SS`/`PRIVILEGE_RING`, and the context-switch
primitive correctly resumes both ring-0 and ring-3 tasks through the
scheduler's ordinary preemption/yield machinery. Getting here surfaced
a real, genuinely deep architectural finding: `IRET`/`IRETQ`'s same-
privilege return path silently ignores the `RSP`/`SS` fields entirely,
which broke specifically when a ring-3-entered interrupt needed to
hand off to a *ring-0* task — a case the scheduler can legitimately hit
at any time. The eventual fix doesn't fight this behavior at all: a
ring-0 destination now bypasses `iretq` entirely and reuses the same,
already-proven `jmp`-based mechanism `fort0k_context_switch` already
uses for every ordinary switch — `iretq` only remains in play for
genuine privilege changes, which is the one thing it's actually needed
for. Verified 5/5 clean single-core boots (a full ring-3/ring-0
interleave running correctly to completion) and 19/21 clean multi-core
boots. See sections 34-38 for the complete, honest debugging arc,
including two earlier fix attempts that turned out to be incomplete
before the real one landed, and a small residual multi-core-specific
timing issue (not part of this fix, flagged as separate future work)
that shows up in roughly 1 in 15-20 runs.

**Task lifecycle is real**: tasks can now genuinely exit
(`SCHED_EXIT_TASK`, a `ZOMBIE` state, deferred cleanup via
`SCHED_REAP_ZOMBIES` from a safe context) rather than living forever,
verified end-to-end via a direct readback confirming a freed task's
slot actually returns to `UNUSED`. `CR3` is plumbed all the way
through the context-switch primitive (a real, hot-path `%cr3` write,
conditional on it actually changing), proven safe in the always-
identical-address-space case — the actual prerequisite for per-task
isolation, not yet used to give a task its own PML4.

**A small feedforward network can score and optionally control real
scheduling decisions** — `sched_nn.f90`, using `MATMUL`/`DOT_PRODUCT`,
wired into the scheduler's dequeue path via a hook so the proven FIFO
mechanism remains the default and is never modified. A real, honestly-
documented finding along the way: the current hand-chosen weights
have a persistent bias favoring higher `TASK_ID`s, found via
independent verification, not left as an unchecked claim.

**Since Stage 5**: `PMM_ALLOC_PAGE`'s bitmap scan is genuinely
vectorized (`DO CONCURRENT` + a per-file SSE/`-O3` override, confirmed
via real `xmm`/`ymm` instructions in the linked binary) — a real
exploration of where Fortran's actual performance strengths apply in
this codebase, not just a stunt. It also surfaced and fixed a real,
previously-latent bug: Application Processors never had their FPU/SSE
state initialized (`ap_trampoline.s` was missing what `boot.s` already
does for the BSP), invisible until an AP finally executed real SSE
code. See `kernel/docs/RING0-BRIDGE-SPEC.md` section 25 for the full
account.

- **Stage 0**: Multiboot2 boot, 32-to-64-bit long mode transition,
  FPU/SSE init, VGA text-mode + serial output from Fortran.
- **Stage 1**: GDT + IDT, 32 CPU exception vectors, a fault reported
  cleanly to serial instead of triple-faulting the machine.
- **Stage 2**: 8259 PIC remap, PIT timer (IRQ0) and PS/2 keyboard
  (IRQ1) delivering real hardware interrupts through the same IDT/
  trampoline/dispatch chain, correctly resuming interrupted code via
  `iretq` rather than halting.
- **Stage 3**: Multiboot2 memory map parsing and a bitmap-based
  physical page allocator, verified with a real allocate/write/
  readback/free/reallocate test rather than trusting a summary count.
- **Stage 4**: a real 4-level (PML4/PDPT/PD/PT) page table structure
  built entirely in Fortran, replacing `boot.s`'s throwaway 1GiB
  bootstrap mapping, with a working higher-half kernel mapping
  verified by reading and writing the same physical page through two
  different virtual addresses.
- **Stage 5 (SMP bring-up)**: ACPI/MADT parsing finds every CPU core
  and its Local APIC ID; a 16-bit real-mode AP trampoline
  (`ap_trampoline.s`) and INIT-SIPI-SIPI wake sequence bring every
  detected Application Processor through real mode, protected mode,
  and long mode into Fortran — verified with 12 consecutive clean
  boot runs (all cores checking in, zero triple faults) after fixing
  a real inter-core shared-memory race with a proper handshake rather
  than a timing guess.

Every finding — what gfortran flags actually do, which codegen
patterns are safe or unsafe at which optimization level, hardware
struct packing behavior under `BIND(C)`, three real triple-faults and
their root causes — is written up in `kernel/docs/RING0-BRIDGE-SPEC.md`
with the actual evidence (register dumps, disassembly, byte offsets),
not asserted from memory. Read that document before writing new
kernel-mode Fortran in this codebase; it exists specifically so the
same landmines don't get rediscovered by the next person (including a
future instance of whoever is working on this).

## Building

```
make            # build kernel/fort0-kernel.elf
make iso        # build a bootable ISO (needs grub-mkrescue, xorriso)
make run-graphic  # boot it in QEMU with a real display + serial console
```

Requires: `gfortran`, GNU `as`/`ld`, `grub-mkrescue`, `xorriso`,
`qemu-system-x86_64`. All plain `apt` packages on Debian/Ubuntu.

## Project layout

```
boot/boot.s        -- Multiboot2 header, 32-bit entry, long-mode transition
boot/link.ld        -- linker script (1MiB load address, vga_buf pinned to 0xB8000)
kernel/src/
  ring0.s           -- privileged-instruction primitives (in/out, lgdt/lidt, cli/sti/hlt, ...)
  ring0_mod.f90      -- Fortran INTERFACE declarations for ring0.s
  isr_stubs.s        -- 49 interrupt entry trampolines (32 exceptions + 16 IRQs + 1 syscall gate)
  ap_trampoline.s    -- 16-bit real-mode AP wake trampoline (Stage 5)
  sched_switch.s     -- context-switch primitive (register save/restore, ring-0 and ring-3 resume)
  sched_lock.s       -- spinlock primitive (xchg-based)
  usermode_enter.s   -- ring 0 -> ring 3 transition primitive (hand-built iretq frame)
  usermode_test.s    -- hand-written ring-3 test programs (syscalls, privilege-boundary test)
  vga.f90            -- VGA text-mode driver
  serial.f90         -- 16550 UART driver (COM1)
  tss.f90            -- Task State Segment (required in long mode for privilege transitions)
  gdt.f90            -- Global Descriptor Table (kernel + user segments, TSS descriptor)
  idt.f90            -- Interrupt Descriptor Table (incl. DPL=3 syscall gate)
  interrupts.f90     -- exception/IRQ/syscall dispatch, IRQ handler registration
  pic.f90            -- 8259 PIC remap, mask, EOI
  timer.f90          -- PIT periodic timer driver (IRQ0)
  keyboard.f90       -- PS/2 keyboard driver (IRQ1)
  multiboot2.f90     -- Multiboot2 info structure parser (memory map)
  pmm.f90            -- physical memory manager (bitmap page allocator, vectorized scan)
  vmm.f90            -- virtual memory manager (4-level page tables, higher-half mapping)
  multiboot2.f90     -- (also parses the ACPI RSDP tag GRUB provides)
  acpi.f90           -- ACPI RSDT/XSDT/MADT parsing, CPU/APIC ID discovery
  apic.f90           -- Local APIC MMIO driver (register access, IPI sending)
  smp.f90            -- SMP bring-up: trampoline copy, per-core wake sequence
  sched.f90          -- scheduler: TCB, ready queue, context switch, task lifecycle,
                        ring-3 task creation (see status above)
  sched_nn.f90       -- feedforward network scoring/policy for scheduling decisions
  kernel_main.f90    -- boot sequence, entry point called from boot.s
kernel/docs/
  RING0-BRIDGE-SPEC.md  -- the actual engineering log: every verified
                            finding, every bug and its root cause,
                            the calling-convention contract this
                            codebase runs on
```

## Where this is headed

**The scheduler's two planned checkpoints are both done.** `sched.f90`,
`sched_switch.s`, and `sched_lock.s` implement a Task Control Block, a
shared ready queue, a context-switch primitive, and a real spinlock.

- **Checkpoint 1 (single-core cooperative switching)**: two demo tasks
  correctly interleave and preserve independent state across real
  switches. Getting here took finding and fixing three real,
  independent bugs — a compiler tail-call optimization silently
  discarding a required return address, a fabricated task's interrupt
  flag causing a non-deterministic fault, and a missing 8-byte stack
  adjustment when transferring control via `jmp` instead of `ret` —
  each confirmed by direct evidence (disassembly, register dumps)
  rather than a plausible-sounding fix alone. See
  `kernel/docs/RING0-BRIDGE-SPEC.md` sections 19-23 for the full,
  honest debugging account, including the parts that turned out to be
  red herrings.
- **Checkpoint 2 (multi-core concurrent scheduling)**: every
  Application Processor now creates and runs its own task via the
  scheduler instead of halting after SMP wake-up, all pulling from the
  SAME shared, spinlock-protected ready queue — this project's first
  genuinely concurrent, multi-writer shared-data-structure use.
  Verified safe under real concurrent load across repeated `-smp 4`
  boot tests (zero corruption, zero triple faults). Two other
  previously-unprotected shared resources (`serial.f90`'s UART output,
  `pmm.f90`'s physical allocator) were found and locked in the same
  pass, before they could become live hazards under this checkpoint's
  actual concurrent load. **Honest limitation**: tasks do not yet
  migrate between cores — each AP's task runs exclusively on the core
  that created it, so this proves the concurrency primitives are safe,
  not that load balancing exists yet. See section 24 for the full
  characterization.

**User mode (ring 3) is real and fully working, verified 4/4 clean
boots** — a hand-written program transitions to ring 3 via a genuine
`iretq`, executes, calls syscalls through a dedicated DPL=3 gate, and
the privilege boundary itself was tested and confirmed to hold. See
sections 31-33 for the five real, independent bugs found and fixed to
get there.

**Ring 3 is now fully wired into the scheduler, working end to end.**
The context-switch primitive correctly resumes both ring-0 and ring-3
tasks through ordinary preemption/yield. The genuinely hard part was
architectural, not a simple bug: `IRET`/`IRETQ`'s same-privilege
return path silently ignores the `RSP`/`SS` fields entirely, which
broke specifically when a ring-3-entered interrupt needed to hand off
to a *ring-0* task — something the scheduler can legitimately decide
to do at any time. The fix doesn't fight this behavior; it sidesteps
`iretq` entirely for a ring-0 destination and reuses the same, already-
proven `jmp`-based mechanism the ordinary switch path already uses —
`iretq` stays in play only for genuine privilege changes, the one case
it's actually needed for. See sections 34-38 for the complete arc,
including two earlier fix attempts that made real, measurable progress
but weren't quite right before the actual fix landed. A small, low-
frequency, multi-core-specific timing issue remains, flagged
explicitly as separate, not-yet-investigated future work rather than
folded into this fix's scope.

Beyond that:

- **Per-task address spaces** — `CR3` is fully plumbed through the
  context-switch primitive (a real, conditional `%cr3` write on the
  hot path) and proven safe in the always-identical-address-space
  case; giving a task its own PML4 is the next concrete step once
  ring 3's remaining scheduling issue is resolved.
- **A C ABI compatibility layer** — this project already leans on
  `BIND(C)`/SysV interop as its core discipline; a real syscall-level
  ABI a compiled C program could target is a natural, high-value
  extension of the ring-3/syscall work already in place.
- **Cross-core task migration** (a Chase-Lev-style work-stealing
  deque is the leading candidate) and **parallel processing** —
  genuinely a Fortran strength (F95's `FORALL`, F2008's `DO
  CONCURRENT` and coarrays, OpenMP/OpenACC's deep Fortran
  integration) and a real long-term direction: a kernel that
  schedules and runs Fortran's own native parallel constructs across
  cores would be distinctive, genuinely different from "a C kernel
  with a Fortran accent." Coarrays specifically were investigated and
  ruled out as a near-term mechanism — gfortran's coarray runtime
  needs OS-level process/shared-memory machinery this kernel doesn't
  (and structurally can't, being the OS) provide.
