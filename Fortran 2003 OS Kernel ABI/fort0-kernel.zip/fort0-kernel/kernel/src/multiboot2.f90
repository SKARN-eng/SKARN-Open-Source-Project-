! multiboot2.f90 -- parses the Multiboot2 information structure
! GRUB hands off in %rbx/%eax at boot (captured by boot.s into
! mb2_info_ptr, passed to KERNEL_MAIN as MB2_INFO_ADDR, unused until
! now). See https://www.gnu.org/software/grub/manual/multiboot2/ for
! the format this module implements against.
!
! STRUCTURE, per the spec, all fields little-endian (native x86-64
! byte order, no translation needed):
!   MBI header: u32 total_size, u32 reserved         (8 bytes)
!   then a stream of 8-byte-aligned tags:
!     tag header: u32 type, u32 size                  (8 bytes)
!     tag payload: type-specific, 'size' bytes total INCLUDING the
!                  8-byte tag header itself
!   terminated by a type=0, size=8 end tag.
!
! This module only implements the ONE tag this project currently
! needs (type 6, memory map) -- per RING0-BRIDGE-SPEC.md's add-only-
! when-needed rule, extended here to mean "parse only the tags a
! consumer exists for," not "parse everything the spec defines."
! Unrecognized tag types are skipped via their own 'size' field
! (every tag is self-describing this way, by design of the format),
! not ignored by assumption.
MODULE MULTIBOOT2
  USE ISO_C_BINDING
  IMPLICIT NONE

  INTEGER(C_INT32_T), PARAMETER :: MB2_TAG_END = 0
  INTEGER(C_INT32_T), PARAMETER :: MB2_TAG_MEMORY_MAP = 6
  INTEGER(C_INT32_T), PARAMETER :: MB2_TAG_ACPI_OLD = 14
  INTEGER(C_INT32_T), PARAMETER :: MB2_TAG_ACPI_NEW = 15
  ! ACPI_OLD carries a copy of the ACPI 1.0 RSDP (20 bytes); ACPI_NEW
  ! carries the extended ACPI 2.0+ RSDP (36 bytes, adds an XSDT
  ! pointer). Confirmed via web search this session (GRUB source,
  ! OSDev wiki, and the multiboot2 crate docs all agree independently)
  ! that Multiboot2 handing over a copy of the RSDP this way is the
  ! *recommended* way to locate it -- this project does not scan BIOS
  ! memory (the EBDA / 0xE0000-0xFFFFF ranges) for the RSDP signature
  ! itself, deliberately: GRUB has already done that scan correctly,
  ! and re-doing it would be duplicate, riskier work for no benefit
  ! this project's boot path (always via GRUB) would ever exercise.

  ! Region types per the Multiboot2 spec (== e820 types, per the
  ! Rust multiboot2 crate documentation consulted while building
  ! this): 1 = available RAM, everything else (2=reserved, 3=ACPI
  ! reclaimable, 4=NVS, 5=bad) is NOT usable by a general-purpose
  ! allocator without type-specific handling this project doesn't
  ! implement yet.
  INTEGER(C_INT32_T), PARAMETER :: MB2_MEM_AVAILABLE = 1

  TYPE, BIND(C) :: MB2_TAG_HEADER_T
    INTEGER(C_INT32_T) :: TAG_TYPE
    INTEGER(C_INT32_T) :: TAG_SIZE
  END TYPE MB2_TAG_HEADER_T

  ! Memory-map tag header (the 4 fields immediately after the generic
  ! 8-byte tag header above) -- all-u32 fields, guaranteed packed by
  ! construction (every field the same width), not independently
  ! byte-offset-probed since that reasoning already covers it.
  TYPE, BIND(C) :: MB2_MMAP_TAG_HEADER_T
    INTEGER(C_INT32_T) :: TAG_TYPE
    INTEGER(C_INT32_T) :: TAG_SIZE
    INTEGER(C_INT32_T) :: ENTRY_SIZE
    INTEGER(C_INT32_T) :: ENTRY_VERSION
  END TYPE MB2_MMAP_TAG_HEADER_T

  ! Memory-map entry -- byte-offset-probed this session via a
  ! standalone probe (objdump on a linked probe binary): BASE_ADDR@0,
  ! LENGTH@8, REGION_TYPE@16, RESERVED@20, total size 24, zero
  ! padding, confirming this specific field-size sequence (8,8,4,4)
  ! sums to naturally-aligned boundaries throughout -- BIND(C) is
  ! safe to use directly here, same reasoning IDT_ENTRY_T's probe
  ! established for its own, different field-size sequence. Does NOT
  ! generalize from that finding without this independent check, per
  ! RING0-BRIDGE-SPEC.md section 1's standing rule.
  TYPE, BIND(C) :: MB2_MMAP_ENTRY_T
    INTEGER(C_INT64_T) :: BASE_ADDR
    INTEGER(C_INT64_T) :: LENGTH
    INTEGER(C_INT32_T) :: REGION_TYPE
    INTEGER(C_INT32_T) :: RESERVED
  END TYPE MB2_MMAP_ENTRY_T

CONTAINS

  ! MB2_FIND_MEMORY_MAP(INFO_ADDR, ENTRIES_ADDR, ENTRY_COUNT, ENTRY_SIZE)
  ! -- walks the tag list starting at INFO_ADDR+8 (skipping the 8-byte
  ! MBI header) looking for the memory-map tag. On success,
  ! ENTRIES_ADDR is set to the address of the FIRST ENTRY (i.e. past
  ! the 16-byte mmap tag header), ENTRY_COUNT and ENTRY_SIZE describe
  ! how to walk it, and the function returns .TRUE.. On failure (tag
  ! not present -- a real possibility per the spec, not just a
  ! defensive check: some bootloaders on some platforms omit it),
  ! returns .FALSE. and the other three arguments are undefined.
  !
  ! Uses C_F_POINTER on a raw computed address (RING0-BRIDGE-SPEC.md
  ! section 1's confirmed-safe-at-O2 idiom) to walk the tag list,
  ! since the tag list's length and structure are only known at
  ! runtime (from the boot loader), not something Fortran array
  ! indexing over a compile-time-shaped type could express directly.
  FUNCTION MB2_FIND_MEMORY_MAP(INFO_ADDR, ENTRIES_ADDR, ENTRY_COUNT, ENTRY_SIZE) RESULT(FOUND)
    INTEGER(C_INT64_T), INTENT(IN) :: INFO_ADDR
    INTEGER(C_INT64_T), INTENT(OUT) :: ENTRIES_ADDR
    INTEGER(C_INT32_T), INTENT(OUT) :: ENTRY_COUNT
    INTEGER(C_INT32_T), INTENT(OUT) :: ENTRY_SIZE
    LOGICAL :: FOUND

    INTEGER(C_INT32_T) :: TOTAL_SIZE
    INTEGER(C_INT64_T) :: CURSOR, TAGS_END
    TYPE(MB2_TAG_HEADER_T), POINTER :: HDR
    TYPE(MB2_MMAP_TAG_HEADER_T), POINTER :: MMAP_HDR
    INTEGER(C_INT32_T), POINTER :: TOTAL_SIZE_PTR
    INTEGER(C_INT64_T) :: PADDED_SIZE

    FOUND = .FALSE.
    ENTRIES_ADDR = 0_C_INT64_T
    ENTRY_COUNT = 0_C_INT32_T
    ENTRY_SIZE = 0_C_INT32_T

    CALL C_F_POINTER(TRANSFER(INFO_ADDR, C_NULL_PTR), TOTAL_SIZE_PTR)
    TOTAL_SIZE = TOTAL_SIZE_PTR
    TAGS_END = INFO_ADDR + INT(TOTAL_SIZE, C_INT64_T)

    CURSOR = INFO_ADDR + 8_C_INT64_T   ! skip the 8-byte MBI header

    DO WHILE (CURSOR < TAGS_END)
      CALL C_F_POINTER(TRANSFER(CURSOR, C_NULL_PTR), HDR)

      IF (HDR%TAG_TYPE == MB2_TAG_END) THEN
        EXIT   ! end tag -- stop, tag not found
      END IF

      IF (HDR%TAG_TYPE == MB2_TAG_MEMORY_MAP) THEN
        CALL C_F_POINTER(TRANSFER(CURSOR, C_NULL_PTR), MMAP_HDR)
        ENTRIES_ADDR = CURSOR + 16_C_INT64_T   ! past the 16-byte mmap
                                                 ! tag header, to the
                                                 ! first entry
        ENTRY_SIZE = MMAP_HDR%ENTRY_SIZE
        ENTRY_COUNT = (MMAP_HDR%TAG_SIZE - 16_C_INT32_T) / MMAP_HDR%ENTRY_SIZE
        FOUND = .TRUE.
        RETURN
      END IF

      ! Advance to the next tag: every tag is padded up to the next
      ! 8-byte boundary (per the spec's "all tags are 8-byte aligned"
      ! rule), so the next tag's address is CURSOR + TAG_SIZE rounded
      ! up to a multiple of 8, not just CURSOR + TAG_SIZE directly --
      ! a real bug this project would otherwise hit silently on any
      ! tag whose size isn't already a multiple of 8 (several aren't,
      ! e.g. the boot command line string tag).
      PADDED_SIZE = INT(HDR%TAG_SIZE, C_INT64_T)
      PADDED_SIZE = ISHFT(ISHFT(PADDED_SIZE + 7_C_INT64_T, -3), 3)
      CURSOR = CURSOR + PADDED_SIZE
    END DO
  END FUNCTION MB2_FIND_MEMORY_MAP

  ! MB2_GET_ENTRY(ENTRIES_ADDR, ENTRY_SIZE, INDEX, BASE, LENGTH, REGION_TYPE)
  ! -- reads entry number INDEX (0-based) out of the memory map found
  ! by MB2_FIND_MEMORY_MAP. Takes ENTRY_SIZE explicitly (rather than
  ! assuming SIZEOF(MB2_MMAP_ENTRY_T)) because the spec explicitly
  ! reserves the right for entry_size to grow in a future memory-map
  ! version with extra trailing fields this project's MB2_MMAP_ENTRY_T
  ! does not know about -- using the boot-loader-reported ENTRY_SIZE
  ! for the stride, while still reading only the fields this project's
  ! type knows about, is forward-compatible with that without this
  ! module needing to track future spec versions itself.
  SUBROUTINE MB2_GET_ENTRY(ENTRIES_ADDR, ENTRY_SIZE, INDEX, BASE, LENGTH, REGION_TYPE)
    INTEGER(C_INT64_T), INTENT(IN) :: ENTRIES_ADDR
    INTEGER(C_INT32_T), INTENT(IN) :: ENTRY_SIZE
    INTEGER(C_INT32_T), INTENT(IN) :: INDEX
    INTEGER(C_INT64_T), INTENT(OUT) :: BASE, LENGTH
    INTEGER(C_INT32_T), INTENT(OUT) :: REGION_TYPE
    TYPE(MB2_MMAP_ENTRY_T), POINTER :: E
    INTEGER(C_INT64_T) :: ADDR

    ADDR = ENTRIES_ADDR + INT(INDEX, C_INT64_T) * INT(ENTRY_SIZE, C_INT64_T)
    CALL C_F_POINTER(TRANSFER(ADDR, C_NULL_PTR), E)
    BASE = E%BASE_ADDR
    LENGTH = E%LENGTH
    REGION_TYPE = E%REGION_TYPE
  END SUBROUTINE MB2_GET_ENTRY

  ! MB2_FIND_TAG(INFO_ADDR, WANT_TYPE, TAG_ADDR) -- generic version of
  ! the tag-walk MB2_FIND_MEMORY_MAP already implements specifically
  ! for the memory-map tag; this one returns the address of the START
  ! of any tag matching WANT_TYPE (the tag's own 8-byte type/size
  ! header, i.e. the caller is responsible for skipping past it to
  ! whatever payload interpretation it needs -- unlike
  ! MB2_FIND_MEMORY_MAP, which already skips past its own 16-byte
  ! header for the caller's convenience, since that function has
  ! exactly one payload shape to interpret and this one deliberately
  ! does not commit to any). MB2_FIND_MEMORY_MAP is NOT rewritten to
  ! call this and stays as its own independent implementation -- it
  ! already works, is boot-tested, and rewriting a working tag-walk to
  ! share code with a new, less-tested one risks the working path for
  ! a code-sharing benefit this project does not need urgently enough
  ! to justify that risk.
  FUNCTION MB2_FIND_TAG(INFO_ADDR, WANT_TYPE, TAG_ADDR) RESULT(FOUND)
    INTEGER(C_INT64_T), INTENT(IN) :: INFO_ADDR
    INTEGER(C_INT32_T), INTENT(IN) :: WANT_TYPE
    INTEGER(C_INT64_T), INTENT(OUT) :: TAG_ADDR
    LOGICAL :: FOUND

    INTEGER(C_INT32_T) :: TOTAL_SIZE
    INTEGER(C_INT64_T) :: CURSOR, TAGS_END
    TYPE(MB2_TAG_HEADER_T), POINTER :: HDR
    INTEGER(C_INT32_T), POINTER :: TOTAL_SIZE_PTR
    INTEGER(C_INT64_T) :: PADDED_SIZE

    FOUND = .FALSE.
    TAG_ADDR = 0_C_INT64_T

    CALL C_F_POINTER(TRANSFER(INFO_ADDR, C_NULL_PTR), TOTAL_SIZE_PTR)
    TOTAL_SIZE = TOTAL_SIZE_PTR
    TAGS_END = INFO_ADDR + INT(TOTAL_SIZE, C_INT64_T)

    CURSOR = INFO_ADDR + 8_C_INT64_T

    DO WHILE (CURSOR < TAGS_END)
      CALL C_F_POINTER(TRANSFER(CURSOR, C_NULL_PTR), HDR)

      IF (HDR%TAG_TYPE == MB2_TAG_END) EXIT

      IF (HDR%TAG_TYPE == WANT_TYPE) THEN
        TAG_ADDR = CURSOR
        FOUND = .TRUE.
        RETURN
      END IF

      PADDED_SIZE = INT(HDR%TAG_SIZE, C_INT64_T)
      PADDED_SIZE = ISHFT(ISHFT(PADDED_SIZE + 7_C_INT64_T, -3), 3)
      CURSOR = CURSOR + PADDED_SIZE
    END DO
  END FUNCTION MB2_FIND_TAG

END MODULE MULTIBOOT2
