! interrupts.f90 -- exception dispatch and handlers.
!
! INTERRUPT_FRAME_T's field layout is independently byte-offset-probed
! (RING0-BRIDGE-SPEC.md section 1's methodology, applied here directly
! rather than just referenced): confirmed via objdump on a linked
! probe this session that every field sits at an exact 8-byte-aligned
! offset with zero padding, matching isr_stubs.s's push order exactly
! (R15 at offset 0 through SS at offset 0xA8, total size 0xB0/176
! bytes for 22 fields). All fields are deliberately the same width
! (INTEGER(C_INT64_T)) specifically so this holds without needing the
! "build it from scalars in asm" workaround the GDTR/IDTR pointer
! shape required -- a uniform-width struct's offsets are always
! field_index * 8 by construction, needing no probe to predict, though
! this project probed it anyway rather than assuming the general
! argument generalizes to this specific struct without checking.
MODULE INTERRUPTS
  USE ISO_C_BINDING
  USE RING0
  USE SERIAL
  IMPLICIT NONE

  TYPE, BIND(C) :: INTERRUPT_FRAME_T
    INTEGER(C_INT64_T) :: R15, R14, R13, R12, R11, R10, R9, R8
    INTEGER(C_INT64_T) :: RDI, RSI, RBP, RBX, RDX, RCX, RAX
    INTEGER(C_INT64_T) :: VECTOR, ERROR_CODE
    INTEGER(C_INT64_T) :: RIP, CS, RFLAGS, RSP, SS
  END TYPE INTERRUPT_FRAME_T

  ! Vectors this project has a specific human-readable name for.
  ! Anything else prints as a bare number -- not every one of the 32
  ! CPU-reserved vectors needs a distinct message to be useful; a
  ! generic "unhandled exception N" is enough until a specific vector
  ! turns out to matter (e.g. this project hits it during real
  ! development and the generic message isn't informative enough),
  ! per this document's general add-only-when-needed instinct applied
  ! to messages, not just primitives.
  INTEGER, PARAMETER :: VEC_DIVIDE_ERROR = 0
  INTEGER, PARAMETER :: VEC_DEBUG = 1
  INTEGER, PARAMETER :: VEC_NMI = 2
  INTEGER, PARAMETER :: VEC_BREAKPOINT = 3
  INTEGER, PARAMETER :: VEC_OVERFLOW = 4
  INTEGER, PARAMETER :: VEC_BOUND_RANGE = 5
  INTEGER, PARAMETER :: VEC_INVALID_OPCODE = 6
  INTEGER, PARAMETER :: VEC_DEVICE_NOT_AVAILABLE = 7
  INTEGER, PARAMETER :: VEC_DOUBLE_FAULT = 8
  INTEGER, PARAMETER :: VEC_INVALID_TSS = 10
  INTEGER, PARAMETER :: VEC_SEGMENT_NOT_PRESENT = 11
  INTEGER, PARAMETER :: VEC_STACK_SEGMENT_FAULT = 12
  INTEGER, PARAMETER :: VEC_GENERAL_PROTECTION = 13
  INTEGER, PARAMETER :: VEC_PAGE_FAULT = 14
  INTEGER, PARAMETER :: VEC_FPU_ERROR = 16
  INTEGER, PARAMETER :: VEC_ALIGNMENT_CHECK = 17
  INTEGER, PARAMETER :: VEC_MACHINE_CHECK = 18
  INTEGER, PARAMETER :: VEC_SIMD_FP = 19

  ! IRQ_HANDLER_T -- procedure interface every registered IRQ handler
  ! must match: takes the IRQ number (0-15, already translated back
  ! from the vector number so handler code never needs to know about
  ! PIC.F90's +32 remap offset), no return value. A PROCEDURE POINTER
  ! array indexed by IRQ number, rather than a SELECT CASE naming
  ! specific handler subroutines directly in FORT0K_DISPATCH, so a new
  ! IRQ handler can be added (timer.f90, keyboard.f90, ...) without
  ! editing this file at all -- each driver module registers itself
  ! via IRQ_REGISTER_HANDLER during kernel_main's boot sequence,
  ! keeping this module ignorant of which specific drivers exist,
  ! matching this project's general preference for one module not
  ! needing to know another's internals to cooperate with it.
  ABSTRACT INTERFACE
    SUBROUTINE IRQ_HANDLER_T(IRQ)
      INTEGER, INTENT(IN) :: IRQ
    END SUBROUTINE IRQ_HANDLER_T
  END INTERFACE

  ! Fortran does not allow a bare array of PROCEDURE POINTERs
  ! (PROCEDURE(X), POINTER :: ARR(N) is a syntax error, confirmed via
  ! a direct probe this session) -- the standard workaround, used
  ! here, is a one-component derived type wrapping a single procedure
  ! pointer, then an array OF that type.
  TYPE :: IRQ_HANDLER_SLOT_T
    PROCEDURE(IRQ_HANDLER_T), POINTER, NOPASS :: P => NULL()
  END TYPE IRQ_HANDLER_SLOT_T

  TYPE(IRQ_HANDLER_SLOT_T) :: IRQ_HANDLERS(16)

  ! SCHED_PREEMPT_HOOK -- a procedure pointer FORT0K_DISPATCH calls,
  ! WITH THE RAW INTERRUPT FRAME ADDRESS, specifically and only on the
  ! timer IRQ (vector 32, IRQ 0) -- kept entirely separate from the
  ! generic IRQ_HANDLERS(IRQ)%P interface every other IRQ handler
  ! (TIMER_IRQ_HANDLER's own tick-counting, KEYBOARD_IRQ_HANDLER)
  ! already uses and relies on staying simple (IRQ number only, no
  ! frame access, no scheduling side effects). Registered by sched.f90
  ! once preemption is set up (SCHED_ENABLE_PREEMPTION), left
  ! unassociated (NULL) otherwise -- FORT0K_DISPATCH checks
  ! ASSOCIATED before calling it, so this project's interrupt path
  ! works identically to every prior stage until a caller specifically
  ! opts into preemption, not merely until sched.f90 happens to be
  ! linked in.
  ABSTRACT INTERFACE
    SUBROUTINE PREEMPT_HOOK_T(FRAME_ADDR)
      IMPORT :: C_INT64_T
      INTEGER(C_INT64_T), INTENT(IN), VALUE :: FRAME_ADDR
    END SUBROUTINE PREEMPT_HOOK_T
  END INTERFACE
  PROCEDURE(PREEMPT_HOOK_T), POINTER :: SCHED_PREEMPT_HOOK => NULL()

  ! SYSCALL_EXIT_HOOK -- procedure pointer, NULL by default, set by
  ! sched.f90/kernel_main.f90 to SCHED_EXIT_TASK's core-0 wrapper
  ! (this module cannot call SCHED_EXIT_TASK directly -- it would
  ! create a circular module dependency, sched.f90 already USEs
  ! INTERRUPTS for SCHED_PREEMPT_HOOK). Same hook-pointer pattern as
  ! SCHED_PREEMPT_HOOK above, for the same reason.
  ABSTRACT INTERFACE
    SUBROUTINE EXIT_HOOK_T()
    END SUBROUTINE EXIT_HOOK_T
  END INTERFACE
  PROCEDURE(EXIT_HOOK_T), POINTER :: SYSCALL_EXIT_HOOK => NULL()

  ! SYSCALL_YIELD_HOOK -- procedure pointer, NULL by default, set by
  ! sched.f90 to a wrapper around SCHED_YIELD's own frame-rewrite
  ! logic. Reuses PREEMPT_HOOK_T's interface shape (a single
  ! FRAME_ADDR argument) since both this and SCHED_PREEMPT_HOOK
  ! ultimately need to rewrite the same interrupt frame the same way
  ! -- see SYSCALL_DISPATCH's own comment on SYS_YIELD for why this is
  ! a separate hook rather than reusing SCHED_PREEMPT_HOOK directly.
  PROCEDURE(PREEMPT_HOOK_T), POINTER :: SYSCALL_YIELD_HOOK => NULL()

CONTAINS

  ! IRQ_REGISTER_HANDLER(IRQ, HANDLER) -- called once per IRQ line by
  ! whichever driver module owns that line (timer.f90 registers IRQ 0,
  ! keyboard.f90 registers IRQ 1, ...). Does NOT unmask the line at
  ! the PIC -- that stays a separate, explicit PIC_SET_MASK call in
  ! kernel_main.f90's boot sequence, so "a handler exists" and "the
  ! line is live" remain two independently visible facts rather than
  ! one call silently implying the other.
  SUBROUTINE IRQ_REGISTER_HANDLER(IRQ, HANDLER)
    INTEGER, INTENT(IN) :: IRQ
    PROCEDURE(IRQ_HANDLER_T) :: HANDLER
    IRQ_HANDLERS(IRQ + 1)%P => HANDLER
  END SUBROUTINE IRQ_REGISTER_HANDLER

  ! FORT0K_DISPATCH(FRAME_ADDR) -- called by isr_stubs.s's
  ! trampoline_common for every one of the 48 installed vectors
  ! (0-31: CPU exceptions; 32-47: hardware IRQs 0-15, after PIC.F90's
  ! remap), with FRAME_ADDR pointing at the INTERRUPT_FRAME_T-shaped
  ! block already sitting on the trampoline's stack.
  !
  ! CPU exceptions (vector < 32) remain fatal, unconditionally, as
  ! before -- no recovery path exists for any of them yet. Hardware
  ! IRQs (vector >= 32) are routed to whichever handler
  ! IRQ_REGISTER_HANDLER registered for that line, then PIC_SEND_EOI
  ! is called, then this routine RETURNS (via trampoline_common's
  ! normal register-restore-and-iretq path) rather than halting --
  ! the whole point of a working IRQ path is that the interrupted code
  ! resumes afterward, unlike the CPU-exception case.
  SUBROUTINE FORT0K_DISPATCH(FRAME_ADDR) BIND(C, NAME="fort0k_dispatch")
    INTEGER(C_INT64_T), INTENT(IN), VALUE :: FRAME_ADDR
    TYPE(INTERRUPT_FRAME_T), POINTER :: F
    INTEGER :: VEC, IRQ

    CALL C_F_POINTER(TRANSFER(FRAME_ADDR, C_NULL_PTR), F)
    VEC = INT(F%VECTOR)

    IF (VEC < 32) THEN
      CALL REPORT_EXCEPTION(F)
      ! No recovery path exists yet for any exception (no page-fault
      ! demand paging, no instruction-emulation-and-retry, nothing) --
      ! every vector is fatal at this stage. Halting here rather than
      ! returning via iretq is deliberate: returning would resume
      ! whatever faulted, which for most of these vectors means
      ! immediately faulting again in a tight loop. A real kernel
      ! eventually wants SOME vectors to be recoverable (page fault,
      ! certainly); this project adds that per-vector once there is a
      ! concrete reason to, not speculatively.
      CALL FORT0K_CLI()
      DO
        CALL FORT0K_HLT()
      END DO
    ELSE IF (VEC == 48) THEN
      ! Syscall gate -- see idt.f90's IDT_GATE_INT_R3 comment for why
      ! this is the only vector reachable via `int` from ring 3.
      ! Minimal convention (this project's own, not modeled on any
      ! specific real OS's ABI, since there is no external program
      ! this needs to be compatible with yet): syscall number in RAX,
      ! one argument in RDI, return value written back into F%RAX
      ! (NOT the live %rax register -- trampoline_common's iretq path
      ! restores every GP register FROM THE FRAME, so writing the
      ! return value into F%RAX here is what the ring-3 caller
      ! actually observes in its own %rax after the int instruction
      ! returns; writing to a local Fortran variable named RAX would
      ! not reach the caller at all).
      CALL SYSCALL_DISPATCH(F, FRAME_ADDR)
    ELSE
      IRQ = VEC - 32
      IF (IRQ >= 0 .AND. IRQ < 16) THEN
        IF (ASSOCIATED(IRQ_HANDLERS(IRQ + 1)%P)) THEN
          CALL IRQ_HANDLERS(IRQ + 1)%P(IRQ)
        END IF
        IF (IRQ == 0 .AND. ASSOCIATED(SCHED_PREEMPT_HOOK)) THEN
          ! Timer tick: give the scheduler a chance to rewrite the
          ! interrupt frame in place before this handler returns and
          ! trampoline_common's iretq resumes whatever RIP/RSP/RFLAGS
          ! the frame now holds -- possibly a DIFFERENT task than the
          ! one that was actually interrupted, which is the entire
          ! mechanism preemption is built on (see sched.f90's
          ! SCHED_PREEMPT_HOOK implementation for the actual rewrite
          ! logic and why this is safe: the frame's first 15 fields
          ! are laid out identically to TCB_REGS_T's first 15,
          ! byte-offset-confirmed, so no field-by-field translation
          ! is needed for those, only RIP/RSP/RFLAGS which live at
          ! different offsets between the two structs).
          CALL SCHED_PREEMPT_HOOK(FRAME_ADDR)
        END IF
        CALL PIC_SEND_EOI_LOCAL(IRQ)
      END IF
      ! Falls through and returns to trampoline_common, which restores
      ! registers and executes iretq -- resuming whatever was
      ! interrupted, exactly the behavior a working IRQ path requires
      ! and a CPU exception's fatal path deliberately does not take.
    END IF
  END SUBROUTINE FORT0K_DISPATCH

  ! SYSCALL_DISPATCH(F) -- the actual (tiny, real, not a stub) syscall
  ! table. Two syscalls exist today: 1 (WRITE_CHAR -- print the
  ! low byte of RDI as one character to serial, proving a ring-3
  ! program can genuinely get output to the outside world through
  ! this mechanism, not merely execute silently) and 2 (EXIT --
  ! calls into the scheduler's real exit path, SCHED_EXIT_TASK, proving
  ! a ring-3 program can genuinely terminate itself through this
  ! mechanism too). Anything else in RAX sets F%RAX to -1 (an
  ! otherwise-impossible syscall return value for either of the two
  ! real syscalls, both of which return 0 on success) and does
  ! nothing else -- an unrecognized syscall number is not fatal, a
  ! deliberate choice distinct from this project's exception-handling
  ! policy (every CPU exception is fatal, per FORT0K_DISPATCH's own
  ! comment) since an unrecognized syscall is a user-mode PROGRAM
  ! error, not a kernel-integrity concern, and killing the whole
  ! machine over it would be a disproportionate response this project
  ! is not willing to accept even at this early, minimal stage.
  SUBROUTINE SYSCALL_DISPATCH(F, FRAME_ADDR)
    TYPE(INTERRUPT_FRAME_T), POINTER, INTENT(IN) :: F
    INTEGER(C_INT64_T), INTENT(IN) :: FRAME_ADDR
    INTEGER(C_INT64_T), PARAMETER :: SYS_WRITE_CHAR = 1_C_INT64_T
    INTEGER(C_INT64_T), PARAMETER :: SYS_EXIT = 2_C_INT64_T
    INTEGER(C_INT64_T), PARAMETER :: SYS_YIELD = 3_C_INT64_T

    IF (F%RAX == SYS_WRITE_CHAR) THEN
      CALL SYSCALL_WRITE_CHAR(F%RDI)
      F%RAX = 0_C_INT64_T
    ELSE IF (F%RAX == SYS_EXIT) THEN
      IF (ASSOCIATED(SYSCALL_EXIT_HOOK)) THEN
        CALL SYSCALL_EXIT_HOOK()
      END IF
      ! Does not return in practice -- SYSCALL_EXIT_HOOK, once
      ! registered (sched.f90's own SCHED_EXIT_TASK, via a procedure-
      ! pointer hook matching this project's established pattern for
      ! avoiding a interrupts.f90 -> sched.f90 compile-time dependency,
      ! same shape as SCHED_PREEMPT_HOOK above), switches away from
      ! the calling task entirely -- trampoline_common's own iretq
      ! never executes for THIS particular interrupt occurrence, since
      ! control does not return here to fall through to it. If the
      ! hook is not registered (should not happen once user-mode
      ! testing is wired up, but not assumed), this falls through
      ! harmlessly and F%RAX is set below, same as any other case.
      F%RAX = 0_C_INT64_T
    ELSE IF (F%RAX == SYS_YIELD) THEN
      ! SYS_YIELD: lets a ring-3 task cooperatively yield -- a real,
      ! necessary addition this session, since ring-3 code has NO
      ! legal way to call SCHED_YIELD directly (that is ordinary,
      ! ring-0-only Fortran code; the syscall gate is the only door
      ! back into the kernel at all). Uses SYSCALL_YIELD_HOOK, NOT
      ! SCHED_PREEMPT_HOOK -- deliberately a separate hook, even
      ! though both ultimately rewrite the SAME interrupt frame using
      ! the same underlying mechanism (SCHED_PREEMPT_TICK's approach,
      ! reused here rather than duplicated) -- because a VOLUNTARY
      ! yield (this) and an INVOLUNTARY preemption (the timer) are
      ! genuinely different events a future scheduling policy might
      ! want to treat differently (e.g. NOT counting a voluntary yield
      ! against a task's fair-share timer the same way an interrupted
      ! task would be), even though today's implementation happens to
      ! call the identical underlying rewrite logic for both.
      IF (ASSOCIATED(SYSCALL_YIELD_HOOK)) THEN
        CALL SYSCALL_YIELD_HOOK(FRAME_ADDR)
      END IF
      F%RAX = 0_C_INT64_T
    ELSE
      F%RAX = -1_C_INT64_T
    END IF
  END SUBROUTINE SYSCALL_DISPATCH

  ! SYSCALL_WRITE_CHAR(CH) -- writes the low byte of CH to serial.
  ! Deliberately does NOT go through SERIAL_PUTS_NL (this codebase's
  ! usual logging entry point) -- that function adds a lock, a CRLF,
  ! and expects a whole message buffer, none of which fits "print one
  ! raw character a ring-3 program handed the kernel." Calls
  ! SERIAL_PUTC directly instead, the lower-level primitive
  ! SERIAL_PUTS_NL itself is built on.
  SUBROUTINE SYSCALL_WRITE_CHAR(CH)
    INTEGER(C_INT64_T), INTENT(IN) :: CH
    CALL SERIAL_PUTC(INT(IAND(CH, INT(Z'FF', C_INT64_T)), C_INT8_T))
  END SUBROUTINE SYSCALL_WRITE_CHAR

  ! PIC_SEND_EOI_LOCAL(IRQ) -- thin wrapper so this module does not
  ! need a direct USE PIC dependency at module scope (would create a
  ! circular concern: PIC.F90 doesn't need INTERRUPTS, but keeping the
  ! dependency one-directional and explicit here, via an interface
  ! declared right where it's used, is cheap and documents exactly
  ! how small the actual coupling is -- one function call, not a
  ! broad module dependency).
  SUBROUTINE PIC_SEND_EOI_LOCAL(IRQ)
    INTEGER, INTENT(IN) :: IRQ
    INTERFACE
      SUBROUTINE PIC_SEND_EOI(IRQ_C) BIND(C, NAME="pic_send_eoi")
        USE ISO_C_BINDING
        INTEGER(C_INT32_T), INTENT(IN), VALUE :: IRQ_C
      END SUBROUTINE PIC_SEND_EOI
    END INTERFACE
    CALL PIC_SEND_EOI(INT(IRQ, C_INT32_T))
  END SUBROUTINE PIC_SEND_EOI_LOCAL

  SUBROUTINE REPORT_EXCEPTION(F)
    TYPE(INTERRUPT_FRAME_T), INTENT(IN) :: F
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    INTEGER :: N

    CALL SAY_LIT("")
    CALL SAY_LIT("*** fort0-kernel: unhandled exception ***")

    N = 0
    CALL APPEND_LIT(BUF, N, "vector: ")
    CALL APPEND_HEX(BUF, N, F%VECTOR)
    CALL APPEND_LIT(BUF, N, "  (")
    CALL APPEND_LIT(BUF, N, VECTOR_NAME(INT(F%VECTOR)))
    CALL APPEND_LIT(BUF, N, ")")
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))

    N = 0
    CALL APPEND_LIT(BUF, N, "error code: ")
    CALL APPEND_HEX(BUF, N, F%ERROR_CODE)
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))

    N = 0
    CALL APPEND_LIT(BUF, N, "rip: ")
    CALL APPEND_HEX(BUF, N, F%RIP)
    CALL APPEND_LIT(BUF, N, "  cs: ")
    CALL APPEND_HEX(BUF, N, F%CS)
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))

    N = 0
    CALL APPEND_LIT(BUF, N, "rsp: ")
    CALL APPEND_HEX(BUF, N, F%RSP)
    CALL APPEND_LIT(BUF, N, "  rflags: ")
    CALL APPEND_HEX(BUF, N, F%RFLAGS)
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))

    IF (INT(F%VECTOR) == VEC_PAGE_FAULT) THEN
      N = 0
      CALL APPEND_LIT(BUF, N, "cr2 (fault address): ")
      CALL APPEND_HEX(BUF, N, FORT0K_READ_CR2())
      CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
    END IF

    CALL SAY_LIT("system halted.")
  END SUBROUTINE REPORT_EXCEPTION

  FUNCTION VECTOR_NAME(V) RESULT(NAME)
    INTEGER, INTENT(IN) :: V
    CHARACTER(LEN=24) :: NAME
    SELECT CASE (V)
      CASE (VEC_DIVIDE_ERROR);          NAME = "divide error            "
      CASE (VEC_DEBUG);                 NAME = "debug                   "
      CASE (VEC_NMI);                   NAME = "nmi                     "
      CASE (VEC_BREAKPOINT);            NAME = "breakpoint              "
      CASE (VEC_OVERFLOW);              NAME = "overflow                "
      CASE (VEC_BOUND_RANGE);           NAME = "bound range exceeded    "
      CASE (VEC_INVALID_OPCODE);        NAME = "invalid opcode          "
      CASE (VEC_DEVICE_NOT_AVAILABLE);  NAME = "device not available    "
      CASE (VEC_DOUBLE_FAULT);          NAME = "double fault            "
      CASE (VEC_INVALID_TSS);           NAME = "invalid tss             "
      CASE (VEC_SEGMENT_NOT_PRESENT);   NAME = "segment not present     "
      CASE (VEC_STACK_SEGMENT_FAULT);   NAME = "stack segment fault     "
      CASE (VEC_GENERAL_PROTECTION);    NAME = "general protection fault"
      CASE (VEC_PAGE_FAULT);            NAME = "page fault              "
      CASE (VEC_FPU_ERROR);             NAME = "x87 fpu error           "
      CASE (VEC_ALIGNMENT_CHECK);       NAME = "alignment check         "
      CASE (VEC_MACHINE_CHECK);         NAME = "machine check           "
      CASE (VEC_SIMD_FP);               NAME = "simd fp exception       "
      CASE DEFAULT;                     NAME = "unnamed                 "
    END SELECT
  END FUNCTION VECTOR_NAME

  ! SAY_LIT(MSG) -- fixed-max-length checkpoint print, same pattern
  ! (and same reason: RING0-BRIDGE-SPEC.md section 1's automatic-array
  ! malloc/free finding) as kernel_main.f90's SAY.
  SUBROUTINE SAY_LIT(MSG)
    CHARACTER(LEN=*), INTENT(IN) :: MSG
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    INTEGER :: N
    N = LEN(MSG)
    IF (N > 80) N = 80
    CALL FILL_STR_N(BUF, MSG, N)
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SAY_LIT

  SUBROUTINE FILL_STR_N(DEST, S, N)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(OUT) :: DEST(:)
    CHARACTER(LEN=*), INTENT(IN) :: S
    INTEGER, INTENT(IN) :: N
    INTEGER :: I
    DO I = 1, N
      DEST(I) = S(I:I)
    END DO
  END SUBROUTINE FILL_STR_N

  ! APPEND_LIT(BUF, N, S) -- appends S to BUF starting at position
  ! N+1, advancing N. No bounds checking against BUF's fixed 80-byte
  ! size -- every call site in this file uses short fixed literals or
  ! VECTOR_NAME's fixed-24-char result, well within budget; revisit if
  ! a future call site's total length isn't obviously safe by
  ! inspection.
  SUBROUTINE APPEND_LIT(BUF, N, S)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    CHARACTER(LEN=*), INTENT(IN) :: S
    INTEGER :: I
    DO I = 1, LEN(S)
      N = N + 1
      BUF(N) = S(I:I)
    END DO
  END SUBROUTINE APPEND_LIT

  ! APPEND_HEX(BUF, N, VAL) -- appends VAL as "0x" followed by 16 hex
  ! digits (fixed width, zero-padded -- a fixed-width field is easier
  ! to eyeball-align across several printed lines than a variable-
  ! width one, and this project has no TRIM available to shorten it
  ! safely per CALL-BRIDGE-SPEC.md section 4 regardless).
  SUBROUTINE APPEND_HEX(BUF, N, VAL)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    INTEGER(C_INT64_T), INTENT(IN) :: VAL
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: I, SHIFT_AMT
    INTEGER(C_INT64_T) :: NIBBLE

    N = N + 1
    BUF(N) = '0'
    N = N + 1
    BUF(N) = 'x'
    DO I = 15, 0, -1
      SHIFT_AMT = I * 4
      NIBBLE = IAND(ISHFT(VAL, -SHIFT_AMT), INT(Z'F', C_INT64_T))
      N = N + 1
      BUF(N) = HEXDIGITS(INT(NIBBLE) + 1 : INT(NIBBLE) + 1)
    END DO
  END SUBROUTINE APPEND_HEX

END MODULE INTERRUPTS
