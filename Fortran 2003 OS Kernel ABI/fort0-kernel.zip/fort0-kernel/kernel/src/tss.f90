! tss.f90 -- the 64-bit Task State Segment. Required in long mode
! even though x86-64 has no hardware task-switching (confirmed via
! web search this session, AMD/Intel manual: "the operating system
! must create at least one 64-bit TSS after activating IA-32e mode...
! must execute the LTR instruction") -- its role in long mode is
! narrower than its 32-bit ancestor's: it exists to tell the CPU
! which stack to switch to (RSP0) whenever a privilege-level change
! happens on an interrupt/exception/syscall, most critically the
! very first real-world case this project has: a ring-3 program
! triggers a timer IRQ or the syscall gate, and the CPU needs
! somewhere to push the interrupt frame OTHER than the ring-3
! program's own (untrusted, possibly-too-small, possibly-invalid)
! user stack.
!
! FIELD LAYOUT, NOT A NAIVE BIND(C) DERIVED TYPE: a direct byte-offset
! probe this session (before writing any of this file) found that a
! straightforward BIND(C) type with a 4-byte RESERVED0 field followed
! by 8-byte RSP0/RSP1/... fields gets 4 bytes of Fortran-inserted
! alignment padding before RSP0, breaking the CPU's REQUIRED fixed
! byte layout (Osdev-Notes/AMD APM: RESERVED0@0, RSP0@4, exactly, no
! padding) -- the same class of GDTR/IDTR packing landmine RING0-
! BRIDGE-SPEC.md section 6 already documented, re-confirmed here for
! this new structure rather than assumed to still hold. Fixed the
! same way this project's other hardware-packed structures are built
! when BIND(C) cannot express the required layout directly: a flat,
! fixed-size byte array, written at explicit, hand-verified offsets
! via a small subroutine, not a derived type at all.
MODULE TSS
  USE ISO_C_BINDING
  USE RING0
  IMPLICIT NONE

  INTEGER, PARAMETER :: TSS_SIZE = 104   ! confirmed structure size,
                                           ! Osdev-Notes/AMD APM: 0x68
  INTEGER(C_INT8_T), TARGET :: TSS_TABLE(TSS_SIZE)
  BIND(C, NAME="tss_table") :: TSS_TABLE

CONTAINS

  ! TSS_SET_RSP0(RSP0_VALUE) -- writes RSP0_VALUE at byte offset 4
  ! within TSS_TABLE, the CONFIRMED (AMD APM Figure 7-11; Osdev-Notes'
  ! packed C struct, cross-checked against each other, not a single
  ! uncorroborated source) offset of the TSS's RSP0 field -- the
  ! stack pointer the CPU loads whenever a privilege-level change
  ! from ring >0 to ring 0 happens on interrupt/exception/syscall
  ! entry. Writes 8 bytes, one at a time, via IBITS/MVBITS-free
  ! explicit shifting (ISHFT+IAND), matching this project's general
  ! preference for explicit bit/byte construction over relying on
  ! any Fortran storage-association trick for a hardware-mandated
  ! exact layout.
  SUBROUTINE TSS_SET_RSP0(RSP0_VALUE)
    INTEGER(C_INT64_T), INTENT(IN) :: RSP0_VALUE
    INTEGER :: I
    DO I = 0, 7
      TSS_TABLE(4 + I + 1) = INT(IAND(ISHFT(RSP0_VALUE, -8*I), INT(Z'FF', C_INT64_T)), C_INT8_T)
    END DO
    ! +1: Fortran 1-based array indexing; byte offset 4 within the
    ! TSS is array index 5 (TSS_TABLE(4+0+1) through TSS_TABLE(4+7+1)
    ! for the 8 bytes of RSP0).
  END SUBROUTINE TSS_SET_RSP0

  ! TSS_INSTALL(RSP0_VALUE) -- zeroes the whole TSS (every reserved
  ! field must be zero per the AMD APM), sets RSP0 (the only field
  ! this project's current, minimal use of the TSS actually needs --
  ! RSP1/RSP2/every IST slot are legitimately left at their zeroed,
  ! unused state, matching this project's add-only-when-needed rule:
  ! IST-based stack switching for specific vectors is real future
  ! work, not needed for this stage's single-ring-3-task test), then
  ! loads the TSS descriptor's selector via LTR. The GDT entry the
  ! selector refers to (a 16-byte TSS descriptor, not an 8-byte
  ! ordinary segment descriptor -- long mode's TSS descriptors are
  ! wider specifically to hold a full 64-bit base address) is built
  ! by gdt.f90, which owns GDT_TABLE and therefore the TSS
  ! descriptor's own construction -- this subroutine only performs
  ! LTR, using the selector gdt.f90 defines (TSS_SEL), not USE'd
  ! directly to avoid a circular module dependency for one constant,
  ! matching this project's existing KERNEL_CODE_SEL cross-file
  ! convention (idt.f90's own comment on that same pattern).
  SUBROUTINE TSS_INSTALL(RSP0_VALUE) BIND(C, NAME="tss_install")
    INTEGER(C_INT64_T), INTENT(IN), VALUE :: RSP0_VALUE
    INTEGER :: I
    DO I = 1, TSS_SIZE
      TSS_TABLE(I) = 0_C_INT8_T
    END DO
    CALL TSS_SET_RSP0(RSP0_VALUE)

    ! BUG FOUND AND FIXED THIS SESSION: this call originally produced
    ! incorrect generated code (the selector's address was loaded into
    ! %rdi instead of its value, confirmed via direct disassembly of
    ! the linked kernel binary, and confirmed to cause a real #GP
    ! fault on LTR the first time this ran) -- ROOT CAUSE, found after
    ! initially misdiagnosing this as a compiler defect and trying two
    ! separate workarounds that did NOT fix it (an intermediate local
    ! variable; isolating the call into its own subroutine, still
    ! present below as TSS_LOAD_SELECTOR though no longer strictly
    ! required) -- this file was simply missing `USE RING0`. With no
    ! explicit interface for FORT0K_LTR visible in this module's
    ! scope, gfortran had no way to know that dummy argument carries
    ! the VALUE attribute, and fell back to its default BY-REFERENCE
    ! convention -- passing the address of a compiler-generated
    ! temporary holding the constant, not the constant itself. This is
    ! exactly the calling-convention mismatch class RING0-BRIDGE-
    ! SPEC.md's whole engineering discipline exists to prevent, missed
    ! here simply because this new file never added the USE RING0
    ! dependency its calls into ring0_mod.f90's primitives require.
    ! Confirmed fixed via direct disassembly (correct `movl $40, %edi`
    ! now appears) once USE RING0 was added to this module's header.
    CALL FORT0K_LTR(INT(Z'0028', C_INT16_T))
    ! 0x0028 = 5*8: the 6th GDT slot (1-based: null, kernel code,
    ! kernel data, user code, user data, TSS -- gdt.f90's
    ! GDT_NUM_ENTRIES extended to accommodate it, see that file).
    ! Not USE'd from GDT directly -- see subroutine header comment.
  END SUBROUTINE TSS_INSTALL

END MODULE TSS
