# isr_stubs.s -- one entry trampoline per IDT vector (0-31, CPU
# exception vectors only at this stage; hardware IRQ vectors are a
# later stage's concern per RING0-BRIDGE-SPEC.md's add-only-when-
# needed rule).
#
# WHY A TRAMPOLINE IS REQUIRED, NOT OPTIONAL: RING0-BRIDGE-SPEC.md
# section 2 resolved this project's open question about whether a
# bare Fortran BIND(C) SUBROUTINE could be a direct interrupt target
# -- gfortran's own prologue makes no assumption about what is below
# %rsp on entry, so Fortran itself imposes no obstacle, BUT: (1) the
# CPU does not save the general-purpose registers a Fortran handler
# body will clobber (only RIP/CS/RFLAGS/RSP/SS, plus an error code for
# some vectors) -- something has to save/restore those, and Fortran
# has no `iretq` intrinsic to return from an interrupt with regardless.
# A trampoline is the only place either of those can live.
#
# STACK LAYOUT NORMALIZATION: the CPU pushes a 32-bit-wide error code
# for exactly these vectors: 8, 10, 11, 12, 13, 14, 17, 21, 29, 30 (per
# the Intel SDM's per-exception definition) and none of the others.
# Every stub below pushes a dummy 0 error code for vectors that don't
# get a real one, so the common trampoline body and the Fortran-side
# frame struct can assume a single, uniform stack shape regardless of
# which vector fired -- never branch on vector number to decide
# whether to read an error code, which would be a real landmine
# (reading one stack slot too many/few depending on vector) worth
# avoiding entirely by construction instead of getting right by care.
#
# FRAME PASSED TO FORTRAN: a pointer to an INTERRUPT_FRAME_T-shaped
# (interrupts.f90) block of eight-byte values, ALL 8-BYTES-WIDE
# DELIBERATELY -- RING0-BRIDGE-SPEC.md's GDTR/IDTR padding finding is
# exactly why this project does not mix field widths in any structure
# crossing the asm/Fortran boundary going forward unless a byte-offset
# probe has specifically confirmed the mixed-width shape is safe (as
# IDT_ENTRY_T was) -- an all-uniform-width struct sidesteps the
# question by construction, the safer default absent a specific reason
# to do otherwise.
#
# Field order in the frame, LOWEST address first (i.e. in the order
# %rsp sees them once trampoline_common finishes pushing, which is the
# reverse of push order since push moves %rsp downward): r15, r14,
# r13, r12, r11, r10, r9, r8, rdi, rsi, rbp, rbx, rdx, rcx, rax, then
# (pushed earliest, so highest address / last in this list) vector,
# error_code, then the CPU-pushed rip, cs, rflags, rsp, ss.
# interrupts.f90's INTERRUPT_FRAME_T field order is defined to match
# this exactly -- re-verify both files agree if either changes.

    .text

# One stub per vector: pushes a dummy error code (only for vectors
# that don't get a real one from the CPU) and the vector number, then
# falls into the shared trampoline body. Built via .altmacro repeat
# rather than 32 hand-written near-duplicate blocks, specifically to
# make the "which vectors get a real CPU error code" list a single
# source of truth (the .if inside the macro) instead of 32 places that
# could individually drift out of sync with the Intel SDM's list.
.altmacro
.macro isr_stub vector
    .globl fort0k_isr\vector
    .type fort0k_isr\vector, @function
fort0k_isr\vector:
    .if \vector == 8 || \vector == 10 || \vector == 11 || \vector == 12 || \vector == 13 || \vector == 14 || \vector == 17 || \vector == 21 || \vector == 29 || \vector == 30
        # CPU already pushed a real error code -- nothing to add.
    .else
        pushq $0
    .endif
    pushq $\vector
    jmp trampoline_common
    .size fort0k_isr\vector, .-fort0k_isr\vector
.endm

.set i, 0
.rept 32
    isr_stub %i
    .set i, i+1
.endr

# Vectors 32-47: hardware IRQs 0-15, AFTER the PIC remap this stage
# performs (pic.f90) -- none of these get a real CPU-pushed error code
# (only CPU exceptions do), so every one of these stubs pushes the
# dummy 0 exactly like isr_stub's .else branch above. Built as their
# own small macro rather than extending isr_stub's vector range,
# because "which vectors get a real error code" is a CPU-exception-
# specific concept (Intel SDM) that does not apply to IRQ vectors at
# all -- reusing isr_stub here would mean its .if condition needs to
# also reason about IRQ vectors it structurally cannot ever match,
# muddying what that condition means for a future reader.
.macro irq_stub vector
    .globl fort0k_isr\vector
    .type fort0k_isr\vector, @function
fort0k_isr\vector:
    pushq $0
    pushq $\vector
    jmp trampoline_common
    .size fort0k_isr\vector, .-fort0k_isr\vector
.endm

.set i, 32
.rept 16
    irq_stub %i
    .set i, i+1
.endr

# Vector 48: the syscall gate. Built identically to an IRQ stub
# (dummy error code, no real one from the CPU -- software interrupts
# never get one) -- the only thing that makes this vector different
# is its IDT gate's DPL (idt.f90's IDT_GATE_INT_R3, DPL=3, distinct
# from every other vector's IDT_GATE_INT_R0/DPL=0), which is a
# Fortran-side-only concern (idt.f90's IDT_SET_GATE call site for this
# vector) -- this trampoline itself needs no special handling to be
# callable from ring 3; the CPU's own privilege check on `int $48`
# happens entirely against the GATE's DPL before this code ever runs.
    .globl fort0k_isr48
    .type fort0k_isr48, @function
fort0k_isr48:
    pushq $0
    pushq $48
    jmp trampoline_common
    .size fort0k_isr48, .-fort0k_isr48

# fort0k_isr_addr(vector) -- returns the address of vector VECTOR's
# trampoline as a value, so idt.f90 can build IDT gates without this
# file needing to know anything about IDT_ENTRY_T's layout (kept
# entirely on the Fortran side, per this project's general separation
# of "asm knows registers/instructions" from "Fortran knows data
# layout" wherever the two can be kept apart). A jump table indexed by
# vector number, built the same .altmacro way as the stubs above so
# it can't drift out of sync with them.
    .section .rodata
    .align 8
isr_addr_table:
.macro isr_addr_entry vector
    .quad fort0k_isr\vector
.endm
.set i, 0
.rept 49
    isr_addr_entry %i
    .set i, i+1
.endr

    .text
    .globl fort0k_isr_addr
    .type fort0k_isr_addr, @function
fort0k_isr_addr:
    # vector arrives in %edi (VALUE, BIND(C) INTEGER(C_INT32_T)).
    mov %edi, %eax
    lea isr_addr_table(%rip), %rcx
    mov (%rcx, %rax, 8), %rax
    ret
    .size fort0k_isr_addr, .-fort0k_isr_addr

# trampoline_common -- entered by every isr_stub above with
# [rsp]=vector, [rsp+8]=error_code, [rsp+16..]=CPU-pushed frame
# (rip, cs, rflags, rsp, ss). Saves general-purpose registers, which
# leaves the stack in exactly the INTERRUPT_FRAME_T shape described in
# this file's header comment, with %rsp pointing at its start -- no
# separate copy step needed, the pushed frame IS the struct. Calls the
# single Fortran dispatcher with a pointer to it, then reverses
# everything and iretq's.
    .type trampoline_common, @function
trampoline_common:
    push %rax
    push %rcx
    push %rdx
    push %rbx
    push %rbp
    push %rsi
    push %rdi
    push %r8
    push %r9
    push %r10
    push %r11
    push %r12
    push %r13
    push %r14
    push %r15

    mov %rsp, %rdi          # frame pointer, sole arg to the Fortran
                             # dispatcher, BIND(C) VALUE convention
                             # (RING0-BRIDGE-SPEC.md section 6: plain
                             # SysV, arrives in %rdi already on the
                             # Fortran side, no dereference needed).
    call fort0k_dispatch

    pop %r15
    pop %r14
    pop %r13
    pop %r12
    pop %r11
    pop %r10
    pop %r9
    pop %r8
    pop %rdi
    pop %rsi
    pop %rbp
    pop %rbx
    pop %rdx
    pop %rcx
    pop %rax
    add $16, %rsp    # discard vector number and error code -- neither
                      # is part of the CPU's own iretq frame

    # RING0-BRIDGE-SPEC.md section 34's fix, this session. At this
    # point %rsp points at the 5-field CPU-defined iretq frame (RIP,
    # CS, RFLAGS, RSP, SS, in that ascending order). trampoline_common
    # itself ALWAYS executes at CPL=0 (kernel code, entered via a
    # KERNEL_CODE_SEL gate regardless of what privilege was
    # interrupted) -- confirmed via web search (multiple independent
    # sources, cross-referenced) that iretq's same-vs-interlevel
    # decision compares the FRAME'S CS RPL against the CPU'S CURRENT
    # CPL at the moment iretq itself executes, NOT against whatever
    # privilege was originally interrupted. This means: whenever the
    # frame's CS RPL is 0 (resuming a ring-0 task), iretq performs a
    # SAME-privilege return -- it pops ONLY RIP/CS/RFLAGS (3 qwords)
    # and completely IGNORES the frame's RSP/SS fields, leaving %rsp
    # wherever it lands after those 3 pops (i.e. still on THIS
    # trampoline's own entry stack, not switched anywhere). This was
    # always correct before ring 3 existed, because the frame's own
    # RSP was always already equal to "this same stack, 24 bytes
    # further up" in every case that existed then -- a scheduler
    # decision could rewrite RIP/RFLAGS in place but never needed a
    # genuinely different STACK for a ring-0 destination. That
    # assumption breaks the moment a ring-3-entered interrupt
    # (SYS_YIELD, or a future ring-3 preemption) hands off to a ring-0
    # task: that task's REAL stack is a completely different memory
    # region than the RSP0 kernel stack this entry is currently
    # running on, and iretq's same-privilege path will never switch to
    # it on its own.
    #
    # FIX (REDESIGNED this session after the original iretq-based
    # version, below in history/git terms but described here for
    # anyone reading this comment fresh, kept faulting for reasons
    # never fully pinned down despite every individual field checking
    # out correct): explicitly check the frame's CS RPL. If ring-0
    # (RPL=0), DO NOT USE IRETQ AT ALL for this case -- manually
    # switch %rsp to the destination task's own real stack (with the
    # SAME unconsumed-return-address-slot correction RING0-BRIDGE-
    # SPEC.md section 23 already established for the ordinary switch
    # path), then `jmp` DIRECTLY to the saved RIP, exactly like
    # sched_switch.s's already-proven, working fort0k_context_switch
    # mechanism. This sidesteps iretq's same-privilege return
    # semantics entirely rather than trying to satisfy them: iretq
    # exists specifically to handle PRIVILEGE CHANGES (ring 3 -> ring
    # 0 or vice versa) -- resuming a RING-0 task from RING-0 code is
    # not a privilege change at all, and has no architectural need
    # for iretq in the first place. The prior version of this fix
    # manually loaded SS and built a same-privilege iretq frame,
    # which repeatedly faulted despite CS/SS/RSP/RFLAGS/RIP all being
    # independently confirmed correct via direct memory dumps -- the
    # exact mechanism of that failure was never conclusively
    # identified even after extensive investigation (RING0-BRIDGE-
    # SPEC.md sections 35-37), and rather than continue chasing an
    # increasingly obscure iretq-specific question, this redesign
    # avoids the question entirely by reusing a mechanism already
    # proven correct for exactly this situation (resuming a ring-0
    # task) in every other context in this codebase. If ring-3
    # (RPL=3), do nothing extra -- the existing interlevel-return
    # iretq path already handles RSP/SS correctly, confirmed working
    # (RING0-BRIDGE-SPEC.md sections 31-33) -- that path is genuinely
    # different (it IS a real privilege change) and iretq is the
    # correct, in fact the ONLY legal, mechanism for it.
    #
    # %rax used as scratch here -- already popped to its real,
    # correct value above; using it again is safe because it is about
    # to be reloaded from the frame's own RIP field below regardless.
    movq 8(%rsp), %rax      # frame's CS field
    andq $3, %rax           # RPL bits
    cmpq $0, %rax
    jne 1f                   # RPL=3 (or, defensively, anything not
                              # exactly 0) -- leave the existing,
                              # already-correct interlevel path alone
    movq 24(%rsp), %rcx     # frame's saved RSP field
    movq (%rsp), %rax       # frame's saved RIP (need it before %rsp moves)
    movq %rcx, %rsp
    # BUG FOUND AND FIXED THIS SESSION (bug cleanse pass): the
    # destination task's saved RSP points AT an unconsumed return-
    # address slot (the same convention RING0-BRIDGE-SPEC.md section
    # 23 already established and fixed for the ORDINARY jmp-based
    # switch path in sched_switch.s -- a task's saved RSP is %rsp
    # exactly as it was at the point `call fort0k_context_switch` (or,
    # here, whatever switch mechanism last saved this task's state)
    # pushed a real return address, never consumed by anything since).
    # Fixed the same way section 23 fixed the identical class of bug:
    # advance %rsp by 8 (discarding the slot) before transferring
    # control, so the net effect on the destination stack is
    # indistinguishable from a real `ret` having consumed it.
    addq $8, %rsp
    jmp *%rax
1:
    iretq
    .size trampoline_common, .-trampoline_common

    .section .note.GNU-stack,"",@progbits

    # trampoline_fix_dump: 5 qwords (40 bytes) of dedicated, linker-
    # allocated .bss scratch space -- no longer used by the current
    # (redesigned, jmp-based) fix, but left declared since it cost
    # nothing to keep and remains directly useful if a future
    # diagnostic pass needs a guaranteed-real, guaranteed-unique
    # scratch location again (see RING0-BRIDGE-SPEC.md section 36 for
    # why a linker-allocated location matters here specifically).
    .section .bss
    .align 8
    .globl trampoline_fix_dump
trampoline_fix_dump:
    .skip 40
