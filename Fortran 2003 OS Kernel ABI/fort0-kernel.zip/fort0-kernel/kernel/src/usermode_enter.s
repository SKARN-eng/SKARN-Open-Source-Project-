# usermode_enter.s -- fort0k_enter_usermode(entry_addr, user_stack_top):
# the actual ring 0 -> ring 3 transition primitive.
#
# MECHANISM: `iretq` is not just for returning from interrupts -- it
# is the ONLY x86-64 instruction that can change CPL (current
# privilege level) as part of a single, atomic instruction while also
# loading a completely fresh SS/RSP/RFLAGS/CS/RIP from the stack. This
# project already has every piece needed to use it deliberately: the
# CPU pushes exactly this shape of frame when delivering a real
# interrupt/exception (isr_stubs.s/interrupts.f90's INTERRUPT_FRAME_T
# already models it), so building the SAME shape by hand and executing
# `iretq` against it is the standard, well-established technique for
# entering ring 3 for the very first time (there is no other legal way
# for software to lower its own privilege level -- `iretq` and the
# related `sysret` are the only two instructions the architecture
# provides for this, and sysret needs MSR setup (STAR/LSTAR/SFMASK)
# this project has not built; iretq reuses machinery already proven
# working, so it is the lower-risk choice for this first pass).
#
# CALLING CONVENTION: BIND(C) VALUE, matching every other asm
# primitive in this codebase (RING0-BRIDGE-SPEC.md section 6) --
# entry_addr in %rdi, user_stack_top in %rsi.
#
# NEVER RETURNS, by construction -- exactly like SCHED_START/
# SCHED_EXIT_TASK (sched.f90), this is a one-way trip from the
# caller's perspective. Unlike those, this is not even a context
# switch in the scheduler's sense -- it is a straight-line function
# that ends by transferring control via iretq instead of ret, with no
# mechanism in this file (or anywhere yet) that would ever transfer
# control BACK to whatever called this. Getting back to ring 0 after
# this point is the syscall gate's job (isr_stubs.s's fort0k_isr48,
# idt.f90's IDT_GATE_INT_R3) -- a completely separate mechanism, entered
# independently by the ring-3 code itself executing `int $48`, not by
# anything in this file.
    .text
    .globl fort0k_enter_usermode
    .type fort0k_enter_usermode, @function
fort0k_enter_usermode:
    # Build the iretq frame on the CURRENT (ring 0) stack, in the
    # exact order iretq expects, PUSHED IN REVERSE (iretq pops SS
    # last, so SS must be pushed first / end up at the highest
    # address): SS, RSP, RFLAGS, CS, RIP -- iretq itself then pops
    # RIP, CS, RFLAGS, RSP, SS in that order and loads each into the
    # corresponding register, RSP/SS last, which is what actually
    # performs the ring-0-to-ring-3 stack switch atomically as part
    # of the same instruction.
    #
    # USER_DATA_SEL/USER_CODE_SEL (gdt.f90) both already have RPL=3
    # baked into their literal values (3*8+3 and 4*8+3) -- pushed
    # here as the raw 16-bit values gdt.f90 defines, not re-OR'd with
    # anything, since gdt.f90 already did that construction once, at
    # the single source of truth for what these selectors are.
    movq $0x23, %rax        # USER_DATA_SEL (4*8+3 = 0x23) -- SS
    pushq %rax
    pushq %rsi              # user_stack_top -- RSP
    pushfq
    popq %rax
    orq $0x200, %rax        # ensure IF is set -- a ring 3 program
                              # should run with interrupts enabled
                              # (a ring 3 program cannot itself
                              # execute cli/sti -- those are
                              # privileged instructions -- so this is
                              # the ONE place that decides whether
                              # interrupts are enabled for the entire
                              # duration of its execution, and
                              # leaving them disabled would mean no
                              # timer tick, no preemption, ever, for
                              # any ring 3 code)
    pushq %rax               # RFLAGS
    movq $0x1B, %rax        # USER_CODE_SEL (3*8+3 = 0x1B) -- CS
    pushq %rax
    pushq %rdi              # entry_addr -- RIP

    iretq
    .size fort0k_enter_usermode, .-fort0k_enter_usermode

    .section .note.GNU-stack,"",@progbits
