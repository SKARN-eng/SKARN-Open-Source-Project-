! vmm.f90 -- Virtual Memory Manager: builds a real 4-level (PML4 ->
! PDPT -> PD -> PT) x86-64 page table structure from scratch, using
! PMM_ALLOC_PAGE for every table's storage, superseding boot.s's
! throwaway single-1GiB-huge-page identity map the same way gdt.f90
! superseded boot.s's minimal bootstrap GDT (RING0-BRIDGE-SPEC.md
! section 2's stated pattern: a minimal asm bootstrap gets Fortran
! running, then Fortran takes over and builds the real structure).
!
! MILESTONE FOR THIS STAGE: a higher-half kernel mapping. The kernel
! image is loaded at physical 1MiB (link.ld) and, until now, only
! ever accessed via its identity-mapped virtual==physical address
! (boot.s's 1GiB huge page made every physical address in the first
! GiB also a valid virtual address at the same number). This module
! additionally maps the kernel image to a virtual address in the
! canonical "higher half" (0xFFFFFFFF80000000+, the conventional
! negative-2GiB region every mainstream x86-64 kernel uses) --
! DOUBLE-mapped, not moved: the low identity mapping is deliberately
! left in place after this stage's work, not torn down, because the
! page tables THEMSELVES are allocated via PMM_ALLOC_PAGE and
! referenced by physical address from CR3 and every table entry, and
! this module's own code (which builds and installs those tables)
! is executing from the low, identity-mapped addresses at the moment
! CR3 is loaded -- removing that mapping the instant it becomes
! unnecessary would require the removal code itself to survive the
! removal, a real ordering hazard this project is not solving in this
! pass. Tearing down the low mapping (once every remaining reference
! to a low address is confirmed gone) is left as a clearly separable
! follow-up, per this project's add-only-when-needed rule -- proving
! the higher-half mapping WORKS is this stage's actual milestone, not
! full higher-half purity.
MODULE VMM
  USE ISO_C_BINDING
  USE RING0
  USE PMM
  IMPLICIT NONE

  INTEGER(C_INT64_T), PARAMETER :: PTE_PRESENT   = INT(Z'0000000000000001', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: PTE_WRITABLE  = INT(Z'0000000000000002', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: PTE_USER      = INT(Z'0000000000000004', C_INT64_T)
  ! PTE_USER: added this session for user-mode work -- a REAL,
  ! PREVIOUSLY MISSING bit. Every page-table entry this project has
  ! ever built, before this session, correctly set PTE_PRESENT/
  ! PTE_WRITABLE but never PTE_USER (bit 2, U/S -- User/Supervisor),
  ! meaning every mapping in this kernel's entire history has been
  ! Supervisor-only (accessible from ring 0, faults immediately if
  ! ring 3 attempts to read/write/fetch from it) -- invisible until
  ! this session's ring-3 work made it matter for the first time.
  ! Confirmed as the actual root cause of a real double fault via
  ! direct boot testing: FORT0K_ENTER_USERMODE's iretq itself
  ! completed the TSS-dependent parts correctly (this session's
  ! earlier TSS fix), but zero ring-3 instructions ever executed
  ! (confirmed: none of usermode_test_body's expected 'U' output
  ! reached serial) -- consistent with the CPU faulting the instant
  ! it tried to fetch the first ring-3 instruction from a page with no
  ! PTE_USER bit set, before even one instruction could run.
  INTEGER(C_INT64_T), PARAMETER :: PTE_HUGE      = INT(Z'0000000000000080', C_INT64_T)
  ! PTE_HUGE (bit 7, "PS") is only meaningful at the PDPT and PD
  ! levels (1GiB and 2MiB pages respectively) -- this module does not
  ! use it (builds full 4-level paths down to 4KiB PT entries
  ! throughout, deliberately, for the finer-grained control a real
  ! kernel eventually wants for permission/COW-per-page reasons this
  ! project doesn't need yet but shouldn't foreclose by defaulting to
  ! huge pages everywhere) -- kept defined for completeness/future use
  ! rather than omitted, since a reader checking "does this project
  ! know about huge pages" should find a definite answer either way.

  INTEGER(C_INT64_T), PARAMETER :: PTE_ADDR_MASK = INT(Z'000FFFFFFFFFF000', C_INT64_T)
  ! Bits 12-51: the physical address a present entry points to (table
  ! or final page, depending on level). Bits 0-11 (flags) and 52-63
  ! (reserved/NX/etc, unused by this module so far) are masked off
  ! when extracting an existing entry's target address.

  TYPE, BIND(C) :: PT_ENTRY_T
    INTEGER(C_INT64_T) :: RAW
  END TYPE PT_ENTRY_T
  ! Byte-offset-probed this session (512-entry array of this type
  ! measured at exactly 4096 bytes via C_SIZEOF on a linked probe --
  ! confirms one page-table page is exactly one physical page with no
  ! padding, the hardware requirement this whole module depends on).

  INTEGER(C_INT64_T), PARAMETER :: HIGHER_HALF_BASE = INT(Z'FFFFFFFF80000000', C_INT64_T)
  ! Conventional x86-64 "negative 2GiB" kernel virtual base. A signed
  ! 64-bit Fortran INTEGER holding this literal is itself negative
  ! (the top bit is set) -- this is expected and handled correctly by
  ! this module's own arithmetic (which only ever does address
  ! addition/masking, never magnitude comparison that would care about
  ! signedness), but is worth flagging for a future reader who might
  ! reflexively "fix" an apparently-negative address constant.

  INTEGER(C_INT64_T) :: VMM_CURRENT_PML4 = 0_C_INT64_T
  BIND(C, NAME="vmm_current_pml4") :: VMM_CURRENT_PML4
  ! Set by VMM_INIT once the new tables are built and CR3 is loaded.
  ! Callers elsewhere in this codebase that need to map additional
  ! pages after VMM_INIT has already run (apic.f90's MMIO mapping,
  ! notably) read this instead of needing VMM_INIT's return value
  ! threaded through every intervening call site -- a module-level
  ! variable is the right tool here specifically because there is,
  ! deliberately, only ever ONE active PML4 in this project so far (no
  ! per-process address space yet -- that is a real future need this
  ! variable's design does not preclude, just does not solve today,
  ! per the add-only-when-needed rule).

CONTAINS

  ! VMM_TABLE_ALLOC() -- allocates one physical page via PMM_ALLOC_PAGE
  ! for use as a page-table page, and zeroes it (every entry
  ! not-present) before returning its physical address. Zeroing uses
  ! an explicit DO loop, not whole-array assignment -- RING0-BRIDGE-
  ! SPEC.md section 1's memset finding applies here exactly as it did
  ! to PMM_BITMAP, same reasoning, not re-derived.
  !
  ! Physical address doubles as the virtual address this module
  ! dereferences it through, because this code runs entirely within
  ! the still-active low identity map while it builds the new tables
  ! -- see this module's header comment for why that mapping stays up
  ! through this whole process.
  FUNCTION VMM_TABLE_ALLOC() RESULT(PHYS_ADDR)
    INTEGER(C_INT64_T) :: PHYS_ADDR
    TYPE(PT_ENTRY_T), POINTER :: TBL(:)
    INTEGER :: I

    PHYS_ADDR = PMM_ALLOC_PAGE()
    IF (PHYS_ADDR < 0_C_INT64_T) RETURN   ! out of memory -- caller
                                            ! must check for this same
                                            ! failure value PMM_ALLOC_
                                            ! PAGE itself uses, kept
                                            ! consistent rather than
                                            ! introducing a second
                                            ! sentinel convention

    CALL C_F_POINTER(TRANSFER(PHYS_ADDR, C_NULL_PTR), TBL, [512])
    DO I = 1, 512
      TBL(I)%RAW = 0_C_INT64_T
    END DO
  END FUNCTION VMM_TABLE_ALLOC

  ! VMM_MAP_4K(PML4_PHYS, VIRT_ADDR, PHYS_ADDR, FLAGS) -- maps one
  ! 4KiB page, walking/creating PML4 -> PDPT -> PD -> PT entries as
  ! needed (allocating a fresh table via VMM_TABLE_ALLOC at any level
  ! that doesn't yet have one). FLAGS is the raw flag-bits value
  ! (PTE_PRESENT/PTE_WRITABLE/...) ORed into the final PT entry --
  ! intermediate (PML4/PDPT/PD) entries always get PRESENT|WRITABLE
  ! regardless of FLAGS, matching the conventional x86-64 idiom of
  ! putting the real permission restriction only at the leaf level
  ! (the CPU ANDs permissions across all levels, so a restrictive
  ! intermediate entry can only ever narrow, never widen, what the
  ! leaf allows -- putting the real policy at the leaf keeps
  ! intermediate-level permissions from needing to be reasoned about
  ! per mapping).
  SUBROUTINE VMM_MAP_4K(PML4_PHYS, VIRT_ADDR, PHYS_ADDR, FLAGS)
    INTEGER(C_INT64_T), INTENT(IN) :: PML4_PHYS, VIRT_ADDR, PHYS_ADDR, FLAGS
    INTEGER(C_INT64_T) :: PML4_IDX, PDPT_IDX, PD_IDX, PT_IDX
    INTEGER(C_INT64_T) :: PDPT_PHYS, PD_PHYS, PT_PHYS
    TYPE(PT_ENTRY_T), POINTER :: PML4(:), PDPT(:), PD(:), PT(:)

    ! Standard x86-64 4-level index extraction: bits 39-47, 30-38,
    ! 21-29, 12-20 respectively, 9 bits each (512 entries per table).
    PML4_IDX = IAND(ISHFT(VIRT_ADDR, -39), 511_C_INT64_T)
    PDPT_IDX = IAND(ISHFT(VIRT_ADDR, -30), 511_C_INT64_T)
    PD_IDX   = IAND(ISHFT(VIRT_ADDR, -21), 511_C_INT64_T)
    PT_IDX   = IAND(ISHFT(VIRT_ADDR, -12), 511_C_INT64_T)

    CALL C_F_POINTER(TRANSFER(PML4_PHYS, C_NULL_PTR), PML4, [512])
    IF (IAND(PML4(PML4_IDX + 1_C_INT64_T)%RAW, PTE_PRESENT) == 0_C_INT64_T) THEN
      PDPT_PHYS = VMM_TABLE_ALLOC()
      PML4(PML4_IDX + 1_C_INT64_T)%RAW = IOR(PDPT_PHYS, IOR(PTE_PRESENT, IOR(PTE_WRITABLE, PTE_USER)))
    ELSE
      PDPT_PHYS = IAND(PML4(PML4_IDX + 1_C_INT64_T)%RAW, PTE_ADDR_MASK)
      ! BUG FOUND AND FIXED THIS SESSION: an intermediate table entry
      ! that already exists (created by an EARLIER VMM_MAP_4K call,
      ! before PTE_USER existed as a concept in this codebase) would
      ! NOT have PTE_USER set, and this ELSE branch previously left it
      ! untouched -- silently continuing to deny user access at this
      ! level even if the FINAL page-table entry this call is about to
      ! write has PTE_USER set, since x86 hardware ANDs the permission
      ! bit across every level of the walk (confirmed via web search
      ! this session; a real, previously-latent gap this project's
      ! first ring-3 test surfaced). Fixed by unconditionally OR-ing
      ! PTE_USER into the existing entry here too, not only at
      ! creation time -- safe to do liberally at every intermediate
      ! level (it does not, by itself, grant access to anything; the
      ! FINAL page's own PTE_USER bit remains the real, page-specific
      ! gate, per the same AND-across-levels rule).
      PML4(PML4_IDX + 1_C_INT64_T)%RAW = IOR(PML4(PML4_IDX + 1_C_INT64_T)%RAW, PTE_USER)
    END IF

    CALL C_F_POINTER(TRANSFER(PDPT_PHYS, C_NULL_PTR), PDPT, [512])
    IF (IAND(PDPT(PDPT_IDX + 1_C_INT64_T)%RAW, PTE_PRESENT) == 0_C_INT64_T) THEN
      PD_PHYS = VMM_TABLE_ALLOC()
      PDPT(PDPT_IDX + 1_C_INT64_T)%RAW = IOR(PD_PHYS, IOR(PTE_PRESENT, IOR(PTE_WRITABLE, PTE_USER)))
    ELSE
      PD_PHYS = IAND(PDPT(PDPT_IDX + 1_C_INT64_T)%RAW, PTE_ADDR_MASK)
      PDPT(PDPT_IDX + 1_C_INT64_T)%RAW = IOR(PDPT(PDPT_IDX + 1_C_INT64_T)%RAW, PTE_USER)
    END IF

    CALL C_F_POINTER(TRANSFER(PD_PHYS, C_NULL_PTR), PD, [512])
    IF (IAND(PD(PD_IDX + 1_C_INT64_T)%RAW, PTE_PRESENT) == 0_C_INT64_T) THEN
      PT_PHYS = VMM_TABLE_ALLOC()
      PD(PD_IDX + 1_C_INT64_T)%RAW = IOR(PT_PHYS, IOR(PTE_PRESENT, IOR(PTE_WRITABLE, PTE_USER)))
    ELSE
      PT_PHYS = IAND(PD(PD_IDX + 1_C_INT64_T)%RAW, PTE_ADDR_MASK)
      PD(PD_IDX + 1_C_INT64_T)%RAW = IOR(PD(PD_IDX + 1_C_INT64_T)%RAW, PTE_USER)
    END IF

    CALL C_F_POINTER(TRANSFER(PT_PHYS, C_NULL_PTR), PT, [512])
    PT(PT_IDX + 1_C_INT64_T)%RAW = IOR(IAND(PHYS_ADDR, PTE_ADDR_MASK), FLAGS)
  END SUBROUTINE VMM_MAP_4K

  ! VMM_MAP_RANGE(PML4_PHYS, VIRT_BASE, PHYS_BASE, LENGTH, FLAGS) --
  ! maps LENGTH bytes (rounded up to whole 4KiB pages) starting at
  ! VIRT_BASE/PHYS_BASE, one VMM_MAP_4K call per page. No huge-page
  ! optimization -- see PTE_HUGE's header comment for why that's a
  ! deliberate choice, not an oversight, at this project's current
  ! scale.
  SUBROUTINE VMM_MAP_RANGE(PML4_PHYS, VIRT_BASE, PHYS_BASE, LENGTH, FLAGS)
    INTEGER(C_INT64_T), INTENT(IN) :: PML4_PHYS, VIRT_BASE, PHYS_BASE, LENGTH, FLAGS
    INTEGER(C_INT64_T) :: OFFSET, NPAGES, I
    NPAGES = (LENGTH + 4095_C_INT64_T) / 4096_C_INT64_T
    DO I = 0_C_INT64_T, NPAGES - 1_C_INT64_T
      OFFSET = I * 4096_C_INT64_T
      CALL VMM_MAP_4K(PML4_PHYS, VIRT_BASE + OFFSET, PHYS_BASE + OFFSET, FLAGS)
    END DO
  END SUBROUTINE VMM_MAP_RANGE

  ! VMM_INIT(KERNEL_PHYS_START, KERNEL_PHYS_END) -- builds a fresh
  ! PML4 (via PMM_ALLOC_PAGE, NOT boot.s's static .bss pml4/pdpt --
  ! this is a genuinely new, dynamically allocated table structure,
  ! not a reuse of the bootstrap one) with:
  !   (1) an identity mapping of the first 1GiB of physical memory
  !       (see BUG FOUND below for why this is 1GiB and not just the
  !       kernel's own footprint),
  !   (2) the kernel's physical range ALSO mapped at HIGHER_HALF_BASE
  !       + (phys - KERNEL_PHYS_START) -- the actual stage 4
  !       milestone, a working higher-half virtual mapping,
  !   (3) the VGA buffer's physical page (0xB8000) identity-mapped
  !       (subsumed by (1) at 1GiB scope, but named explicitly so a
  !       future reduction of (1)'s range doesn't silently break VGA
  !       without a specific reminder at the call site),
  ! then loads the new PML4 into CR3.
  !
  ! BUG FOUND AND FIXED THIS SESSION: the first version of this
  ! function identity-mapped ONLY [KERNEL_PHYS_START, KERNEL_PHYS_END)
  ! -- the kernel image's own footprint -- on the theory that this
  ! module's own executing code only needed to keep working from
  ! addresses inside that range. This missed something: VMM_TABLE_ALLOC
  ! calls PMM_ALLOC_PAGE for every PML4/PDPT/PD/PT table this function
  ! builds, and PMM_ALLOC_PAGE hands out memory from anywhere in the
  ! PMM's free pool -- NOT restricted to the kernel image -- so the
  ! new page tables' OWN storage (including the PML4 table itself)
  ! typically lands OUTSIDE [KERNEL_PHYS_START, KERNEL_PHYS_END) and
  ! was therefore NOT present in the very page tables it belonged to.
  ! The moment CR3 was reloaded and the CPU next tried to walk that
  ! PML4 to service ANY memory access (including reading the PML4
  ! table itself for a subsequent VMM_MAP_4K call), it faulted --
  ! confirmed via a real triple-fault-free but clean page-fault report
  ! (interrupts.f90's handler correctly caught it): CR2 matched the
  ! PML4's own physical address almost exactly, and the faulting
  ! instruction (`mov (%rbx),%rdx`, confirmed via objdump) was exactly
  ! the array-indexing load pattern for a PT_ENTRY_T table access.
  ! Fixed by identity-mapping a full 1GiB up front (matching boot.s's
  ! original bootstrap scope, comfortably covering every address
  ! PMM_ALLOC_PAGE can return given PMM_MAX_PAGES's current 4GiB cap
  ! and this project's practical QEMU test environment's RAM size) --
  ! not a permanent design (a real kernel would map exactly what's
  ! needed, or use a scheme where page-table pages are always taken
  ! from a reserved, already-mapped pool), but correct and sufficient
  ! for this project's current stage, with the actual chicken-and-egg
  ! mechanism now understood and documented rather than worked around
  ! blindly.
  FUNCTION VMM_INIT(KERNEL_PHYS_START, KERNEL_PHYS_END) RESULT(NEW_PML4_PHYS)
    INTEGER(C_INT64_T), INTENT(IN) :: KERNEL_PHYS_START, KERNEL_PHYS_END
    INTEGER(C_INT64_T) :: NEW_PML4_PHYS
    INTEGER(C_INT64_T) :: KLEN
    INTEGER(C_INT64_T), PARAMETER :: IDENTITY_MAP_SIZE = INT(Z'40000000', C_INT64_T)
    ! 0x40000000 = 1GiB.

    NEW_PML4_PHYS = VMM_TABLE_ALLOC()
    IF (NEW_PML4_PHYS < 0_C_INT64_T) RETURN

    KLEN = KERNEL_PHYS_END - KERNEL_PHYS_START

    ! (1) identity mapping of the first 1GiB of physical memory -- see
    ! this function's header comment for why this is 1GiB and not
    ! just the kernel's own footprint.
    CALL VMM_MAP_RANGE(NEW_PML4_PHYS, 0_C_INT64_T, 0_C_INT64_T, &
                        IDENTITY_MAP_SIZE, IOR(PTE_PRESENT, PTE_WRITABLE))

    ! (2) higher-half mapping of the kernel's own physical range
    CALL VMM_MAP_RANGE(NEW_PML4_PHYS, HIGHER_HALF_BASE, KERNEL_PHYS_START, &
                        KLEN, IOR(PTE_PRESENT, PTE_WRITABLE))

    CALL FORT0K_LOAD_CR3(NEW_PML4_PHYS)
    VMM_CURRENT_PML4 = NEW_PML4_PHYS
  END FUNCTION VMM_INIT

END MODULE VMM
