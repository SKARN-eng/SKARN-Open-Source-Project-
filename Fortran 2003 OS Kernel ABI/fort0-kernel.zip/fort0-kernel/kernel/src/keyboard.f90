! keyboard.f90 -- PS/2 keyboard driver, IRQ 1.
!
! Scope at this stage: read the raw scancode byte from port 0x60 (so
! the PS/2 controller's output buffer is drained -- REQUIRED, not
! optional, since the controller will not generate another IRQ1 until
! the current byte is read) and print it in hex to serial. Scancode-
! to-ASCII keymap translation, key-up vs key-down distinction beyond
! the raw "high bit set" convention, and any kind of input queue for
! other kernel code to consume are all later-stage concerns, per this
! project's add-only-when-needed rule -- there is no consumer for
! translated keystrokes yet, so building the translation table now
! would be speculative.
MODULE KEYBOARD
  USE ISO_C_BINDING
  USE RING0
  USE SERIAL
  IMPLICIT NONE

  INTEGER(C_INT16_T), PARAMETER :: PS2_DATA_PORT = INT(Z'0060', C_INT16_T)

CONTAINS

  ! KEYBOARD_IRQ_HANDLER(IRQ) -- matches INTERRUPTS module's
  ! IRQ_HANDLER_T interface, registered via
  ! IRQ_REGISTER_HANDLER(1, KEYBOARD_IRQ_HANDLER) in kernel_main.f90.
  SUBROUTINE KEYBOARD_IRQ_HANDLER(IRQ)
    INTEGER, INTENT(IN) :: IRQ
    INTEGER(C_INT8_T) :: SCANCODE
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(20)
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: N, HI, LO

    SCANCODE = FORT0K_INB(PS2_DATA_PORT)

    N = 0
    CALL PUT(BUF, N, 'k'); CALL PUT(BUF, N, 'e'); CALL PUT(BUF, N, 'y')
    CALL PUT(BUF, N, ':'); CALL PUT(BUF, N, ' ')
    CALL PUT(BUF, N, '0'); CALL PUT(BUF, N, 'x')
    HI = IAND(ISHFT(INT(SCANCODE), -4), 15)
    LO = IAND(INT(SCANCODE), 15)
    CALL PUT(BUF, N, HEXDIGITS(HI+1:HI+1))
    CALL PUT(BUF, N, HEXDIGITS(LO+1:LO+1))
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE KEYBOARD_IRQ_HANDLER

  ! PUT(BUF, N, CH) -- appends one character, advancing N. Inlined as
  ! a tiny helper rather than calling through a shared FILL_STR-style
  ! routine, per RING0-BRIDGE-SPEC.md section 1's constprop/memcpy
  ! finding: that finding was never root-caused precisely enough to
  ! trust a shared copy routine at a NEW call site without re-
  ! verifying via nm, and a single-character append has no copy loop
  ! for the optimizer to potentially misrecognize in the first place,
  ! sidestepping the question entirely rather than re-litigating it
  ! here.
  SUBROUTINE PUT(BUF, N, CH)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    CHARACTER(LEN=1), INTENT(IN) :: CH
    N = N + 1
    BUF(N) = CH
  END SUBROUTINE PUT

END MODULE KEYBOARD
