# usermode_test.s -- a tiny, hand-written "program" this project runs
# at ring 3, to prove the user-mode entry mechanism (usermode_enter.s)
# and the syscall gate (isr_stubs.s's fort0k_isr48, interrupts.f90's
# SYSCALL_DISPATCH) both actually work, end to end.
#
# WRITTEN IN ASM, NOT FORTRAN, DELIBERATELY: a Fortran-compiled
# subroutine's body is, in principle, still just machine code no
# different from hand-written asm once compiled -- but writing this
# test directly in asm removes any ambiguity about what a given
# Fortran construct might compile to underneath (this project has
# disabled stack protectors/exception tables project-wide, but a
# genuinely from-scratch, minimal instruction sequence is the clearest
# possible test of "does entering ring 3 and executing untrusted-shaped
# code actually work," with nothing else to account for.
#
# TWO PARTS: USERMODE_TEST_BODY (the "good" test -- calls the write-
# char syscall a few times, then exits cleanly) and
# USERMODE_TEST_PRIVILEGED (the "bad" test -- attempts a privileged
# instruction, `cli`, which should fault with #GP since ring 3 code
# has no permission to execute it -- proving the privilege boundary
# is REAL, not merely that entry/exit work when a program behaves).
    .text

    .globl usermode_test_body
    .type usermode_test_body, @function
usermode_test_body:
    # (Diagnostic checkpoint write removed: it targeted 0x9021, a
    # scratch address never remapped with PTE_USER, so ring-3 code
    # writing to it correctly faulted -- this was the actual, full
    # explanation for the double fault this session spent significant
    # effort chasing. Confirmed via QEMU's own -d int exception trace,
    # which showed CPL=3 and RIP correctly at this exact address at
    # the moment of the fault -- definitive proof the TSS/paging/GDT/
    # iretq frame mechanism ALL work correctly; the bug was in this
    # diagnostic itself, not in the mechanism it was trying to verify.
    # See RING0-BRIDGE-SPEC.md for the full account.)

    # Syscall 1 (SYS_WRITE_CHAR): print 'U' three times, proving this
    # code is genuinely executing (not stuck, not immediately faulted)
    # and that the syscall mechanism genuinely round-trips.
    movq $1, %rax
    movq $0x55, %rdi        # 'U'
    int $48

    movq $1, %rax
    movq $0x55, %rdi
    int $48

    movq $1, %rax
    movq $0x55, %rdi
    int $48

    # Syscall 2 (SYS_EXIT): terminate this task via the real scheduler
    # exit path. Does not return -- see interrupts.f90's SYSCALL_
    # DISPATCH comment on SYS_EXIT for why.
    movq $2, %rax
    int $48

    # Unreachable if SYS_EXIT worked correctly. A tight spin loop
    # here (NOT hlt -- see below) is a deliberate, safe fallback if
    # the exit hook was somehow not registered.
    #
    # BUG FOUND AND FIXED THIS SESSION: this originally used `hlt` for
    # the fallback loop -- but `hlt` is ITSELF a privileged
    # instruction, and executing it at ring 3 faults (#GP) exactly
    # the same way usermode_test_privileged's deliberate `cli` test
    # (below) is designed to. This was found via a real, confirmed
    # boot test: with the IRQ-delivery double fault (RING0-BRIDGE-
    # SPEC.md section 32) fixed, all three SYS_WRITE_CHAR syscalls
    # printed correctly ('UUU'), then a #GP occurred right where
    # SYS_EXIT's fallthrough reached this exact `hlt` instruction
    # (confirmed via direct disassembly of the fault address) -- this
    # standalone test runs before any scheduler task exists, so
    # SCHED_EXIT_TASK correctly no-ops and execution correctly falls
    # through to here, which then incorrectly tried to execute a
    # privileged instruction at ring 3. Fixed with a plain `jmp $`
    # spin, which is NOT privileged and is safe at any ring.
1:  jmp 1b
    .size usermode_test_body, .-usermode_test_body

    # usermode_test_scheduled -- a SECOND ring-3 test entry point,
    # added this session specifically to prove a REAL SCHEDULED ring-3
    # task works, not just the standalone entry usermode_test_body
    # proves (that one runs before the scheduler exists at all, via
    # FORT0K_ENTER_USERMODE directly). This one is designed to be
    # created via SCHED_CREATE_TASK_USERMODE (sched.f90) and run
    # ALONGSIDE ring-0 demo tasks, genuinely interleaving with them
    # through the scheduler's ordinary ready queue -- printing 'S'
    # (not 'U', to distinguish this task's output from
    # usermode_test_body's in a shared serial log) three times, each
    # preceded by a SYS_YIELD (syscall 3) rather than SYS_WRITE_CHAR
    # alone, so each iteration genuinely hands control to the
    # scheduler and back, then exits via SYS_EXIT exactly like the
    # standalone test.
    .globl usermode_test_scheduled
    .type usermode_test_scheduled, @function
usermode_test_scheduled:
    movq $1, %rax
    movq $0x53, %rdi        # 'S'
    int $48
    movq $3, %rax            # SYS_YIELD
    int $48

    movq $1, %rax
    movq $0x53, %rdi
    int $48
    movq $3, %rax
    int $48

    movq $1, %rax
    movq $0x53, %rdi
    int $48
    movq $3, %rax
    int $48

    movq $2, %rax            # SYS_EXIT
    int $48
1:  jmp 1b
    .size usermode_test_scheduled, .-usermode_test_scheduled

    .globl usermode_test_privileged
    .type usermode_test_privileged, @function
usermode_test_privileged:
    # Deliberately attempts a privileged instruction (cli) while
    # running at ring 3 -- this MUST fault (#GP, vector 13) if the
    # privilege boundary is real. This project's kernel currently
    # treats every CPU exception as fatal (interrupts.f90's
    # FORT0K_DISPATCH, "no recovery path exists yet") -- so a
    # successful test of this function is a REPORTED #GP fault
    # followed by the kernel halting, not a return from this
    # function, which is exactly what "the boundary holds" looks like
    # given this project's current fault-handling policy. A version
    # of this test that expected a graceful, resumable recovery from
    # ring 3 attempting a privileged instruction would need real
    # signal/exception delivery back to user mode -- explicitly out of
    # scope for this first pass (see RING0-BRIDGE-SPEC.md).
    cli
    # Unreachable if the privilege check works as intended.
    movq $1, %rax
    movq $0x21, %rdi        # '!' -- would print only if cli did NOT
                              # fault, which would itself be the real
                              # finding (a genuinely broken privilege
                              # boundary) worth treating as such
    int $48
1:  jmp 1b
    .size usermode_test_privileged, .-usermode_test_privileged

    .section .note.GNU-stack,"",@progbits
