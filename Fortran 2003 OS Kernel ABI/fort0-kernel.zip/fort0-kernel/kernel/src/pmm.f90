! pmm.f90 -- Physical Memory Manager: a bitmap page-frame allocator.
!
! DESIGN: one bit per 4KiB physical page, in a fixed-size module-level
! array (BIND(C), for the same reasons every hardware-adjacent table
! in this codebase is: predictable linker-visible storage, no runtime
! allocation call needed to create it -- see RING0-BRIDGE-SPEC.md
! section 5's GDT/IDT precedent, same reasoning applied to this
! table). Bit=1 means "in use or otherwise unavailable", bit=0 means
! "free". A bitmap, not a free-list, specifically because: (a) it
! needs no dynamic memory itself to exist (a free-list's nodes would
! need to live IN the free pages they describe, a well-known
! bootstrapping headache this project sidesteps entirely by not doing
! it), and (b) bit-scanning operations (find first zero bit, count
! zero bits in a range) are the kind of thing that parallelizes
! cleanly across cores later (README.md's stated direction) -- a
! free-list's pointer-chasing does not parallelize nearly as
! naturally, so this choice is made with that direction in mind, not
! just for today's single-core use.
!
! FIXED UPPER BOUND, NOT DYNAMICALLY SIZED: PMM_MAX_PAGES caps the
! physical address range this allocator can track. A real production
! kernel would size the bitmap dynamically from the actual detected
! RAM (chicken-and-egg: sizing it needs an allocation, which needs the
! allocator that doesn't exist yet -- solvable, but with real
! complexity: place the bitmap itself at a computed offset right after
! the kernel image, sized from the parsed memory map's highest
! address). This project takes the simpler fixed-upper-bound approach
! for now (4GiB of trackable physical address space, 128KiB of
! bitmap) -- correct and sufficient for QEMU's default RAM and most
! real development machines, revisited if a genuine need for >4GiB
! support arises, per this project's standing add-only-when-needed
! rule.
MODULE PMM
  USE ISO_C_BINDING
  USE MULTIBOOT2
  USE RING0
  IMPLICIT NONE

  INTEGER(C_INT64_T), PARAMETER :: PAGE_SIZE = 4096_C_INT64_T
  INTEGER(C_INT64_T), PARAMETER :: PMM_MAX_PAGES = 1048576_C_INT64_T
  ! 1048576 pages * 4KiB = 4GiB of trackable physical address space.
  INTEGER(C_INT64_T), PARAMETER :: PMM_BITMAP_WORDS = PMM_MAX_PAGES / 64_C_INT64_T
  ! One bit per page, packed into 64-bit words -- 1048576/64 = 16384
  ! words = 131072 bytes = 128KiB of bitmap, a fixed .bss cost paid
  ! regardless of how much RAM is actually present, the tradeoff for

  ! COMPILE-TIME INVARIANT CHECK, not a runtime assertion: if a future
  ! edit changes PMM_MAX_PAGES to a value that is not an exact multiple
  ! of 64, the division above silently TRUNCATES (confirmed via a
  ! direct probe this session: gfortran does emit a real
  ! -Winteger-division WARNING for this specific case, but only a
  ! warning, easy to miss in normal build output) -- the bitmap would
  ! then track fewer pages than PMM_MAX_PAGES actually specifies, with
  ! no error, discoverable only by noticing missing memory at runtime
  ! well after the fact. This PARAMETER expression is a Fortran
  ! "static assert" idiom (a compile-time-evaluated division that is
  ! deliberately made to divide by zero, and therefore fail
  ! compilation with a hard Error, if and only if the invariant it
  ! checks is violated) -- confirmed via a direct before/after probe
  ! this session that it compiles cleanly when the invariant holds and
  ! genuinely FAILS TO COMPILE (a real "Error: Division by zero", not
  ! merely a warning) when it does not, for the exact PMM_MAX_PAGES/64
  ! relationship this file depends on. Costs nothing at runtime (the
  ! PARAMETER itself, ASSERT_PMM_BITMAP_DIVIDES_EVENLY, is never
  ! referenced anywhere else -- its only purpose is to exist and be
  ! evaluatable) and is exactly the kind of "Fortran's type/constant
  ! system catching a bug class before boot" this project's alien-
  ! Fortran exploration is specifically looking for, per the
  ! vectorization-audit research (Tier 1, item 3).
  INTEGER, PARAMETER :: ASSERT_PMM_BITMAP_DIVIDES_EVENLY = &
    1 / MERGE(1, 0, MOD(PMM_MAX_PAGES, 64_C_INT64_T) == 0_C_INT64_T) - 1
  ! not needing a dynamic-sizing bootstrap step.

  INTEGER(C_INT64_T) :: PMM_BITMAP(PMM_BITMAP_WORDS)
  BIND(C, NAME="pmm_bitmap") :: PMM_BITMAP

  LOGICAL(C_BOOL) :: PMM_SCAN_MASK(PMM_BITMAP_WORDS)
  BIND(C, NAME="pmm_scan_mask") :: PMM_SCAN_MASK
  ! Scratch buffer for PMM_ALLOC_PAGE's vectorized scan (see that
  ! function). FIXED SIZE, matching PMM_BITMAP_WORDS exactly -- a
  ! compile-time PARAMETER, not a runtime-sized automatic array --
  ! deliberately, since a probe this session confirmed a runtime-
  ! sized LOGICAL array used the same way triggers a real malloc/free
  ! pair (RING0-BRIDGE-SPEC.md section 1's standing landmine, re-
  ! confirmed for this specific new use rather than assumed to still
  ! hold). Module-level rather than a local variable inside
  ! PMM_ALLOC_PAGE for the same reason: this project's convention
  ! throughout is fixed, named, linker-visible storage in place of
  ! anything that might need a runtime allocation to exist.

  INTEGER(C_INT64_T) :: PMM_TOTAL_PAGES = 0_C_INT64_T
  INTEGER(C_INT64_T) :: PMM_FREE_PAGES = 0_C_INT64_T
  BIND(C, NAME="pmm_total_pages") :: PMM_TOTAL_PAGES
  BIND(C, NAME="pmm_free_pages") :: PMM_FREE_PAGES

  ! PMM_LAST_ALLOC_WORD -- bitmap word index PMM_ALLOC_PAGE resumes
  ! scanning from, so repeated allocations don't re-scan already-
  ! exhausted low memory on every call. See PMM_ALLOC_PAGE's header
  ! comment for why this is not yet a more elaborate structure.
  INTEGER(C_INT64_T) :: PMM_LAST_ALLOC_WORD = 0_C_INT64_T
  BIND(C, NAME="pmm_last_alloc_word") :: PMM_LAST_ALLOC_WORD

  INTEGER(C_INT32_T), TARGET :: PMM_LOCK = 0
  BIND(C, NAME="pmm_lock") :: PMM_LOCK
  ! Added alongside sched.f90's READY_QUEUE_LOCK and serial.f90's
  ! SERIAL_LOCK: PMM_ALLOC_PAGE/PMM_FREE_PAGE mutate PMM_BITMAP,
  ! PMM_FREE_PAGES, and PMM_LAST_ALLOC_WORD with no protection before
  ! this -- safe every time this project has used them so far (every
  ! prior stage's PMM activity happened either single-core, or during
  ! SMP bring-up's deliberately-serialized one-core-at-a-time wake
  ! sequence) but a real, live hazard the moment more than one core
  ! genuinely runs concurrently and both allocate, exactly the
  ! situation the scheduler's multi-core checkpoint creates.

CONTAINS

  ! PMM_MARK_USED(PAGE_FRAME) / PMM_MARK_FREE(PAGE_FRAME) -- set or
  ! clear one bit. PAGE_FRAME is a page NUMBER (physical address /
  ! PAGE_SIZE), not a byte address -- callers convert once at the call
  ! site rather than this routine silently dividing every time, so a
  ! caller that already has a page number (the common case, once
  ! initial setup is done) pays no redundant division.
  SUBROUTINE PMM_MARK_USED(PAGE_FRAME)
    INTEGER(C_INT64_T), INTENT(IN) :: PAGE_FRAME
    INTEGER(C_INT64_T) :: WORD_IDX, BIT_IDX
    LOGICAL :: WAS_FREE
    IF (PAGE_FRAME < 0_C_INT64_T .OR. PAGE_FRAME >= PMM_MAX_PAGES) RETURN
    WORD_IDX = PAGE_FRAME / 64_C_INT64_T + 1_C_INT64_T   ! Fortran 1-based
    BIT_IDX = MOD(PAGE_FRAME, 64_C_INT64_T)
    WAS_FREE = .NOT. BTEST(PMM_BITMAP(WORD_IDX), INT(BIT_IDX))
    PMM_BITMAP(WORD_IDX) = IBSET(PMM_BITMAP(WORD_IDX), INT(BIT_IDX))
    IF (WAS_FREE) PMM_FREE_PAGES = PMM_FREE_PAGES - 1_C_INT64_T
  END SUBROUTINE PMM_MARK_USED

  SUBROUTINE PMM_MARK_FREE(PAGE_FRAME)
    INTEGER(C_INT64_T), INTENT(IN) :: PAGE_FRAME
    INTEGER(C_INT64_T) :: WORD_IDX, BIT_IDX
    LOGICAL :: WAS_USED
    IF (PAGE_FRAME < 0_C_INT64_T .OR. PAGE_FRAME >= PMM_MAX_PAGES) RETURN
    WORD_IDX = PAGE_FRAME / 64_C_INT64_T + 1_C_INT64_T
    BIT_IDX = MOD(PAGE_FRAME, 64_C_INT64_T)
    WAS_USED = BTEST(PMM_BITMAP(WORD_IDX), INT(BIT_IDX))
    PMM_BITMAP(WORD_IDX) = IBCLR(PMM_BITMAP(WORD_IDX), INT(BIT_IDX))
    IF (WAS_USED) PMM_FREE_PAGES = PMM_FREE_PAGES + 1_C_INT64_T
  END SUBROUTINE PMM_MARK_FREE

  ! PMM_MARK_RANGE_USED/FREE(BASE_ADDR, LENGTH) -- byte-address,
  ! byte-length convenience wrappers over the page-frame primitives
  ! above, rounding BASE_ADDR down and the end address up to whole
  ! pages (conservative in both directions: a partially-covered page
  ! at either end of a "used" range is marked fully used, since using
  ! even one byte of it makes the rest unsafe to hand out; a partially
  ! covered page at either end of a "free" range is NOT marked free by
  ! this rounding, since assuming free bytes make a whole page free
  ! would be the unsafe direction -- PMM_INIT below relies on this
  ! asymmetry, marking free BEFORE used, so used's conservative
  ! rounding always wins where the two overlap at a boundary).
  SUBROUTINE PMM_MARK_RANGE_USED(BASE_ADDR, LENGTH)
    INTEGER(C_INT64_T), INTENT(IN) :: BASE_ADDR, LENGTH
    INTEGER(C_INT64_T) :: FIRST_PAGE, LAST_PAGE, P
    IF (LENGTH <= 0_C_INT64_T) RETURN
    FIRST_PAGE = BASE_ADDR / PAGE_SIZE
    LAST_PAGE = (BASE_ADDR + LENGTH - 1_C_INT64_T) / PAGE_SIZE
    DO P = FIRST_PAGE, LAST_PAGE
      CALL PMM_MARK_USED(P)
    END DO
  END SUBROUTINE PMM_MARK_RANGE_USED

  SUBROUTINE PMM_MARK_RANGE_FREE(BASE_ADDR, LENGTH)
    INTEGER(C_INT64_T), INTENT(IN) :: BASE_ADDR, LENGTH
    INTEGER(C_INT64_T) :: FIRST_PAGE, LAST_PAGE, P
    IF (LENGTH <= 0_C_INT64_T) RETURN
    FIRST_PAGE = (BASE_ADDR + PAGE_SIZE - 1_C_INT64_T) / PAGE_SIZE
    LAST_PAGE = (BASE_ADDR + LENGTH) / PAGE_SIZE - 1_C_INT64_T
    DO P = FIRST_PAGE, LAST_PAGE
      CALL PMM_MARK_FREE(P)
    END DO
  END SUBROUTINE PMM_MARK_RANGE_FREE

  ! PMM_INIT(MB2_INFO_ADDR, KERNEL_START, KERNEL_END) -- builds the
  ! bitmap from the Multiboot2 memory map. KERNEL_START/KERNEL_END
  ! (physical addresses, from link.ld-provided symbols -- see
  ! kernel_main.f90's call site) are marked used explicitly and
  ! separately from the memory-map walk, because the Multiboot2 spec
  ! itself warns the map's "available" regions INCLUDE the space the
  ! kernel is currently occupying (the boot loader has no way to know
  ! what the kernel will do with its own memory) -- the kernel must
  ! reserve its own footprint itself, the map will not do it.
  !
  ! ORDER OF OPERATIONS MATTERS: (1) mark EVERYTHING used, as the safe
  ! default; (2) mark every "available" region from the memory map
  ! free; (3) mark the kernel image and the low 1MiB (real-mode IVT,
  ! BIOS data area, video memory -- never safe to hand out regardless
  ! of what the map claims) used again, LAST, so step 3 always wins
  ! over step 2 at any overlap. Reversing steps 2 and 3 would be a
  ! real bug: a kernel image that happens to fall inside a region the
  ! map calls "available" (extremely likely, since the map has no
  ! knowledge of where GRUB loaded the kernel) would get marked free
  ! again by the wider region, and the allocator would eventually hand
  ! out pages the kernel itself is running from.
  SUBROUTINE PMM_INIT(MB2_INFO_ADDR, KERNEL_START, KERNEL_END)
    INTEGER(C_INT64_T), INTENT(IN) :: MB2_INFO_ADDR
    INTEGER(C_INT64_T), INTENT(IN) :: KERNEL_START, KERNEL_END
    INTEGER(C_INT64_T) :: ENTRIES_ADDR
    INTEGER(C_INT32_T) :: ENTRY_COUNT, ENTRY_SIZE, I, REGION_TYPE
    INTEGER(C_INT64_T) :: BASE, LENGTH
    INTEGER(C_INT64_T) :: I2
    LOGICAL :: FOUND

    ! all bits set = everything used. Uses an explicit DO loop, NOT
    ! whole-array assignment (PMM_BITMAP = -1_C_INT64_T) -- a real
    ! build failure this session (undefined reference to memset)
    ! showed that whole-array assignment on an array this size (16384
    ! elements) compiles to a real memset call, correcting an earlier
    ! claim in RING0-BRIDGE-SPEC.md section 1 that had wrongly
    ! generalized from a DIFFERENT, smaller array's clean result
    ! without re-probing this array's own size/shape -- see that
    ! section's corrected entry for the full account. The DO loop
    ! below is the same explicit-element-assignment pattern this
    ! project already uses everywhere else for exactly this reason.
    DO I2 = 1_C_INT64_T, PMM_BITMAP_WORDS
      PMM_BITMAP(I2) = -1_C_INT64_T
    END DO
    PMM_TOTAL_PAGES = PMM_MAX_PAGES
    PMM_FREE_PAGES = 0_C_INT64_T

    FOUND = MB2_FIND_MEMORY_MAP(MB2_INFO_ADDR, ENTRIES_ADDR, ENTRY_COUNT, ENTRY_SIZE)
    IF (FOUND) THEN
      DO I = 0, ENTRY_COUNT - 1
        CALL MB2_GET_ENTRY(ENTRIES_ADDR, ENTRY_SIZE, I, BASE, LENGTH, REGION_TYPE)
        IF (REGION_TYPE == MB2_MEM_AVAILABLE) THEN
          CALL PMM_MARK_RANGE_FREE(BASE, LENGTH)
        END IF
      END DO
    END IF
    ! FOUND == .FALSE. (no memory map tag at all) is not specially
    ! handled beyond this -- the bitmap stays all-used, PMM_FREE_PAGES
    ! stays 0, and PMM_ALLOC_PAGE (below) correctly reports
    ! out-of-memory for every request rather than crashing, which is
    ! the right degraded behavior for a boot loader that genuinely
    ! didn't provide the information this module needs.

    CALL PMM_MARK_RANGE_USED(0_C_INT64_T, 1048576_C_INT64_T)   ! low 1MiB
    CALL PMM_MARK_RANGE_USED(KERNEL_START, KERNEL_END - KERNEL_START)
    CALL PMM_MARK_RANGE_USED(MB2_INFO_ADDR, 32768_C_INT64_T)
    ! The Multiboot2 info structure's own true size is in its first
    ! 4 bytes (total_size, per multiboot2.f90) and could in principle
    ! be read here instead of using a fixed 32KiB guess -- 32KiB is
    ! used instead because it is comfortably larger than any
    ! Multiboot2 info structure this project has observed in practice
    ! (a handful of tags, each at most a few hundred bytes) and
    ! guarantees safety even if PMM_INIT's own reservation logic ran
    ! before MB2_FIND_MEMORY_MAP for some future reordering -- revisit
    ! with the exact reported size if a bootloader/config combination
    ! is ever found where 32KiB is insufficient.
  END SUBROUTINE PMM_INIT

  ! PMM_ALLOC_PAGE() -- returns the physical address of one free 4KiB
  ! page, marks it used, and decrements PMM_FREE_PAGES. Returns -1 (an
  ! otherwise-impossible page-aligned physical address, since bit 0 of
  ! -1 as a signed 64-bit value is set, meaning "used" if ever
  ! misinterpreted as a valid page number -- chosen so a caller that
  ! forgets to check the failure case fails LOUD, not quietly, on any
  ! subsequent use of the returned value as an address) if no free
  ! page exists.
  !
  ! VECTORIZED WORD SCAN, ADDED THIS SESSION: the "which bitmap WORDS
  ! have at least one free bit" computation is now a DO CONCURRENT
  ! loop over the whole bitmap into PMM_SCAN_MASK (a fixed-size
  ! LOGICAL(C_BOOL) buffer, module-level, matching PMM_BITMAP_WORDS
  ! exactly -- confirmed via direct probe this session, with the
  ! object file's own -S output showing genuine xmm/ymm SIMD register
  ! use, that this specific pattern (compile-time-fixed array extent,
  ! LOGICAL(C_BOOL) element type) is what gfortran's autovectorizer
  ! actually picks up at -O3; -O2 alone did not, even with SSE
  ! available). This file compiles with SSE enabled and -O3
  ! (Makefile's PMM_ALLOC_FLAGS, overriding the project's -mno-sse
  ! baseline for this ONE file specifically) because every call into
  ! this module happens after boot.s's own FPU/SSE initialization has
  ! already run -- confirmed by reading boot.s directly, not assumed;
  ! see the Makefile comment on PMM_ALLOC_FLAGS for the full
  ! reasoning. FINDING THE FIRST TRUE ENTRY in the resulting mask, and
  ! then finding the first free BIT within that word, both remain
  ! ordinary sequential loops -- DO CONCURRENT is a standard-mandated
  ! promise that iterations have no cross-dependencies, which is true
  ! for computing each word's own free/full status independently, but
  ! is NOT true for "find the smallest index where this holds," which
  ! genuinely depends on iteration order and must not be expressed as
  ! DO CONCURRENT even though a well-known reduction idiom (this
  ! mask-then-scan split) lets the independently-parallelizable part
  ! still benefit from vectorization.
  !
  ! LINEAR SCAN, NOT YET A FASTER STRUCTURE (e.g. a free-page count
  ! per bitmap word, or a stack of recently-freed pages): the search
  ! starts from PMM_LAST_ALLOC_WORD rather than word 0 every time,
  ! which is enough to keep repeated allocations from re-scanning
  ! already-exhausted low memory on every call, without the complexity
  ! of a proper free list. Revisit if allocation becomes a measured
  ! bottleneck -- not speculatively optimized further today.
  FUNCTION PMM_ALLOC_PAGE() BIND(C, NAME="pmm_alloc_page") RESULT(ADDR)
    INTEGER(C_INT64_T) :: ADDR
    INTEGER(C_INT64_T) :: W, B, PAGE_FRAME
    LOGICAL :: FOUND

    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(PMM_LOCK), 0_C_INT64_T))

    ADDR = -1_C_INT64_T
    FOUND = .FALSE.

    IF (PMM_FREE_PAGES > 0_C_INT64_T) THEN
      ! Vectorized: compute "does this word have a free bit" for
      ! EVERY word at once (no cross-iteration dependency -- each
      ! word's own bitmap content is all that determines its own mask
      ! entry), instead of the original version's word-by-word
      ! sequential check done as part of the same loop that also
      ! searched for the answer.
      DO CONCURRENT (W = 1_C_INT64_T : PMM_BITMAP_WORDS)
        PMM_SCAN_MASK(W) = LOGICAL(PMM_BITMAP(W) /= -1_C_INT64_T, C_BOOL)
      END DO

      ! Sequential: find the first TRUE entry from PMM_LAST_ALLOC_WORD
      ! onward (order-dependent, correctly NOT expressed as DO
      ! CONCURRENT -- see header comment).
      DO W = PMM_LAST_ALLOC_WORD, PMM_BITMAP_WORDS - 1_C_INT64_T
        IF (FOUND) EXIT
        IF (LOGICAL(PMM_SCAN_MASK(W + 1_C_INT64_T))) THEN
          DO B = 0_C_INT64_T, 63_C_INT64_T
            IF (.NOT. BTEST(PMM_BITMAP(W + 1_C_INT64_T), INT(B))) THEN
              PAGE_FRAME = W * 64_C_INT64_T + B
              CALL PMM_MARK_USED(PAGE_FRAME)
              PMM_LAST_ALLOC_WORD = W
              ADDR = PAGE_FRAME * PAGE_SIZE
              FOUND = .TRUE.
              EXIT
            END IF
          END DO
        END IF
      END DO

      ! Free pages exist (per PMM_FREE_PAGES) but none found from
      ! PMM_LAST_ALLOC_WORD onward -- they must be in an earlier word
      ! this scan skipped past on a previous call. Wrap around once.
      ! Reuses the SAME PMM_SCAN_MASK computed above -- no need to
      ! recompute it, since the bitmap has not changed between the
      ! two passes (still holding PMM_LOCK throughout).
      IF (.NOT. FOUND) THEN
        DO W = 0_C_INT64_T, PMM_LAST_ALLOC_WORD - 1_C_INT64_T
          IF (FOUND) EXIT
          IF (LOGICAL(PMM_SCAN_MASK(W + 1_C_INT64_T))) THEN
            DO B = 0_C_INT64_T, 63_C_INT64_T
              IF (.NOT. BTEST(PMM_BITMAP(W + 1_C_INT64_T), INT(B))) THEN
                PAGE_FRAME = W * 64_C_INT64_T + B
                CALL PMM_MARK_USED(PAGE_FRAME)
                PMM_LAST_ALLOC_WORD = W
                ADDR = PAGE_FRAME * PAGE_SIZE
                FOUND = .TRUE.
                EXIT
              END IF
            END DO
          END IF
        END DO
      END IF
    END IF

    ! SINGLE EXIT POINT, DELIBERATELY: this function was restructured
    ! from its original multiple-RETURN-statement form specifically so
    ! FORT0K_SPIN_UNLOCK is called exactly once, here, regardless of
    ! which path (found immediately, found after wraparound, or never
    ! found) was taken -- a lock acquired at entry and released at N
    ! different early-return points is a real, easy-to-introduce bug
    ! class (miss one path when the function is edited later, and the
    ! lock is held forever) this restructuring avoids by construction
    ! rather than by discipline alone.
    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(PMM_LOCK), 0_C_INT64_T))
  END FUNCTION PMM_ALLOC_PAGE

  ! PMM_FREE_PAGE(ADDR) -- returns a page to the free pool. ADDR must
  ! be a page-aligned physical address previously returned by
  ! PMM_ALLOC_PAGE; no double-free or foreign-address detection is
  ! implemented (would need per-page ownership tracking this project
  ! does not have yet) -- a double-free silently increments
  ! PMM_FREE_PAGES a second time for the same page, which is a real
  ! correctness gap worth being honest about rather than implying a
  ! safety this routine does not provide.
  SUBROUTINE PMM_FREE_PAGE(ADDR) BIND(C, NAME="pmm_free_page")
    INTEGER(C_INT64_T), INTENT(IN), VALUE :: ADDR
    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(PMM_LOCK), 0_C_INT64_T))
    CALL PMM_MARK_FREE(ADDR / PAGE_SIZE)
    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(PMM_LOCK), 0_C_INT64_T))
  END SUBROUTINE PMM_FREE_PAGE

END MODULE PMM
