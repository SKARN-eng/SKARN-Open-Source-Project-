! gdt.f90 -- Global Descriptor Table, built as a Fortran BIND(C)
! derived-type array rather than the throwaway hand-asm table boot.s
! used to get through the initial long-mode transition.
!
! RING0-BRIDGE-SPEC.md section 5's plan: hardware-mandated exact byte
! layout is achieved via BIND(C) derived types placed at a linker- or
! runtime-fixed address, the same idiom fort0's start.s used for its
! three captured stack-layout words. Confirmed this session (probe,
! not assumed): a BIND(C) derived type containing a single
! INTEGER(C_INT64_T) field, in a module-level array, produces exactly
! 8 bytes per entry with no compiler-inserted padding (nm/size
! confirmed: N entries -> exactly 8*N bytes in .bss).
!
! boot.s's own minimal GDT (gdt64 in that file) remains in place and
! is NOT replaced by this module for the long-mode transition itself
! -- that GDT only needs to exist for the handful of instructions
! between "paging enabled" and "call kernel_main", and rebuilding it
! in Fortran would need Fortran running before Fortran can run,
! which is not solvable. This module's table is loaded via
! GDT_INSTALL(), called early in kernel_main, and becomes the GDT for
! everything from that point on -- the boot.s table is used exactly
! once and then superseded.
MODULE GDT
  USE ISO_C_BINDING
  USE RING0
  USE TSS
  IMPLICIT NONE

  ! One INTEGER(C_INT64_T) per descriptor -- the raw 8-byte GDT entry
  ! encoding, built with IOR/ISHFT rather than bitfield sub-structuring,
  ! matching this project's general preference (RING0-BRIDGE-SPEC.md
  ! section 1) for explicit integer construction over compiler-managed
  ! bitfield layout wherever the two would otherwise be interchangeable.
  INTEGER, PARAMETER :: GDT_NUM_ENTRIES = 7
  ! 0: null, 1: kernel code, 2: kernel data, 3: user code, 4: user data
  ! (user segments built now, unused until a later stage has ring-3
  ! code to run -- cheaper to reserve the selectors now than to
  ! renumber every reference to KERNEL_DATA_SEL/KERNEL_CODE_SEL later)
  ! 5-6: the TSS descriptor (this session's user-mode work) -- a
  ! LONG-MODE TSS DESCRIPTOR IS 16 BYTES, TWO GDT SLOTS, not the 8
  ! bytes every other descriptor in this table uses -- confirmed via
  ! web search this session (AMD APM, Osdev-Notes): long mode widens
  ! the base-address field to a full 64 bits specifically so a TSS
  ! can be placed anywhere in the address space, which does not fit
  ! an ordinary 8-byte descriptor's base-address field width. Entry 6
  ! (index 6 in this array) holds the UPPER 32 bits of the base
  ! address plus a reserved word, per that same widened format --
  ! GDT_BUILD_ENTRY, built for ordinary 8-byte descriptors, is NOT
  ! reused for this -- see GDT_INSTALL's own TSS-specific construction
  ! below.

  TYPE, BIND(C) :: GDT_ENTRY_T
    INTEGER(C_INT64_T) :: RAW
  END TYPE GDT_ENTRY_T

  TYPE(GDT_ENTRY_T), TARGET :: GDT_TABLE(GDT_NUM_ENTRIES)
  BIND(C, NAME="gdt_table") :: GDT_TABLE

  ! Selector values -- byte offset into GDT_TABLE, matching the x86
  ! segment-selector encoding (index * 8, low 3 bits are RPL/TI and 0
  ! for every selector this project uses so far).
  INTEGER(C_INT16_T), PARAMETER :: KERNEL_CODE_SEL = 1_C_INT16_T * 8
  INTEGER(C_INT16_T), PARAMETER :: KERNEL_DATA_SEL = 2_C_INT16_T * 8

  ! USER_CODE_SEL/USER_DATA_SEL: added this session for user-mode
  ! entry. Unlike KERNEL_CODE_SEL/KERNEL_DATA_SEL, these have their
  ! low 2 bits (RPL, Requested Privilege Level) set to 3 -- required
  ! whenever a selector is loaded INTO CS/SS while actually running at
  ! ring 3 (the CPU checks RPL against the descriptor's own DPL and
  ! against CPL; a mismatch faults). Every OTHER selector this project
  ! has used until now (KERNEL_CODE_SEL/KERNEL_DATA_SEL) correctly
  ! left RPL=0 since this kernel has only ever run at ring 0 -- these
  ! two are the first selectors in this codebase where RPL is not
  ! simply "0 because everything so far has been ring 0."
  INTEGER(C_INT16_T), PARAMETER :: USER_CODE_SEL = 3_C_INT16_T * 8 + 3_C_INT16_T
  INTEGER(C_INT16_T), PARAMETER :: USER_DATA_SEL = 4_C_INT16_T * 8 + 3_C_INT16_T

CONTAINS

  ! GDT_BUILD_ENTRY(BASE, LIMIT, ACCESS, FLAGS) -- assembles one raw
  ! 8-byte GDT descriptor from its logical fields. Base/limit are
  ! mostly vestigial in 64-bit mode (the CPU ignores them for code/
  ! data segments under long mode, per the Intel SDM) but are still
  ! encoded correctly here rather than left as magic hex, so a future
  ! reader can see what each field means instead of reverse-engineering
  ! a literal the way boot.s's gdt64_code/gdt64_data comments had to
  ! gesture at without building.
  FUNCTION GDT_BUILD_ENTRY(BASE, LIMIT, ACCESS, FLAGS) RESULT(RAW)
    INTEGER(C_INT64_T), INTENT(IN) :: BASE
    INTEGER(C_INT64_T), INTENT(IN) :: LIMIT
    INTEGER(C_INT64_T), INTENT(IN) :: ACCESS
    INTEGER(C_INT64_T), INTENT(IN) :: FLAGS
    INTEGER(C_INT64_T) :: RAW

    RAW = IAND(LIMIT, INT(Z'FFFF', C_INT64_T))
    RAW = IOR(RAW, ISHFT(IAND(BASE, INT(Z'FFFFFF', C_INT64_T)), 16))
    RAW = IOR(RAW, ISHFT(IAND(ACCESS, INT(Z'FF', C_INT64_T)), 40))
    RAW = IOR(RAW, ISHFT(IAND(LIMIT, INT(Z'F0000', C_INT64_T)), 32))
    RAW = IOR(RAW, ISHFT(IAND(FLAGS, INT(Z'F', C_INT64_T)), 52))
    RAW = IOR(RAW, ISHFT(IAND(ISHFT(BASE, -24), INT(Z'FF', C_INT64_T)), 56))
  END FUNCTION GDT_BUILD_ENTRY

  ! GDT_INSTALL() -- build all entries, load via lgdt, reload segment
  ! registers. Called once from kernel_main, early.
  SUBROUTINE GDT_INSTALL() BIND(C, NAME="gdt_install")
    ! Access byte bit layout: present(1) | DPL(2) | S(1) | type(4)
    ! Kernel code: present, DPL=0, S=1 (code/data), exec+read = 0x9A
    ! Kernel data: present, DPL=0, S=1, read/write             = 0x92
    ! Flags nibble: G(granularity) | D/B(0 in long mode) | L(long
    ! mode, 1 for code) | AVL(0). Code: G=1,L=1 -> 0xA. Data: G=1,L=0
    ! (L is CPU-defined for code segments only) -> 0xC.
    GDT_TABLE(1)%RAW = 0_C_INT64_T   ! null descriptor, mandatory
    GDT_TABLE(2)%RAW = GDT_BUILD_ENTRY(0_C_INT64_T, INT(Z'FFFFF', C_INT64_T), &
                                        INT(Z'9A', C_INT64_T), INT(Z'A', C_INT64_T))
    GDT_TABLE(3)%RAW = GDT_BUILD_ENTRY(0_C_INT64_T, INT(Z'FFFFF', C_INT64_T), &
                                        INT(Z'92', C_INT64_T), INT(Z'C', C_INT64_T))
    ! User segments (DPL=3): reserved now, unused until ring 3 exists.
    GDT_TABLE(4)%RAW = GDT_BUILD_ENTRY(0_C_INT64_T, INT(Z'FFFFF', C_INT64_T), &
                                        INT(Z'FA', C_INT64_T), INT(Z'A', C_INT64_T))
    GDT_TABLE(5)%RAW = GDT_BUILD_ENTRY(0_C_INT64_T, INT(Z'FFFFF', C_INT64_T), &
                                        INT(Z'F2', C_INT64_T), INT(Z'C', C_INT64_T))

    ! TSS descriptor (this session's user-mode work): 16 bytes, two
    ! GDT slots -- NOT built via GDT_BUILD_ENTRY, which only knows the
    ! ordinary 8-byte descriptor shape. Long-mode TSS descriptor
    ! layout, confirmed via web search this session (AMD APM):
    !   Slot 1 (low 8 bytes): limit[15:0] | base[23:0] | type=0x89
    !     (present, DPL=0, type=1001=64-bit TSS available) | limit
    !     [19:16]/flags | base[31:24] -- same BIT positions as an
    !     ordinary descriptor's first 8 bytes, but TYPE is 0x89 (a TSS
    !     descriptor, not code/data) rather than 0x9A/0x92/etc.
    !   Slot 2 (high 8 bytes): base[63:32] in the LOW 32 bits, then 32
    !     reserved bits (must be zero).
    ! LIMIT set to TSS_SIZE-1 (tss.f90's confirmed 104-byte structure,
    ! so limit=103=0x67) -- the TSS's own byte extent, not the usual
    ! 0xFFFFF "cover all memory" convention this project's other
    ! descriptors use, since a TSS descriptor's limit genuinely bounds
    ! the real, fixed-size structure it points at.
    BLOCK
      INTEGER(C_INT64_T) :: TSS_BASE
      INTEGER(C_INT64_T) :: LOW, HIGH
      TSS_BASE = TRANSFER(C_LOC(TSS_TABLE(1)), TSS_BASE)

      LOW = IAND(INT(TSS_SIZE - 1, C_INT64_T), INT(Z'FFFF', C_INT64_T))
      LOW = IOR(LOW, ISHFT(IAND(TSS_BASE, INT(Z'FFFFFF', C_INT64_T)), 16))
      LOW = IOR(LOW, ISHFT(INT(Z'89', C_INT64_T), 40))
      LOW = IOR(LOW, ISHFT(IAND(ISHFT(TSS_BASE, -24), INT(Z'FF', C_INT64_T)), 56))
      GDT_TABLE(6)%RAW = LOW

      HIGH = IAND(ISHFT(TSS_BASE, -32), INT(Z'FFFFFFFF', C_INT64_T))
      GDT_TABLE(7)%RAW = HIGH
    END BLOCK

    CALL FORT0K_LGDT(INT(GDT_NUM_ENTRIES * 8 - 1, C_INT16_T), &
                      TRANSFER(C_LOC(GDT_TABLE(1)), 0_C_INT64_T))
    CALL FORT0K_RELOAD_SEGMENTS(KERNEL_CODE_SEL, KERNEL_DATA_SEL)
  END SUBROUTINE GDT_INSTALL

END MODULE GDT
