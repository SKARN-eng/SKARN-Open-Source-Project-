! serial.f90 -- minimal 16550 UART driver, COM1 (port 0x3F8), polled
! (no interrupts -- none are enabled yet, and this exists specifically
! to debug the boot path before an IDT is trustworthy, so it cannot
! itself depend on interrupts working).
!
! This is not a stage-0-only debug hack meant for deletion: a serial
! console is the standard way to get trustworthy kernel output before
! (and alongside) a screen, since QEMU/real hardware can log it to a
! file with zero risk of a VGA-layer bug making a real failure look
! like a hang. Kept as permanent infrastructure.
!
! Register layout (offsets from the port base, standard 16550):
!   +0 (DLAB=0): data register (read: RX, write: TX)
!   +1 (DLAB=0): interrupt enable register
!   +0 (DLAB=1): divisor latch low byte
!   +1 (DLAB=1): divisor latch high byte
!   +2: FIFO control register (write) / interrupt ID (read)
!   +3: line control register (LCR) -- bit 7 is DLAB
!   +4: modem control register (MCR)
!   +5: line status register (LSR) -- bit 5 = transmit holding register empty
MODULE SERIAL
  USE ISO_C_BINDING
  USE RING0
  IMPLICIT NONE

  INTEGER(C_INT16_T), PARAMETER :: COM1_BASE = INT(Z'03F8', C_INT16_T)

  INTEGER(C_INT32_T), TARGET :: SERIAL_LOCK = 0
  BIND(C, NAME="serial_lock") :: SERIAL_LOCK
  ! Added alongside sched.f90's READY_QUEUE_LOCK, this codebase's
  ! first two real spinlock uses: this project's serial output was
  ! flagged as a known gap (smp.f90's AP_MAIN comment) the moment more
  ! than one core could genuinely run concurrently and both try to
  ! print -- true starting with the scheduler's multi-core checkpoint.
  ! Locked at SERIAL_PUTS_NL's granularity (one whole logical message,
  ! not per-character) so two cores' messages interleave as complete
  ! lines, never as intermixed bytes within a line.

CONTAINS

  ! SERIAL_INIT() -- 38400 baud, 8 data bits, no parity, 1 stop bit.
  ! Divisor for 38400 baud = 115200 / 38400 = 3.
  SUBROUTINE SERIAL_INIT() BIND(C, NAME="serial_init")
    CALL FORT0K_OUTB(COM1_BASE + 1_C_INT16_T, 0_C_INT8_T)        ! disable interrupts
    CALL FORT0K_OUTB(COM1_BASE + 3_C_INT16_T, INT(Z'80', C_INT8_T)) ! LCR: DLAB=1
    CALL FORT0K_OUTB(COM1_BASE + 0_C_INT16_T, 3_C_INT8_T)        ! divisor low = 3
    CALL FORT0K_OUTB(COM1_BASE + 1_C_INT16_T, 0_C_INT8_T)        ! divisor high = 0
    CALL FORT0K_OUTB(COM1_BASE + 3_C_INT16_T, 3_C_INT8_T)        ! LCR: 8N1, DLAB=0
    CALL FORT0K_OUTB(COM1_BASE + 2_C_INT16_T, INT(Z'C7', C_INT8_T)) ! enable FIFO, clear, 14-byte threshold
    CALL FORT0K_OUTB(COM1_BASE + 4_C_INT16_T, INT(Z'0B', C_INT8_T)) ! IRQs disabled, RTS/DSR set
  END SUBROUTINE SERIAL_INIT

  ! SERIAL_TX_READY() -- .TRUE. when the transmit holding register is
  ! empty (safe to write the next byte). Polled busy-wait, matching
  ! this module's header comment: no interrupts available yet.
  LOGICAL FUNCTION SERIAL_TX_READY()
    INTEGER(C_INT8_T) :: LSR
    LSR = FORT0K_INB(COM1_BASE + 5_C_INT16_T)
    SERIAL_TX_READY = IAND(INT(LSR), INT(Z'20')) /= 0
  END FUNCTION SERIAL_TX_READY

  ! SERIAL_PUTC(CH) -- write one byte, busy-waiting for the transmit
  ! holding register to be empty first.
  SUBROUTINE SERIAL_PUTC(CH) BIND(C, NAME="serial_putc")
    INTEGER(C_INT8_T), INTENT(IN), VALUE :: CH
    DO WHILE (.NOT. SERIAL_TX_READY())
      CONTINUE
    END DO
    CALL FORT0K_OUTB(COM1_BASE, CH)
  END SUBROUTINE SERIAL_PUTC

  ! SERIAL_PUTS(STR, SLEN) -- write SLEN characters, no string
  ! intrinsics per CALL-BRIDGE-SPEC.md section 4 (element-wise only).
  SUBROUTINE SERIAL_PUTS(STR, SLEN) BIND(C, NAME="serial_puts")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: SLEN
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(IN) :: STR(SLEN)
    INTEGER :: I
    DO I = 1, SLEN
      CALL SERIAL_PUTC(INT(IACHAR(STR(I)), C_INT8_T))
    END DO
  END SUBROUTINE SERIAL_PUTS

  ! SERIAL_PUTS_NL(STR, SLEN) -- SERIAL_PUTS followed by CRLF (real
  ! serial terminals/loggers expect CR before LF, not LF alone).
  ! Locked (SERIAL_LOCK) for the entire message + CRLF, so two cores
  ! calling this concurrently produce two complete, non-interleaved
  ! lines rather than intermixed bytes.
  SUBROUTINE SERIAL_PUTS_NL(STR, SLEN) BIND(C, NAME="serial_puts_nl")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: SLEN
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(IN) :: STR(SLEN)
    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(SERIAL_LOCK), 0_C_INT64_T))
    CALL SERIAL_PUTS(STR, SLEN)
    CALL SERIAL_PUTC(13_C_INT8_T)   ! CR
    CALL SERIAL_PUTC(10_C_INT8_T)   ! LF
    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(SERIAL_LOCK), 0_C_INT64_T))
  END SUBROUTINE SERIAL_PUTS_NL

END MODULE SERIAL
