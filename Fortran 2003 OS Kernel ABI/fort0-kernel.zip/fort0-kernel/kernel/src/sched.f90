! sched.f90 -- Task Control Block layout, task table, and the ready
! queue. Context switching itself (the actual register save/restore)
! is asm (sched_switch.s) -- this module owns the data, that file
! owns the mechanism, matching this project's general split between
! "Fortran knows data layout" and "asm knows registers/instructions"
! (RING0-BRIDGE-SPEC.md's stated preference, applied here to a new
! primitive family).
!
! TCB_REGS_T's field layout is byte-offset-probed this session
! (objdump on a linked probe): all INTEGER(C_INT64_T) fields, packed
! with zero padding at every offset checked (RSP@120, RIP@128,
! RFLAGS@136, total size 144) -- confirms this specific field-count/
! shape is safe as BIND(C), independently of the similar-looking
! INTERRUPT_FRAME_T (interrupts.f90) or PT_ENTRY_T (vmm.f90) findings,
! per RING0-BRIDGE-SPEC.md section 1's standing rule that packing
! findings do not generalize across different field-count/shape
! structures without their own check.
MODULE SCHED
  USE ISO_C_BINDING
  USE RING0
  USE PMM
  USE SERIAL
  USE ACPI
  USE APIC
  USE INTERRUPTS
  USE TIMER
  USE VMM
  USE GDT
  IMPLICIT NONE

  ! Saved register set for one task. Deliberately does NOT include
  ! the segment registers (CS/DS/ES/FS/GS/SS) or CR3 -- every task in
  ! this stage runs in ring 0, sharing the one kernel PML4
  ! VMM_CURRENT_PML4 already established (no per-task address space
  ! yet, matching this project's current single-address-space design
  ! -- see vmm.f90's VMM_CURRENT_PML4 comment for the same "real
  ! future need, not solved today" framing applied to that layer).
  ! Adding a per-task CR3/segment set is real future work once
  ! per-task address spaces exist, not attempted in this pass.
  TYPE, BIND(C) :: TCB_REGS_T
    INTEGER(C_INT64_T) :: R15, R14, R13, R12, R11, R10, R9, R8
    INTEGER(C_INT64_T) :: RDI, RSI, RBP, RBX, RDX, RCX, RAX
    INTEGER(C_INT64_T) :: RSP, RIP, RFLAGS
    INTEGER(C_INT64_T) :: CR3
    ! CR3: added in an earlier pass this session -- the real,
    ! previously-flagged gap (this file's own earlier header comment
    ! on TCB_REGS_T, and sched.f90's own TCB_T comment) preventing
    ! per-task address-space isolation, the actual prerequisite for
    ! user mode/ring 3 meaning anything. Byte offset (144/0x90)
    ! CONFIRMED via a direct byte-offset probe before sched_switch.s's
    ! asm below was written against it -- not assumed from the field
    ! list alone. Total struct size at THIS point in the type's
    ! history was 152/0x98; see below for the fields added afterward,
    ! which changed it again -- re-verify the CURRENT total (this
    ! comment does not restate it a second time to avoid two sources
    ! of truth going stale independently).
    INTEGER(C_INT64_T) :: CS, SS
    INTEGER(C_INT32_T) :: PRIVILEGE_RING
    ! CS/SS/PRIVILEGE_RING: added this session, the actual prerequisite
    ! for a SCHEDULED task to correctly run and resume at ring 3 (user
    ! mode entry itself, sections 31-33, proved the MECHANISM works,
    ! but only for a standalone, non-scheduled test -- a real scheduled
    ! ring-3 task needs its own CS/SS remembered across a switch, since
    ! `fort0k_context_switch`'s existing `jmp *%rax` resume path
    ! preserves whatever ring/segment the SWITCHING code is currently
    ! running at, not what the task itself needs). Offsets (CS@152/
    ! 0x98, SS@160/0xA0, PRIVILEGE_RING@168/0xA8, total size 176/0xB0)
    ! CONFIRMED via the same byte-offset-probe technique, before any
    ! new asm was written against them. PRIVILEGE_RING (0 or 3) is a
    ! Fortran-side-only bookkeeping field -- NOT read by
    ! fort0k_context_switch itself, which instead branches on whether
    ! the SAVED CS value's low 2 bits (RPL) indicate ring 3, the
    ! actual authoritative signal the CPU itself would use; kept as a
    ! separate, explicit field anyway so Fortran-side code (task
    ! creation, scheduler queries) can check a task's privilege level
    ! without needing to decode CS's RPL bits itself every time.
  END TYPE TCB_REGS_T

  INTEGER, PARAMETER :: TASK_STATE_UNUSED  = 0
  INTEGER, PARAMETER :: TASK_STATE_READY   = 1
  INTEGER, PARAMETER :: TASK_STATE_RUNNING = 2
  INTEGER, PARAMETER :: TASK_STATE_ZOMBIE  = 3
  ! ZOMBIE: a task that has called SCHED_EXIT_TASK on itself -- marked
  ! for destruction but NOT YET actually cleaned up (TASK_TABLE slot
  ! not yet reset to UNUSED, stack not yet freed). The real hazard
  ! this state exists to avoid: a task cannot free its own stack and
  ! then keep running on it -- that is a use-after-free of the exact
  ! memory currently holding this task's own call frame, registers-
  ! about-to-be-saved, and the return address the eventual context
  ! switch away from it needs to read. SCHED_EXIT_TASK therefore only
  ! marks the state and immediately switches away (never returns);
  ! the ACTUAL cleanup (PMM_FREE_PAGE on the stack, resetting the slot
  ! to UNUSED) happens later, from SCHED_REAP_ZOMBIES, called from a
  ! DIFFERENT task's context (never the zombie's own), once it is
  ! genuinely safe -- i.e. once that task has been switched away from
  ! and is not the CURRENTLY RUNNING task on ANY core (checked via
  ! CURRENT_TASK_INDEX, not merely "not RUNNING" locally, since with
  ! multiple cores a task's own STATE field and which core currently
  ! has it loaded are two different, both-necessary things to check).
  ! No TASK_STATE_BLOCKED yet -- every task in this stage is either
  ! runnable or not created; blocking on I/O/a lock is real future
  ! work once something exists worth blocking on (add-only-when-
  ! needed).

  TYPE, BIND(C) :: TCB_T
    TYPE(TCB_REGS_T) :: REGS
    INTEGER(C_INT32_T) :: STATE
    INTEGER(C_INT32_T) :: TASK_ID
    INTEGER(C_INT64_T) :: STACK_BASE_PHYS
    ! STACK_BASE_PHYS: the physical page PMM_ALLOC_PAGE returned for
    ! this task's stack, kept so a future SCHED_DESTROY_TASK (not
    ! built yet -- no task in this stage ever exits) can free it via
    ! PMM_FREE_PAGE. Not the current stack pointer -- REGS%RSP is
    ! that, and moves as the task runs; this field is fixed at
    ! creation and only ever used for eventual cleanup.
    INTEGER(C_INT64_T) :: RUN_COUNT
    INTEGER(C_INT64_T) :: LAST_SCHEDULED_TICK
    ! RUN_COUNT/LAST_SCHEDULED_TICK: added for SCHED_NN's scoring
    ! policy (sched_nn.f90) -- real scheduling-decision inputs, not
    ! placeholder/demo fields. RUN_COUNT increments once per switch
    ! INTO this task (SCHED_YIELD, SCHED_PREEMPT_TICK, SCHED_START);
    ! LAST_SCHEDULED_TICK is set to TIMER's TICK_COUNT at the same
    ! moments, letting a scoring function compute "how long has this
    ! task been waiting" as (current tick - LAST_SCHEDULED_TICK)
    ! without this module needing its own separate wall-clock
    ! mechanism. APPENDED AFTER every existing field, deliberately:
    ! REGS stays at byte offset 0, which sched_switch.s's asm and
    ! every SCHED_START/SCHED_YIELD/SCHED_PREEMPT_TICK call site
    ! depends on via C_LOC(TASK_TABLE(I)%REGS) -- adding fields after
    ! REGS cannot change REGS's own offset or size, confirmed by the
    ! same reasoning (BIND(C) types lay out fields in declaration
    ! order with no reordering) already relied on throughout this
    ! codebase, not re-verified by a fresh probe since it follows
    ! directly from BIND(C)'s own defined semantics rather than being
    ! a new, uncertain claim.
  END TYPE TCB_T

  INTEGER, PARAMETER :: SCHED_MAX_TASKS = 64
  ! Fixed upper bound, same "no dynamic allocation needed for this
  ! table to exist" reasoning as every other fixed-size table in this
  ! codebase (PMM_BITMAP, ACPI_CPU_APIC_IDS, ...) -- 64 is far beyond
  ! anything this stage's demo workload needs; revisit only if a
  ! genuine need for more arises.

  TYPE(TCB_T), TARGET :: TASK_TABLE(SCHED_MAX_TASKS)
  BIND(C, NAME="task_table") :: TASK_TABLE

  INTEGER(C_INT32_T) :: SCHED_NEXT_TASK_ID = 0
  BIND(C, NAME="sched_next_task_id") :: SCHED_NEXT_TASK_ID

  ! READY_QUEUE: a fixed-size ring buffer of task-table INDICES (not
  ! TCB_T values themselves -- indices are cheap to move, the TCB
  ! stays put in TASK_TABLE), read/written by every core concurrently
  ! once multiple cores are scheduling -- this is the first genuinely
  ! shared, concurrently-mutated structure in this codebase (every
  ! prior shared structure -- AP_STARTED_FLAGS, the PMM bitmap during
  ! SMP bring-up -- was written by exactly one core at a time, by
  ! this project's own wake-sequence design). Protected by
  ! SCHED_QUEUE_LOCK (sched_lock.s) -- a real spinlock, this
  ! project's first, built and verified in isolation before this
  ! module's own queue operations use it (see that file).
  INTEGER(C_INT32_T) :: READY_QUEUE(SCHED_MAX_TASKS)
  BIND(C, NAME="ready_queue") :: READY_QUEUE
  INTEGER(C_INT32_T) :: READY_QUEUE_HEAD = 0
  BIND(C, NAME="ready_queue_head") :: READY_QUEUE_HEAD
  INTEGER(C_INT32_T) :: READY_QUEUE_TAIL = 0
  BIND(C, NAME="ready_queue_tail") :: READY_QUEUE_TAIL
  INTEGER(C_INT32_T) :: READY_QUEUE_COUNT = 0
  BIND(C, NAME="ready_queue_count") :: READY_QUEUE_COUNT

  INTEGER(C_INT32_T), TARGET :: READY_QUEUE_LOCK = 0
  BIND(C, NAME="ready_queue_lock") :: READY_QUEUE_LOCK
  ! Protects READY_QUEUE/_HEAD/_TAIL/_COUNT together as one unit --
  ! every operation that reads or writes any of them must hold this
  ! lock for its entire read-modify-write sequence, not just the
  ! final store, or two cores could still race between reading a
  ! stale COUNT and acting on it. SCHED_ENQUEUE/SCHED_DEQUEUE below
  ! are the only code in this codebase permitted to touch these four
  ! variables directly, specifically so "every access goes through
  ! the lock" is enforced by having exactly one gatekeeper each,
  ! rather than needing to audit every call site across the codebase
  ! for correct lock discipline.

  ! CURRENT_TASK_INDEX(CORE) -- which TASK_TABLE index each core is
  ! currently running, indexed by core index (0-based, same indexing
  ! smp.f90's AP_STARTED_FLAGS already uses -- BSP is index 0). -1
  ! means "this core is not yet running any task" (still in its
  ! pre-scheduler idle/setup code). Per-core, not a single shared
  ! variable, since every core genuinely has its own independent
  ! "currently running" answer -- this is NOT a structure needing the
  ! spinlock READY_QUEUE uses, since each core only ever writes its
  ! own element (matching AP_STARTED_FLAGS's existing, already-
  ! reasoned-about pattern from smp.f90).
  INTEGER(C_INT32_T) :: CURRENT_TASK_INDEX(ACPI_MAX_CPUS) = -1
  BIND(C, NAME="current_task_index") :: CURRENT_TASK_INDEX
  ! Same fix, same reasoning as smp.f90's AP_STARTED_FLAGS (found in
  ! the same cross-file check this session): previously a hardcoded
  ! literal 64, now references ACPI_MAX_CPUS directly so this array
  ! cannot silently desync from the actual maximum core count this
  ! project supports.

  ! SCHED_DEQUEUE_HOOK -- procedure pointer, NULL by default, that
  ! SCHED_YIELD/SCHED_PREEMPT_TICK call INSTEAD OF SCHED_DEQUEUE when
  ! set. This is how a scored (or any future alternative) dequeue
  ! policy is wired into REAL scheduling decisions without touching
  ! SCHED_DEQUEUE itself, which stays exactly as-is (plain FIFO,
  ! proven, unmodified) as the always-available fallback -- this
  ! module has no compile-time dependency on sched_nn.f90 (the
  ! dependency runs the other way, sched_nn.f90 -> sched.f90, and
  ! stays that way), so the hook is the only mechanism by which a
  ! scoring policy defined elsewhere can actually change which task
  ! runs next. Declared here, in the module's specification part
  ! (before CONTAINS) -- ABSTRACT INTERFACE/procedure-pointer
  ! declarations are not executable statements and cannot appear
  ! inside CONTAINS, a real compile error caught immediately the
  ! first time this was placed incorrectly this session.
  ABSTRACT INTERFACE
    FUNCTION DEQUEUE_HOOK_T() RESULT(R)
      INTEGER :: R
    END FUNCTION DEQUEUE_HOOK_T
  END INTERFACE
  PROCEDURE(DEQUEUE_HOOK_T), POINTER :: SCHED_DEQUEUE_HOOK => NULL()

  ! CORE_IDLE_TASK_INDEX(core) -- each core's dedicated idle task's
  ! TASK_TABLE index, or -1 if that core has none yet. A REAL,
  ! SCHEDULED task (not a bare HLT loop a core falls into OUTSIDE the
  ! scheduler, which is what this project had before -- see
  ! kernel_main.f90's IDLE_LOOP, which remains, unrelated, for the
  ! separate case of a core that never entered the scheduler at all)
  ! -- existing specifically so SCHED_EXIT_TASK always has a safe
  ! switch-to target even when the ready queue is genuinely empty. One
  ! per core, created lazily (SCHED_ENSURE_IDLE_TASK) the first time a
  ! core actually needs one, rather than unconditionally at boot for
  ! every possible core index whether or not that core ever runs the
  ! scheduler. Declared here, in the module's specification part --
  ! the same misplaced-declaration-inside-CONTAINS error already
  ! caught once this session for SCHED_DEQUEUE_HOOK was hit again for
  ! this variable and fixed the same way.
  INTEGER :: CORE_IDLE_TASK_INDEX(ACPI_MAX_CPUS) = -1

CONTAINS

  ! SCHED_CREATE_TASK(ENTRY_ADDR) -- allocates a stack (one page, via
  ! PMM_ALLOC_PAGE, same convention smp.f90's per-core AP stacks use),
  ! finds an unused TASK_TABLE slot, and initializes a TCB whose
  ! REGS%RIP is ENTRY_ADDR and REGS%RSP is the top of the new stack --
  ! ready to be switched into via FORT0K_CONTEXT_SWITCH the first
  ! time a scheduler decision picks it, exactly as if it had already
  ! been running and voluntarily called a function that immediately
  ! returned (the standard "fake initial stack frame" trick every
  ! reference kernel scheduler uses, so the FIRST switch into a new
  ! task needs no special-casing in the switch primitive itself).
  !
  ! REGS%RFLAGS is initialized with IF (interrupt flag) SET -- a task
  ! that begins running with interrupts disabled would never be
  ! preemptible, defeating the point of a preemptive scheduler before
  ! it ever got a chance to run.
  FUNCTION SCHED_CREATE_TASK(ENTRY_ADDR) RESULT(TASK_INDEX)
    INTEGER(C_INT64_T), INTENT(IN) :: ENTRY_ADDR
    INTEGER :: TASK_INDEX
    INTEGER :: I
    INTEGER(C_INT64_T) :: STACK_PHYS

    TASK_INDEX = -1
    DO I = 1, SCHED_MAX_TASKS
      IF (TASK_TABLE(I)%STATE == TASK_STATE_UNUSED) THEN
        TASK_INDEX = I
        EXIT
      END IF
    END DO
    IF (TASK_INDEX < 0) RETURN   ! task table full

    STACK_PHYS = PMM_ALLOC_PAGE()
    IF (STACK_PHYS < 0_C_INT64_T) THEN
      TASK_INDEX = -1
      RETURN   ! out of memory
    END IF

    TASK_TABLE(TASK_INDEX)%REGS%R15 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R14 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R13 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R12 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R11 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R10 = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R9  = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%R8  = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RDI = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RSI = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RBP = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RBX = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RDX = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RCX = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RAX = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RSP = STACK_PHYS + 4096_C_INT64_T
    TASK_TABLE(TASK_INDEX)%REGS%RIP = ENTRY_ADDR
    TASK_TABLE(TASK_INDEX)%REGS%RFLAGS = INT(Z'002', C_INT64_T)
    TASK_TABLE(TASK_INDEX)%REGS%CR3 = VMM_CURRENT_PML4
    ! CR3: every task created today shares the SAME kernel PML4
    ! (VMM_CURRENT_PML4, vmm.f90 -- the one, shared address space this
    ! project has had since Stage 4), correctly and deliberately --
    ! this field's plumbing (this line, plus sched_switch.s's now-
    ! real save/conditional-restore logic) is being proven safe in
    ! the always-identical-CR3 case FIRST, before anything actually
    ! creates a task with a genuinely different address space, which
    ! is real, separate future work (giving a task its own PML4,
    ! built via vmm.f90's existing page-table machinery, is a bigger
    ! step than adding the field and switch-primitive support for it).

    TASK_TABLE(TASK_INDEX)%REGS%CS = KERNEL_CODE_SEL
    TASK_TABLE(TASK_INDEX)%REGS%SS = KERNEL_DATA_SEL
    TASK_TABLE(TASK_INDEX)%REGS%PRIVILEGE_RING = 0
    ! CS/SS/PRIVILEGE_RING: added this session, explicitly, for every
    ! task -- ring 0 by default, matching every task this project has
    ! ever created. Previously these fields were left at Fortran's
    ! default zero-initialization, which happened to be harmless only
    ! because the ORIGINAL switch primitive's ring-0 `jmp` path never
    ! read CS/SS at all -- now that sched_switch.s branches on the
    ! SAVED CS's RPL bits (the new ring3_resume path), leaving CS at 0
    ! would be read as RPL=0 by coincidence (0 AND 3 = 0), which is
    ! actually still correct for ring 0's own case, but stating it
    ! explicitly here removes the "correct by accident" property in
    ! favor of "correct because it says so." See SCHED_CREATE_TASK_
    ! USERMODE below for the ring-3 variant that sets these
    ! differently.

    TASK_TABLE(TASK_INDEX)%STATE = TASK_STATE_READY
    SCHED_NEXT_TASK_ID = SCHED_NEXT_TASK_ID + 1
    TASK_TABLE(TASK_INDEX)%TASK_ID = SCHED_NEXT_TASK_ID
    TASK_TABLE(TASK_INDEX)%STACK_BASE_PHYS = STACK_PHYS
    TASK_TABLE(TASK_INDEX)%RUN_COUNT = 0_C_INT64_T
    TASK_TABLE(TASK_INDEX)%LAST_SCHEDULED_TICK = TICK_COUNT
  END FUNCTION SCHED_CREATE_TASK

  ! SCHED_CREATE_TASK_USERMODE(ENTRY_ADDR) -- ring-3-aware variant of
  ! SCHED_CREATE_TASK. Two REAL differences from the ring-0 version,
  ! both prerequisites confirmed necessary by direct testing/research
  ! this session, not guessed:
  !   1. CS/SS are set to USER_CODE_SEL/USER_DATA_SEL (gdt.f90),
  !      RPL=3 already baked into those constants -- this is the
  !      field sched_switch.s's ring3_resume path branches on.
  !   2. The task's stack page is explicitly remapped with PTE_USER
  !      added (vmm.f90) -- confirmed this session (RING0-BRIDGE-
  !      SPEC.md sections 31-33) that EVERY page in this project is
  !      Supervisor-only by default; a ring-3 task's own stack must be
  !      user-accessible or it faults the instant it tries to push
  !      anything, which a task does immediately (its own compiled
  !      prologue, before executing a single meaningful instruction).
  !      The task's CODE page is NOT remapped here -- that remains the
  !      caller's responsibility (matching kernel_main.f90's
  !      USERMODE_TEST, which remaps its own code page before calling
  !      FORT0K_ENTER_USERMODE) since SCHED_CREATE_TASK_USERMODE has
  !      no way to know the code's actual extent, only its entry
  !      address.
  FUNCTION SCHED_CREATE_TASK_USERMODE(ENTRY_ADDR) RESULT(TASK_INDEX)
    INTEGER(C_INT64_T), INTENT(IN) :: ENTRY_ADDR
    INTEGER :: TASK_INDEX

    TASK_INDEX = SCHED_CREATE_TASK(ENTRY_ADDR)
    IF (TASK_INDEX < 1) RETURN

    TASK_TABLE(TASK_INDEX)%REGS%CS = USER_CODE_SEL
    TASK_TABLE(TASK_INDEX)%REGS%SS = USER_DATA_SEL
    TASK_TABLE(TASK_INDEX)%REGS%PRIVILEGE_RING = 3

    CALL VMM_MAP_4K(VMM_CURRENT_PML4, &
                     TASK_TABLE(TASK_INDEX)%STACK_BASE_PHYS, &
                     TASK_TABLE(TASK_INDEX)%STACK_BASE_PHYS, &
                     IOR(PTE_PRESENT, IOR(PTE_WRITABLE, PTE_USER)))
  END FUNCTION SCHED_CREATE_TASK_USERMODE

  ! SCHED_ENQUEUE(TASK_INDEX) / SCHED_DEQUEUE() -- ready-queue
  ! operations, now protected by READY_QUEUE_LOCK -- checkpoint 2's
  ! actual change from checkpoint 1's single-core-safe versions (this
  ! file's earlier comment on that staging is now out of date on this
  ! specific point; left as historical context on why these were ever
  ! unprotected rather than deleted, since the reasoning for building
  ! it that way first was sound and is worth keeping legible).
  SUBROUTINE SCHED_ENQUEUE(TASK_INDEX)
    INTEGER, INTENT(IN) :: TASK_INDEX
    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))

    IF (READY_QUEUE_COUNT >= SCHED_MAX_TASKS) THEN
      CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
      RETURN   ! queue full, drop -- should not happen given
                ! SCHED_MAX_TASKS bounds both tables identically
    END IF

    READY_QUEUE_TAIL = READY_QUEUE_TAIL + 1
    IF (READY_QUEUE_TAIL > SCHED_MAX_TASKS) READY_QUEUE_TAIL = 1
    READY_QUEUE(READY_QUEUE_TAIL) = TASK_INDEX
    READY_QUEUE_COUNT = READY_QUEUE_COUNT + 1

    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
  END SUBROUTINE SCHED_ENQUEUE

  FUNCTION SCHED_DEQUEUE() RESULT(TASK_INDEX)
    INTEGER :: TASK_INDEX
    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))

    IF (READY_QUEUE_COUNT <= 0) THEN
      TASK_INDEX = -1
      CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
      RETURN
    END IF

    READY_QUEUE_HEAD = READY_QUEUE_HEAD + 1
    IF (READY_QUEUE_HEAD > SCHED_MAX_TASKS) READY_QUEUE_HEAD = 1
    TASK_INDEX = READY_QUEUE(READY_QUEUE_HEAD)
    READY_QUEUE_COUNT = READY_QUEUE_COUNT - 1

    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
  END FUNCTION SCHED_DEQUEUE

  ! SCHED_DEQUEUE_HOOK -- procedure pointer, NULL by default, that
  ! SCHED_YIELD/SCHED_PREEMPT_TICK call INSTEAD OF SCHED_DEQUEUE when
  ! set. This is how a scored (or any future alternative) dequeue
  ! policy is wired into REAL scheduling decisions without touching
  ! SCHED_DEQUEUE itself, which stays exactly as-is (plain FIFO,
  ! proven, unmodified) as the always-available fallback -- this
  ! module has no compile-time dependency on sched_nn.f90 (the
  ! dependency runs the other way, sched_nn.f90 -> sched.f90, and
  ! stays that way), so the hook is the only mechanism by which a
  ! scoring policy defined elsewhere can actually change which task
  ! runs next.

  ! SCHED_DEQUEUE_ACTIVE() -- the ACTUAL function SCHED_YIELD/
  ! SCHED_PREEMPT_TICK call: uses SCHED_DEQUEUE_HOOK if one is
  ! registered, otherwise falls back to plain SCHED_DEQUEUE. Every
  ! existing call site that used to call SCHED_DEQUEUE directly now
  ! calls this instead -- a single, obvious place where "which
  ! dequeue policy is active" is decided, rather than that decision
  ! being duplicated at every call site.
  FUNCTION SCHED_DEQUEUE_ACTIVE() RESULT(TASK_INDEX)
    INTEGER :: TASK_INDEX
    IF (ASSOCIATED(SCHED_DEQUEUE_HOOK)) THEN
      TASK_INDEX = SCHED_DEQUEUE_HOOK()
    ELSE
      TASK_INDEX = SCHED_DEQUEUE()
    END IF
  END FUNCTION SCHED_DEQUEUE_ACTIVE

  ! SCHED_DEQUEUE_SCORED_IMPL(SCORE_FN) -- a real, general scored-
  ! selection dequeue: given a caller-supplied scoring function
  ! (SCORE_FN(TASK_INDEX) -> REAL(C_DOUBLE)), removes and returns the
  ! HIGHEST-SCORING task currently in READY_QUEUE, not necessarily the
  ! head. This is genuinely harder than FIFO's O(1) pop, because
  ! removing an ARBITRARY element from a circular buffer, correctly,
  ! needs care -- the approach here is copy-out-then-rebuild: read
  ! every live entry into a local, fixed-size array (bounded by
  ! SCHED_MAX_TASKS, no allocation), score each, remember the best,
  ! then rebuild READY_QUEUE from the remaining entries in their
  ! original relative order (so tasks NOT selected keep their FIFO
  ! ordering relative to each other, only the winner is pulled out of
  ! sequence) with HEAD/TAIL reset to a fresh, simple layout
  ! (1-based, contiguous from index 1) -- simpler and more obviously
  ! correct than trying to splice a hole into the existing circular
  ! indices in place, at the cost of O(n) work per dequeue instead of
  ! O(1). Given SCHED_MAX_TASKS is 64, this is a small, bounded cost
  ! (at most 64 score evaluations, each a small fixed-size forward
  ! pass), not a scalability concern at this project's current scale.
  ! Takes and releases READY_QUEUE_LOCK for its ENTIRE body (the copy-
  ! out, the scoring, and the rebuild) -- the scoring calls
  ! (SCORE_FN, ultimately SCHED_NN_SCORE_TASK) read TASK_TABLE, which
  ! is not itself lock-protected, so no nested-lock hazard exists, but
  ! holding the queue lock across the whole operation is still
  ! required for CORRECTNESS (another core must not enqueue or dequeue
  ! while this function is mid-rebuild) not merely as a convenience.
  FUNCTION SCHED_DEQUEUE_SCORED_IMPL(SCORE_FN) RESULT(TASK_INDEX)
    INTERFACE
      FUNCTION SCORE_FN(TASK_IDX) RESULT(SCORE)
        USE ISO_C_BINDING
        INTEGER(C_INT32_T), INTENT(IN), VALUE :: TASK_IDX
        REAL(C_DOUBLE) :: SCORE
      END FUNCTION SCORE_FN
    END INTERFACE
    INTEGER :: TASK_INDEX
    INTEGER :: LIVE(SCHED_MAX_TASKS)
    INTEGER :: LIVE_COUNT, I, POS, BEST_POS
    REAL(C_DOUBLE) :: THIS_SCORE, BEST_SCORE

    CALL FORT0K_SPIN_LOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))

    IF (READY_QUEUE_COUNT <= 0) THEN
      TASK_INDEX = -1
      CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
      RETURN
    END IF

    ! Copy out every live entry, in FIFO order, starting from the
    ! current HEAD -- same traversal order SCHED_DEQUEUE itself would
    ! use, just reading all of it instead of popping one.
    LIVE_COUNT = READY_QUEUE_COUNT
    POS = READY_QUEUE_HEAD
    DO I = 1, LIVE_COUNT
      POS = POS + 1
      IF (POS > SCHED_MAX_TASKS) POS = 1
      LIVE(I) = READY_QUEUE(POS)
    END DO

    ! Score every live entry, remember the best.
    BEST_POS = 1
    BEST_SCORE = SCORE_FN(INT(LIVE(1), C_INT32_T))
    DO I = 2, LIVE_COUNT
      THIS_SCORE = SCORE_FN(INT(LIVE(I), C_INT32_T))
      IF (THIS_SCORE > BEST_SCORE) THEN
        BEST_SCORE = THIS_SCORE
        BEST_POS = I
      END IF
    END DO
    TASK_INDEX = LIVE(BEST_POS)

    ! Rebuild the queue from every entry EXCEPT the winner, preserving
    ! their original relative order -- a fresh, simple 1-based layout,
    ! not an attempt to preserve the old circular HEAD/TAIL positions
    ! (which no longer mean anything coherent once an arbitrary middle
    ! element has been removed).
    READY_QUEUE_COUNT = 0
    READY_QUEUE_HEAD = 0
    READY_QUEUE_TAIL = 0
    DO I = 1, LIVE_COUNT
      IF (I /= BEST_POS) THEN
        READY_QUEUE_TAIL = READY_QUEUE_TAIL + 1
        READY_QUEUE(READY_QUEUE_TAIL) = LIVE(I)
        READY_QUEUE_COUNT = READY_QUEUE_COUNT + 1
      END IF
    END DO

    CALL FORT0K_SPIN_UNLOCK(TRANSFER(C_LOC(READY_QUEUE_LOCK), 0_C_INT64_T))
  END FUNCTION SCHED_DEQUEUE_SCORED_IMPL

  ! SCHED_YIELD(CORE_INDEX) -- stage checkpoint 1's mechanism:
  ! voluntary, cooperative switch. The CURRENTLY RUNNING task on
  ! CORE_INDEX calls this to give up the CPU; the scheduler re-
  ! enqueues it (so it gets another turn later), dequeues the next
  ! ready task, and calls FORT0K_CONTEXT_SWITCH to actually transfer
  ! control. Deliberately built and proven BEFORE any interrupt-
  ! driven preemption exists -- proving the context-switch primitive
  ! itself works correctly (registers really do survive a round trip
  ! through two different tasks) is this stage's first, isolated
  ! milestone; making that switch happen automatically via a timer
  ! IRQ is a distinct, later concern that should not be debugged at
  ! the same time as the primitive itself.
  !
  ! If the ready queue is empty (only one task exists, or every other
  ! task is not yet created), this is a no-op -- the current task
  ! simply keeps running, which is correct behavior for a cooperative
  ! yield with nothing else runnable.
  SUBROUTINE SCHED_YIELD(CORE_INDEX)
    INTEGER, INTENT(IN) :: CORE_INDEX
    INTEGER :: CURRENT_INDEX, NEXT_INDEX

    CURRENT_INDEX = CURRENT_TASK_INDEX(CORE_INDEX + 1)
    IF (CURRENT_INDEX < 1) RETURN   ! this core has no current task
                                      ! yet (SCHED_START not called) --
                                      ! nothing to yield FROM

    NEXT_INDEX = SCHED_DEQUEUE_ACTIVE()
    IF (NEXT_INDEX < 1) RETURN   ! nothing else ready -- keep running
                                   ! the current task uninterrupted

    TASK_TABLE(CURRENT_INDEX)%STATE = TASK_STATE_READY
    CALL SCHED_ENQUEUE(CURRENT_INDEX)

    TASK_TABLE(NEXT_INDEX)%STATE = TASK_STATE_RUNNING
    TASK_TABLE(NEXT_INDEX)%RUN_COUNT = TASK_TABLE(NEXT_INDEX)%RUN_COUNT + 1_C_INT64_T
    TASK_TABLE(NEXT_INDEX)%LAST_SCHEDULED_TICK = TICK_COUNT
    CURRENT_TASK_INDEX(CORE_INDEX + 1) = NEXT_INDEX

    CALL FORT0K_CONTEXT_SWITCH( &
      TRANSFER(C_LOC(TASK_TABLE(CURRENT_INDEX)%REGS), 0_C_INT64_T), &
      TRANSFER(C_LOC(TASK_TABLE(NEXT_INDEX)%REGS), 0_C_INT64_T))
    ! Execution resumes HERE, in the ORIGINAL (CURRENT_INDEX) task,
    ! the next time some other switch picks it back up -- exactly the
    ! same "this looks like an ordinary function return, but arrives
    ! via a totally different mechanism" property sched_switch.s's
    ! header comment describes. Nothing after this call executes
    ! until that happens.
  END SUBROUTINE SCHED_YIELD

  ! SCHED_START(CORE_INDEX, FIRST_TASK_INDEX) -- called once per core,
  ! establishes CURRENT_TASK_INDEX for that core and performs the
  ! FIRST switch into FIRST_TASK_INDEX. Uses a throwaway REGS_T as the
  ! "old" side of the switch (this core's pre-scheduler execution
  ! state -- e.g. AP_MAIN's own halt-loop-bound call frame -- is never
  ! going to be switched BACK to, so there is nothing meaningful to
  ! preserve it for; a real value is still saved there by
  ! FORT0K_CONTEXT_SWITCH's mechanics regardless, simply never read
  ! again).
  SUBROUTINE SCHED_START(CORE_INDEX, FIRST_TASK_INDEX)
    INTEGER, INTENT(IN) :: CORE_INDEX, FIRST_TASK_INDEX
    TYPE(TCB_REGS_T), TARGET :: THROWAWAY

    TASK_TABLE(FIRST_TASK_INDEX)%STATE = TASK_STATE_RUNNING
    TASK_TABLE(FIRST_TASK_INDEX)%RUN_COUNT = TASK_TABLE(FIRST_TASK_INDEX)%RUN_COUNT + 1_C_INT64_T
    TASK_TABLE(FIRST_TASK_INDEX)%LAST_SCHEDULED_TICK = TICK_COUNT
    CURRENT_TASK_INDEX(CORE_INDEX + 1) = FIRST_TASK_INDEX

    CALL FORT0K_CONTEXT_SWITCH( &
      TRANSFER(C_LOC(THROWAWAY), 0_C_INT64_T), &
      TRANSFER(C_LOC(TASK_TABLE(FIRST_TASK_INDEX)%REGS), 0_C_INT64_T))
    ! Does not return -- FORT0K_CONTEXT_SWITCH jumps directly into
    ! FIRST_TASK_INDEX's saved RIP (SCHED_CREATE_TASK's fabricated
    ! entry point), never back to this call site, since THROWAWAY is
    ! never switched into again.
  END SUBROUTINE SCHED_START

  ! SCHED_TEST() -- the scheduler's first checkpoint (single core,
  ! cooperative yield only, no preemption yet): creates two demo
  ! tasks that each print a distinct message and call SCHED_YIELD
  ! repeatedly, then starts the scheduler on the BSP (core 0). Proves
  ! the context-switch primitive genuinely preserves per-task state
  ! across a round trip (each task's own loop counter survives being
  ! switched away from and back), not merely "does not crash."
  !
  ! MODULE-LEVEL, DELIBERATELY, NOT NESTED IN KERNEL_MAIN: this
  ! subroutine and the two demo task bodies below were originally
  ! written as internal (CONTAINS) procedures of KERNEL_MAIN. That
  ! failed at link time -- see RING0-BRIDGE-SPEC.md's finding this
  ! session: a procedure referenced only via C_FUNLOC, never CALLed
  ! directly, is not reliably compiled/linked by gfortran when it is
  ! an internal procedure. Moving these here, as ordinary module-level
  ! procedures (matching smp.f90's AP_MAIN, which already worked),
  ! resolved it.
  !
  ! DOES NOT RETURN in the normal sense: SCHED_START's first switch
  ! jumps into SCHED_DEMO_TASK_A and never comes back to this call
  ! site (see SCHED_START's own comment).
  SUBROUTINE SCHED_TEST()
    INTEGER :: TASK_A, TASK_B

    TASK_A = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_DEMO_TASK_A), 0_C_INT64_T))
    TASK_B = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_DEMO_TASK_B), 0_C_INT64_T))

    IF (TASK_A < 0 .OR. TASK_B < 0) THEN
      CALL SCHED_SAY("fort0-kernel: SCHED TEST FAILED - could not create demo tasks")
      RETURN
    END IF

    CALL SCHED_SAY("fort0-kernel: sched - two tasks created, starting cooperative switch test")
    CALL SCHED_ENQUEUE(TASK_B)
    CALL SCHED_START(0, TASK_A)

    ! Unreachable -- see header comment.
    CALL SCHED_SAY("fort0-kernel: ERROR - reached past SCHED_START, should be impossible")
  END SUBROUTINE SCHED_TEST

  ! SCHED_DEMO_TASK_A / SCHED_DEMO_TASK_B -- the two demo task bodies.
  ! Each maintains its OWN local loop counter (a genuine test that
  ! per-task state survives a switch: if the context-switch primitive
  ! were corrupting registers, these counters would not increment
  ! correctly, or would show one task's count bleeding into the
  ! other's) and yields after each iteration. After a fixed number of
  ! iterations, prints a final summary and halts THAT TASK (not the
  ! whole machine) in a loop -- stopping a single task cleanly, with
  ! the other task (and the ready queue) still intact, is itself part
  ! of what this checkpoint demonstrates, though nothing yet exists
  ! to reclaim a halted task's resources (SCHED_DESTROY_TASK is real
  ! future work, per TCB_T's own comment above).
  SUBROUTINE SCHED_DEMO_TASK_A() BIND(C, NAME="sched_demo_task_a")
    INTEGER :: I
    DO I = 1, 5
      CALL SCHED_SAY_HEX("fort0-kernel: task A iteration = ", INT(I, C_INT64_T))
      CALL SCHED_YIELD(0)
    END DO
    CALL SCHED_SAY("fort0-kernel: task A finished 5 iterations, halting this task")
    DO
      CALL FORT0K_HLT()
    END DO
  END SUBROUTINE SCHED_DEMO_TASK_A

  SUBROUTINE SCHED_DEMO_TASK_B() BIND(C, NAME="sched_demo_task_b")
    INTEGER :: I
    DO I = 1, 3
      CALL SCHED_SAY_HEX("fort0-kernel: task B iteration = ", INT(I, C_INT64_T))
      CALL SCHED_YIELD(0)
    END DO
    ! BUG FOUND AND FIXED THIS SESSION, in the TEST itself, not the
    ! scheduler: this loop originally ran 5 iterations (matching
    ! SCHED_DEMO_TASK_A), which meant B's own FINAL yield handed
    ! control to A right as A was ALSO finishing its 5th iteration and
    ! about to permanently halt (SCHED_DEMO_TASK_A parks in a bare
    ! HLT loop once done, never yielding again -- this project's
    ! cooperative-only scheduler, with no preemption active yet, has
    ! no mechanism to reclaim the CPU from a task that stops
    ! cooperating). The result: B's own post-loop code (the reap
    ! verification below) never ran, not because of any bug in
    ! SCHED_EXIT_TASK/SCHED_REAP_ZOMBIES, but because B itself never
    ! got scheduled again after handing off to a now-permanently-
    ! halted A. Confirmed via direct log inspection: all 5 of B's
    ! iteration messages printed correctly, proving B's own switching
    ! worked fine -- only the code AFTER the loop was starved.
    ! Shortened to 3 iterations so B's post-loop verification runs
    ! well before A's 5-iteration loop can strand it.
    CALL SCHED_SAY("fort0-kernel: task B finished its iterations")

    ! Direct, explicit verification of SCHED_REAP_ZOMBIES, called from
    ! HERE rather than relying solely on the idle task ever getting a
    ! turn: task A (this file's own SCHED_DEMO_TASK_A) halts forever
    ! in a bare HLT loop once it finishes, rather than continuing to
    ! call SCHED_YIELD -- a real, pre-existing property of this
    ! project's cooperative-only scheduler (no preemption is active
    ! yet), not a bug introduced by this session's exit-task work, but
    ! one that means the ready queue can genuinely stop being serviced
    ! once a task stops cooperating, so the idle task (and therefore
    ! its own SCHED_REAP_ZOMBIES call) is not GUARANTEED to run in
    ! this specific demo scenario. Calling it directly here instead
    ! gives an unambiguous, direct test of the reap mechanism itself.
    CALL SCHED_REAP_ZOMBIES()
    CALL SCHED_SAY_HEX("fort0-kernel: exit-task slot state after reap = ", &
                        INT(TASK_TABLE(2)%STATE, C_INT64_T))
    ! Real task creation order (kernel_main.f90's SCHED_TEST_WRAPPER):
    ! NN_TASK=1, EXIT_TASK=2, then SCHED_TEST() creates TASK_A=3,
    ! TASK_B=4 -- slot 2 is the exit task's real index, confirmed
    ! (not assumed) against kernel_main.f90's actual creation-call
    ! order. Expected: 0 (TASK_STATE_UNUSED) if the reap correctly
    ! ran and found the zombie safe to clean up.

    DO
      CALL FORT0K_HLT()
    END DO
  END SUBROUTINE SCHED_DEMO_TASK_B

  ! SCHED_DEMO_TASK_EXIT() -- proves the real exit path
  ! (SCHED_EXIT_TASK) end to end: yields a couple of times (so it
  ! genuinely interleaves with A/B/NN rather than exiting instantly
  ! before anything else gets a turn), prints its own stack's physical
  ! address (so a later reap can be visually confirmed to have
  ! actually freed THIS specific page, not merely "some" page), then
  ! calls SCHED_EXIT_TASK. Nothing after that call executes -- see
  ! SCHED_EXIT_TASK's own header comment on why.
  SUBROUTINE SCHED_DEMO_TASK_EXIT() BIND(C, NAME="sched_demo_task_exit")
    INTEGER :: I
    INTEGER :: MY_INDEX
    MY_INDEX = CURRENT_TASK_INDEX(1)   ! core 0 -- this test only ever
                                         ! runs on the BSP, matching
                                         ! every other demo task in
                                         ! this file's own test scope
    CALL SCHED_SAY_HEX("fort0-kernel: exit-task stack phys = ", &
                        TASK_TABLE(MY_INDEX)%STACK_BASE_PHYS)
    DO I = 1, 2
      CALL SCHED_SAY_HEX("fort0-kernel: exit-task iteration = ", INT(I, C_INT64_T))
      CALL SCHED_YIELD(0)
    END DO
    CALL SCHED_SAY("fort0-kernel: exit-task calling SCHED_EXIT_TASK now")
    CALL SCHED_EXIT_TASK(0)
    ! Unreachable -- see SCHED_EXIT_TASK's header comment.
    CALL SCHED_SAY("fort0-kernel: ERROR - reached past SCHED_EXIT_TASK, should be impossible")
  END SUBROUTINE SCHED_DEMO_TASK_EXIT

  ! SCHED_SAY / SCHED_SAY_HEX -- self-contained checkpoint-print
  ! helpers, same pattern (fixed-max-length buffer, inline element-
  ! wise copy, no shared FILL_STR-style call) as every other module
  ! in this codebase that needs one -- kept local to this module
  ! rather than depending on kernel_main.f90's own SAY/SAY_HEX, since
  ! this module should not depend on the program entry point module
  ! for basic logging (the dependency would also point the wrong
  ! direction architecturally: kernel_main USEs SCHED, not the other
  ! way around).
  SUBROUTINE SCHED_SAY(MSG)
    CHARACTER(LEN=*), INTENT(IN) :: MSG
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    INTEGER :: N, I, MSG_LEN
    MSG_LEN = LEN(MSG)
    IF (MSG_LEN > 80) MSG_LEN = 80
    DO I = 1, MSG_LEN
      BUF(I) = MSG(I:I)
    END DO
    N = MSG_LEN
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SCHED_SAY

  SUBROUTINE SCHED_SAY_HEX(PREFIX, VAL)
    CHARACTER(LEN=*), INTENT(IN) :: PREFIX
    INTEGER(C_INT64_T), INTENT(IN) :: VAL
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: N, I, PLEN, SHIFT_AMT
    INTEGER(C_INT64_T) :: NIBBLE

    PLEN = LEN(PREFIX)
    IF (PLEN > 60) PLEN = 60
    DO I = 1, PLEN
      BUF(I) = PREFIX(I:I)
    END DO
    N = PLEN

    N = N + 1; BUF(N) = '0'
    N = N + 1; BUF(N) = 'x'
    DO I = 15, 0, -1
      SHIFT_AMT = I * 4
      NIBBLE = IAND(ISHFT(VAL, -SHIFT_AMT), INT(Z'F', C_INT64_T))
      N = N + 1
      BUF(N) = HEXDIGITS(INT(NIBBLE) + 1 : INT(NIBBLE) + 1)
    END DO

    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SCHED_SAY_HEX

  ! SCHED_MY_CORE_INDEX() -- resolves the calling core's 0-based
  ! index (matching smp.f90's AP_STARTED_FLAGS/CURRENT_TASK_INDEX
  ! indexing convention: BSP is index 0) from its own APIC ID, by
  ! searching ACPI_CPU_APIC_IDS -- same pattern AP_MAIN (smp.f90)
  ! already established for the identical lookup.
  FUNCTION SCHED_MY_CORE_INDEX() RESULT(IDX)
    INTEGER :: IDX
    INTEGER(C_INT8_T) :: MY_ID
    INTEGER :: I
    MY_ID = APIC_GET_ID()
    IDX = 0
    DO I = 1, ACPI_CPU_COUNT
      IF (ACPI_CPU_APIC_IDS(I) == MY_ID) THEN
        IDX = I - 1
        RETURN
      END IF
    END DO
  END FUNCTION SCHED_MY_CORE_INDEX

  ! SCHED_AP_TASK() -- checkpoint 2's demo task body: every AP runs
  ! an instance of this (each core's own task, created fresh ON that
  ! core so SCHED_CREATE_TASK's stack allocation genuinely exercises
  ! PMM_ALLOC_PAGE concurrently from multiple cores, not just
  ! sequentially at BSP boot). Prints its own APIC ID and an iteration
  ! count, yielding cooperatively -- proving actual multi-core
  ! scheduling: several cores, each running its own task, all pulling
  ! from and returning to the SAME shared, now-locked ready queue
  ! (READY_QUEUE_LOCK), not separate per-core queues.
  !
  ! MODULE-LEVEL, DELIBERATELY, per section 18's finding: this
  ! procedure's address is taken via C_FUNLOC (smp.f90's AP_MAIN,
  ! which creates one instance of this task per waking core) --
  ! module-level is required for that to link correctly, not a style
  ! choice.
  !
  ! BOUNDED, NOT INFINITE: unlike SCHED_DEMO_TASK_A/_B's fixed 5-
  ! iteration count, this task loops a larger, still-bounded number
  ! of times (50) before halting -- enough to give a real, visible
  ! multi-core interleave in the serial log without running so long
  ! that a boot test's own timeout cuts it off mid-run.
  SUBROUTINE SCHED_AP_TASK() BIND(C, NAME="sched_ap_task")
    INTEGER(C_INT8_T) :: MY_ID
    INTEGER(C_INT64_T) :: ITER
    INTEGER :: MY_CORE

    MY_ID = APIC_GET_ID()
    MY_CORE = SCHED_MY_CORE_INDEX()
    DO ITER = 1_C_INT64_T, 50_C_INT64_T
      CALL SCHED_SAY_HEX_ID("sched: ap task running, apic id = ", &
                             INT(MY_ID, C_INT64_T), ITER)
      CALL SCHED_YIELD(MY_CORE)
    END DO
    CALL SCHED_SAY_HEX_ID("sched: ap task finished, apic id = ", &
                           INT(MY_ID, C_INT64_T), ITER)
    DO
      CALL FORT0K_HLT()
    END DO
  END SUBROUTINE SCHED_AP_TASK

  ! SCHED_SAY_HEX_ID -- same self-contained inline hex-print pattern
  ! as SCHED_SAY_HEX, printing a second hex value (the iteration
  ! count) after the first (the APIC ID) on the same line.
  SUBROUTINE SCHED_SAY_HEX_ID(PREFIX, VAL1, VAL2)
    CHARACTER(LEN=*), INTENT(IN) :: PREFIX
    INTEGER(C_INT64_T), INTENT(IN) :: VAL1, VAL2
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: N, I, PLEN, SHIFT_AMT
    INTEGER(C_INT64_T) :: NIBBLE

    PLEN = LEN(PREFIX)
    IF (PLEN > 40) PLEN = 40
    DO I = 1, PLEN
      BUF(I) = PREFIX(I:I)
    END DO
    N = PLEN
    N = N + 1; BUF(N) = '0'
    N = N + 1; BUF(N) = 'x'
    DO I = 15, 0, -1
      SHIFT_AMT = I * 4
      NIBBLE = IAND(ISHFT(VAL1, -SHIFT_AMT), INT(Z'F', C_INT64_T))
      N = N + 1
      BUF(N) = HEXDIGITS(INT(NIBBLE) + 1 : INT(NIBBLE) + 1)
    END DO
    N = N + 1; BUF(N) = ' '
    N = N + 1; BUF(N) = 'i'
    N = N + 1; BUF(N) = 't'
    N = N + 1; BUF(N) = 'e'
    N = N + 1; BUF(N) = 'r'
    N = N + 1; BUF(N) = '='
    DO I = 15, 0, -1
      SHIFT_AMT = I * 4
      NIBBLE = IAND(ISHFT(VAL2, -SHIFT_AMT), INT(Z'F', C_INT64_T))
      N = N + 1
      BUF(N) = HEXDIGITS(INT(NIBBLE) + 1 : INT(NIBBLE) + 1)
    END DO
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SCHED_SAY_HEX_ID

  ! SCHED_ENABLE_PREEMPTION() -- registers SCHED_PREEMPT_TICK
  ! (interrupts.f90's SCHED_PREEMPT_HOOK) so every subsequent timer
  ! IRQ (IRQ0, vector 32) gives the scheduler a chance to switch tasks
  ! -- until this is called, FORT0K_DISPATCH's own ASSOCIATED check
  ! means the timer IRQ behaves exactly as it did before this stage
  ! (TIMER_IRQ_HANDLER's ordinary tick-counting, nothing more).
  SUBROUTINE SCHED_ENABLE_PREEMPTION()
    SCHED_PREEMPT_HOOK => SCHED_PREEMPT_TICK
  END SUBROUTINE SCHED_ENABLE_PREEMPTION

  ! SCHED_PREEMPT_TICK(FRAME_ADDR) -- the actual preemption mechanism:
  ! called from inside the timer IRQ's own trampoline_common/
  ! FORT0K_DISPATCH path, WITH INTERRUPTS ALREADY DISABLED (the IDT
  ! gate for every vector in this project is an INTERRUPT gate, which
  ! clears IF on entry -- idt.f90's IDT_GATE_INT_R0 -- so this routine
  ! runs with no risk of a second timer tick or any other interrupt
  ! arriving mid-rewrite; this is NOT the same guarantee SCHED_YIELD's
  ! cooperative path relies on, and is worth stating explicitly since
  ! it is a real, different safety argument for why this code is
  ! allowed to touch the frame directly without a lock of its own).
  !
  ! REWRITES THE INTERRUPT FRAME IN PLACE, does not call
  ! FORT0K_CONTEXT_SWITCH: unlike SCHED_YIELD's cooperative path
  ! (which reaches the scheduler via an ordinary `call` and switches
  ! via a genuine register-level jump), this path is already inside
  ! trampoline_common's machinery (isr_stubs.s), which will restore
  ! whatever ends up in the interrupt frame's register fields and
  ! `iretq` unconditionally once FORT0K_DISPATCH returns. Preemption
  ! therefore works by ensuring the frame holds the NEXT task's saved
  ! state instead of the interrupted task's, before that unconditional
  ! restore/iretq happens -- a fundamentally different mechanism from
  ! the cooperative path, using this project's EXISTING interrupt-
  ! return machinery rather than a second copy of context-switch logic.
  !
  ! FIELD TRANSLATION: INTERRUPT_FRAME_T (interrupts.f90) and
  ! TCB_REGS_T (this file) share an IDENTICAL first-15-field layout
  ! (R15 through RAX, both byte-offset-confirmed independently this
  ! project -- interrupts.f90's own header comment for the frame,
  ! this file's TCB_REGS_T comment for the TCB), so those 15 fields
  ! are copied directly, offset-for-offset, with no reordering. RIP/
  ! RSP/RFLAGS live at DIFFERENT offsets in the two structs (frame:
  ! RIP@0x88, CS@0x90, RFLAGS@0x98, RSP@0xA0, SS@0xA8; TCB: RSP@0x78,
  ! RIP@0x80, RFLAGS@0x88) and are copied field-by-field, not by
  ! blind offset range -- CS/SS have no TCB_REGS_T equivalent (every
  ! task in this project runs in ring 0 under the one shared kernel
  ! PML4, matching TCB_REGS_T's own header comment on why segment
  ! registers/CR3 are not tracked per-task yet) and are left
  ! UNCHANGED in the frame across a preemption (both the outgoing and
  ! incoming task use the same kernel CS/SS values regardless, so
  ! there is nothing meaningful to save or restore there yet).
  SUBROUTINE SCHED_PREEMPT_TICK(FRAME_ADDR) BIND(C, NAME="sched_preempt_tick_impl")
    INTEGER(C_INT64_T), INTENT(IN), VALUE :: FRAME_ADDR
    INTEGER(C_INT64_T), POINTER :: F(:)   ! raw 8-byte-word view of
                                            ! the frame, indexed
                                            ! numerically rather than
                                            ! via INTERRUPT_FRAME_T's
                                            ! own type -- deliberate,
                                            ! see below
    INTEGER :: CORE_IDX, CUR_TASK, NEXT_TASK

    ! Uses a raw INTEGER(C_INT64_T) array view of the frame, indexed
    ! by word number, rather than TRANSFERing FRAME_ADDR to a
    ! TYPE(INTERRUPT_FRAME_T) POINTER the way interrupts.f90's own
    ! REPORT_EXCEPTION does -- because this routine needs to WRITE
    ! into the frame, and doing so through this project's own
    ! established derived-type-pointer idiom would require sched.f90
    ! to declare its own copy of INTERRUPT_FRAME_T's type (that type
    ! is not itself exported for reuse from interrupts.f90 in a form
    ! this module currently pulls in for that purpose) -- indexing a
    ! flat word array by the SAME byte offsets that type's own fields
    ! already confirmed achieves the identical effect with one fewer
    ! type declaration to keep in sync between the two files. Word
    ! index N corresponds to byte offset N*8, matching both structs'
    ! all-8-byte-field layout exactly.
    CALL C_F_POINTER(TRANSFER(FRAME_ADDR, C_NULL_PTR), F, [22])

    CORE_IDX = SCHED_MY_CORE_INDEX()
    CUR_TASK = CURRENT_TASK_INDEX(CORE_IDX + 1)
    IF (CUR_TASK < 1) RETURN   ! this core has no scheduler task yet
                                ! (preemption enabled before
                                ! SCHED_START ever ran on it) --
                                ! nothing to preempt FROM; let the
                                ! ordinary tick-counting path (already
                                ! run before this hook, see
                                ! FORT0K_DISPATCH) be the only effect

    ! Save the OUTGOING (interrupted) task's state FROM the frame.
    ! Words 0-14 (R15..RAX) map directly.
    TASK_TABLE(CUR_TASK)%REGS%R15 = F(1);  TASK_TABLE(CUR_TASK)%REGS%R14 = F(2)
    TASK_TABLE(CUR_TASK)%REGS%R13 = F(3);  TASK_TABLE(CUR_TASK)%REGS%R12 = F(4)
    TASK_TABLE(CUR_TASK)%REGS%R11 = F(5);  TASK_TABLE(CUR_TASK)%REGS%R10 = F(6)
    TASK_TABLE(CUR_TASK)%REGS%R9  = F(7);  TASK_TABLE(CUR_TASK)%REGS%R8  = F(8)
    TASK_TABLE(CUR_TASK)%REGS%RDI = F(9);  TASK_TABLE(CUR_TASK)%REGS%RSI = F(10)
    TASK_TABLE(CUR_TASK)%REGS%RBP = F(11); TASK_TABLE(CUR_TASK)%REGS%RBX = F(12)
    TASK_TABLE(CUR_TASK)%REGS%RDX = F(13); TASK_TABLE(CUR_TASK)%REGS%RCX = F(14)
    TASK_TABLE(CUR_TASK)%REGS%RAX = F(15)
    ! Word 16 (F(16), offset 120/0x78) = VECTOR; word 17 (F(17),
    ! offset 128/0x80) = ERROR_CODE -- neither is part of TCB_REGS_T,
    ! correctly skipped in both directions.
    TASK_TABLE(CUR_TASK)%REGS%RIP    = F(18)   ! offset 136/0x88
    TASK_TABLE(CUR_TASK)%REGS%CS     = F(19)   ! offset 144/0x90
    TASK_TABLE(CUR_TASK)%REGS%RFLAGS = F(20)   ! offset 152/0x98
    TASK_TABLE(CUR_TASK)%REGS%RSP    = F(21)   ! offset 160/0xA0
    TASK_TABLE(CUR_TASK)%REGS%SS     = F(22)   ! offset 168/0xA8
    ! BUG FOUND AND FIXED THIS SESSION (bug cleanse pass, prompted
    ! directly by the prior session's unresolved iretq mystery): this
    ! read CS from F(17), which is actually ERROR_CODE (offset 128),
    ! NOT CS (the real CS is F(19), offset 144) -- a genuine off-by-
    ! two indexing error introduced when CS/SS support was first added
    ! to this routine, confirmed by recomputing the FULL word-index
    ! table for INTERRUPT_FRAME_T from scratch (R15..RAX are 15 words,
    ! VECTOR is word 16, ERROR_CODE is word 17, THEN RIP/CS/RFLAGS/
    ! RSP/SS at 18-22) rather than trusting the inline comments that
    ! had accompanied the original, wrong indices. Found via a
    ! systematic re-verification pass, not via a new crash -- but this
    ! is very likely the actual explanation for the prior session's
    ! extensively-chased, never-resolved contradiction (real evidence
    ! that fix code executed, paired with equally real evidence that
    ! its effects never reached memory as expected, RING0-BRIDGE-
    ! SPEC.md section 35): with this bug in place, EVERY prior write to
    ! TASK_TABLE(...)%REGS%CS was capturing ERROR_CODE (always 0 for
    ! every vector actually exercised so far), not the task's real,
    ! interrupted CS -- and every attempt to READ BACK a task's "CS"
    ! for the ring-3-aware switch/return logic was reading a value that
    ! had never been the real CS to begin with. This does not, by
    ! itself, explain section 35's specific memory-write mystery in
    ! trampoline_common (that fix's own logic operates on the FRAME
    ! directly, not through this field), but it is a real, serious,
    ! independently-confirmed bug in its own right, entirely capable of
    ! having corrupted every ring-3-related CS value this session
    ! worked with, and is fixed here regardless of whether it turns
    ! out to be the full explanation for section 35's mystery.

    ! Pick the next task -- re-enqueue the outgoing one (it is still
    ! READY, just no longer RUNNING) exactly as SCHED_YIELD does, then
    ! dequeue. If nothing else is ready, put the SAME task back as
    ! both outgoing and incoming (a no-op preemption -- the frame is
    ! about to be overwritten with the exact values it already held,
    ! so this core simply resumes what it was already running,
    ! correctly, rather than needing a special-cased early return that
    ! would leave TASK_STATE_RUNNING/CURRENT_TASK_INDEX out of sync
    ! with the READY state SCHED_ENQUEUE below already committed it
    ! to).
    TASK_TABLE(CUR_TASK)%STATE = TASK_STATE_READY
    CALL SCHED_ENQUEUE(CUR_TASK)

    NEXT_TASK = SCHED_DEQUEUE_ACTIVE()
    IF (NEXT_TASK < 1) NEXT_TASK = CUR_TASK   ! queue was otherwise
                                                ! empty -- see comment
                                                ! above

    TASK_TABLE(NEXT_TASK)%STATE = TASK_STATE_RUNNING
    TASK_TABLE(NEXT_TASK)%RUN_COUNT = TASK_TABLE(NEXT_TASK)%RUN_COUNT + 1_C_INT64_T
    TASK_TABLE(NEXT_TASK)%LAST_SCHEDULED_TICK = TICK_COUNT
    CURRENT_TASK_INDEX(CORE_IDX + 1) = NEXT_TASK

    ! Overwrite the frame with the INCOMING task's saved state --
    ! trampoline_common's restore/iretq path (isr_stubs.s), which
    ! runs immediately after FORT0K_DISPATCH returns, will now resume
    ! into NEXT_TASK, not CUR_TASK, even though NEXT_TASK is not the
    ! task that was actually interrupted -- this is the entire
    ! preemption mechanism, and it is why this routine writes to F
    ! rather than merely reading it.
    F(1) = TASK_TABLE(NEXT_TASK)%REGS%R15;  F(2) = TASK_TABLE(NEXT_TASK)%REGS%R14
    F(3) = TASK_TABLE(NEXT_TASK)%REGS%R13;  F(4) = TASK_TABLE(NEXT_TASK)%REGS%R12
    F(5) = TASK_TABLE(NEXT_TASK)%REGS%R11;  F(6) = TASK_TABLE(NEXT_TASK)%REGS%R10
    F(7) = TASK_TABLE(NEXT_TASK)%REGS%R9;   F(8) = TASK_TABLE(NEXT_TASK)%REGS%R8
    F(9) = TASK_TABLE(NEXT_TASK)%REGS%RDI;  F(10) = TASK_TABLE(NEXT_TASK)%REGS%RSI
    F(11) = TASK_TABLE(NEXT_TASK)%REGS%RBP; F(12) = TASK_TABLE(NEXT_TASK)%REGS%RBX
    F(13) = TASK_TABLE(NEXT_TASK)%REGS%RDX; F(14) = TASK_TABLE(NEXT_TASK)%REGS%RCX
    F(15) = TASK_TABLE(NEXT_TASK)%REGS%RAX
    F(18) = TASK_TABLE(NEXT_TASK)%REGS%RIP
    F(19) = TASK_TABLE(NEXT_TASK)%REGS%CS
    F(20) = TASK_TABLE(NEXT_TASK)%REGS%RFLAGS
    F(21) = TASK_TABLE(NEXT_TASK)%REGS%RSP
    F(22) = TASK_TABLE(NEXT_TASK)%REGS%SS
    ! BUG FOUND AND FIXED THIS SESSION (bug cleanse pass): this wrote
    ! CS into F(17), which is actually ERROR_CODE (offset 128), not CS
    ! (the real CS is F(19), offset 144) -- the write-side half of the
    ! same off-by-two indexing bug fixed on the save side above (see
    ! that fix's full comment for the complete account, including why
    ! this is very likely connected to RING0-BRIDGE-SPEC.md section
    ! 35's unresolved iretq mystery from the prior session). With this
    ! bug, every "CS" this routine ever wrote for an incoming task
    ! landed in the frame's ERROR_CODE slot instead -- meaning the
    ! frame's REAL CS field was never actually updated by preemption/
    ! yield at all, silently retaining whatever the ORIGINAL interrupt
    ! entry had put there. Confirmed via a from-scratch recomputation
    ! of INTERRUPT_FRAME_T's full word-index table, not by a new crash.

  END SUBROUTINE SCHED_PREEMPT_TICK

  ! ================================================================
  ! "ALIEN FORTRAN" SCHEDULER QUERIES -- whole-array/masked-reduction
  ! expressions over TASK_TABLE, in place of hand-rolled loops, as a
  ! genuinely different idiom from how this same logic would be
  ! written in C. Purely ADDITIVE: none of SCHED_ENQUEUE/SCHED_DEQUEUE/
  ! SCHED_YIELD/SCHED_PREEMPT_TICK's proven, working mechanism is
  ! touched or replaced by anything below -- these are read-only
  ! DIAGNOSTIC/QUERY functions callable alongside it, not a
  ! replacement scheduling algorithm.
  !
  ! Every intrinsic used below was individually verified this session
  ! (RING0-BRIDGE-SPEC.md section 26) to compile with zero undefined
  ! symbols under this project's freestanding flags, including on the
  ! specific shape used here (a component of a BIND(C) derived-type
  ! array, e.g. TASK_TABLE%STATE) -- not merely assumed safe because a
  ! simpler standalone-array version worked. PACK and FINDLOC were
  ! tested and found UNSAFE (real libgfortran calls) and are
  ! deliberately not used anywhere in this codebase as a result.
  ! ================================================================

  ! SCHED_COUNT_READY() -- how many tasks are currently READY, across
  ! the whole task table, expressed as a single masked COUNT rather
  ! than a loop with an accumulator.
  FUNCTION SCHED_COUNT_READY() BIND(C, NAME="sched_count_ready") RESULT(N)
    INTEGER(C_INT32_T) :: N
    N = COUNT(TASK_TABLE%STATE == TASK_STATE_READY)
  END FUNCTION SCHED_COUNT_READY

  ! SCHED_COUNT_RUNNING() -- same shape, different mask -- how many
  ! tasks are currently RUNNING (i.e. one per core actually executing
  ! something, in this project's current one-task-per-core-at-a-time
  ! design).
  FUNCTION SCHED_COUNT_RUNNING() BIND(C, NAME="sched_count_running") RESULT(N)
    INTEGER(C_INT32_T) :: N
    N = COUNT(TASK_TABLE%STATE == TASK_STATE_RUNNING)
  END FUNCTION SCHED_COUNT_RUNNING

  ! SCHED_ANY_READY() -- .TRUE. iff at least one task is READY.
  ! Genuinely different from "SCHED_COUNT_READY() > 0" at the
  ! LANGUAGE level (ANY can short-circuit; whether this compiler's
  ! generated code actually does is a separate, unverified question
  ! this project has not checked and does not depend on either way --
  ! both forms are correct, ANY is simply the more direct expression
  ! of the actual question being asked).
  FUNCTION SCHED_ANY_READY() BIND(C, NAME="sched_any_ready") RESULT(R)
    LOGICAL(C_BOOL) :: R
    R = LOGICAL(ANY(TASK_TABLE%STATE == TASK_STATE_READY), C_BOOL)
  END FUNCTION SCHED_ANY_READY

  ! SCHED_ALL_UNUSED() -- .TRUE. iff every task table slot is UNUSED
  ! (i.e. no task has ever been created, or every created task has
  ! since been destroyed -- this project has no SCHED_DESTROY_TASK
  ! yet, so in practice this is only ever true before the first
  ! SCHED_CREATE_TASK call, but the query is written generally rather
  ! than special-cased to that one situation).
  FUNCTION SCHED_ALL_UNUSED() BIND(C, NAME="sched_all_unused") RESULT(R)
    LOGICAL(C_BOOL) :: R
    R = LOGICAL(ALL(TASK_TABLE%STATE == TASK_STATE_UNUSED), C_BOOL)
  END FUNCTION SCHED_ALL_UNUSED

  ! SCHED_MOST_ADVANCED_TASK_ID() -- among all currently-USED (READY
  ! or RUNNING) task slots, the TASK_ID of whichever one is numerically
  ! highest -- i.e. the most recently created task still alive. A
  ! single masked MAXLOC expression in place of a hand-rolled "loop
  ! and track the running max" pattern that would otherwise be needed
  ! for this exact question. Returns 0 (an otherwise-impossible
  ! TASK_ID, since SCHED_CREATE_TASK's IDs start at 1) if no task is
  ! currently alive, matching MAXLOC's own defined behavior when its
  ! MASK matches nothing (the result location is 0 in that case, per
  ! the Fortran standard) -- checked against that behavior directly
  ! rather than assumed, since a caller treating a 0 index as "slot
  ! zero" instead of "not found" would be a real, silent bug.
  FUNCTION SCHED_MOST_ADVANCED_TASK_ID() BIND(C, NAME="sched_most_advanced_task_id") RESULT(TID)
    INTEGER(C_INT32_T) :: TID
    INTEGER :: LOC_ARR(1)
    LOC_ARR = MAXLOC(TASK_TABLE%TASK_ID, &
                      MASK=(TASK_TABLE%STATE == TASK_STATE_READY .OR. &
                            TASK_TABLE%STATE == TASK_STATE_RUNNING))
    IF (LOC_ARR(1) == 0) THEN
      TID = 0
    ELSE
      TID = TASK_TABLE(LOC_ARR(1))%TASK_ID
    END IF
  END FUNCTION SCHED_MOST_ADVANCED_TASK_ID

  ! SCHED_QUERY_TEST() -- exercises every query above against the
  ! real, live TASK_TABLE state at whatever point in boot it is
  ! called, printing results to serial -- this stage's proof that the
  ! whole-array queries above produce CORRECT answers against real
  ! scheduler state, not merely that they compile. Deliberately
  ! read-only: calling this does not create, destroy, or otherwise
  ! mutate any task, so it is safe to call at any point without
  ! disturbing whatever the rest of the scheduler is doing.
  SUBROUTINE SCHED_QUERY_TEST() BIND(C, NAME="sched_query_test")
    CALL SCHED_SAY_HEX("sched-query: count ready = ", INT(SCHED_COUNT_READY(), C_INT64_T))
    CALL SCHED_SAY_HEX("sched-query: count running = ", INT(SCHED_COUNT_RUNNING(), C_INT64_T))
    IF (SCHED_ANY_READY()) THEN
      CALL SCHED_SAY("sched-query: any_ready = true")
    ELSE
      CALL SCHED_SAY("sched-query: any_ready = false")
    END IF
    IF (SCHED_ALL_UNUSED()) THEN
      CALL SCHED_SAY("sched-query: all_unused = true")
    ELSE
      CALL SCHED_SAY("sched-query: all_unused = false")
    END IF
    CALL SCHED_SAY_HEX("sched-query: most advanced task id = ", &
                        INT(SCHED_MOST_ADVANCED_TASK_ID(), C_INT64_T))
  END SUBROUTINE SCHED_QUERY_TEST

  ! ================================================================
  ! TASK LIFECYCLE: exit and cleanup. Everything above this point
  ! assumed every task lives forever (no task in this codebase, before
  ! this addition, ever legitimately stopped being READY/RUNNING
  ! except by parking in its own infinite HLT loop -- a task that
  ! never truly exits, just stops doing anything useful). This section
  ! adds a REAL exit path.
  ! ================================================================

  ! SCHED_IDLE_TASK_BODY() -- the idle task's entire job: HLT forever,
  ! periodically reaping ZOMBIE tasks. Deliberately does NOT yield/
  ! re-enqueue itself the way a normal task would -- an idle task is
  ! not competing for CPU time the way real work is; it is what runs
  ! when there is genuinely nothing else, and it should sit there
  ! (HLT, which stops fetching until the next interrupt -- the
  ! standard idle idiom this project already uses elsewhere, e.g.
  ! kernel_main.f90's IDLE_LOOP) rather than spin-yielding and adding
  ! lock/queue traffic for no purpose. A future timer tick (once
  ! preemption is active, RING0-BRIDGE-SPEC.md's still-not-yet-
  ! activated preemption work) is what would actually move a core off
  ! its idle task and onto newly-READY real work -- this task itself
  ! does not need to do anything to make that happen.
  !
  ! REAPING HAPPENS HERE, DELIBERATELY, NOT IN kernel_main.f90's
  ! IDLE_LOOP: IDLE_LOOP is unreachable dead code in this project's
  ! current boot sequence (SCHED_TEST_WRAPPER's SCHED_START call never
  ! returns, so IDLE_LOOP's own call site is never reached -- a real,
  ! pre-existing situation noticed while designing this feature, not
  ! introduced by it). This idle task, by contrast, IS genuinely
  ! reached (it is what SCHED_EXIT_TASK switches to when the ready
  ! queue is empty), making it the correct place for the one
  ! "periodically do background cleanup work" responsibility this
  ! project currently has -- SCHED_REAP_ZOMBIES only runs when a core
  ! actually falls idle, both a genuine safety property (per that
  ! function's own header comment, cleanup must never happen from the
  ! zombie task's own context, and idle-task context is trivially
  ! never that) and a reasonable, low-cost cadence (only scans
  ! TASK_TABLE when there is nothing better to do anyway).
  SUBROUTINE SCHED_IDLE_TASK_BODY() BIND(C, NAME="sched_idle_task_body")
    DO
      CALL SCHED_REAP_ZOMBIES()
      CALL FORT0K_HLT()
    END DO
  END SUBROUTINE SCHED_IDLE_TASK_BODY

  ! SCHED_ENSURE_IDLE_TASK(CORE_INDEX) -- creates CORE_INDEX's idle
  ! task if it does not already have one, returns its TASK_TABLE
  ! index either way. Idempotent -- safe to call every time
  ! SCHED_EXIT_TASK might need a fallback, not just once at boot,
  ! since which cores actually end up needing an idle task is not
  ! known in advance.
  FUNCTION SCHED_ENSURE_IDLE_TASK(CORE_INDEX) RESULT(IDX)
    INTEGER, INTENT(IN) :: CORE_INDEX
    INTEGER :: IDX
    IF (CORE_IDLE_TASK_INDEX(CORE_INDEX + 1) < 1) THEN
      IDX = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_IDLE_TASK_BODY), 0_C_INT64_T))
      CORE_IDLE_TASK_INDEX(CORE_INDEX + 1) = IDX
    ELSE
      IDX = CORE_IDLE_TASK_INDEX(CORE_INDEX + 1)
    END IF
  END FUNCTION SCHED_ENSURE_IDLE_TASK

  ! SCHED_EXIT_TASK(CORE_INDEX) -- the real exit path: the CURRENTLY
  ! RUNNING task on CORE_INDEX calls this to permanently stop running.
  ! Marks itself ZOMBIE (this file's TASK_STATE_ZOMBIE comment
  ! explains why not immediately freed/reset here) and switches to
  ! either the next READY task (if any) or this core's idle task
  ! (SCHED_ENSURE_IDLE_TASK, guaranteeing a fallback always exists,
  ! unlike SCHED_YIELD which can legitimately no-op and return if
  ! nothing else is ready -- SCHED_EXIT_TASK cannot do that, since
  ! "keep running the exiting task" is not an option here the way it
  ! is for an ordinary yield).
  !
  ! NEVER RETURNS, by construction: unlike SCHED_YIELD (which DOES
  ! return, later, once switched back into), a ZOMBIE task is never
  ! switched back into by any mechanism in this codebase -- SCHED_
  ! ENQUEUE is never called on it, so SCHED_DEQUEUE/SCHED_DEQUEUE_
  ! ACTIVE can never select it again. The CALL FORT0K_CONTEXT_SWITCH
  ! below still technically "returns" in the sense every other switch
  ! site's comment describes (the mechanism is identical, section 23's
  ! fixed primitive works the same way regardless of caller intent),
  ! but nothing in this codebase will ever cause that return to
  ! happen, so this subroutine's caller should treat the call as
  ! non-returning in practice -- stated explicitly here since Fortran
  ! itself has no NORETURN attribute to enforce or document this at
  ! the language level.
  SUBROUTINE SCHED_EXIT_TASK(CORE_INDEX)
    INTEGER, INTENT(IN) :: CORE_INDEX
    INTEGER :: CURRENT_INDEX, NEXT_INDEX

    CURRENT_INDEX = CURRENT_TASK_INDEX(CORE_INDEX + 1)
    IF (CURRENT_INDEX < 1) RETURN   ! no current task to exit --
                                       ! should not happen given only
                                       ! a running task can call this
                                       ! on itself, but a defined,
                                       ! safe no-op rather than
                                       ! undefined behavior if it ever
                                       ! does

    TASK_TABLE(CURRENT_INDEX)%STATE = TASK_STATE_ZOMBIE
    ! Deliberately NOT calling SCHED_ENQUEUE -- see header comment.
    ! This is the one substantive difference from SCHED_YIELD's
    ! otherwise near-identical shape.

    NEXT_INDEX = SCHED_DEQUEUE_ACTIVE()
    IF (NEXT_INDEX < 1) THEN
      NEXT_INDEX = SCHED_ENSURE_IDLE_TASK(CORE_INDEX)
    END IF

    TASK_TABLE(NEXT_INDEX)%STATE = TASK_STATE_RUNNING
    TASK_TABLE(NEXT_INDEX)%RUN_COUNT = TASK_TABLE(NEXT_INDEX)%RUN_COUNT + 1_C_INT64_T
    TASK_TABLE(NEXT_INDEX)%LAST_SCHEDULED_TICK = TICK_COUNT
    CURRENT_TASK_INDEX(CORE_INDEX + 1) = NEXT_INDEX

    CALL FORT0K_CONTEXT_SWITCH( &
      TRANSFER(C_LOC(TASK_TABLE(CURRENT_INDEX)%REGS), 0_C_INT64_T), &
      TRANSFER(C_LOC(TASK_TABLE(NEXT_INDEX)%REGS), 0_C_INT64_T))
    ! See header comment: this does not return in practice, though
    ! the mechanism itself does not distinguish this call from any
    ! other FORT0K_CONTEXT_SWITCH call site.
  END SUBROUTINE SCHED_EXIT_TASK

  ! SCHED_REAP_ZOMBIES() -- the ACTUAL cleanup: scans TASK_TABLE for
  ! ZOMBIE tasks and, for each one that is SAFE to clean up (see
  ! below), frees its stack (PMM_FREE_PAGE) and resets its slot to
  ! UNUSED, making it available for a future SCHED_CREATE_TASK again.
  !
  ! SAFETY CHECK, THE WHOLE POINT OF DEFERRING THIS FROM SCHED_EXIT_
  ! TASK: a ZOMBIE task's slot must NOT be touched while it is still
  ! the CURRENT_TASK_INDEX of ANY core -- this is a real possibility
  ! even though SCHED_EXIT_TASK already switched that core's OWN
  ! CURRENT_TASK_INDEX away from it, because that switch and this
  ! reap call can, on a multi-core system, be observed at different
  ! times by different cores; checking every core's CURRENT_TASK_
  ! INDEX here (not just trusting that STATE==ZOMBIE alone means
  ! safe) is what actually prevents freeing a stack a core might
  ! still be mid-switch away from. Must be called from a task/context
  ! OTHER than the zombie itself (true by construction: a ZOMBIE task
  ! is never running, since SCHED_EXIT_TASK already switched away from
  ! it before this could ever be called).
  SUBROUTINE SCHED_REAP_ZOMBIES() BIND(C, NAME="sched_reap_zombies")
    INTEGER :: I, CORE
    LOGICAL :: STILL_CURRENT

    DO I = 1, SCHED_MAX_TASKS
      IF (TASK_TABLE(I)%STATE == TASK_STATE_ZOMBIE) THEN
        STILL_CURRENT = .FALSE.
        DO CORE = 1, ACPI_MAX_CPUS
          IF (CURRENT_TASK_INDEX(CORE) == I) THEN
            STILL_CURRENT = .TRUE.
            EXIT
          END IF
        END DO

        IF (.NOT. STILL_CURRENT) THEN
          CALL PMM_FREE_PAGE(TASK_TABLE(I)%STACK_BASE_PHYS)
          TASK_TABLE(I)%STATE = TASK_STATE_UNUSED
          TASK_TABLE(I)%TASK_ID = 0
          TASK_TABLE(I)%RUN_COUNT = 0_C_INT64_T
          TASK_TABLE(I)%LAST_SCHEDULED_TICK = 0_C_INT64_T
        END IF
      END IF
    END DO
  END SUBROUTINE SCHED_REAP_ZOMBIES

  ! SCHED_SYSCALL_EXIT_WRAPPER -- matches interrupts.f90's EXIT_HOOK_T
  ! interface (no arguments) exactly, so it can be registered as
  ! SYSCALL_EXIT_HOOK. Hardcodes CORE_INDEX=0 -- this project's
  ! user-mode testing only ever runs on the BSP so far, matching every
  ! other demo task in this file's own test scope (SCHED_DEMO_TASK_A/
  ! _B/_EXIT all hardcode core 0 for the same reason) -- a genuinely
  ! per-core-aware version (reading the calling core's real index,
  ! the way SCHED_MY_CORE_INDEX does elsewhere) is real future work
  ! once user-mode tasks exist on more than one core, not attempted
  ! here.
  SUBROUTINE SCHED_SYSCALL_EXIT_WRAPPER()
    CALL SCHED_EXIT_TASK(0)
  END SUBROUTINE SCHED_SYSCALL_EXIT_WRAPPER

  ! SCHED_REGISTER_SYSCALL_EXIT_HOOK() -- registers the wrapper above
  ! as interrupts.f90's SYSCALL_EXIT_HOOK. Must be called once, before
  ! any ring-3 code that might execute the SYS_EXIT syscall runs --
  ! kernel_main.f90 calls this during setup, before entering user mode
  ! for the first time.
  SUBROUTINE SCHED_REGISTER_SYSCALL_EXIT_HOOK()
    SYSCALL_EXIT_HOOK => SCHED_SYSCALL_EXIT_WRAPPER
  END SUBROUTINE SCHED_REGISTER_SYSCALL_EXIT_HOOK

  ! SCHED_REGISTER_SYSCALL_YIELD_HOOK() -- registers SCHED_PREEMPT_TICK
  ! ITSELF (not a new wrapper) as interrupts.f90's SYSCALL_YIELD_HOOK.
  ! This is deliberate reuse, not a coincidence of matching signatures:
  ! a voluntary SYS_YIELD and an involuntary timer preemption both
  ! need to do EXACTLY the same thing to the interrupt frame (save the
  ! interrupted task's state from it, pick the next READY task, write
  ! that task's state back into the frame) -- SCHED_PREEMPT_TICK
  ! already implements this correctly and is already proven (RING0-
  ! BRIDGE-SPEC.md's preemption work), so this registers that same,
  ! already-correct procedure for the syscall path too, rather than
  ! writing a second, parallel implementation of identical logic.
  SUBROUTINE SCHED_REGISTER_SYSCALL_YIELD_HOOK()
    SYSCALL_YIELD_HOOK => SCHED_PREEMPT_TICK
  END SUBROUTINE SCHED_REGISTER_SYSCALL_YIELD_HOOK

END MODULE SCHED
