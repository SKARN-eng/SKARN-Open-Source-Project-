! vga.f90 -- VGA text-mode buffer access.
!
! No TRANSFER, no C_F_POINTER, no EQUIVALENCE. The VGA text buffer is
! a fixed-address, linker-placed BIND(C) module array: this project's
! .ld script sets the symbol vga_buf's address to 0xB8000 directly
! (confirmed working this session -- see build log / RING0-BRIDGE-
! SPEC.md), so ordinary Fortran array indexing on VGA_BUF compiles to
! a direct memory write at that address with zero indirection and zero
! runtime call, exactly matching CALL-BRIDGE-SPEC.md section 4's rule
! that TRANSFER-based address handling pulls in a libgfortran memcpy
! call this project cannot afford -- this approach sidesteps the
! question entirely rather than fighting it, the same resolution
! fort0's own start.s reached for its three captured stack-layout
! words (named linker-visible storage instead of a runtime call).
!
! VGA text mode cell format (2 bytes, little-endian as stored, but
! written here as one INTEGER(C_INT16_T) value so byte order is
! handled by the integer's own bit layout, not by manual byte
! splitting): low byte = ASCII character, high byte = attribute
! (bits 0-3 foreground color, bits 4-6 background color, bit 7 blink
! on some hardware/emulators).
MODULE VGA
  USE ISO_C_BINDING
  IMPLICIT NONE

  INTEGER, PARAMETER :: VGA_WIDTH  = 80
  INTEGER, PARAMETER :: VGA_HEIGHT = 25
  INTEGER, PARAMETER :: VGA_SIZE   = VGA_WIDTH * VGA_HEIGHT

  ! Default attribute: light grey (0x7) on black (0x0) = 0x07.
  INTEGER(C_INT16_T), PARAMETER :: VGA_ATTR_DEFAULT = INT(Z'0700', C_INT16_T)

  INTEGER(C_INT16_T) :: VGA_BUF(VGA_SIZE)
  BIND(C, NAME="vga_buf") :: VGA_BUF

CONTAINS

  ! VGA_CLEAR() -- fill the entire text buffer with blank (space,
  ! default attribute) cells. Whole-array assignment (BUF = value) was
  ! nm-verified clean (no memset call) for a fixed-size local array in
  ! RING0-BRIDGE-SPEC.md section 1's probing; VGA_BUF is module-level
  ! rather than local, so this is re-verified directly below rather
  ! than assumed to generalize -- see build log.
  ! VGA_CLEAR() -- fills the entire text buffer with blanks (space
  ! character, default attribute).
  !
  ! WHOLE-ARRAY ASSIGNMENT, not a DO loop: verified safe for this
  ! MMIO-backed buffer via a direct probe this session (RING0-BRIDGE-
  ! SPEC.md's vectorization-audit section) before converting --
  ! section 9's MMIO/VOLATILE finding is about REPEATED writes to the
  ! SAME address being collapsed by dead-store elimination, which does
  ! not apply here (every element is written exactly once, to a
  ! distinct address, and nothing reads any of them back within this
  ! routine) -- confirmed the generated code is a genuine per-element
  ! store loop (2x-unrolled `movq`, matching the codegen this project
  ! already sees for ordinary array fills elsewhere), not a folded/
  ! eliminated no-op and not a memset call (this project's
  ! -fno-tree-loop-distribute-patterns flag already forbids that
  ! substitution project-wide, re-confirmed here for this specific
  ! new use rather than assumed to still hold).
  SUBROUTINE VGA_CLEAR() BIND(C, NAME="vga_clear")
    INTEGER(C_INT16_T) :: BLANK
    BLANK = IOR(INT(IACHAR(' '), C_INT16_T), VGA_ATTR_DEFAULT)
    VGA_BUF = BLANK
  END SUBROUTINE VGA_CLEAR

  ! VGA_PUTC_AT(ROW, COL, CH, ATTR) -- write one character cell.
  ! ROW, COL are 0-based (0..VGA_HEIGHT-1, 0..VGA_WIDTH-1); no bounds
  ! checking -- an out-of-range ROW/COL is a kernel bug, and this
  ! project has no fault handler yet (stage 1) to catch the
  ! consequence gracefully, so out-of-range input is the caller's
  ! contract to uphold, not this routine's to defend against, for now.
  SUBROUTINE VGA_PUTC_AT(ROW, COL, CH, ATTR) BIND(C, NAME="vga_putc_at")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: ROW, COL
    INTEGER(C_INT8_T), INTENT(IN), VALUE :: CH
    INTEGER(C_INT16_T), INTENT(IN), VALUE :: ATTR
    INTEGER :: IDX
    IDX = ROW * VGA_WIDTH + COL + 1   ! +1: Fortran arrays are 1-based
    VGA_BUF(IDX) = IOR(INT(IAND(INT(CH), 255), C_INT16_T), ATTR)
  END SUBROUTINE VGA_PUTC_AT

  ! VGA_PUTS_AT(ROW, COL, STR, SLEN, ATTR) -- write SLEN characters of
  ! STR starting at (ROW, COL), left to right. No string intrinsics
  ! (no TRIM, no //, no LEN_TRIM) per CALL-BRIDGE-SPEC.md section 4 --
  ! explicit length passed in, explicit element-wise indexing, exactly
  ! that document's cstr.f90/le64.f90 pattern.
  SUBROUTINE VGA_PUTS_AT(ROW, COL, STR, SLEN, ATTR) BIND(C, NAME="vga_puts_at")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: ROW, COL, SLEN
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(IN) :: STR(SLEN)
    INTEGER(C_INT16_T), INTENT(IN), VALUE :: ATTR
    INTEGER :: I
    DO I = 1, SLEN
      CALL VGA_PUTC_AT(ROW, COL + (I - 1), INT(IACHAR(STR(I)), C_INT8_T), ATTR)
    END DO
  END SUBROUTINE VGA_PUTS_AT

END MODULE VGA
