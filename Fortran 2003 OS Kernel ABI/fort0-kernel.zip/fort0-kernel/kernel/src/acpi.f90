! acpi.f90 -- ACPI table parsing: locates the RSDP (via the Multiboot2
! tag GRUB already provides -- see MULTIBOOT2 module's MB2_TAG_ACPI_
! OLD/NEW comment for why this project does not scan BIOS memory
! itself), walks RSDT or XSDT to find the MADT (Multiple APIC
! Description Table), and enumerates every Processor Local APIC entry
! -- the CPU discovery mechanism SMP bring-up needs to know how many
! cores exist and each one's APIC ID (required to target it with a
! Startup IPI later).
!
! Every structure this module reads was byte-offset-probed this
! session (objdump on linked probes, same technique as every other
! hardware structure in this codebase) before being trusted as
! BIND(C): the generic SDT header (36 bytes, all offsets confirmed
! matching the ACPI spec exactly) and the MADT Local APIC entry
! (8 bytes, ditto). Not re-derived from memory or copied from a
! reference without independent verification.
MODULE ACPI
  USE ISO_C_BINDING
  USE MULTIBOOT2
  IMPLICIT NONE

  TYPE, BIND(C) :: SDT_HEADER_T
    CHARACTER(KIND=C_CHAR), DIMENSION(4) :: SIG
    INTEGER(C_INT32_T) :: LENGTH
    INTEGER(C_INT8_T)  :: REVISION
    INTEGER(C_INT8_T)  :: CHECKSUM
    CHARACTER(KIND=C_CHAR), DIMENSION(6) :: OEM_ID
    CHARACTER(KIND=C_CHAR), DIMENSION(8) :: OEM_TABLE_ID
    INTEGER(C_INT32_T) :: OEM_REVISION
    INTEGER(C_INT32_T) :: CREATOR_ID
    INTEGER(C_INT32_T) :: CREATOR_REVISION
  END TYPE SDT_HEADER_T

  ! MADT-specific fields immediately after the generic 36-byte SDT
  ! header: u32 local_apic_address, u32 flags -- both plain u32, no
  ! independent byte-offset probe needed beyond the general "uniform
  ! field widths sum to aligned offsets" reasoning already established
  ! elsewhere in this codebase (RING0-BRIDGE-SPEC.md section 1).
  TYPE, BIND(C) :: MADT_HEADER_T
    TYPE(SDT_HEADER_T) :: SDT
    INTEGER(C_INT32_T) :: LOCAL_APIC_ADDR
    INTEGER(C_INT32_T) :: MADT_FLAGS
  END TYPE MADT_HEADER_T

  TYPE, BIND(C) :: MADT_LAPIC_T
    INTEGER(C_INT8_T)  :: ENTRY_TYPE
    INTEGER(C_INT8_T)  :: ENTRY_LENGTH
    INTEGER(C_INT8_T)  :: ACPI_PROCESSOR_ID
    INTEGER(C_INT8_T)  :: APIC_ID
    INTEGER(C_INT32_T) :: LAPIC_FLAGS
  END TYPE MADT_LAPIC_T

  INTEGER(C_INT8_T), PARAMETER :: MADT_ENTRY_LOCAL_APIC = 0_C_INT8_T
  INTEGER(C_INT32_T), PARAMETER :: MADT_LAPIC_FLAG_ENABLED = 1
  ! Bit 0 of a Local APIC entry's flags: processor is usable. An entry
  ! can exist (a physical socket/core is present) without this bit
  ! set (e.g. a core disabled by firmware) -- this project skips any
  ! entry where it is clear, matching every reference OS's behavior,
  ! not attempting to wake a core the firmware itself marked unusable.

  INTEGER, PARAMETER :: ACPI_MAX_CPUS = 64
  ! Fixed upper bound, same "fixed-size, no dynamic allocation needed
  ! to exist" reasoning as PMM_BITMAP (RING0-BRIDGE-SPEC.md section
  ! 5's storage-placement precedent) -- 64 is comfortably above any
  ! core count this project's QEMU test environment or realistic
  ! target hardware would present; revisit only if a genuine need for
  ! more arises.

  INTEGER(C_INT8_T) :: ACPI_CPU_APIC_IDS(ACPI_MAX_CPUS)
  BIND(C, NAME="acpi_cpu_apic_ids") :: ACPI_CPU_APIC_IDS
  INTEGER(C_INT32_T) :: ACPI_CPU_COUNT = 0
  BIND(C, NAME="acpi_cpu_count") :: ACPI_CPU_COUNT

  INTEGER(C_INT64_T) :: ACPI_LOCAL_APIC_PHYS = 0_C_INT64_T
  BIND(C, NAME="acpi_local_apic_phys") :: ACPI_LOCAL_APIC_PHYS
  ! MADT's local_apic_address field -- the physical (MMIO) base
  ! address every core's Local APIC register block is mapped at.
  ! Read once here, used by apic.f90 (a later file in this stage) to
  ! know where to map and access it -- this module only discovers and
  ! records the address, apic.f90 owns actually using it, keeping
  ! "parse ACPI" and "operate the APIC" as separate concerns the same
  ! way MULTIBOOT2/PMM stayed separate in stage 3.

CONTAINS

  ! ACPI_FIND_RSDP(MB2_INFO_ADDR, RSDT_OR_XSDT_ADDR, USE_XSDT) --
  ! locates the RSDP via the Multiboot2 ACPI_NEW tag (preferred, gives
  ! an XSDT) or ACPI_OLD tag (fallback, RSDT only) and returns the
  ! address of whichever root table to use next, plus a flag saying
  ! which table-entry width (4-byte RSDT pointers vs 8-byte XSDT
  ! pointers) the caller must use to walk it. Returns .FALSE. if
  ! neither tag is present (a real possibility this project does not
  ! treat as impossible, matching MB2_FIND_MEMORY_MAP's own precedent
  ! of a genuine not-found return rather than an assumed-always-present
  ! shortcut).
  FUNCTION ACPI_FIND_RSDP(MB2_INFO_ADDR, ROOT_ADDR, USE_XSDT) RESULT(FOUND)
    INTEGER(C_INT64_T), INTENT(IN) :: MB2_INFO_ADDR
    INTEGER(C_INT64_T), INTENT(OUT) :: ROOT_ADDR
    LOGICAL, INTENT(OUT) :: USE_XSDT
    LOGICAL :: FOUND
    INTEGER(C_INT64_T) :: TAG_ADDR
    INTEGER(C_INT32_T), POINTER :: RSDT_ADDR32
    INTEGER(C_INT64_T), POINTER :: XSDT_ADDR64

    FOUND = .FALSE.
    ROOT_ADDR = 0_C_INT64_T
    USE_XSDT = .FALSE.

    ! Prefer ACPI_NEW (v2+, gives an XSDT with 64-bit table pointers)
    ! over ACPI_OLD -- checked first, not merely present-vs-absent,
    ! because a system CAN provide both tags and this project should
    ! use the more capable one when available, matching the OSDev
    ! wiki/ACPI spec's own stated preference order for RSDT vs XSDT.
    IF (MB2_FIND_TAG(MB2_INFO_ADDR, MB2_TAG_ACPI_NEW, TAG_ADDR)) THEN
      ! ACPI_NEW tag payload is the RSDP v2 structure starting at
      ! TAG_ADDR+8 (past the generic 8-byte MB2 tag header). RSDP v2's
      ! xsdt_address field sits at byte offset 24 within the RSDP
      ! (confirmed against the RSDP v1 probe this session extended by
      ! the v2 fields' known offsets from the ACPI spec: length@20,
      ! xsdt_address@24 -- not independently re-probed for v2
      ! specifically since v1's first 20 bytes are unchanged and v2
      ! only appends fields, but flagged here as an assumption carried
      ! from the spec text rather than this project's own probe,
      ! unlike every other structure in this file).
      CALL C_F_POINTER(TRANSFER(TAG_ADDR + 8_C_INT64_T + 24_C_INT64_T, C_NULL_PTR), XSDT_ADDR64)
      IF (XSDT_ADDR64 /= 0_C_INT64_T) THEN
        ROOT_ADDR = XSDT_ADDR64
        USE_XSDT = .TRUE.
        FOUND = .TRUE.
        RETURN
      END IF
      ! XSDT address of 0 (some firmware genuinely omits it even in
      ! an ACPI_NEW tag) falls through to the ACPI_OLD/RSDT attempt
      ! below rather than failing outright.
    END IF

    IF (MB2_FIND_TAG(MB2_INFO_ADDR, MB2_TAG_ACPI_OLD, TAG_ADDR)) THEN
      ! RSDP v1's rsdt_address field is at byte offset 16 (byte-offset
      ! probed this session, see this file's header comment).
      CALL C_F_POINTER(TRANSFER(TAG_ADDR + 8_C_INT64_T + 16_C_INT64_T, C_NULL_PTR), RSDT_ADDR32)
      IF (RSDT_ADDR32 /= 0) THEN
        ! Same sign-extension hazard as LOCAL_APIC_ADDR below (this
        ! file's ACPI_PARSE_MADT) -- RSDT addresses are conventionally
        ! low (typically well under 1MiB in practice on real/QEMU
        ! firmware), so this specific field is much less likely to
        ! ever have its high bit set than LOCAL_APIC_ADDR's fixed
        ! 0xFEE00000 does -- but "less likely" is not "safe," and
        ! fixing it here costs nothing, so it is fixed rather than
        ! left as a latent bug waiting for a firmware that happens to
        ! place its RSDT above 2GiB.
        ROOT_ADDR = IAND(INT(RSDT_ADDR32, C_INT64_T), INT(Z'00000000FFFFFFFF', C_INT64_T))
        USE_XSDT = .FALSE.
        FOUND = .TRUE.
        RETURN
      END IF
    END IF
  END FUNCTION ACPI_FIND_RSDP

  ! ACPI_FIND_MADT(ROOT_ADDR, USE_XSDT, MADT_ADDR) -- walks the
  ! RSDT/XSDT's array of table pointers looking for the one whose SDT
  ! header signature is "APIC" (the MADT's actual ACPI signature,
  ! confirmed via web search this session against OSDev/print3m's
  ! notes -- "APIC" not "MADT", a real naming mismatch worth getting
  ! right since a literal string match on the wrong signature would
  ! silently never find the table).
  FUNCTION ACPI_FIND_MADT(ROOT_ADDR, USE_XSDT, MADT_ADDR) RESULT(FOUND)
    INTEGER(C_INT64_T), INTENT(IN) :: ROOT_ADDR
    LOGICAL, INTENT(IN) :: USE_XSDT
    INTEGER(C_INT64_T), INTENT(OUT) :: MADT_ADDR
    LOGICAL :: FOUND
    TYPE(SDT_HEADER_T), POINTER :: ROOT_HDR, CANDIDATE_HDR
    INTEGER(C_INT32_T), POINTER :: PTR32
    INTEGER(C_INT64_T), POINTER :: PTR64
    INTEGER(C_INT64_T) :: NUM_ENTRIES, I, ENTRY_ADDR, CANDIDATE_ADDR
    INTEGER(C_INT64_T) :: STRIDE

    FOUND = .FALSE.
    MADT_ADDR = 0_C_INT64_T

    CALL C_F_POINTER(TRANSFER(ROOT_ADDR, C_NULL_PTR), ROOT_HDR)
    STRIDE = MERGE(8_C_INT64_T, 4_C_INT64_T, USE_XSDT)
    NUM_ENTRIES = (INT(ROOT_HDR%LENGTH, C_INT64_T) - 36_C_INT64_T) / STRIDE
    ! 36: the generic SDT header size (byte-offset-probed, this
    ! file's header comment) -- the table-pointer array starts
    ! immediately after it, with no additional RSDT/XSDT-specific
    ! header fields between them (confirmed against the OSDev RSDT
    ! page's struct definition, which shows the header immediately
    ! followed by the pointer array with no gap).

    DO I = 0_C_INT64_T, NUM_ENTRIES - 1_C_INT64_T
      ENTRY_ADDR = ROOT_ADDR + 36_C_INT64_T + I * STRIDE
      IF (USE_XSDT) THEN
        CALL C_F_POINTER(TRANSFER(ENTRY_ADDR, C_NULL_PTR), PTR64)
        CANDIDATE_ADDR = PTR64
      ELSE
        CALL C_F_POINTER(TRANSFER(ENTRY_ADDR, C_NULL_PTR), PTR32)
        ! Same sign-extension hazard as ACPI_FIND_RSDP's RSDT_ADDR32
        ! handling and ACPI_PARSE_MADT's LOCAL_APIC_ADDR handling --
        ! masked here for the same reason (low-probability in
        ! practice for RSDT-referenced table addresses, but the fix
        ! is free and this project does not leave a known-latent
        ! instance of a bug it has already found and fixed elsewhere
        ! in the same file).
        CANDIDATE_ADDR = IAND(INT(PTR32, C_INT64_T), INT(Z'00000000FFFFFFFF', C_INT64_T))
      END IF

      CALL C_F_POINTER(TRANSFER(CANDIDATE_ADDR, C_NULL_PTR), CANDIDATE_HDR)
      IF (CANDIDATE_HDR%SIG(1) == 'A' .AND. CANDIDATE_HDR%SIG(2) == 'P' .AND. &
          CANDIDATE_HDR%SIG(3) == 'I' .AND. CANDIDATE_HDR%SIG(4) == 'C') THEN
        MADT_ADDR = CANDIDATE_ADDR
        FOUND = .TRUE.
        RETURN
      END IF
    END DO
  END FUNCTION ACPI_FIND_MADT

  ! ACPI_PARSE_MADT(MADT_ADDR) -- walks the MADT's variable-length
  ! entry list (immediately following the fixed MADT_HEADER_T),
  ! collecting every enabled Processor Local APIC entry's APIC ID into
  ! ACPI_CPU_APIC_IDS, and records LOCAL_APIC_ADDR into
  ! ACPI_LOCAL_APIC_PHYS. Skips every entry type other than
  ! MADT_ENTRY_LOCAL_APIC (I/O APIC entries, interrupt source
  ! overrides, etc. are real and present in a typical MADT but not
  ! this project's concern yet -- add-only-when-needed) using each
  ! entry's own ENTRY_LENGTH field to advance, the same self-
  ! describing-list pattern MB2_FIND_TAG already uses for Multiboot2
  ! tags.
  SUBROUTINE ACPI_PARSE_MADT(MADT_ADDR)
    INTEGER(C_INT64_T), INTENT(IN) :: MADT_ADDR
    TYPE(MADT_HEADER_T), POINTER :: MADT_HDR
    TYPE(MADT_LAPIC_T), POINTER :: ENTRY
    INTEGER(C_INT64_T) :: CURSOR, ENTRIES_END

    ACPI_CPU_COUNT = 0
    CALL C_F_POINTER(TRANSFER(MADT_ADDR, C_NULL_PTR), MADT_HDR)
    ! BUG FOUND AND FIXED THIS SESSION: LOCAL_APIC_ADDR is a 32-bit
    ! FIELD read as INTEGER(C_INT32_T) -- Fortran has no unsigned
    ! integer type, so a field whose top bit is set (0xFEE00000, the
    ! standard/QEMU Local APIC address, has bit 31 set) is negative as
    ! a signed INTEGER(C_INT32_T). The original version of this line
    ! used INT(MADT_HDR%LOCAL_APIC_ADDR, C_INT64_T), which performs
    ! Fortran's normal SIGN-EXTENDING widening conversion -- producing
    ! 0xFFFFFFFFFEE00000 instead of the intended 0x00000000FEE00000.
    ! This was not caught until a real page fault (CR2 matching the
    ! sign-extended, wrong address exactly) surfaced it during
    ! apic.f90's first MMIO access -- worth noting explicitly that the
    ! wrong value WAS ALREADY VISIBLE in this project's own earlier
    ! ACPI_TEST checkpoint output ("acpi local apic phys addr =
    ! 0xfffffffffee00000") for a full session before anything actually
    ! dereferenced it and forced the bug to be noticed, the same
    ! "wrong-but-plausible-looking value sits latent until something
    ! reads it" pattern RING0-BRIDGE-SPEC.md section 2 already
    ! documented for the MB2_INFO_ADDR calling-convention bug -- a
    ! second real instance of that general lesson, worth remembering
    ! as a recurring failure shape in this project, not a one-off.
    ! Fixed via IAND against a 32-bit all-ones mask, which zero-fills
    ! instead of sign-extending: this is the standard idiom for
    ! "treat a signed integer's bit pattern as unsigned" in a language
    ! without a native unsigned type, and the same pattern this
    ! project should reach for any time a hardware field is narrower
    ! than the Fortran INTEGER kind being converted into and the
    ! field's top bit is not guaranteed clear.
    ACPI_LOCAL_APIC_PHYS = IAND(INT(MADT_HDR%LOCAL_APIC_ADDR, C_INT64_T), &
                                 INT(Z'00000000FFFFFFFF', C_INT64_T))

    ENTRIES_END = MADT_ADDR + INT(MADT_HDR%SDT%LENGTH, C_INT64_T)
    CURSOR = MADT_ADDR + 44_C_INT64_T
    ! 44 = 36 (generic SDT header) + 4 (local_apic_address) + 4
    ! (madt flags) -- the fixed portion of MADT_HEADER_T, all uniform
    ! u32 fields after the SDT header so no independent byte-offset
    ! probe was needed beyond confirming MADT_HEADER_T's own total
    ! size, done implicitly by this arithmetic matching the type
    ! declaration's field list exactly.

    DO WHILE (CURSOR < ENTRIES_END)
      CALL C_F_POINTER(TRANSFER(CURSOR, C_NULL_PTR), ENTRY)

      IF (ENTRY%ENTRY_TYPE == MADT_ENTRY_LOCAL_APIC) THEN
        IF (IAND(ENTRY%LAPIC_FLAGS, MADT_LAPIC_FLAG_ENABLED) /= 0) THEN
          IF (ACPI_CPU_COUNT < ACPI_MAX_CPUS) THEN
            ACPI_CPU_COUNT = ACPI_CPU_COUNT + 1
            ACPI_CPU_APIC_IDS(ACPI_CPU_COUNT) = ENTRY%APIC_ID
          END IF
        END IF
      END IF

      IF (ENTRY%ENTRY_LENGTH <= 0_C_INT8_T) EXIT   ! malformed entry --
                                                     ! stop rather than
                                                     ! loop forever on
                                                     ! a zero-length
                                                     ! advance
      CURSOR = CURSOR + INT(ENTRY%ENTRY_LENGTH, C_INT64_T)
    END DO
  END SUBROUTINE ACPI_PARSE_MADT

  ! ACPI_INIT(MB2_INFO_ADDR) -- convenience entry point chaining the
  ! three functions above. Returns .TRUE. iff a MADT was found and
  ! parsed (ACPI_CPU_COUNT may still end up 0 in the not-found case,
  ! or in the unusual case of a MADT with no enabled Local APIC
  ! entries -- callers check ACPI_CPU_COUNT directly rather than
  ! relying solely on this function's return value for that
  ! distinction).
  FUNCTION ACPI_INIT(MB2_INFO_ADDR) RESULT(OK)
    INTEGER(C_INT64_T), INTENT(IN) :: MB2_INFO_ADDR
    LOGICAL :: OK
    INTEGER(C_INT64_T) :: ROOT_ADDR, MADT_ADDR
    LOGICAL :: USE_XSDT

    OK = .FALSE.
    IF (.NOT. ACPI_FIND_RSDP(MB2_INFO_ADDR, ROOT_ADDR, USE_XSDT)) RETURN
    IF (.NOT. ACPI_FIND_MADT(ROOT_ADDR, USE_XSDT, MADT_ADDR)) RETURN
    CALL ACPI_PARSE_MADT(MADT_ADDR)
    OK = .TRUE.
  END FUNCTION ACPI_INIT

END MODULE ACPI
