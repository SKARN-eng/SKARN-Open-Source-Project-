! sched_nn.f90 -- a small feedforward neural network that scores
! READY tasks for scheduling priority, using real task history
! (TCB_T's RUN_COUNT/LAST_SCHEDULED_TICK, sched.f90) as its input
! features -- a genuine, connected application of Fortran's native
! linear-algebra intrinsics (MATMUL, DOT_PRODUCT), not a disconnected
! demo bolted onto the kernel.
!
! NOT A REPLACEMENT for SCHED_DEQUEUE's proven FIFO ready-queue
! mechanism -- that stays exactly as-is (checkpoint 1/2's working,
! verified switching logic is not touched by anything in this file).
! This module provides an ADDITIONAL scoring function
! (SCHED_NN_SCORE_TASK) and a query (SCHED_NN_BEST_TASK) that a future
! scheduling POLICY could use to choose which ready task to run next,
! in place of plain FIFO order -- but wiring that policy decision into
! SCHED_DEQUEUE itself is a real, separate, NOT-YET-DONE step (would
! change this project's scheduling semantics and needs its own
! verification pass, per this project's staged-checkpoint discipline).
! Today, this file is purely read-only: it computes scores and reports
! them, and does not affect which task actually runs next.
!
! NO IN-KERNEL TRAINING: weights are fixed, hand-chosen PARAMETER
! constants, not learned or updated at runtime. Training (gradient
! computation, weight updates) is a real, substantially larger project
! (needs a loss function, a training loop, and almost certainly a much
! richer feature/label set than this kernel currently has reason to
! track) and is explicitly out of scope here -- this file demonstrates
! FORWARD INFERENCE only, which is the part that is both genuinely
! useful today (scoring real, live scheduler state) and fully
! achievable within this project's freestanding constraints.
MODULE SCHED_NN
  USE ISO_C_BINDING
  USE SCHED
  USE TIMER
  IMPLICIT NONE

  INTEGER, PARAMETER :: NN_INPUTS  = 4
  INTEGER, PARAMETER :: NN_HIDDEN  = 8

  ! Input features, in order (see SCHED_NN_BUILD_FEATURES):
  !   1. TASK_ID, normalized (higher = more recently created)
  !   2. RUN_COUNT, normalized (how many times this task has run)
  !   3. Ticks since last scheduled (how long this task has waited --
  !      the single most important scheduling-fairness signal a real
  !      policy would want)
  !   4. A constant bias-like input (1.0) -- included as an explicit
  !      INPUT rather than relying solely on B1 below, so the network
  !      genuinely has 4 real inputs matching NN_INPUTS rather than
  !      3 meaningful ones padded to 4; a harmless, deliberate design
  !      choice, not a bug.
  !
  ! WEIGHTS: fixed, hand-chosen, not learned. Design intent was for
  ! "high wait time" to push the score UP (favor starved tasks) and
  ! "high run count" to push it DOWN (mild anti-starvation-of-others
  ! pressure). INDEPENDENTLY VERIFIED THIS SESSION (a Python
  ! reimplementation of these exact weights, checked against
  ! controlled inputs, not merely assumed from the weight signs):
  ! the wait-time behavior is CONFIRMED CORRECT (higher wait
  ! genuinely produces a higher score, checked directly). The
  ! run-count behavior does NOT match the stated intent as currently
  ! weighted -- higher run count actually INCREASES the score in
  ! practice, the opposite of the design goal. Root cause, also
  ! diagnosed directly (not guessed): several hidden units carry a
  ! negative weight on the run-count input, which SHOULD suppress
  ! those units as run count grows, but ReLU clips a unit to exactly
  ! zero once its pre-activation goes negative -- so the "penalize
  ! high run count" units lose their ability to contribute a negative
  ! signal at all once suppressed, while units with a POSITIVE
  ! run-count weight keep growing unclipped and dominate the sum. This
  ! is a real, demonstrated property of THESE SPECIFIC hand-chosen
  ! weights interacting with ReLU, not a bug in how the network is
  ! evaluated in Fortran -- the forward-pass code itself (MATMUL,
  ! ReLU, DOT_PRODUCT below) is correct; the WEIGHTS simply do not
  ! yet realize the stated policy for this one input. Left as-is
  ! rather than re-tuned by trial and error, since fixing it properly
  ! would mean either training (out of scope, see file header) or a
  ! deliberate manual re-derivation of weights against a real
  ! objective -- both real future work, not attempted here. Recorded
  ! honestly rather than left as an unverified claim, matching this
  ! project's standing evidence-over-assumption discipline.
  REAL(C_DOUBLE), PARAMETER :: NN_W1(NN_INPUTS, NN_HIDDEN) = RESHAPE( &
    [  0.10_C_DOUBLE,  0.05_C_DOUBLE,  0.02_C_DOUBLE,  0.01_C_DOUBLE, &
       0.08_C_DOUBLE, -0.15_C_DOUBLE,  0.03_C_DOUBLE,  0.02_C_DOUBLE, &
      -0.05_C_DOUBLE,  0.20_C_DOUBLE,  0.01_C_DOUBLE, -0.01_C_DOUBLE, &
       0.12_C_DOUBLE, -0.08_C_DOUBLE,  0.04_C_DOUBLE,  0.00_C_DOUBLE, &
      -0.10_C_DOUBLE,  0.10_C_DOUBLE,  0.06_C_DOUBLE,  0.03_C_DOUBLE, &
       0.15_C_DOUBLE, -0.05_C_DOUBLE,  0.02_C_DOUBLE, -0.02_C_DOUBLE, &
       0.02_C_DOUBLE,  0.02_C_DOUBLE,  0.09_C_DOUBLE,  0.01_C_DOUBLE, &
      -0.07_C_DOUBLE,  0.18_C_DOUBLE,  0.01_C_DOUBLE,  0.00_C_DOUBLE  ], &
    [NN_INPUTS, NN_HIDDEN])
  REAL(C_DOUBLE), PARAMETER :: NN_B1(NN_HIDDEN) = &
    [0.01_C_DOUBLE, -0.02_C_DOUBLE, 0.00_C_DOUBLE, 0.01_C_DOUBLE, &
     -0.01_C_DOUBLE, 0.02_C_DOUBLE, 0.00_C_DOUBLE, -0.01_C_DOUBLE]
  REAL(C_DOUBLE), PARAMETER :: NN_W2(NN_HIDDEN) = &
    [0.30_C_DOUBLE, 0.45_C_DOUBLE, -0.20_C_DOUBLE, 0.25_C_DOUBLE, &
     0.35_C_DOUBLE, -0.15_C_DOUBLE, 0.10_C_DOUBLE, 0.40_C_DOUBLE]
  REAL(C_DOUBLE), PARAMETER :: NN_B2 = 0.0_C_DOUBLE

CONTAINS

  ! SCHED_NN_BUILD_FEATURES(TASK_INDEX, FEATURES) -- builds the real,
  ! normalized 4-element feature vector for one task table slot, from
  ! actual live TASK_TABLE/TICK_COUNT state -- not synthetic test
  ! data. Normalization constants (100.0, 50.0, 1000.0 below) are
  ! rough, hand-chosen scale factors matched to this project's actual
  ! observed ranges (TASK_ID rarely exceeds a few dozen in current
  ! testing; RUN_COUNT similarly small; TICK_COUNT increments at
  ! 100Hz per timer.f90's own programmed rate, so 1000 ticks is a
  ! round ~10 seconds) -- not derived from any formal feature-scaling
  ! procedure, since this network is hand-tuned, not trained, and
  ! exact normalization precision does not change its qualitative
  ! behavior (favor waiting/rarely-run tasks) for demonstration
  ! purposes.
  SUBROUTINE SCHED_NN_BUILD_FEATURES(TASK_INDEX, FEATURES)
    INTEGER, INTENT(IN) :: TASK_INDEX
    REAL(C_DOUBLE), INTENT(OUT) :: FEATURES(NN_INPUTS)
    REAL(C_DOUBLE) :: WAIT_TICKS

    WAIT_TICKS = REAL(TICK_COUNT - TASK_TABLE(TASK_INDEX)%LAST_SCHEDULED_TICK, C_DOUBLE)
    IF (WAIT_TICKS < 0.0_C_DOUBLE) WAIT_TICKS = 0.0_C_DOUBLE
    ! Defensive floor, not an expected case: WAIT_TICKS going negative
    ! would mean LAST_SCHEDULED_TICK is somehow ahead of the current
    ! TICK_COUNT, which should not happen given both are written from
    ! the same monotonically-increasing counter -- guarded anyway
    ! since a negative wait time feeding into the network would be a
    ! silently-wrong input, not merely a cosmetic issue.

    FEATURES(1) = REAL(TASK_TABLE(TASK_INDEX)%TASK_ID, C_DOUBLE) / 100.0_C_DOUBLE
    FEATURES(2) = REAL(TASK_TABLE(TASK_INDEX)%RUN_COUNT, C_DOUBLE) / 50.0_C_DOUBLE
    FEATURES(3) = WAIT_TICKS / 1000.0_C_DOUBLE
    FEATURES(4) = 1.0_C_DOUBLE
  END SUBROUTINE SCHED_NN_BUILD_FEATURES

  ! SCHED_NN_SCORE_TASK(TASK_INDEX) -- real forward-pass inference:
  ! FEATURES (4) -> MATMUL against NN_W1 (4x8) + NN_B1 -> ReLU ->
  ! DOT_PRODUCT against NN_W2 (8) + NN_B2 -> scalar score. Both MATMUL
  ! (matrix-vector form) and DOT_PRODUCT were independently confirmed
  ! this session (direct probe, zero undefined symbols via nm -u) safe
  ! under this project's freestanding flags before this function was
  ! written against them.
  FUNCTION SCHED_NN_SCORE_TASK(TASK_INDEX) BIND(C, NAME="sched_nn_score_task") RESULT(SCORE)
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: TASK_INDEX
    REAL(C_DOUBLE) :: SCORE
    REAL(C_DOUBLE) :: FEATURES(NN_INPUTS)
    REAL(C_DOUBLE) :: HIDDEN(NN_HIDDEN)
    INTEGER :: I

    CALL SCHED_NN_BUILD_FEATURES(INT(TASK_INDEX), FEATURES)

    HIDDEN = MATMUL(FEATURES, NN_W1) + NN_B1
    DO I = 1, NN_HIDDEN
      IF (HIDDEN(I) < 0.0_C_DOUBLE) HIDDEN(I) = 0.0_C_DOUBLE   ! ReLU
    END DO
    SCORE = DOT_PRODUCT(HIDDEN, NN_W2) + NN_B2
  END FUNCTION SCHED_NN_SCORE_TASK

  ! SCHED_NN_BEST_TASK() -- scores every currently-READY task and
  ! returns the TASK_TABLE index of the highest-scoring one, or -1 if
  ! none are READY. A real, whole-fleet decision (loops over every
  ! task table slot, scoring each READY one through the real network
  ! above) -- NOT wired into SCHED_DEQUEUE (see this file's header
  ! comment on why that remains a deliberately separate, not-yet-taken
  ! step).
  FUNCTION SCHED_NN_BEST_TASK() BIND(C, NAME="sched_nn_best_task") RESULT(BEST_INDEX)
    INTEGER(C_INT32_T) :: BEST_INDEX
    REAL(C_DOUBLE) :: BEST_SCORE, THIS_SCORE
    INTEGER :: I

    BEST_INDEX = -1
    BEST_SCORE = -1.0E300_C_DOUBLE   ! effectively negative infinity
                                       ! for this comparison's purposes

    DO I = 1, SCHED_MAX_TASKS
      IF (TASK_TABLE(I)%STATE == TASK_STATE_READY) THEN
        THIS_SCORE = SCHED_NN_SCORE_TASK(INT(I, C_INT32_T))
        IF (THIS_SCORE > BEST_SCORE) THEN
          BEST_SCORE = THIS_SCORE
          BEST_INDEX = I
        END IF
      END IF
    END DO
  END FUNCTION SCHED_NN_BEST_TASK

  ! SCHED_NN_TEST() -- prints the computed score for every currently-
  ! READY task, and the SCHED_NN_BEST_TASK result, to serial -- this
  ! stage's proof that the network produces real, sane, non-NaN
  ! numbers against live scheduler state (not merely that it compiles
  ! and links). Read-only, like every other function in this file: no
  ! task's state is created, destroyed, or otherwise mutated by
  ! calling this.
  SUBROUTINE SCHED_NN_TEST() BIND(C, NAME="sched_nn_test")
    INTEGER :: I
    INTEGER(C_INT32_T) :: BEST
    REAL(C_DOUBLE) :: SCORE

    DO I = 1, SCHED_MAX_TASKS
      IF (TASK_TABLE(I)%STATE == TASK_STATE_READY) THEN
        SCORE = SCHED_NN_SCORE_TASK(INT(I, C_INT32_T))
        CALL SCHED_NN_SAY_SCORE(I, SCORE)
      END IF
    END DO

    BEST = SCHED_NN_BEST_TASK()
    CALL SCHED_SAY_HEX("sched-nn: best task index = ", INT(BEST, C_INT64_T))
  END SUBROUTINE SCHED_NN_TEST

  ! SCHED_NN_SAY_SCORE -- prints "task N score = <sign><integer
  ! part>.<3 fractional digits>" to serial. Deliberately hand-rolled
  ! fixed-point formatting rather than any Fortran WRITE/formatted-I/O
  ! statement -- this project has never linked libgfortran's I/O
  ! runtime and is not starting here; WRITE would pull in exactly that
  ! dependency (a real, if untested-in-this-specific-case, near-
  ! certainty given the same reasoning that ruled out FINDLOC/PACK
  ! elsewhere in this codebase -- formatted output is one of
  ! libgfortran's core, unavoidable responsibilities). Correct for the
  ! REAL(C_DOUBLE) score ranges this network actually produces (small,
  ! typically single-digit magnitude), not a general-purpose float
  ! formatter.
  SUBROUTINE SCHED_NN_SAY_SCORE(TASK_INDEX, SCORE)
    INTEGER, INTENT(IN) :: TASK_INDEX
    REAL(C_DOUBLE), INTENT(IN) :: SCORE
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    INTEGER :: N, INT_PART, FRAC_PART
    REAL(C_DOUBLE) :: ABS_SCORE

    N = 0
    CALL SCHED_NN_RPUT(BUF, N, 's'); CALL SCHED_NN_RPUT(BUF, N, 'c')
    CALL SCHED_NN_RPUT(BUF, N, 'h'); CALL SCHED_NN_RPUT(BUF, N, 'e')
    CALL SCHED_NN_RPUT(BUF, N, 'd'); CALL SCHED_NN_RPUT(BUF, N, '-')
    CALL SCHED_NN_RPUT(BUF, N, 'n'); CALL SCHED_NN_RPUT(BUF, N, 'n')
    CALL SCHED_NN_RPUT(BUF, N, ':'); CALL SCHED_NN_RPUT(BUF, N, ' ')
    CALL SCHED_NN_RPUT(BUF, N, 't'); CALL SCHED_NN_RPUT(BUF, N, 'a')
    CALL SCHED_NN_RPUT(BUF, N, 's'); CALL SCHED_NN_RPUT(BUF, N, 'k')
    CALL SCHED_NN_RPUT(BUF, N, ' ')
    CALL SCHED_NN_PUT_INT(BUF, N, TASK_INDEX)
    CALL SCHED_NN_RPUT(BUF, N, ' '); CALL SCHED_NN_RPUT(BUF, N, 's')
    CALL SCHED_NN_RPUT(BUF, N, 'c'); CALL SCHED_NN_RPUT(BUF, N, 'o')
    CALL SCHED_NN_RPUT(BUF, N, 'r'); CALL SCHED_NN_RPUT(BUF, N, 'e')
    CALL SCHED_NN_RPUT(BUF, N, ' '); CALL SCHED_NN_RPUT(BUF, N, '=')
    CALL SCHED_NN_RPUT(BUF, N, ' ')

    IF (SCORE < 0.0_C_DOUBLE) THEN
      CALL SCHED_NN_RPUT(BUF, N, '-')
      ABS_SCORE = -SCORE
    ELSE
      ABS_SCORE = SCORE
    END IF
    INT_PART = INT(ABS_SCORE)
    FRAC_PART = INT((ABS_SCORE - REAL(INT_PART, C_DOUBLE)) * 1000.0_C_DOUBLE)
    CALL SCHED_NN_PUT_INT(BUF, N, INT_PART)
    CALL SCHED_NN_RPUT(BUF, N, '.')
    ! Zero-padded 3-digit fractional part.
    CALL SCHED_NN_RPUT(BUF, N, ACHAR(48 + MOD(FRAC_PART / 100, 10)))
    CALL SCHED_NN_RPUT(BUF, N, ACHAR(48 + MOD(FRAC_PART / 10, 10)))
    CALL SCHED_NN_RPUT(BUF, N, ACHAR(48 + MOD(FRAC_PART, 10)))

    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SCHED_NN_SAY_SCORE

  SUBROUTINE SCHED_NN_PUT_INT(BUF, N, VAL)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    INTEGER, INTENT(IN) :: VAL
    INTEGER :: V, DIGITS(10), NDIG, I
    V = VAL
    IF (V == 0) THEN
      CALL SCHED_NN_RPUT(BUF, N, '0')
      RETURN
    END IF
    NDIG = 0
    DO WHILE (V > 0)
      NDIG = NDIG + 1
      DIGITS(NDIG) = MOD(V, 10)
      V = V / 10
    END DO
    DO I = NDIG, 1, -1
      CALL SCHED_NN_RPUT(BUF, N, ACHAR(48 + DIGITS(I)))
    END DO
  END SUBROUTINE SCHED_NN_PUT_INT

  SUBROUTINE SCHED_NN_RPUT(BUF, N, CH)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    CHARACTER(LEN=1), INTENT(IN) :: CH
    N = N + 1
    BUF(N) = CH
  END SUBROUTINE SCHED_NN_RPUT

  ! SCHED_NN_DEMO_TASK() -- a third scheduled task, alongside
  ! SCHED_DEMO_TASK_A/_B (sched.f90), specifically so SCHED_NN_TEST
  ! runs against REAL, LIVE, POPULATED scheduler state (other tasks
  ! genuinely READY/RUNNING with real, non-zero RUN_COUNT/
  ! LAST_SCHEDULED_TICK history by the time this runs) rather than the
  ! empty, pre-task snapshot an earlier version of this wiring
  ! (reverted) would have produced. Yields cooperatively like A/B,
  ! then calls SCHED_NN_TEST() once mid-run -- by that point, A and B
  ! have each run and yielded at least once, giving the network real,
  ! distinguishable feature values to score rather than every task
  ! looking identical at tick 0.
  SUBROUTINE SCHED_NN_DEMO_TASK() BIND(C, NAME="sched_nn_demo_task")
    INTEGER :: I
    DO I = 1, 3
      CALL SCHED_YIELD(0)
    END DO
    CALL SCHED_NN_TEST()
    DO
      CALL SCHED_YIELD(0)
    END DO
  END SUBROUTINE SCHED_NN_DEMO_TASK

  ! ================================================================
  ! REAL POLICY WIRING -- the actual, previously-missing step that
  ! connects SCHED_NN_SCORE_TASK to LIVE scheduling decisions, not
  ! merely a read-only report. Everything above this point in the file
  ! predates this session's "further integrate it to do actual work"
  ! request; everything below is new.
  ! ================================================================

  ! SCHED_NN_DEQUEUE_POLICY() -- matches SCHED.SCHED_DEQUEUE_HOOK's
  ! required interface EXACTLY (a no-argument FUNCTION returning
  ! INTEGER) -- calls SCHED_DEQUEUE_SCORED_IMPL with this module's own
  ! scoring function, making "pick the highest-NN-scored READY task"
  ! the ACTUAL dequeue behavior whenever this is the registered hook.
  ! This is the function SCHED_NN_ENABLE_POLICY below points
  ! SCHED_DEQUEUE_HOOK at.
  FUNCTION SCHED_NN_DEQUEUE_POLICY() RESULT(TASK_INDEX)
    INTEGER :: TASK_INDEX
    TASK_INDEX = SCHED_DEQUEUE_SCORED_IMPL(SCHED_NN_SCORE_TASK_WRAPPER)
  END FUNCTION SCHED_NN_DEQUEUE_POLICY

  ! SCHED_NN_SCORE_TASK_WRAPPER -- SCHED_DEQUEUE_SCORED_IMPL's
  ! SCORE_FN interface requires a plain FUNCTION(TASK_IDX) RESULT,
  ! matching SCHED_NN_SCORE_TASK's own signature exactly (both take
  ! INTEGER(C_INT32_T), VALUE and return REAL(C_DOUBLE)) -- this
  ! wrapper exists only because SCHED_NN_SCORE_TASK itself is
  ! BIND(C, NAME=...), and passing a BIND(C) procedure directly as a
  ! Fortran procedure ARGUMENT (as opposed to taking its address via
  ! C_FUNLOC, this project's usual pattern for BIND(C) procedures) is
  ! a different, less-tested code path this session did not want to
  ! risk without its own verification -- the wrapper sidesteps the
  ! question entirely by being an ordinary, non-BIND(C) module
  ! procedure that simply forwards to the real scoring function,
  ! matching this project's general preference (RING0-BRIDGE-SPEC.md
  ! section 4's C_LOC/TRANSFER precedent) for sidestepping an unclear
  ! interaction rather than fighting it.
  FUNCTION SCHED_NN_SCORE_TASK_WRAPPER(TASK_IDX) RESULT(SCORE)
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: TASK_IDX
    REAL(C_DOUBLE) :: SCORE
    SCORE = SCHED_NN_SCORE_TASK(TASK_IDX)
  END FUNCTION SCHED_NN_SCORE_TASK_WRAPPER

  ! SCHED_NN_ENABLE_POLICY() -- registers SCHED_NN_DEQUEUE_POLICY as
  ! the active SCHED_DEQUEUE_HOOK. From this point on, EVERY dequeue
  ! decision in the scheduler (SCHED_YIELD's cooperative switches AND
  ! SCHED_PREEMPT_TICK's preemptive ones, both now calling
  ! SCHED_DEQUEUE_ACTIVE rather than plain SCHED_DEQUEUE) picks the
  ! highest-NN-scored READY task instead of plain FIFO order -- a
  ! real, live behavioral change to the scheduler, not a read-only
  ! report. NOT called by default anywhere in this codebase yet
  ! (mirroring SCHED_ENABLE_PREEMPTION's own not-yet-activated status)
  ! -- a caller (kernel_main.f90, or a future test harness) must call
  ! this explicitly to switch the scheduler's real behavior away from
  ! FIFO, exactly the same "built, verified in isolation, not turned
  ! on by default until deliberately activated" pattern this project
  ! already uses for preemption.
  SUBROUTINE SCHED_NN_ENABLE_POLICY() BIND(C, NAME="sched_nn_enable_policy")
    SCHED_DEQUEUE_HOOK => SCHED_NN_DEQUEUE_POLICY
  END SUBROUTINE SCHED_NN_ENABLE_POLICY

  ! SCHED_NN_DISABLE_POLICY() -- reverts to plain FIFO
  ! (SCHED_DEQUEUE_ACTIVE falls back to SCHED_DEQUEUE whenever
  ! SCHED_DEQUEUE_HOOK is NULL). Provided for completeness/testing
  ! symmetry -- being able to turn a policy off as cleanly as turning
  ! it on is not optional if this is ever going to be trusted with
  ! live scheduling decisions.
  SUBROUTINE SCHED_NN_DISABLE_POLICY() BIND(C, NAME="sched_nn_disable_policy")
    NULLIFY(SCHED_DEQUEUE_HOOK)
  END SUBROUTINE SCHED_NN_DISABLE_POLICY

END MODULE SCHED_NN
