! smp.f90 -- SMP bring-up: copies ap_trampoline.s to its fixed
! physical address, allocates a stack for each detected AP, and runs
! the standard INIT-SIPI-SIPI sequence to wake them one at a time.
!
! ONE CORE AT A TIME, DELIBERATELY, NOT IN PARALLEL: ap_trampoline.s's
! header comment already states why this is safe (a single shared
! ap_target_rsp/ap_target_rip slot, reused per core) -- this module is
! the caller-side half of that contract: SMP_WAKE_ALL_APS must fully
! confirm core N has started (via AP_STARTED_FLAGS, below) before
! writing core N+1's stack pointer into that shared slot and sending
! its SIPI, or two cores could race on the same slot and one could
! silently receive the wrong stack.
MODULE SMP
  USE ISO_C_BINDING
  USE RING0
  USE VMM
  USE PMM
  USE ACPI
  USE APIC
  USE SERIAL
  USE SCHED
  IMPLICIT NONE

  INTEGER(C_INT64_T), PARAMETER :: AP_TRAMPOLINE_PHYS = INT(Z'8000', C_INT64_T)
  INTEGER(C_INT8_T), PARAMETER :: AP_TRAMPOLINE_SIPI_VECTOR = INT(Z'08', C_INT8_T)
  ! 0x8000 / 0x1000 = 0x08 -- see ap_trampoline.s's header comment for
  ! why the trampoline's physical address and this vector byte must
  ! stay in this exact relationship; if AP_TRAMPOLINE_PHYS ever
  ! changes, this must be recomputed to match, by hand -- stated as
  ! two independently-readable literals rather than one derived from
  ! the other, on the theory that a reader checking "does this vector
  ! match this address" should be able to compare two plain numbers
  ! against the header comment's stated arithmetic directly.

  ! AP_STARTED_FLAGS(N) is set to 1 by core N itself, from Fortran,
  ! once it has safely reached AP_MAIN below -- the BSP polls this
  ! (with a bounded timeout, not forever) to know when it is safe to
  ! move on to waking the NEXT core. A plain INTEGER array, not
  ! anything more elaborate (an atomic type, a lock) -- this project
  ! has no other concurrent writer to any single element (each core
  ! writes only its own slot, the BSP only reads), so there is no real
  ! race to guard against yet; revisit if a future change adds a
  ! second writer to the same element.
  INTEGER(C_INT32_T) :: AP_STARTED_FLAGS(ACPI_MAX_CPUS) = 0
  BIND(C, NAME="ap_started_flags") :: AP_STARTED_FLAGS
  ! BUG FOUND AND FIXED THIS SESSION (found via a cross-file check
  ! prompted by the vectorization-audit research's Tier 1 "compile-
  ! time invariant" idea, not by a real fault): this was previously
  ! declared with a hardcoded literal 64, matching acpi.f90's
  ! ACPI_MAX_CPUS=64 only by coincidence of both currently happening
  ! to use the same value -- nothing enforced them staying equal. A
  ! future change to ACPI_MAX_CPUS (to support more cores) would have
  ! silently left this array at its old, now-too-small size, with
  ! indexing (CORE_INDEX + 1, this file's own SMP_WAKE_ONE_AP/AP_MAIN)
  ! for any core index beyond the stale bound overflowing or
  ! truncating with no compiler warning and no error until it actually
  ! happened at runtime on hardware with enough cores to trigger it.
  ! Fixed by referencing ACPI_MAX_CPUS directly -- this file already
  ! USEs ACPI, so no new dependency was introduced, only the removal
  ! of a duplicated constant that had no mechanism keeping it correct.

  INTEGER(C_INT32_T) :: AP_STARTED_COUNT = 0
  BIND(C, NAME="ap_started_count") :: AP_STARTED_COUNT

CONTAINS

  ! SMP_COPY_TRAMPOLINE() -- copies ap_trampoline.s's assembled bytes
  ! (FORT0K_AP_TRAMPOLINE_START/_END, ring0.s-adjacent addresses --
  ! see that file) from wherever the linker placed them in the kernel
  ! image to AP_TRAMPOLINE_PHYS, byte by byte (explicit DO loop, not
  ! whole-array assignment or any copy-shaped idiom -- this copy runs
  ! exactly once at boot, is not remotely performance-sensitive, and
  ! an explicit loop costs nothing extra to keep as the visibly-safe
  ! default rather than leaning on -fno-tree-loop-distribute-patterns
  ! alone for a copy this consequential to get right).
  SUBROUTINE SMP_COPY_TRAMPOLINE()
    INTEGER(C_INT64_T) :: SRC_START, SRC_END, LEN, I
    INTEGER(C_INT8_T), POINTER :: SRC_BYTE, DST_BYTE

    SRC_START = FORT0K_AP_TRAMPOLINE_START()
    SRC_END = FORT0K_AP_TRAMPOLINE_END()
    LEN = SRC_END - SRC_START

    DO I = 0_C_INT64_T, LEN - 1_C_INT64_T
      CALL C_F_POINTER(TRANSFER(SRC_START + I, C_NULL_PTR), SRC_BYTE)
      CALL C_F_POINTER(TRANSFER(AP_TRAMPOLINE_PHYS + I, C_NULL_PTR), DST_BYTE)
      DST_BYTE = SRC_BYTE
    END DO
  END SUBROUTINE SMP_COPY_TRAMPOLINE

  ! SMP_WAKE_ONE_AP(APIC_ID, CORE_INDEX) -- allocates a fresh stack
  ! (PMM_ALLOC_PAGE -- one page, 4KiB; small, but every AP so far only
  ! runs AP_MAIN below, which does nothing stack-intensive; revisit if
  ! a future AP workload needs more), pokes it and the shared AP_MAIN
  ! entry point into the trampoline's fixed slots, and runs the
  ! standard INIT - (wait) - SIPI - (wait) - SIPI sequence (two SIPIs,
  ! per the Intel MP spec / every reference OS's implementation -- the
  ! second SIPI is a real-hardware-quirk-driven redundancy some older
  ! CPUs need and newer ones ignore harmlessly, not a bug in this
  ! project's sequence). Waits (bounded) for AP_STARTED_FLAGS to
  ! confirm the core actually started before returning, so the caller
  ! (SMP_WAKE_ALL_APS) can safely move on to the next core per this
  ! file's header comment.
  SUBROUTINE SMP_WAKE_ONE_AP(APIC_ID, CORE_INDEX)
    INTEGER(C_INT8_T), INTENT(IN) :: APIC_ID
    INTEGER(C_INT32_T), INTENT(IN) :: CORE_INDEX
    INTEGER(C_INT64_T) :: STACK_PHYS
    INTEGER(C_INT64_T), POINTER :: TARGET_CR3, TARGET_RSP, TARGET_RIP
    INTEGER(C_INT8_T), POINTER, VOLATILE :: CLAIM_FLAG
    INTEGER(C_INT64_T) :: WAIT_ITER

    STACK_PHYS = PMM_ALLOC_PAGE()
    ! STACK_PHYS points at the LOW end of the allocated page; the
    ! stack must start at the HIGH end and grow down, same convention
    ! boot.s's own boot_stack_top used.

    CALL C_F_POINTER(TRANSFER(AP_TRAMPOLINE_PHYS + AP_TARGET_CR3_OFFSET(), C_NULL_PTR), TARGET_CR3)
    CALL C_F_POINTER(TRANSFER(AP_TRAMPOLINE_PHYS + AP_TARGET_RSP_OFFSET(), C_NULL_PTR), TARGET_RSP)
    CALL C_F_POINTER(TRANSFER(AP_TRAMPOLINE_PHYS + AP_TARGET_RIP_OFFSET(), C_NULL_PTR), TARGET_RIP)
    CALL C_F_POINTER(TRANSFER(INT(Z'9004', C_INT64_T), C_NULL_PTR), CLAIM_FLAG)

    ! BUG FOUND AND FIXED THIS SESSION -- a real structural race, not
    ! merely an imprecise timing constant: an earlier version of this
    ! function wrote the target slots, sent the IPIs, then waited on
    ! AP_STARTED_FLAGS -- a signal set only much later, after the AP
    ! has fully reached Fortran. This left a real window, between "AP
    ! begins executing the trampoline" and "AP has finished reading
    ! ap_target_cr3/_rsp into real registers," during which this
    ! function could time out (or simply race ahead once a generous-
    ! but-finite wait elapsed) and let SMP_WAKE_ALL_APS call this
    ! function again for the NEXT core, overwriting the shared target
    ! slots while the current core might still be reading them.
    ! Repeated boot testing (20+ runs across two sessions) showed the
    ! signature of exactly this: every core eventually printed its
    ! "core up" confirmation (so nothing crashed), yet the BSP's own
    ! count still came out short, with cores sometimes arriving out
    ! of wake-order -- consistent with a race on shared state, not
    ! with a core simply being slow. Fixed by clearing the trampoline
    ! image's ap_target_claimed byte HERE (before it is copied to
    ! AP_TRAMPOLINE_PHYS for THIS wake, ensuring a stale claim from a
    ! previous core cannot be misread as this core's) and waiting on
    ! THAT flag, not AP_STARTED_FLAGS, before returning -- the claim
    ! flag is set by ap_trampoline.s itself, in real mode, before it
    ! reads any shared slot (see that file's header comment for the
    ! full reasoning), so observing it set is a genuine guarantee the
    ! current core is done reading, not an inference from elapsed time.
    CLAIM_FLAG = 0_C_INT8_T

    TARGET_CR3 = VMM_CURRENT_PML4
    TARGET_RSP = STACK_PHYS + 4096_C_INT64_T
    TARGET_RIP = FORT0K_AP_MAIN_ADDR()

    AP_STARTED_FLAGS(CORE_INDEX + 1) = 0

    CALL APIC_SEND_INIT(APIC_ID)
    CALL SMP_BUSY_WAIT_SHORT()

    CALL APIC_SEND_STARTUP(APIC_ID, AP_TRAMPOLINE_SIPI_VECTOR)
    CALL SMP_BUSY_WAIT_SHORT()
    CALL APIC_SEND_STARTUP(APIC_ID, AP_TRAMPOLINE_SIPI_VECTOR)

    ! Wait for the CLAIM, not for AP_STARTED_FLAGS -- see comment
    ! above. Once this returns (claim observed), it is safe for the
    ! caller to move on and overwrite the shared slots for the next
    ! core; AP_STARTED_FLAGS (checked separately, later, by
    ! SMP_WAKE_ALL_APS, purely for reporting purposes) may still be
    ! unset at this point and is expected to be -- this core has more
    ! work to do (protected mode, long mode, reaching Fortran) after
    ! claiming, all of which can safely happen concurrently with the
    ! BSP moving on, since none of it touches the shared slots again.
    DO WAIT_ITER = 1_C_INT64_T, 200000000_C_INT64_T
      IF (CLAIM_FLAG /= 0_C_INT8_T) EXIT
    END DO
  END SUBROUTINE SMP_WAKE_ONE_AP

  ! AP_TARGET_CR3_OFFSET/RSP_OFFSET/RIP_OFFSET -- byte offsets of the
  ! three target slots within the trampoline image, relative to
  ! AP_TRAMPOLINE_PHYS. Computed from ap_trampoline.s's own linker-
  ! visible symbols (FORT0K_AP_TARGET_CR3_ADDR/_RSP/_RIP, ring0.s)
  ! rather than hand-copied literal byte offsets, so a future edit to
  ! ap_trampoline.s's layout cannot silently desynchronize this file
  ! from that one -- the offsets are always read from the assembled
  ! object's own symbol addresses at runtime via these small asm-
  ! backed accessors, not hard-coded here.
  FUNCTION AP_TARGET_CR3_OFFSET() RESULT(OFF)
    INTEGER(C_INT64_T) :: OFF
    OFF = FORT0K_AP_TARGET_CR3_ADDR() - FORT0K_AP_TRAMPOLINE_START()
  END FUNCTION AP_TARGET_CR3_OFFSET

  FUNCTION AP_TARGET_RSP_OFFSET() RESULT(OFF)
    INTEGER(C_INT64_T) :: OFF
    OFF = FORT0K_AP_TARGET_RSP_ADDR() - FORT0K_AP_TRAMPOLINE_START()
  END FUNCTION AP_TARGET_RSP_OFFSET

  FUNCTION AP_TARGET_RIP_OFFSET() RESULT(OFF)
    INTEGER(C_INT64_T) :: OFF
    OFF = FORT0K_AP_TARGET_RIP_ADDR() - FORT0K_AP_TRAMPOLINE_START()
  END FUNCTION AP_TARGET_RIP_OFFSET

  ! SMP_BUSY_WAIT_SHORT() -- a fixed-iteration busy loop standing in
  ! for the "wait ~10 microseconds" the Intel MP spec calls for
  ! between INIT and the first SIPI, and between the two SIPIs. This
  ! project has no calibrated microsecond-precision timing source yet
  ! (timer.f90's PIT is programmed for ~10ms ticks, far too coarse) --
  ! a fixed busy-loop iteration count is a real, acknowledged
  ! approximation, not a calibrated wait, and is expected to be more
  ! conservative (longer) than the spec's actual minimum on any
  ! reasonably modern CPU. Revisit with a calibrated delay (e.g. via
  ! the PIT itself, reprogrammed one-shot, or the TSC) if this ever
  ! proves insufficient on real hardware slower than this project's
  ! QEMU test environment.
  SUBROUTINE SMP_BUSY_WAIT_SHORT()
    INTEGER(C_INT64_T) :: I
    INTEGER(C_INT64_T) :: SINK
    SINK = 0_C_INT64_T
    ! Kept at the original scale, NOT the 10x-longer version tried
    ! earlier this session -- that increase did not fix the real bug
    ! (see SMP_WAKE_ONE_AP's confirmation-wait comment for the actual
    ! structural race found and fixed this session) and unnecessarily
    ! lengthened every core's wake sequence for no benefit. This
    ! loop's job is only to satisfy the Intel MP spec's INIT-to-SIPI
    ! and SIPI-to-SIPI minimum gaps (microseconds to low
    ! milliseconds) -- not the multi-second scale the confirmation
    ! wait now allows for a genuinely slow core to finish starting.
    DO I = 1_C_INT64_T, 5000000_C_INT64_T
      SINK = SINK + I
    END DO
    IF (SINK == -1_C_INT64_T) THEN
      CALL FORT0K_HLT()   ! unreachable; keeps SINK observably used so
                            ! -O2 cannot eliminate this loop as dead
                            ! code (RING0-BRIDGE-SPEC.md's divide-by-
                            ! zero milestone test already found this
                            ! exact class of elimination once; applied
                            ! proactively here rather than waiting to
                            ! rediscover it).
    END IF
  END SUBROUTINE SMP_BUSY_WAIT_SHORT

  ! SMP_WAKE_ALL_APS() -- wakes every ACPI-enumerated core other than
  ! the BSP (identified as the core whose APIC ID matches APIC_GET_ID()
  ! at call time, not assumed to be ACPI_CPU_APIC_IDS(1) -- see
  ! kernel_main.f90's ACPI_TEST checkpoint, which already found this
  ! project's environment DOES follow that convention, but this
  ! function checks the real value rather than relying on the
  ! convention holding). Copies the trampoline once, then wakes cores
  ! strictly one at a time (this file's header comment).
  SUBROUTINE SMP_WAKE_ALL_APS()
    INTEGER :: I
    INTEGER(C_INT8_T) :: MY_ID

    CALL SMP_COPY_TRAMPOLINE()
    MY_ID = APIC_GET_ID()
    AP_STARTED_COUNT = 0

    DO I = 1, ACPI_CPU_COUNT
      IF (ACPI_CPU_APIC_IDS(I) /= MY_ID) THEN
        CALL SMP_WAKE_ONE_AP(ACPI_CPU_APIC_IDS(I), INT(I - 1, C_INT32_T))
        IF (AP_STARTED_FLAGS(I) /= 0) THEN
          AP_STARTED_COUNT = AP_STARTED_COUNT + 1
        END IF
      END IF
    END DO
  END SUBROUTINE SMP_WAKE_ALL_APS

  ! AP_MAIN() -- the Fortran entry point every AP jumps to once
  ! ap_trampoline.s finishes its real-to-long-mode transition. Named
  ! exactly "ap_main" (BIND(C, NAME="ap_main")) because ring0.s's
  ! fort0k_ap_main_addr looks up that literal symbol via `lea`
  ! (ring0.s) -- if this name ever changes, that lea must change with
  ! it, and nothing enforces the two staying in sync automatically
  ! (the same class of manual-synchronization dependency this
  ! project's isr_stubs.s/idt.f90 pairing has, documented there in
  ! more detail for that pairing's own case).
  !
  ! MINIMAL BY DESIGN: this stage's milestone is proving cores wake up
  ! and can report in -- CORE_INDEX identifies which core this is
  ! (passed... actually NOT passed as an argument, since ap_trampoline.s
  ! jumps here with no calling convention set up beyond a valid stack;
  ! this core determines its own identity via APIC_GET_ID() instead,
  ! then finds its own AP_STARTED_FLAGS slot by searching
  ! ACPI_CPU_APIC_IDS for a match, since that is the only per-core
  ! identity this project has plumbed through so far). Once identified,
  ! sets its own flag, prints a one-line confirmation to serial (the
  ! same shared, single COM1 UART every core writes to -- SERIAL_PUTS_NL
  ! is not yet made safe against concurrent multi-core writers with a
  ! lock, a real known gap flagged here rather than silently assumed
  ! away, see this subroutine's closing comment), and halts in a loop.
  ! Actually scheduling real work onto these cores is future work this
  ! stage does not attempt.
  SUBROUTINE AP_MAIN() BIND(C, NAME="ap_main")
    INTEGER(C_INT8_T) :: MY_ID
    INTEGER :: I, MY_INDEX
    INTEGER :: MY_TASK

    MY_ID = APIC_GET_ID()
    MY_INDEX = -1
    DO I = 1, ACPI_CPU_COUNT
      IF (ACPI_CPU_APIC_IDS(I) == MY_ID) THEN
        MY_INDEX = I
        EXIT
      END IF
    END DO

    IF (MY_INDEX > 0) THEN
      AP_STARTED_FLAGS(MY_INDEX) = 1
    END IF

    ! Serial output is now safe under concurrent multi-core calls --
    ! SERIAL_PUTS_NL is locked (serial.f90's SERIAL_LOCK), closing the
    ! gap this comment used to flag as real future work. Left as a
    ! marker of when/why that lock was added rather than silently
    ! removed, matching this project's practice of keeping the
    ! reasoning for a fix legible near where the original gap was
    ! identified.
    CALL SMP_AP_REPORT(MY_ID, MY_INDEX)

    ! CHECKPOINT 2: hand off to the scheduler instead of halting.
    ! Every AP creates and runs its OWN task (SCHED_AP_TASK, sched.f90)
    ! -- MY_INDEX - 1 converts this file's 1-based ACPI_CPU_APIC_IDS
    ! index to the 0-based core-index convention SCHED_START/
    ! CURRENT_TASK_INDEX use (matching AP_STARTED_FLAGS's own 1-based-
    ! array-of-0-based-cores convention already established in this
    ! file). SCHED_CREATE_TASK allocates this task's stack via
    ! PMM_ALLOC_PAGE -- now safe to call concurrently from multiple
    ! cores because PMM_LOCK protects it (pmm.f90), closing the other
    ! gap this checkpoint's design required addressing before multiple
    ! cores could safely reach this point at genuinely the same time.
    IF (MY_INDEX > 0) THEN
      MY_TASK = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_AP_TASK), 0_C_INT64_T))
      IF (MY_TASK > 0) THEN
        CALL SCHED_START(MY_INDEX - 1, MY_TASK)
        ! Does not return -- SCHED_START's first switch jumps directly
        ! into SCHED_AP_TASK and never comes back here, same property
        ! documented at every other SCHED_START call site in this
        ! codebase.
      END IF
    END IF

    ! Reached only if MY_INDEX could not be resolved, or task creation
    ! failed (e.g. out of memory) -- a real degraded-but-not-crashing
    ! fallback rather than this core silently vanishing with no
    ! record of why it never joined the scheduler.
    DO
      CALL FORT0K_HLT()
    END DO
  END SUBROUTINE AP_MAIN

  ! SMP_AP_REPORT -- tiny, deliberately self-contained hex-print
  ! helper so AP_MAIN does not need a USE SERIAL/KERNEL_MAIN
  ! dependency for one checkpoint message; inlines its own copy loop
  ! (no shared FILL_STR-style routine call) per this project's
  ! standing caution around call sites into copy-shaped routines
  ! (RING0-BRIDGE-SPEC.md section 1's constprop/memcpy finding).
  SUBROUTINE SMP_AP_REPORT(APIC_ID, CORE_INDEX)
    INTEGER(C_INT8_T), INTENT(IN) :: APIC_ID
    INTEGER, INTENT(IN) :: CORE_INDEX
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(60)
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: N, HI, LO

    N = 0
    CALL RPUT(BUF, N, 'a'); CALL RPUT(BUF, N, 'p'); CALL RPUT(BUF, N, ':')
    CALL RPUT(BUF, N, ' ')
    CALL RPUT(BUF, N, 'c'); CALL RPUT(BUF, N, 'o'); CALL RPUT(BUF, N, 'r')
    CALL RPUT(BUF, N, 'e'); CALL RPUT(BUF, N, ' ')
    CALL RPUT(BUF, N, 'u'); CALL RPUT(BUF, N, 'p'); CALL RPUT(BUF, N, ' ')
    CALL RPUT(BUF, N, '('); CALL RPUT(BUF, N, 'a'); CALL RPUT(BUF, N, 'p')
    CALL RPUT(BUF, N, 'i'); CALL RPUT(BUF, N, 'c'); CALL RPUT(BUF, N, '=')
    HI = IAND(ISHFT(INT(APIC_ID), -4), 15)
    LO = IAND(INT(APIC_ID), 15)
    CALL RPUT(BUF, N, HEXDIGITS(HI+1:HI+1))
    CALL RPUT(BUF, N, HEXDIGITS(LO+1:LO+1))
    CALL RPUT(BUF, N, ')')
    ! BUG FOUND AND FIXED THIS SESSION (bug cleanse pass): CORE_INDEX
    ! was accepted as a real argument but never used anywhere in this
    ! subroutine's body -- a genuine diagnostic gap, not just a
    ! cosmetic unused-variable warning. The printed message reported
    ! WHICH APIC ID checked in but never WHICH core-table index it was
    ! assigned to, even though that mapping (APIC_ID -> CORE_INDEX,
    ! established once at ACPI/MADT parse time, acpi.f90) is exactly
    ! the kind of thing worth confirming explicitly in the boot log
    ! for any future multi-core debugging session, rather than trusted
    ! silently. Fixed by also printing CORE_INDEX (a small integer,
    ! this project's task/core indices never exceed ACPI_MAX_CPUS=64,
    ! so a single hex digit's worth of care is enough -- reusing the
    ! same HEXDIGITS table already in scope).
    CALL RPUT(BUF, N, ' '); CALL RPUT(BUF, N, 'i'); CALL RPUT(BUF, N, 'd')
    CALL RPUT(BUF, N, 'x'); CALL RPUT(BUF, N, '=')
    HI = IAND(ISHFT(CORE_INDEX, -4), 15)
    LO = IAND(CORE_INDEX, 15)
    CALL RPUT(BUF, N, HEXDIGITS(HI+1:HI+1))
    CALL RPUT(BUF, N, HEXDIGITS(LO+1:LO+1))
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SMP_AP_REPORT

  SUBROUTINE RPUT(BUF, N, CH)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(INOUT) :: BUF(:)
    INTEGER, INTENT(INOUT) :: N
    CHARACTER(LEN=1), INTENT(IN) :: CH
    N = N + 1
    BUF(N) = CH
  END SUBROUTINE RPUT

END MODULE SMP
