# ring0.s -- privileged x86 instruction primitives, callable from
# Fortran BIND(C) interfaces. See RING0-BRIDGE-SPEC.md section 3 for
# the naming convention and the rule that a new primitive gets a new
# named entry point, never a flag on an existing one.
#
# These are called via BIND(C) NAME="..." on the Fortran side, so the
# symbol names below are exactly what Fortran's INTERFACE block must
# name -- no gfortran mangling to account for (BIND(C, NAME=...)
# bypasses gfortran's default trailing-underscore convention entirely,
# unlike fort0's userspace bridge which relied on -fno-underscoring
# instead because it did not use BIND(C) NAME on every entry point).
#
# Calling convention here is NOT the "everything by reference" rule
# CALL-BRIDGE-SPEC.md documents for gfortran's own default convention
# -- these are BIND(C) interfaces with VALUE dummy arguments on the
# Fortran side, which is standard System V AMD64 ABI: arguments in
# %rdi, %rsi, %rdx, ... BY VALUE, exactly what a C function would
# receive. This is deliberate and documented here because it is the
# one place this project's convention differs from fort0's, and a
# future reader must not assume the dereference-in-asm pattern
# applies here just because it applies everywhere in the sibling
# project -- confirmed by the calling code in kernel_main.f90's
# INTERFACE block declaring VALUE on every dummy argument.

    .text

    .globl fort0k_hlt
    .type fort0k_hlt, @function
fort0k_hlt:
    hlt
    ret
    .size fort0k_hlt, .-fort0k_hlt

    .globl fort0k_cli
    .type fort0k_cli, @function
fort0k_cli:
    cli
    ret
    .size fort0k_cli, .-fort0k_cli

    .globl fort0k_sti
    .type fort0k_sti, @function
fort0k_sti:
    sti
    ret
    .size fort0k_sti, .-fort0k_sti

# fort0k_outb(port, data) -- port in %di (VALUE, low 16 bits of %rdi),
# data in %sil (VALUE, low 8 bits of %rsi). `out` requires the port in
# %dx specifically when using a 16-bit port number.
    .globl fort0k_outb
    .type fort0k_outb, @function
fort0k_outb:
    mov %rdi, %rdx        # port (VALUE already, no dereference)
    mov %rsi, %rax        # data (VALUE already)
    out %al, %dx
    ret
    .size fort0k_outb, .-fort0k_outb

# fort0k_inb(port) -- port in %di (VALUE), returns byte in %al/%rax
# per SysV integer-return convention. RING0-BRIDGE-SPEC.md section 6
# flags BIND(C) FUNCTION return convention as untested-until-probed;
# this entry point exists so that probe has something concrete to
# test against.
    .globl fort0k_inb
    .type fort0k_inb, @function
fort0k_inb:
    mov %rdi, %rdx
    xor %rax, %rax        # clear high bits -- `in` only writes %al
    in %dx, %al
    ret
    .size fort0k_inb, .-fort0k_inb

# fort0k_lgdt(limit, base) -- RING0-BRIDGE-SPEC.md section 1 (BIND(C)
# struct padding finding): a BIND(C) derived type combining a 16-bit
# limit and a 64-bit base is NOT packed the way lgdt's operand
# requires (gfortran pads the 16-bit field to 8 bytes for the 64-bit
# field's natural alignment, confirmed via a real triple fault and a
# follow-up byte-offset probe). Fix: take limit/base as two separate
# scalar VALUE arguments and build the correct packed 10-byte image
# right here, on this function's own stack, immediately before
# executing lgdt -- no Fortran-side struct layout involved at all for
# this specific packed shape.
#
# limit arrives in %di (VALUE, low 16 bits of %rdi), base in %rsi
# (VALUE, full 64 bits).
    .globl fort0k_lgdt
    .type fort0k_lgdt, @function
fort0k_lgdt:
    sub $16, %rsp              # scratch space for the packed image;
                                # 16 for alignment convenience, only
                                # 10 bytes are actually used
    mov %di, (%rsp)             # limit, 2 bytes, offset 0
    mov %rsi, 2(%rsp)           # base, 8 bytes, offset 2 -- exactly
                                 # the packed layout lgdt requires,
                                 # built by hand instead of trusting
                                 # any compiler's struct layout
    lgdt (%rsp)
    add $16, %rsp
    ret
    .size fort0k_lgdt, .-fort0k_lgdt

# fort0k_ltr(selector) -- loads the Task Register from a GDT
# selector. Simpler than lgdt/lidt: ltr takes the 16-bit selector
# value directly, no packed memory image needed -- the selector
# arrives in %di (VALUE, BIND(C) INTEGER(C_INT16_T)).
    .globl fort0k_ltr
    .type fort0k_ltr, @function
fort0k_ltr:
    ltr %di
    ret
    .size fort0k_ltr, .-fort0k_ltr

# fort0k_reload_segments(code_sel, data_sel) -- reloads CS via a far
# return (the only way to reload CS in 64-bit mode without a full
# far jump/call, and the standard idiom for doing this from inside a
# callable function rather than inline at a fixed asm location) and
# reloads DS/ES/FS/GS/SS with data_sel directly.
#
# WHY NOT A SIMPLE MOV: %cs cannot be loaded with `mov` on x86 in any
# mode -- only far jump/call/return or an interrupt/exception return
# can change it. This function builds a fake far-return frame on the
# stack (return address + new CS) and executes `lretq` (GNU as's name
# for the 64-bit far return, Intel syntax calls it RETF/RETFQ) to
# reload CS with the value the caller requested and resume at the
# very next instruction in this function -- functionally "jump to
# right here, but with a new CS", the standard idiom for this.
#
# code_sel arrives in %rdi, data_sel in %rsi, BOTH AS VALUES already
# (BIND(C) VALUE dummy arguments -- RING0-BRIDGE-SPEC.md section 6,
# confirmed via objdump this session: no dereference needed, unlike
# gfortran's own default by-reference convention fort0's bridge
# relies on).
    .globl fort0k_reload_segments
    .type fort0k_reload_segments, @function
fort0k_reload_segments:
    mov %rsi, %rax             # data_sel value
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss

    # Build a far-return frame: push target CS, then push target RIP
    # (the label right after retfq), then retfq pops RIP then CS.
    lea reload_cs_done(%rip), %rax
    push %rdi                  # new CS (code_sel value)
    push %rax                  # return RIP
    lretq                      # far return: pops RIP then CS
reload_cs_done:
    ret
    .size fort0k_reload_segments, .-fort0k_reload_segments

# fort0k_read_cr2() -- returns CR2 (page-fault linear address), no
# arguments.
    .globl fort0k_read_cr2
    .type fort0k_read_cr2, @function
fort0k_read_cr2:
    mov %cr2, %rax
    ret
    .size fort0k_read_cr2, .-fort0k_read_cr2

# fort0k_load_cr3(pml4_phys) -- loads CR3 with a new PML4 physical
# address, switching the active page table structure. pml4_phys
# arrives in %rdi (VALUE, per RING0-BRIDGE-SPEC.md section 6). No
# implicit TLB-flush-only reasoning needed beyond what loading CR3
# itself does -- writing CR3 unconditionally flushes the entire TLB
# (excluding global pages, which this project does not use anywhere,
# so there is nothing PCID/global-page-related to account for here).
#
# CALLER'S RESPONSIBILITY, NOT THIS FUNCTION'S: the new table
# structure must already correctly map the code that executes the
# very next instruction after this `ret` -- vmm.f90's VMM_INIT
# ensures this by identity-mapping the kernel's own physical footprint
# into the new tables before calling this function (see that
# function's header comment) -- this primitive has no way to verify
# that condition itself and does not attempt to.
    .globl fort0k_load_cr3
    .type fort0k_load_cr3, @function
fort0k_load_cr3:
    mov %rdi, %cr3
    ret
    .size fort0k_load_cr3, .-fort0k_load_cr3

# fort0k_kernel_start() / fort0k_kernel_end() -- return the linker-
# defined __kernel_start/__kernel_end addresses (link.ld) as plain
# values. These symbols have NO STORAGE -- they are pure linker-
# assigned addresses, not variables -- so RING0-BRIDGE-SPEC.md
# section 6's C_LOC+TRANSFER idiom does not apply (that idiom needs a
# real Fortran TARGET variable to take the address of; these are
# neither). `lea` loads the symbol's address directly, the standard
# way to read a linker symbol's value from asm.
    .globl fort0k_kernel_start
    .type fort0k_kernel_start, @function
fort0k_kernel_start:
    lea __kernel_start(%rip), %rax
    ret
    .size fort0k_kernel_start, .-fort0k_kernel_start

    .globl fort0k_kernel_end
    .type fort0k_kernel_end, @function
fort0k_kernel_end:
    lea __kernel_end(%rip), %rax
    ret
    .size fort0k_kernel_end, .-fort0k_kernel_end

# fort0k_ap_trampoline_start() / _end() / _target_cr3_addr() /
# _target_rsp_addr() / _target_rip_addr() -- return the LINKED
# (kernel-image, wherever link.ld/the linker placed it) addresses of
# ap_trampoline.s's symbols -- these are the SOURCE addresses
# smp.f90's SMP_COPY_TRAMPOLINE reads bytes FROM; the DESTINATION
# (AP_TRAMPOLINE_PHYS, 0x8000, smp.f90) is a separate, fixed constant
# that file already knows independently. Same "lea a linker symbol,
# no C_LOC needed" pattern as fort0k_kernel_start/_end above, applied
# to ap_trampoline.s's own labels since those also have no Fortran-
# side storage/TARGET variable to take an address of.
    .globl fort0k_ap_trampoline_start
    .type fort0k_ap_trampoline_start, @function
fort0k_ap_trampoline_start:
    lea ap_trampoline_start(%rip), %rax
    ret
    .size fort0k_ap_trampoline_start, .-fort0k_ap_trampoline_start

    .globl fort0k_ap_trampoline_end
    .type fort0k_ap_trampoline_end, @function
fort0k_ap_trampoline_end:
    lea ap_trampoline_end(%rip), %rax
    ret
    .size fort0k_ap_trampoline_end, .-fort0k_ap_trampoline_end

    .globl fort0k_ap_target_cr3_addr
    .type fort0k_ap_target_cr3_addr, @function
fort0k_ap_target_cr3_addr:
    lea ap_target_cr3(%rip), %rax
    ret
    .size fort0k_ap_target_cr3_addr, .-fort0k_ap_target_cr3_addr

    .globl fort0k_ap_target_rsp_addr
    .type fort0k_ap_target_rsp_addr, @function
fort0k_ap_target_rsp_addr:
    lea ap_target_rsp(%rip), %rax
    ret
    .size fort0k_ap_target_rsp_addr, .-fort0k_ap_target_rsp_addr

    .globl fort0k_ap_target_rip_addr
    .type fort0k_ap_target_rip_addr, @function
fort0k_ap_target_rip_addr:
    lea ap_target_rip(%rip), %rax
    ret
    .size fort0k_ap_target_rip_addr, .-fort0k_ap_target_rip_addr

# fort0k_ap_main_addr() -- returns the address of ap_main, the Fortran
# BIND(C) entry point every AP jumps to once ap_trampoline.s finishes
# its long-mode transition (kernel_main.f90). Same lea pattern; ap_main
# is an ordinary BIND(C) SUBROUTINE, not a linker symbol without
# storage the way __kernel_start etc. are, but `lea` still works
# identically for a function symbol's address either way.
    .globl fort0k_ap_main_addr
    .type fort0k_ap_main_addr, @function
fort0k_ap_main_addr:
    lea ap_main(%rip), %rax
    ret
    .size fort0k_ap_main_addr, .-fort0k_ap_main_addr

# fort0k_usermode_test_body_addr() / fort0k_usermode_test_privileged_addr()
# -- same lea-a-linker-symbol pattern as fort0k_ap_main_addr above,
# applied to usermode_test.s's two hand-written asm entry points
# (which have no Fortran-side BIND(C) declaration to take a C_FUNLOC
# of, being plain asm symbols, not Fortran procedures).
    .globl fort0k_usermode_test_body_addr
    .type fort0k_usermode_test_body_addr, @function
fort0k_usermode_test_body_addr:
    lea usermode_test_body(%rip), %rax
    ret
    .size fort0k_usermode_test_body_addr, .-fort0k_usermode_test_body_addr

    .globl fort0k_usermode_test_scheduled_addr
    .type fort0k_usermode_test_scheduled_addr, @function
fort0k_usermode_test_scheduled_addr:
    lea usermode_test_scheduled(%rip), %rax
    ret
    .size fort0k_usermode_test_scheduled_addr, .-fort0k_usermode_test_scheduled_addr

    .globl fort0k_trampoline_fix_dump_addr
    .type fort0k_trampoline_fix_dump_addr, @function
fort0k_trampoline_fix_dump_addr:
    lea trampoline_fix_dump(%rip), %rax
    ret
    .size fort0k_trampoline_fix_dump_addr, .-fort0k_trampoline_fix_dump_addr

    .globl fort0k_usermode_test_privileged_addr
    .type fort0k_usermode_test_privileged_addr, @function
fort0k_usermode_test_privileged_addr:
    lea usermode_test_privileged(%rip), %rax
    ret
    .size fort0k_usermode_test_privileged_addr, .-fort0k_usermode_test_privileged_addr

# fort0k_get_zero() -- returns 0, always, via a genuine runtime
# instruction (xor) rather than a value gfortran could see through
# and constant-fold at the call site. Exists specifically so
# kernel_main.f90's deliberate divide-by-zero milestone test produces
# a REAL runtime DIV-by-zero trap rather than being caught and
# rejected at compile time (gfortran can and does diagnose a literal
# division by a compile-time-constant zero statically, which would
# defeat the test's purpose) -- a function call across a translation
# unit boundary is opaque to gfortran's constant-propagation in a way
# a literal or even a local variable might not reliably be.
    .globl fort0k_get_zero
    .type fort0k_get_zero, @function
fort0k_get_zero:
    xor %rax, %rax
    ret
    .size fort0k_get_zero, .-fort0k_get_zero

# fort0k_lidt(limit, base) -- same packed-structure fix as
# fort0k_lgdt above, same reasoning (RING0-BRIDGE-SPEC.md section 1).
    .globl fort0k_lidt
    .type fort0k_lidt, @function
fort0k_lidt:
    sub $16, %rsp
    mov %di, (%rsp)
    mov %rsi, 2(%rsp)
    lidt (%rsp)
    add $16, %rsp
    ret
    .size fort0k_lidt, .-fort0k_lidt


    .section .note.GNU-stack,"",@progbits
