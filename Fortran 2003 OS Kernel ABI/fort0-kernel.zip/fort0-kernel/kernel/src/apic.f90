! apic.f90 -- Local APIC (xAPIC, MMIO-based) driver.
!
! CRITICAL: every register access in this file goes through a
! VOLATILE pointer -- RING0-BRIDGE-SPEC.md section 9's finding this
! session: a plain (non-VOLATILE) POINTER dereference is subject to
! ordinary dead-store elimination at -O2, which silently collapsed
! three sequential writes to the SAME address down to just the last
! one in a direct probe. For an ordinary memory location that is
! correct and harmless; for a hardware MMIO register, where each
! individual write can trigger a real, distinct hardware action
! (sending an IPI, in this file's case), it is a silent correctness
! bug with no compiler warning. VOLATILE is not optional anywhere in
! this file.
!
! The Local APIC's MMIO register page is NOT covered by this
! project's current 1GiB identity map (0xFEE00000 is ~3.98GiB,
! confirmed via direct calculation this session before writing any
! code against it, rather than assumed) -- APIC_INIT explicitly maps
! it via VMM_MAP_4K before any register is touched.
MODULE APIC
  USE ISO_C_BINDING
  USE RING0
  USE VMM
  USE ACPI
  IMPLICIT NONE

  ! Register byte offsets within the Local APIC's 4KiB MMIO page, per
  ! the Intel SDM's xAPIC register map (well-known, stable values --
  ! not independently re-derived, since these are architectural
  ! constants rather than a structure this project needs to probe the
  ! layout of; there is no "layout" here, only fixed offsets the CPU
  ! itself defines).
  INTEGER(C_INT64_T), PARAMETER :: APIC_REG_ID          = INT(Z'020', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: APIC_REG_EOI         = INT(Z'0B0', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: APIC_REG_SPURIOUS    = INT(Z'0F0', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: APIC_REG_ICR_LOW     = INT(Z'300', C_INT64_T)
  INTEGER(C_INT64_T), PARAMETER :: APIC_REG_ICR_HIGH    = INT(Z'310', C_INT64_T)

  INTEGER(C_INT32_T), PARAMETER :: APIC_ICR_DELIVERY_INIT      = ISHFT(5, 8)
  INTEGER(C_INT32_T), PARAMETER :: APIC_ICR_DELIVERY_STARTUP   = ISHFT(6, 8)
  INTEGER(C_INT32_T), PARAMETER :: APIC_ICR_LEVEL_ASSERT       = ISHFT(1, 14)
  INTEGER(C_INT32_T), PARAMETER :: APIC_ICR_TRIGGER_LEVEL      = ISHFT(1, 15)
  ! ICR (Interrupt Command Register) bit fields used by the INIT/
  ! Startup IPI sequence -- see APIC_SEND_INIT/APIC_SEND_STARTUP
  ! below. Fixed architectural bit positions, same "no layout to
  ! probe" reasoning as the register offsets above.

  INTEGER(C_INT64_T) :: APIC_VIRT_BASE = 0_C_INT64_T
  BIND(C, NAME="apic_virt_base") :: APIC_VIRT_BASE
  ! Set by APIC_INIT. This project maps the Local APIC page at its
  ! own physical address (identity mapping, not a separate higher-
  ! half MMIO region) -- kept as a distinct module variable rather
  ! than always re-reading ACPI_LOCAL_APIC_PHYS at every register
  ! access, so a future change to use a different virtual address for
  ! MMIO (e.g. a dedicated MMIO region, common in more mature kernels)
  ! only needs to change APIC_INIT, not every register accessor.

CONTAINS

  ! APIC_REG_ADDR(OFFSET) -- returns the address of a register. Not
  ! itself doing the C_F_POINTER call, so callers can declare their
  ! own POINTER, VOLATILE locals with the exact type width they need
  ! (32-bit for every xAPIC register) without this helper needing a
  ! generic/polymorphic result type Fortran does not offer cleanly
  ! for this.
  FUNCTION APIC_REG_ADDR(OFFSET) RESULT(ADDR)
    INTEGER(C_INT64_T), INTENT(IN) :: OFFSET
    INTEGER(C_INT64_T) :: ADDR
    ADDR = APIC_VIRT_BASE + OFFSET
  END FUNCTION APIC_REG_ADDR

  ! APIC_READ(OFFSET) / APIC_WRITE(OFFSET, VALUE) -- the only two
  ! functions in this codebase that touch Local APIC registers
  ! directly; every other subroutine in this file goes through these,
  ! so the VOLATILE requirement (section 9) has exactly one place it
  ! needs to be gotten right, not one per call site.
  FUNCTION APIC_READ(OFFSET) RESULT(VAL)
    INTEGER(C_INT64_T), INTENT(IN) :: OFFSET
    INTEGER(C_INT32_T) :: VAL
    INTEGER(C_INT32_T), POINTER, VOLATILE :: REG
    CALL C_F_POINTER(TRANSFER(APIC_REG_ADDR(OFFSET), C_NULL_PTR), REG)
    VAL = REG
  END FUNCTION APIC_READ

  SUBROUTINE APIC_WRITE(OFFSET, VAL)
    INTEGER(C_INT64_T), INTENT(IN) :: OFFSET
    INTEGER(C_INT32_T), INTENT(IN) :: VAL
    INTEGER(C_INT32_T), POINTER, VOLATILE :: REG
    CALL C_F_POINTER(TRANSFER(APIC_REG_ADDR(OFFSET), C_NULL_PTR), REG)
    REG = VAL
  END SUBROUTINE APIC_WRITE

  ! APIC_INIT() -- maps the Local APIC's MMIO page (identity-mapped,
  ! at its own physical address, via VMM_CURRENT_PML4 -- the PML4
  ! VMM_INIT already installed and left active; this function does
  ! NOT build a new page table structure, it adds one mapping to the
  ! existing one) and enables the APIC via the spurious-interrupt
  ! vector register's bit 8 (APIC software-enable bit).
  !
  ! ORDER DEPENDENCY, EXPLICIT: must be called after VMM_INIT (needs
  ! VMM_CURRENT_PML4 to be a real, active PML4) and after ACPI_INIT
  ! (needs ACPI_LOCAL_APIC_PHYS to be populated) -- kernel_main.f90's
  ! boot sequence already satisfies this ordering since VMM_TEST and
  ! ACPI_TEST both already ran earlier in this project's existing
  ! sequence; this comment states the dependency explicitly rather
  ! than leaving it implicit in call order alone, per this project's
  ! general practice of naming ordering hazards rather than trusting
  ! them to remain correct by accident through future edits.
  SUBROUTINE APIC_INIT()
    INTEGER(C_INT32_T) :: SPURIOUS

    APIC_VIRT_BASE = ACPI_LOCAL_APIC_PHYS
    CALL VMM_MAP_4K(VMM_CURRENT_PML4, APIC_VIRT_BASE, ACPI_LOCAL_APIC_PHYS, &
                     IOR(PTE_PRESENT, PTE_WRITABLE))

    SPURIOUS = APIC_READ(APIC_REG_SPURIOUS)
    SPURIOUS = IOR(SPURIOUS, ISHFT(1, 8))              ! bit 8: APIC
                                                         ! software enable
    SPURIOUS = IOR(SPURIOUS, INT(Z'FF', C_INT32_T))    ! spurious vector
                                                         ! number, low
                                                         ! byte: 0xFF,
                                                         ! conventional,
                                                         ! must be
                                                         ! distinct from
                                                         ! every real IDT
                                                         ! vector this
                                                         ! project uses
                                                         ! (highest so
                                                         ! far: 47)
    CALL APIC_WRITE(APIC_REG_SPURIOUS, SPURIOUS)
  END SUBROUTINE APIC_INIT

  ! APIC_GET_ID() -- reads this core's own APIC ID back from its
  ! Local APIC. On the BSP, called as a sanity check that MMIO access
  ! itself works before anything more elaborate (sending IPIs) is
  ! attempted.
  !
  ! Register layout note: the ID occupies bits 24-31 of the 32-bit ID
  ! register in xAPIC mode (this project does not yet support x2APIC
  ! mode, which uses a different register access mechanism (MSRs, not
  ! MMIO) and a wider ID field -- add-only-when-needed, xAPIC is
  ! sufficient for this project's current core-count scale).
  FUNCTION APIC_GET_ID() RESULT(ID)
    INTEGER(C_INT8_T) :: ID
    INTEGER(C_INT32_T) :: RAW
    RAW = APIC_READ(APIC_REG_ID)
    ID = INT(IAND(ISHFT(RAW, -24), INT(Z'FF', C_INT32_T)), C_INT8_T)
  END FUNCTION APIC_GET_ID

  ! APIC_SEND_INIT(TARGET_APIC_ID) -- sends an INIT IPI to the given
  ! core: assert, THEN DE-ASSERT (two separate ICR writes), the first
  ! step of the standard INIT-SIPI-SIPI sequence real firmware and
  ! every reference OS uses to wake an Application Processor.
  !
  ! BUG FOUND AND FIXED THIS SESSION: the original version of this
  ! subroutine sent only the assert half and never de-asserted --
  ! confirmed via a real triple fault during this project's first SMP
  ! wake attempt (a target core's second QEMU "CPU Reset" showing this
  ! project's own protected-mode GDT loaded but jumping to a garbage
  ! EIP outside the trampoline, suggesting the core was left in an
  ! inconsistent state), then confirmed via web search this session
  ! that every reference implementation checked (Linux's smpboot.c,
  ! GNU Mach's smp.c) sends BOTH an assert and a de-assert ICR write
  ! for INIT, not assert alone -- this project's original code was
  ! missing the second write entirely. Writes ICR_HIGH (destination)
  ! before EACH of the two ICR_LOW writes, matching APIC_SEND_STARTUP's
  ! same ordering requirement (writing ICR_LOW is what dispatches the
  ! IPI, so the destination must already be set).
  SUBROUTINE APIC_SEND_INIT(TARGET_APIC_ID)
    INTEGER(C_INT8_T), INTENT(IN) :: TARGET_APIC_ID
    INTEGER(C_INT32_T) :: ICR_LOW
    INTEGER(C_INT32_T) :: DEST_HIGH

    DEST_HIGH = ISHFT(INT(IAND(INT(TARGET_APIC_ID), 255), C_INT32_T), 24)

    ! Assert.
    CALL APIC_WRITE(APIC_REG_ICR_HIGH, DEST_HIGH)
    ICR_LOW = IOR(APIC_ICR_DELIVERY_INIT, IOR(APIC_ICR_LEVEL_ASSERT, APIC_ICR_TRIGGER_LEVEL))
    CALL APIC_WRITE(APIC_REG_ICR_LOW, ICR_LOW)

    CALL APIC_WAIT_ICR_IDLE()

    ! De-assert (APIC_ICR_LEVEL_ASSERT bit clear -- the same trigger
    ! mode, level, but the "assert" bit off signals the de-assert edge
    ! per the Intel SDM's ICR encoding).
    CALL APIC_WRITE(APIC_REG_ICR_HIGH, DEST_HIGH)
    ICR_LOW = IOR(APIC_ICR_DELIVERY_INIT, APIC_ICR_TRIGGER_LEVEL)
    CALL APIC_WRITE(APIC_REG_ICR_LOW, ICR_LOW)

    CALL APIC_WAIT_ICR_IDLE()
  END SUBROUTINE APIC_SEND_INIT

  ! APIC_WAIT_ICR_IDLE() -- polls ICR_LOW's delivery-status bit (bit
  ! 12) until the APIC reports the previous IPI write has actually
  ! been sent, per every reference implementation checked this
  ! session (Linux's safe_apic_wait_icr_idle, GNU Mach's wait_for_ipi)
  ! -- writing a second ICR value before the first has finished
  ! sending is a real, documented hazard (Intel SDM), not a
  ! theoretical one; this project's original code had no such wait
  ! anywhere, sending INIT/STARTUP/STARTUP back-to-back-to-back with
  ! only a fixed busy-loop between them and no confirmation the APIC
  ! hardware itself was ready for the next write.
  SUBROUTINE APIC_WAIT_ICR_IDLE()
    INTEGER(C_INT32_T) :: STATUS
    INTEGER(C_INT64_T) :: ITER
    DO ITER = 1_C_INT64_T, 1000000_C_INT64_T
      STATUS = APIC_READ(APIC_REG_ICR_LOW)
      IF (IAND(STATUS, ISHFT(1, 12)) == 0) EXIT   ! delivery status
                                                    ! bit clear = idle
    END DO
  END SUBROUTINE APIC_WAIT_ICR_IDLE

  ! APIC_SEND_STARTUP(TARGET_APIC_ID, VECTOR) -- sends a Startup IPI
  ! (SIPI). VECTOR encodes the physical starting address the target
  ! core begins executing at IN REAL MODE: the CPU takes VECTOR
  ! (an 8-bit value) and multiplies by 0x1000 to get the physical
  ! address -- so VECTOR must equal (trampoline physical address) /
  ! 0x1000, and the trampoline's physical address must therefore be
  ! page-aligned and below 1MiB (real-mode addressing range) by
  ! construction. This project's AP trampoline (a later file in this
  ! stage) is placed to satisfy that constraint; this function does
  ! not itself verify it, trusting the caller (the AP-wake sequence
  ! that also placed the trampoline) to have gotten the address right
  ! -- see that code's own placement comment for the actual value
  ! used and why.
  SUBROUTINE APIC_SEND_STARTUP(TARGET_APIC_ID, VECTOR)
    INTEGER(C_INT8_T), INTENT(IN) :: TARGET_APIC_ID
    INTEGER(C_INT8_T), INTENT(IN) :: VECTOR
    INTEGER(C_INT32_T) :: ICR_LOW

    CALL APIC_WRITE(APIC_REG_ICR_HIGH, ISHFT(INT(IAND(INT(TARGET_APIC_ID), 255), C_INT32_T), 24))

    ICR_LOW = IOR(APIC_ICR_DELIVERY_STARTUP, IAND(INT(VECTOR), 255))
    CALL APIC_WRITE(APIC_REG_ICR_LOW, ICR_LOW)

    CALL APIC_WAIT_ICR_IDLE()
  END SUBROUTINE APIC_SEND_STARTUP

  ! APIC_SEND_EOI() -- signals end-of-interrupt to the Local APIC.
  ! Not yet wired into interrupts.f90's dispatch (which still uses
  ! pic.f90's 8259 EOI exclusively, since this project has not yet
  ! switched IRQ routing from the legacy PIC to the APIC/IOAPIC) --
  ! provided now because APIC_INIT enabling the Local APIC is a
  ! prerequisite for it existing at all, and a kernel that enables an
  ! APIC without ever being able to EOI through it would be an
  ! obviously incomplete pairing to leave for a future reader to
  ! notice was missing. Switching actual IRQ delivery from PIC to
  ! APIC/IOAPIC is real, separate, future work (add-only-when-needed)
  ! -- this project's timer/keyboard IRQs still flow through pic.f90
  ! exactly as stage 2 built them.
  SUBROUTINE APIC_SEND_EOI()
    CALL APIC_WRITE(APIC_REG_EOI, 0_C_INT32_T)
  END SUBROUTINE APIC_SEND_EOI

END MODULE APIC
