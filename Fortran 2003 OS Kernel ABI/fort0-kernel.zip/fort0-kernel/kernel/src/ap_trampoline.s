# ap_trampoline.s -- the code every Application Processor (AP) begins
# executing when the BSP sends it a Startup IPI (SIPI). This is a
# second, much smaller version of boot.s's 32-to-64-bit transition --
# necessary because an AP starts from the EXACT SAME power-on state
# the BSP itself started from (16-bit real mode, paging off, nothing
# initialized), regardless of how far the BSP has already gotten.
#
# FIXED PLACEMENT, NOT LINKED NORMALLY: this code cannot be placed by
# link.ld alongside the rest of the kernel (which loads at 1MiB and
# runs in 64-bit long mode) -- it must sit at a FIXED, PAGE-ALIGNED
# PHYSICAL ADDRESS BELOW 1MIB, because:
#   (1) real mode can only address the first 1MiB (20-bit addressing),
#       so the CPU literally cannot execute code above that until
#       this trampoline itself gets it into a wider mode, and
#   (2) APIC_SEND_STARTUP's SIPI vector byte is multiplied by 0x1000
#       by the CPU to form the starting physical address (Intel SDM),
#       so the address must be an exact multiple of 0x1000 for the
#       vector encoding to express it at all.
# This project places the trampoline at physical 0x8000 (32KiB) --
# comfortably clear of the BIOS data area (below 0x500) and anything
# real-mode BIOS/GRUB code used earlier in boot, and safely inside the
# low 1MiB range pmm.f90's PMM_INIT already reserves unconditionally
# (see that file's PMM_MARK_RANGE_USED(0, 1048576) call), so the
# physical allocator will never hand this memory out to anything else
# -- no dedicated reservation logic needed beyond what already exists.
# vector = 0x8000 / 0x1000 = 0x08, the SIPI vector byte
# kernel_main.f90's AP-wake sequence uses.
#
# HOW THIS CODE GETS TO PHYSICAL 0x8000: the Makefile assembles this
# file separately and kernel_main.f90 (via a small copy routine)
# copies the assembled bytes there at runtime, rather than this file
# being linked into the main kernel image at that address directly --
# see kernel_main.f90's AP_COPY_TRAMPOLINE for why a runtime copy,
# not link-time placement, was the simpler choice given this
# project's existing single-linker-script setup.
#
# PER-CORE STATE: this trampoline reads its target 64-bit entry point,
# stack pointer, and CR3 from FIXED, KNOWN OFFSETS within the copied
# trampoline image itself (ap_target_rip/ap_target_rsp/ap_target_cr3,
# at the very end of this file) rather than from any general
# shared-memory handshake mechanism -- kernel_main.f90/smp.f90 pokes
# fresh values into these slots for EACH core before sending that
# core's SIPI.
#
# REAL HANDSHAKE, NOT A TIMING GUESS: an earlier version of this
# project's SMP bring-up relied on the BSP waiting for AP_STARTED_
# FLAGS (a much LATER signal -- set only after the AP has reached
# Fortran, found its own index by searching ACPI_CPU_APIC_IDS, and
# called back into serial) before considering it safe to overwrite
# these shared slots for the next core. Repeated boot testing (20+
# runs across two sessions) found this insufficient: multiple runs
# showed EVERY core successfully printing its "core up" confirmation,
# yet the BSP's own count still came out short -- with zero triple
# faults across any of these runs, ruling out a crash and pointing
# instead to the shared slots being overwritten by the BSP (waking
# the next core) WHILE THE CURRENT core's trampoline code was still
# between "started executing" and "finished reading ap_target_rsp/
# ap_target_cr3 into real registers" -- a window AP_STARTED_FLAGS,
# firing only much later in Fortran, does nothing to protect.
#
# FIX: ap_target_claimed is set to a fixed sentinel (0x43, 'C' for
# "claimed" -- chosen only to be visually recognizable in a memory
# dump, not load-bearing) by THIS TRAMPOLINE ITSELF, in real mode,
# immediately after the segment registers are set up and BEFORE
# reading any shared slot -- smp.f90's SMP_WAKE_ONE_AP now polls THIS
# flag (cleared before each SIPI is sent), not AP_STARTED_FLAGS,
# before it is willing to send the NEXT core's SIPI or overwrite
# these slots again. This closes the actual race: the claim write
# happens before ap_target_cr3/_rsp/_rip are ever read, so the BSP
# seeing the claim guarantees the current core is at least at that
# point -- combined with the trampoline being uninterruptible real-
# mode code with no way for the BSP to preempt it mid-instruction,
# this establishes a real happens-before relationship, not a
# probabilistic one.

    .code16
    .section .text
    .globl ap_trampoline_start
ap_trampoline_start:
    cli
    xor %ax, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %ss

    # Claim: signal to the BSP that this core has begun executing and
    # is about to read the shared target slots -- see header comment.
    # Written FIRST, before anything else, specifically so the BSP's
    # wait for it bounds the window during which the shared slots
    # must remain stable to the smallest possible margin.
    movb $0x43, %al
    mov $0x9004, %bx
    mov %al, (%bx)

    # CHECKPOINT 1: reached real-mode entry, before touching GDT/CR0.
    movb $0x11, %al
    mov $0x9000, %bx
    mov %al, (%bx)

    # BUG FOUND AND FIXED THIS SESSION: this lgdtl was missing the
    # "+ 0x8000" trampoline-base offset every other absolute address
    # reference in this file correctly includes (compare the
    # protected-mode lgdtl below, which has it) -- confirmed via a
    # real, reproduced triple fault (the AP loaded a GDT pointer from
    # LINEAR ADDRESS 0x00D0, not 0x80D0, since this instruction's
    # 16-bit-relative operand was computed relative to DS:0, and
    # DS=0 was set at trampoline entry -- QEMU's cpu_reset log showed
    # the affected core running with a GDT base matching SeaBIOS's
    # own descriptor table, not this project's ap_gdt32, confirming
    # this instruction read garbage/BIOS memory instead of our real
    # GDT pointer). Every other absolute reference in this file
    # already had the +0x8000 offset; this was the one omission.
    lgdtl ap_gdt32_ptr - ap_trampoline_start + 0x8000

    # CHECKPOINT 2: GDT loaded.
    movb $0x12, %al
    mov %al, (%bx)

    mov %cr0, %eax
    or $1, %eax             # CR0.PE -- enter protected mode
    mov %eax, %cr0

    ljmpl $0x08, $(ap_protected_mode - ap_trampoline_start + 0x8000)    # far jump to flush the instruction prefetch queue and load a
    # 32-bit code selector -- standard real-to-protected-mode idiom.
    # Absolute target computed as (label offset within this file) +
    # 0x8000 (this trampoline's fixed load address), since %cs:%eip
    # addressing after this jump is no longer relative to wherever
    # the CPU happened to start fetching real-mode code from.

    .code32
ap_protected_mode:
    mov $0x10, %ax           # 32-bit data selector (ap_gdt32's 2nd entry)
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss

    # CHECKPOINT 3: reached 32-bit protected mode.
    movb $0x13, %al
    mov $0x9000, %ebx
    mov %al, (%ebx)

    # --- Enable PAE and load the SAME PML4 the BSP already built ---
    # (kernel_main.f90 pokes VMM_CURRENT_PML4's value into
    # ap_target_cr3 before sending this core's SIPI -- every core
    # shares ONE address space in this project, no per-core address
    # space yet, matching this project's current single-PML4 design;
    # see vmm.f90's VMM_CURRENT_PML4 comment.)
    mov %cr4, %eax
    or $0x20, %eax            # CR4.PAE
    mov %eax, %cr4

    mov (ap_target_cr3 - ap_trampoline_start + 0x8000), %eax
    mov %eax, %cr3

    # CHECKPOINT 4: PAE enabled, CR3 loaded.
    movb $0x14, %al
    mov %al, (%ebx)

    mov $0xC0000080, %ecx     # IA32_EFER
    rdmsr
    or $0x100, %eax           # EFER.LME
    wrmsr

    mov %cr0, %eax
    or $0x80000000, %eax      # CR0.PG
    mov %eax, %cr0

    # CHECKPOINT 5: paging enabled (now in compatibility mode).
    movb $0x15, %al
    mov %al, (%ebx)

    lgdtl ap_gdt64_ptr - ap_trampoline_start + 0x8000
    ljmpl $0x08, $(ap_long_mode - ap_trampoline_start + 0x8000)

    .code64
ap_long_mode:
    mov $0x10, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss

    # --- FPU/SSE initialization ---
    # BUG FOUND AND FIXED THIS SESSION: this trampoline never
    # initialized FPU/SSE state (CR0.EM/CR0.MP/CR4.OSFXSR) the way
    # boot.s does for the BSP -- a real, latent gap since boot.s's own
    # RING0-BRIDGE-SPEC.md section 1 finding (SSE instructions before
    # this init triple-fault) applies identically to every AP, not
    # just the BSP, but nothing exercised it until this session added
    # a vectorized (SSE-using) code path -- pmm.f90's PMM_ALLOC_PAGE
    # -- that an AP genuinely calls (AP_MAIN -> SCHED_CREATE_TASK ->
    # PMM_ALLOC_PAGE, smp.f90/sched.f90). Confirmed via a real,
    # reproduced triple fault occurring immediately after an AP's own
    # "core up" report, on every boot -- deterministic, unlike the
    # earlier, unrelated SMP timing flakiness (RING0-BRIDGE-SPEC.md
    # section 15) this superficially resembled at first glance before
    # being root-caused. Same CR0.MP/CR4.OSFXSR sequence boot.s uses,
    # applied here for exactly the same reason.
    mov %cr0, %rax
    and $0xFFFFFFFB, %eax          # clear CR0.EM (bit 2)
    or $0x00000002, %eax           # set CR0.MP (bit 1)
    mov %rax, %cr0

    mov %cr4, %rax
    or $0x00000600, %eax           # set CR4.OSFXSR (bit 9) and
                                    # CR4.OSXMMEXCPT (bit 10)
    mov %rax, %cr4

    # fninit: same fix, same reasoning, as boot.s -- see that file's
    # comment for the full account (found via web search confirming
    # standard practice, applied here proactively rather than waiting
    # for a real fault the way the CR0/CR4 fix above it was found).
    fninit

    # CHECKPOINT 6: reached 64-bit long mode.
    mov $0x9000, %rbx
    movb $0x16, %al
    mov %al, (%rbx)

    # Load this core's stack (poked into ap_target_rsp by
    # kernel_main.f90 before this core's SIPI was sent -- see this
    # file's header comment on why a single shared slot is safe given
    # the strictly-sequential, one-core-at-a-time wake order).
    mov ap_target_rsp - ap_trampoline_start + 0x8000, %rsp
    mov %rsp, %rbp
    xor %rbp, %rbp

    mov ap_target_rip - ap_trampoline_start + 0x8000, %rax
    jmp *%rax

    .align 8
ap_gdt32:
    .quad 0
    .quad 0x00CF9A000000FFFF   # 32-bit code, base 0, limit 4G
    .quad 0x00CF92000000FFFF   # 32-bit data, base 0, limit 4G
ap_gdt32_end:
ap_gdt32_ptr:
    .word ap_gdt32_end - ap_gdt32 - 1
    .long ap_gdt32 - ap_trampoline_start + 0x8000

    .align 8
ap_gdt64:
    .quad 0
    .quad 0x00AF9A000000FFFF   # 64-bit code
    .quad 0x00AF92000000FFFF   # 64-bit data
ap_gdt64_end:
ap_gdt64_ptr:
    .word ap_gdt64_end - ap_gdt64 - 1
    .quad ap_gdt64 - ap_trampoline_start + 0x8000

    .align 8
    .globl ap_target_cr3
ap_target_cr3:
    .quad 0
    .globl ap_target_rsp
ap_target_rsp:
    .quad 0
    .globl ap_target_rip
ap_target_rip:
    .quad 0

    .globl ap_trampoline_end
ap_trampoline_end:

    .section .note.GNU-stack,"",@progbits
