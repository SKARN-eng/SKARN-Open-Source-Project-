# sched_switch.s -- fort0k_context_switch(old_regs_addr, new_regs_addr):
# the actual register-level mechanism a task switch is built on.
#
# CALLING CONVENTION, DELIBERATELY UNUSUAL: this is called like an
# ordinary BIND(C) VALUE function (old_regs_addr in %rdi, new_regs_addr
# in %rsi, per RING0-BRIDGE-SPEC.md section 6's confirmed plain-SysV
# convention for such calls) -- but it does NOT behave like an
# ordinary function from the CALLER's perspective: the `call` that
# reaches this function and the `ret`/return path that eventually
# comes BACK to that same call site are, in general, executed by TWO
# DIFFERENT TASKS. The task that called in is the one being SAVED (to
# old_regs_addr); the code that eventually "returns" from this
# function, resuming right after that same `call` instruction, is
# whatever task NEW_REGS_ADDR belongs to -- which, the very first
# time a given task is switched into, was never actually the caller
# of this function at all (see sched.f90's SCHED_CREATE_TASK, which
# fabricates a REGS_T as if the task had already been running and had
# just called this function itself -- the "fake initial stack frame"
# trick, standard in every reference kernel scheduler, that lets this
# primitive treat every switch, first or subsequent, identically,
# with no special-casing for "is this the task's first run").
#
# FIELD OFFSETS: TCB_REGS_T (sched.f90) was byte-offset-probed this
# session and confirmed packed, zero padding: R15@0, R14@8, ...,
# RAX@112, RSP@120, RIP@128, RFLAGS@136, total size 144. This file's
# offsets below are written out as the confirmed numeric values
# directly (not symbolically computed), matching the general pattern
# established for INTERRUPT_FRAME_T/isr_stubs.s (both files agree on
# a fixed layout, independently re-verified rather than sharing a
# single generated source of truth) -- re-verify both files still
# agree if TCB_REGS_T's field list ever changes.
    .text
    .globl fort0k_context_switch
    .type fort0k_context_switch, @function
fort0k_context_switch:
    # --- Save the OUTGOING task's state to (%rdi) ---
    movq %r15, 0(%rdi)
    movq %r14, 8(%rdi)
    movq %r13, 16(%rdi)
    movq %r12, 24(%rdi)
    movq %r11, 32(%rdi)
    movq %r10, 40(%rdi)
    movq %r9,  48(%rdi)
    movq %r8,  56(%rdi)
    movq %rdi, 64(%rdi)
    movq %rsi, 72(%rdi)
    movq %rbp, 80(%rdi)
    movq %rbx, 88(%rdi)
    movq %rdx, 96(%rdi)
    movq %rcx, 104(%rdi)
    movq %rax, 112(%rdi)

    # RSP: the outgoing task's stack pointer AT THE POINT OF THIS
    # CALL -- i.e. pointing at the return address `call
    # fort0k_context_switch` pushed. Saved as-is; RESTORING this same
    # value later and executing a jump to the saved RIP is exactly
    # what resumes the outgoing task right where it left off, the
    # whole mechanism this primitive relies on.
    movq %rsp, 120(%rdi)

    # RIP: the return address itself, sitting at (%rsp) right now
    # (the `call` that reached this function pushed it there). Saved
    # explicitly as a separate field (rather than relying solely on
    # RSP pointing at it) so SCHED_CREATE_TASK's fabricated initial
    # frame has an unambiguous place to put a brand-new task's entry
    # point -- see sched.f90.
    movq (%rsp), %rax
    movq %rax, 128(%rdi)

    pushfq
    popq %rax
    movq %rax, 136(%rdi)

    # CR3: added in an earlier pass this session, the real prerequisite
    # for per-task address-space isolation (previously flagged as a
    # known gap in both sched.f90's TCB_T comment and this file's own
    # earlier header). Read unconditionally -- reading %cr3 is always
    # safe, has no side effect, and costs nothing meaningful -- unlike
    # WRITING it (the incoming side, below), which is a real,
    # non-trivial operation (flushes the entire TLB) and can triple-
    # fault instantly if given a bad physical address, so the write
    # side is made conditional instead of unconditional -- see below.
    movq %cr3, %rax
    movq %rax, 144(%rdi)

    # CS/SS: added this session, the prerequisite for a SCHEDULED task
    # to correctly resume at ring 3 (user mode ITSELF, sections 31-33,
    # already proved the ring-0-to-ring-3 TRANSITION mechanism works;
    # this is the separate, additional piece needed for a task that
    # has ALREADY been running at ring 3 to correctly resume there
    # again after being switched away from). Reading %cs/%ss into a
    # GP register requires `mov %cs, %ax`-style segment-register reads
    # (no direct `movq %cs, 152(%rdi)` form exists) -- always safe, no
    # side effect, same reasoning as the CR3 read immediately above.
    #
    # BUG CAUGHT BEFORE BOOT-TESTING: `mov %cs, %ax` only writes the
    # low 16 bits of %rax -- the upper 48 bits are left as whatever
    # %rax already held (here, stale bits from the CR3 read
    # immediately above, a real 64-bit physical address). Storing that
    # directly as CS's saved value would corrupt it with garbage in
    # the upper bits. Fixed with an explicit `movzwq` (zero-extending
    # 16-bit-to-64-bit load) through a scratch memory location is not
    # needed here -- `xor %eax,%eax` first (clearing the FULL 64-bit
    # %rax, since operating on the 32-bit %eax form zero-extends into
    # the upper 32 bits per the standard x86-64 rule) makes the
    # subsequent 16-bit `mov %cs,%ax` land in an already-zeroed
    # register, achieving the same zero-extending effect directly.
    xor %eax, %eax
    mov %cs, %ax
    movq %rax, 152(%rdi)
    xor %eax, %eax
    mov %ss, %ax
    movq %rax, 160(%rdi)

    # --- Restore the INCOMING task's state from (%rsi) ---
    movq 136(%rsi), %rax
    pushq %rax
    popfq

    # CR3: conditional restore, deliberately -- writing %cr3
    # unconditionally on every switch would flush the entire TLB even
    # when the incoming task shares the exact same address space as
    # the outgoing one (true for EVERY task in this project today,
    # since real per-task address spaces are not yet built -- this
    # plumbing exists ahead of that so the mechanism is proven safe
    # first, in the always-safe "same CR3" case, before anything
    # actually creates a task with a DIFFERENT one).
    #
    # BUG FOUND AND FIXED THIS SESSION, before boot-testing: an
    # earlier version of this block ran AFTER the general-purpose
    # register restore below (%r15..%rax), using %r10/%r11 as scratch
    # for the CR3 comparison -- but %r10/%r11 are THEMSELVES two of
    # the registers that block restores from the incoming task's real
    # saved state (see the restore list a few lines down). Using them
    # as throwaway scratch there would have overwritten the resumed
    # task's actual %r10/%r11 values with CR3-comparison garbage right
    # before resuming it -- a real, silent register-corruption bug,
    # caught by re-checking which registers were already "spoken for"
    # at each point in the sequence before trusting a register as
    # scratch, not found via a crash. Fixed by moving this whole block
    # to HERE, before any of %r15/%r14/%r13/%r12/%r11/%r10/%r9/%r8/
    # %rbp/%rbx/%rdx/%rcx/%rax are loaded with real incoming-task
    # values, so %rax is safe to use as scratch (it gets genuinely
    # reloaded from the task's saved state a few lines below
    # regardless, so using it here first costs nothing).
    movq 144(%rsi), %rax
    movq %cr3, %rdx
    cmpq %rax, %rdx
    je 1f
    movq %rax, %cr3
1:

    # RING CHECK: added this session. Reads the incoming task's saved
    # CS (offset 152) and tests its low 2 bits (RPL -- Requested
    # Privilege Level) to decide which of two COMPLETELY DIFFERENT
    # resume mechanisms to use: RPL=0 (ring 0) uses the ORIGINAL,
    # already-proven `jmp *%rax` path unchanged below; RPL=3 (ring 3)
    # branches to a NEW path (ring3_resume, below) that builds and
    # executes an iretq frame instead -- the only architecturally
    # correct way to resume execution at ring 3 with a specific
    # CS/SS/RFLAGS/RSP/RIP combination, matching usermode_enter.s's
    # own, already-proven mechanism for the FIRST entry into ring 3
    # (RING0-BRIDGE-SPEC.md sections 31-33) -- this is that same
    # mechanism, reused for every SUBSEQUENT resume of an already-
    # running ring-3 task, not a new, independently-invented one.
    # %r8 used as scratch here -- confirmed safe by the same
    # discipline as the CR3 fix: %r8 has not yet been loaded with the
    # incoming task's real saved value at this point (that happens a
    # few lines below), so clobbering it now costs nothing.
    movq 152(%rsi), %r8
    andq $3, %r8
    cmpq $3, %r8
    je ring3_resume

    movq 0(%rsi), %r15
    movq 8(%rsi), %r14
    movq 16(%rsi), %r13
    movq 24(%rsi), %r12
    movq 32(%rsi), %r11
    movq 40(%rsi), %r10
    movq 48(%rsi), %r9
    movq 56(%rsi), %r8
    movq 80(%rsi), %rbp
    movq 88(%rsi), %rbx
    movq 96(%rsi), %rdx
    movq 104(%rsi), %rcx
    movq 112(%rsi), %rax

    # RSP switch: from this instruction onward, we are executing on
    # the INCOMING task's stack, not the outgoing one's -- everything
    # above this point still ran on the outgoing task's stack (safe,
    # since nothing above touched the stack except the already-
    # completed pushfq/popq pair, which is balanced).
    movq 120(%rsi), %rsp

    # RDI/RSI restored LAST, since %rsi is still needed as the base
    # for the read immediately below it (RIP).
    movq 128(%rsi), %rax   # incoming task's saved RIP
    movq 64(%rsi), %rdi
    movq 72(%rsi), %rsi    # clobbers %rsi itself -- must be the
                             # final read that uses the OLD %rsi value
                             # as a base address; nothing after this
                             # line may use %rsi as "new_regs_addr"
                             # again, and nothing does.

    # BUG FOUND AND FIXED THIS SESSION -- a genuine, fundamental
    # 8-byte stack-alignment bug in the original design, root-caused
    # via a combination of instrumented checkpoint tracing, a direct
    # Fortran-side readback confirming the TCB itself held the
    # CORRECT saved RIP, and a QEMU register dump at the fault showing
    # %rax ALSO already held that same correct value -- yet execution
    # was happening at a completely different, wrong address. This
    # combination (right value in the register, wrong place actually
    # executing) pointed away from "the switch computed/restored the
    # wrong RIP" and toward "control reached the right RIP, then went
    # wrong a few instructions later purely from a stack-depth error."
    #
    # THE MECHANISM: this primitive saves %rsp exactly as it is at
    # entry -- i.e. still pointing AT the 8-byte return-address slot
    # `call fort0k_context_switch` itself pushed, never adjusted. The
    # original version then jumped to the saved RIP via `jmp *%rax`
    # rather than a real `ret`. A `jmp` does not pop anything, so
    # that 8-byte slot is left sitting, unconsumed, on the resumed
    # task's own stack. The resumed code (SCHED_YIELD's compiler-
    # generated epilogue, in the reproduction that exposed this) has
    # NO IDEA that extra 8-byte slot is there -- it was compiled
    # assuming a normal `call`/`ret` pair, where `ret` itself would
    # have consumed exactly that slot. The result: every subsequent
    # stack read in the resumed function (its own saved-register pops,
    # and its own final `ret`) is off by one 8-byte slot, reading
    # garbage -- confirmed by tracing the actual resumed code
    # (SCHED_DEMO_TASK_A, via SCHED_YIELD) and finding its compiled
    # epilogue pops exactly 6 registers immediately after this
    # primitive's jump target, with no slack for an extra unconsumed
    # value.
    #
    # FIX: advance %rsp by 8 (discarding that slot) immediately
    # before transferring control, so the resumed code sees EXACTLY
    # the %rsp state a genuine `ret` from `call fort0k_context_switch`
    # would have left -- indistinguishable, from the resumed code's
    # perspective, from having actually returned normally. The jump
    # still goes to the explicitly-saved RIP value (%rax), not to
    # whatever is now at the top of the stack -- this fix changes
    # ONLY the stack pointer's final value, not how the jump target
    # is determined, so SCHED_CREATE_TASK's fabricated-frame case
    # (where there was never a real return-address slot to begin
    # with) is unaffected: that case's saved RSP is simply the top of
    # a fresh, empty page, and advancing it by 8 before an
    # unconditional jmp to a fixed, separately-known entry point is
    # harmless (the resumed code there is a fresh function entry, not
    # code with any expectation about what, if anything, sits at the
    # very top of its stack).
    addq $8, %rsp

    # Jump to the incoming task's saved RIP directly, rather than
    # using `ret` -- SEE FIX COMMENT ABOVE for why the stack is now
    # first adjusted to make this equivalent to a real ret's effect,
    # while still using the explicitly-saved RIP value as the target
    # rather than trusting whatever is (or was) at the top of the
    # stack, since a fabricated task's stack has no such value to
    # trust in the first place.
    jmp *%rax
    .size fort0k_context_switch, .-fort0k_context_switch

    # ring3_resume: added this session. Reached when the RING CHECK
    # above found the incoming task's saved CS has RPL=3. Builds a
    # genuine iretq frame from the task's saved state and transfers
    # control via iretq -- the same mechanism usermode_enter.s already
    # uses and RING0-BRIDGE-SPEC.md sections 31-33 already proved
    # correct, applied here to a RESUME rather than a first entry.
    #
    # STILL ON THE OUTGOING TASK'S STACK at this label's entry --
    # unlike the ring-0 path above, which switches %rsp to the
    # incoming task's OWN stack before jumping (since a plain `jmp`
    # trusts whatever is already loaded into %rsp/%ss to be correct
    # for the destination), this path does NOT need to manually switch
    # %rsp at all: iretq itself performs the ENTIRE SS:RSP switch
    # atomically as part of restoring the incoming task's saved frame
    # -- attempting to also switch %rsp by hand first, the way the
    # ring-0 path does, would be redundant at best and could easily
    # corrupt the very values this path is about to push, at worst.
    # This means the iretq frame is built and pushed on the CURRENT
    # (outgoing task's, still ring 0 at this point in
    # fort0k_context_switch's own execution) stack -- safe, since
    # nothing here is resuming FROM that stack, only using it as
    # scratch space for the handful of pushes iretq needs, exactly the
    # same way usermode_enter.s already does from kernel_main.f90's
    # own ring-0 stack.
ring3_resume:
    movq 160(%rsi), %rax   # SS
    pushq %rax
    movq 120(%rsi), %rax   # RSP
    pushq %rax
    movq 136(%rsi), %rax   # RFLAGS
    pushq %rax
    movq 152(%rsi), %rax   # CS
    pushq %rax
    movq 128(%rsi), %rax   # RIP
    pushq %rax

    # General-purpose registers restored AFTER the iretq frame is
    # pushed, deliberately -- every push above used %rax as scratch,
    # so %rax itself must be restored to its REAL saved value last,
    # immediately before iretq, not before (which would have clobbered
    # the very value the RIP push above needed). %rsi is still needed
    # as the base address for every read in this block, so it too must
    # be among the last restored, matching the ring-0 path's own
    # RDI/RSI-restored-last discipline for the identical reason.
    movq 0(%rsi), %r15
    movq 8(%rsi), %r14
    movq 16(%rsi), %r13
    movq 24(%rsi), %r12
    movq 32(%rsi), %r11
    movq 40(%rsi), %r10
    movq 48(%rsi), %r9
    movq 56(%rsi), %r8
    movq 80(%rsi), %rbp
    movq 88(%rsi), %rbx
    movq 96(%rsi), %rdx
    movq 104(%rsi), %rcx
    movq 64(%rsi), %rdi
    movq 112(%rsi), %rax
    movq 72(%rsi), %rsi    # clobbers %rsi itself -- must be THE
                             # ABSOLUTE LAST restore in this path,
                             # exactly like the ring-0 path's own
                             # identical constraint, for the identical
                             # reason (nothing after this may use the
                             # OLD %rsi as a base address again, and
                             # nothing does -- iretq reads only from
                             # the stack this block already pushed to,
                             # not from %rsi).

    iretq
    .size fort0k_context_switch, .-fort0k_context_switch

    .section .note.GNU-stack,"",@progbits
