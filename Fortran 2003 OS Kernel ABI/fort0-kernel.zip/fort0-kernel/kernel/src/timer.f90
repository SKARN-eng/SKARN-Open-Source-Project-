! timer.f90 -- PIT (8253/8254) periodic timer driver, IRQ 0.
MODULE TIMER
  USE ISO_C_BINDING
  USE RING0
  IMPLICIT NONE

  INTEGER(C_INT16_T), PARAMETER :: PIT_CHANNEL0 = INT(Z'0040', C_INT16_T)
  INTEGER(C_INT16_T), PARAMETER :: PIT_COMMAND  = INT(Z'0043', C_INT16_T)
  INTEGER(C_INT64_T), PARAMETER :: PIT_BASE_HZ  = 1193182_C_INT64_T
  ! 1193182 Hz: the PIT's fixed input oscillator frequency -- a
  ! hardware constant (derived from the original IBM PC's crystal),
  ! not a value this project chose.

  INTEGER(C_INT64_T) :: TICK_COUNT = 0_C_INT64_T
  BIND(C, NAME="tick_count") :: TICK_COUNT
  ! Module-level counter, incremented once per IRQ0. No lock/atomicity
  ! concern yet: interrupts are the only concurrency this project has
  ! at this stage (no SMP, no preemptive kernel-mode reentrancy -- an
  ! interrupt handler cannot itself be interrupted by the same vector
  ! while it runs, since isr_stubs.s's trampoline enters via an
  ! interrupt gate, which clears IF on entry per IDT_GATE_INT_R0's
  ! definition in idt.f90). Revisit if either of those assumptions
  ! stops holding.

CONTAINS

  ! TIMER_INIT(HZ) -- programs PIT channel 0 for a periodic (mode 3,
  ! square wave) interrupt at approximately HZ interrupts per second.
  ! Does not unmask IRQ0 at the PIC -- kernel_main.f90 does that
  ! explicitly after registering TIMER_IRQ_HANDLER, per this project's
  ! general "wiring is visible where it happens" preference (see
  ! interrupts.f90's IRQ_REGISTER_HANDLER comment for the same
  ! reasoning applied there).
  SUBROUTINE TIMER_INIT(HZ)
    INTEGER(C_INT64_T), INTENT(IN) :: HZ
    INTEGER(C_INT64_T) :: DIVISOR

    DIVISOR = PIT_BASE_HZ / HZ
    ! 16-bit divisor -- PIT channel 0's counter register is 16 bits
    ! wide, so HZ below ~18 would overflow it (1193182/18 > 65535).
    ! Not clamped here: a caller requesting an HZ that low is a
    ! caller bug worth surfacing by a visibly wrong tick rate rather
    ! than silently clamping to something the caller didn't ask for.

    CALL FORT0K_OUTB(PIT_COMMAND, INT(Z'36', C_INT8_T))
    ! 0x36: channel 0 | lobyte/hibyte access | mode 3 (square wave) |
    ! binary (not BCD) counting.

    CALL FORT0K_OUTB(PIT_CHANNEL0, &
        INT(IAND(DIVISOR, INT(Z'FF', C_INT64_T)), C_INT8_T))
    CALL FORT0K_OUTB(PIT_CHANNEL0, &
        INT(IAND(ISHFT(DIVISOR, -8), INT(Z'FF', C_INT64_T)), C_INT8_T))
  END SUBROUTINE TIMER_INIT

  ! TIMER_IRQ_HANDLER(IRQ) -- matches INTERRUPTS module's
  ! IRQ_HANDLER_T interface exactly (same argument shape), registered
  ! via IRQ_REGISTER_HANDLER(0, TIMER_IRQ_HANDLER) in kernel_main.f90.
  ! IRQ argument is unused (this handler only ever gets called for
  ! IRQ 0, since that's the only line it's registered against) but
  ! kept in the signature to match every other handler's interface
  ! uniformly, rather than giving TIMER_IRQ_HANDLER a different
  ! signature that IRQ_REGISTER_HANDLER's PROCEDURE(IRQ_HANDLER_T)
  ! constraint would then reject at compile time anyway.
  SUBROUTINE TIMER_IRQ_HANDLER(IRQ)
    INTEGER, INTENT(IN) :: IRQ
    TICK_COUNT = TICK_COUNT + 1_C_INT64_T
  END SUBROUTINE TIMER_IRQ_HANDLER

END MODULE TIMER
