! idt.f90 -- Interrupt Descriptor Table.
!
! RING0-BRIDGE-SPEC.md section 1: IDT_ENTRY_T's field layout was
! independently verified via a byte-offset probe (objdump on a linked
! probe binary) to place every field at its intended offset with zero
! padding -- unlike GDT_PTR/IDT_PTR's limit+base shape, this
! particular field-size sequence (2,2,1,1,2,4,4 bytes) happens to sum
! to naturally-aligned boundaries throughout, so BIND(C) is safe to
! use directly for the gate descriptor itself. The IDTR (limit+base)
! that POINTS AT this table is a different shape and goes through
! FORT0K_LIDT's scalar-argument, build-in-asm path instead, exactly
! like FORT0K_LGDT -- see gdt.f90 and ring0.s.
MODULE IDT
  USE ISO_C_BINDING
  USE RING0
  IMPLICIT NONE

  INTEGER, PARAMETER :: IDT_NUM_ENTRIES = 49
  ! 0-31: CPU-reserved exception vectors (Intel SDM). 32-47: hardware
  ! IRQs 0-15, after PIC.F90's remap moves them off their post-power-on
  ! default of vectors 8-15 -- which collide with CPU exception vectors
  ! 8-15 (#DF, #TS, #NP, #SS, #GP, #PF, ...), a real and serious bug if
  ! interrupts were ever enabled before the remap. See pic.f90.
  ! 48: the syscall gate (this session's user-mode work) -- the ONLY
  ! vector in this table with DPL=3 (IDT_GATE_INT_R3, below); every
  ! other vector deliberately keeps DPL=0 (IDT_GATE_INT_R0), so a ring
  ! 3 program cannot directly invoke, say, the page-fault handler or
  ! any hardware IRQ vector by executing a bare `int N` -- only vector
  ! 48 is reachable that way from ring 3, by design.

  TYPE, BIND(C) :: IDT_ENTRY_T
    INTEGER(C_INT16_T) :: OFFSET_LOW
    INTEGER(C_INT16_T) :: SELECTOR
    INTEGER(C_INT8_T)  :: IST
    INTEGER(C_INT8_T)  :: TYPE_ATTR
    INTEGER(C_INT16_T) :: OFFSET_MID
    INTEGER(C_INT32_T) :: OFFSET_HIGH
    INTEGER(C_INT32_T) :: RESERVED
  END TYPE IDT_ENTRY_T

  TYPE(IDT_ENTRY_T), TARGET :: IDT_TABLE(IDT_NUM_ENTRIES)
  BIND(C, NAME="idt_table") :: IDT_TABLE

  ! Type-attribute byte for a 64-bit interrupt gate: present(1) |
  ! DPL(2) | 0 | type(4)=0xE. Present, ring 0, interrupt gate (as
  ! opposed to trap gate -- interrupt gates clear IF on entry, which
  ! this project wants: no nested interrupts during a handler until
  ! that is deliberately supported) = 0x8E.
  INTEGER(C_INT8_T), PARAMETER :: IDT_GATE_INT_R0 = INT(Z'8E', C_INT8_T)

  ! Type-attribute byte for the syscall gate: present(1) | DPL(2)=3 |
  ! 0 | type(4)=0xE -- identical to IDT_GATE_INT_R0 except DPL, which
  ! occupies bits 5-6 (0x60 when set to 3, binary 11). 0x8E | 0x60 =
  ! 0xEE. This is the ONLY gate in this table using this type --
  ! IDT_SET_GATE takes the type-attribute byte as an explicit
  ! argument specifically so this one exception did not need its own
  ! special-cased subroutine.
  INTEGER(C_INT8_T), PARAMETER :: IDT_GATE_INT_R3 = INT(Z'EE', C_INT8_T)

CONTAINS

  ! IDT_SET_GATE(VECTOR, HANDLER_ADDR, GATE_TYPE) -- fills
  ! IDT_TABLE(VECTOR+1) (Fortran 1-based indexing; VECTOR is the
  ! 0-based x86 vector number) to point at HANDLER_ADDR, using the
  ! kernel code selector and the given GATE_TYPE attribute byte
  ! (IDT_GATE_INT_R0 for every ordinary vector, IDT_GATE_INT_R3 for
  ! the one syscall vector -- see IDT_INSTALL below for which is used
  ! where). HANDLER_ADDR is the address of an asm trampoline
  ! (isr_stubs.s), never a bare Fortran BIND(C) subroutine's address
  ! directly -- see that file's header comment for why a trampoline
  ! is required (register save/restore and iretq, none of which a
  ! plain `ret`-terminated Fortran routine provides).
  SUBROUTINE IDT_SET_GATE(VECTOR, HANDLER_ADDR, GATE_TYPE)
    INTEGER, INTENT(IN) :: VECTOR
    INTEGER(C_INT64_T), INTENT(IN) :: HANDLER_ADDR
    INTEGER(C_INT8_T), INTENT(IN) :: GATE_TYPE
    INTEGER :: I
    I = VECTOR + 1

    IDT_TABLE(I)%OFFSET_LOW  = INT(IAND(HANDLER_ADDR, INT(Z'FFFF', C_INT64_T)), C_INT16_T)
    IDT_TABLE(I)%SELECTOR    = INT(Z'0008', C_INT16_T)   ! kernel code
                                                          ! selector; matches
                                                          ! GDT's KERNEL_CODE_SEL
                                                          ! (gdt.f90) -- not
                                                          ! USE'd directly to
                                                          ! avoid a circular
                                                          ! module dependency
                                                          ! for one constant;
                                                          ! re-verify both
                                                          ! stay in sync if
                                                          ! either changes.
                                                          ! Deliberately the
                                                          ! KERNEL code
                                                          ! selector even for
                                                          ! the DPL=3 syscall
                                                          ! gate -- the gate's
                                                          ! own SELECTOR field
                                                          ! is what CS gets
                                                          ! set to WHILE the
                                                          ! handler runs (ring
                                                          ! 0, correctly, since
                                                          ! the syscall
                                                          ! HANDLER itself must
                                                          ! run with kernel
                                                          ! privilege even
                                                          ! though a ring 3
                                                          ! program triggered
                                                          ! entry into it) --
                                                          ! DPL on the GATE
                                                          ! ITSELF (in
                                                          ! TYPE_ATTR, not
                                                          ! here) is the
                                                          ! separate, correct
                                                          ! place that
                                                          ! controls who is
                                                          ! ALLOWED to invoke
                                                          ! it via `int`.
    IDT_TABLE(I)%IST         = 0_C_INT8_T                ! no IST stack switch
    IDT_TABLE(I)%TYPE_ATTR   = GATE_TYPE
    IDT_TABLE(I)%OFFSET_MID  = INT(IAND(ISHFT(HANDLER_ADDR, -16), INT(Z'FFFF', C_INT64_T)), C_INT16_T)
    IDT_TABLE(I)%OFFSET_HIGH = INT(ISHFT(HANDLER_ADDR, -32), C_INT32_T)
    IDT_TABLE(I)%RESERVED    = 0_C_INT32_T
  END SUBROUTINE IDT_SET_GATE

  ! IDT_INSTALL() -- fills every vector with its trampoline's address
  ! (see isr_stubs.s for the trampoline symbols FORT0K_ISR_ADDR
  ! resolves) and loads the IDTR. Called once from kernel_main, after
  ! GDT_INSTALL (IDT gates reference the kernel code selector GDT
  ! installs).
  SUBROUTINE IDT_INSTALL() BIND(C, NAME="idt_install")
    INTERFACE
      FUNCTION FORT0K_ISR_ADDR(VECTOR) BIND(C, NAME="fort0k_isr_addr") RESULT(R)
        USE ISO_C_BINDING
        INTEGER(C_INT32_T), INTENT(IN), VALUE :: VECTOR
        INTEGER(C_INT64_T) :: R
      END FUNCTION FORT0K_ISR_ADDR
    END INTERFACE
    INTEGER :: V

    DO V = 0, IDT_NUM_ENTRIES - 1
      IF (V == 48) THEN
        CALL IDT_SET_GATE(V, FORT0K_ISR_ADDR(INT(V, C_INT32_T)), IDT_GATE_INT_R3)
      ELSE
        CALL IDT_SET_GATE(V, FORT0K_ISR_ADDR(INT(V, C_INT32_T)), IDT_GATE_INT_R0)
      END IF
    END DO

    CALL FORT0K_LIDT(INT(IDT_NUM_ENTRIES * 16 - 1, C_INT16_T), &
                      TRANSFER(C_LOC(IDT_TABLE(1)), 0_C_INT64_T))
  END SUBROUTINE IDT_INSTALL

END MODULE IDT
