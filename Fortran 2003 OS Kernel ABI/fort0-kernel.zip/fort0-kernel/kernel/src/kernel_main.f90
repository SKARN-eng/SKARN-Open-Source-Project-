! kernel_main.f90 -- Fortran-side entry point, called once from
! boot.s's long_mode_entry via `call kernel_main` (no gfortran name-
! mangling issue here: BIND(C, NAME="kernel_main") makes the exported
! symbol exactly "kernel_main", matching what boot.s calls literally).
!
! This is a BIND(C) SUBROUTINE, not a PROGRAM -- RING0-BRIDGE-SPEC.md
! section 1 found (nm-verified) that PROGRAM units pull in
! _gfortran_set_args/_gfortran_set_options, real libgfortran runtime-
! init calls this project's zero-libgfortran contract cannot use. No
! file in this codebase may contain a PROGRAM unit; this rule has no
! exceptions, unlike some of this project's other rules which allow
! documented per-file deviation.
SUBROUTINE KERNEL_MAIN(MB2_INFO_ADDR) BIND(C, NAME="kernel_main")
  USE ISO_C_BINDING
  USE VGA
  USE RING0
  USE SERIAL
  USE GDT
  USE TSS
  USE IDT
  USE PIC
  USE INTERRUPTS
  USE TIMER
  USE KEYBOARD
  USE MULTIBOOT2
  USE PMM
  USE VMM
  USE ACPI
  USE APIC
  USE SMP
  USE SCHED
  USE SCHED_NN
  IMPLICIT NONE
  INTEGER(C_INT64_T), INTENT(IN), VALUE :: MB2_INFO_ADDR
  INTEGER, PARAMETER :: SAY_BUF_MAX = 80   ! longest checkpoint message
                                            ! in this file is well under
                                            ! this; SAY() truncates
                                            ! rather than overruns if
                                            ! that ever stops being true

  ! Stage 0 goal: prove the boot chain end to end (Multiboot2 header
  ! accepted by GRUB -> 32-bit stub -> long mode transition -> call
  ! into Fortran) by writing visible text to the screen. MB2_INFO_ADDR
  ! is accepted as an argument (proving the by-reference-scalar-VALUE
  ! passing convention boot.s's comment describes actually works) but
  ! not yet parsed -- Multiboot2 info-structure parsing is a stage 1
  ! concern (memory map, specifically) once there's a use for it.
  !
  ! Serial checkpoints bracket every stage so a hang or crash is
  ! immediately visible in the serial log (QEMU -serial file:...)
  ! independent of whether the VGA write path itself is the thing at
  ! fault -- two independent output channels, not one channel checked
  ! twice, per this project's general instinct to verify rather than
  ! assume (RING0-BRIDGE-SPEC.md's whole methodology).
  CALL SERIAL_INIT()
  CALL SAY("fort0-kernel: serial online")
  CALL SAY("fort0-kernel: kernel_main entered, long mode confirmed")

  CALL GDT_INSTALL()
  CALL SAY("fort0-kernel: gdt installed, segments reloaded")

  CALL IDT_INSTALL()
  CALL SAY("fort0-kernel: idt installed")

  ! Stage 3 milestone: parse the Multiboot2 memory map (MB2_INFO_ADDR
  ! has been sitting unused since stage 0 -- see this subroutine's
  ! original header comment above, now out of date on that specific
  ! point) and build the physical page allocator from it. Placed here,
  ! before PIC_REMAP/interrupt-enabling below, deliberately: PMM_INIT
  ! does not need interrupts and has no reason to wait for them, and
  ! keeping "memory management is ready" independent of "interrupts
  ! are ready" makes it easier to reason about either failing without
  ! the other being implicated.
  CALL PMM_INIT(MB2_INFO_ADDR, FORT0K_KERNEL_START(), FORT0K_KERNEL_END())
  CALL SAY_HEX("fort0-kernel: pmm initialized, free pages = ", PMM_FREE_PAGES)
  CALL SAY_HEX("fort0-kernel: pmm total trackable pages = ", PMM_TOTAL_PAGES)

  CALL PMM_ALLOC_TEST()

  CALL VMM_TEST()

  CALL ACPI_TEST()

  CALL APIC_TEST()

  CALL SMP_TEST()

  CALL SCHED_REGISTER_SYSCALL_EXIT_HOOK()
  CALL SCHED_REGISTER_SYSCALL_YIELD_HOOK()

  ! TSS install: MUST happen before the first ring-3 transition --
  ! confirmed via web search this session (AMD APM) that long mode
  ! requires a valid TSS loaded via LTR, and this project's first
  ! attempt at USERMODE_TEST triple-faulted with CPL never once
  ! reaching 3 in the register dump, consistent with exactly this
  ! missing prerequisite. RSP0 is a freshly allocated page (PMM_ALLOC_
  ! PAGE, already available -- PMM_INIT ran earlier in this sequence)
  ! -- the stack the CPU switches to whenever an interrupt/exception/
  ! syscall raises the privilege level back to ring 0 while a ring-3
  ! program is running, matching every other stack-allocation
  ! convention in this codebase (top of the page, growing down).
  BLOCK
    INTEGER(C_INT64_T) :: KERNEL_STACK0_PHYS
    KERNEL_STACK0_PHYS = PMM_ALLOC_PAGE()
    IF (KERNEL_STACK0_PHYS < 0_C_INT64_T) THEN
      CALL SAY("fort0-kernel: TSS INSTALL FAILED - could not allocate RSP0 stack")
    ELSE
      CALL TSS_INSTALL(KERNEL_STACK0_PHYS + 4096_C_INT64_T)
      CALL SAY("fort0-kernel: tss installed, ltr loaded")
    END IF
  END BLOCK

  ! BUG FOUND AND FIXED THIS SESSION -- the actual root cause of the
  ! double fault documented in RING0-BRIDGE-SPEC.md sections 31-32:
  ! PIC_REMAP/TIMER_INIT/FORT0K_STI previously ran AFTER USERMODE_TEST,
  ! meaning the very first time this project ever had interrupts
  ! enabled (RFLAGS.IF=1, set inside USERMODE_TEST's own constructed
  ! iretq frame, independent of whether FORT0K_STI had run globally),
  ! the PIC was STILL AT ITS POWER-ON DEFAULT MAPPING -- IRQ0 (the
  ! timer) delivered as vector 8, which is literally the CPU's own
  ! Double Fault vector. Confirmed via QEMU's `-d int,guest_errors`
  ! trace this session: "Servicing hardware INT=0x08" repeated,
  ! showing the timer being misdelivered directly AS a double fault,
  ! not merely causing one as a side effect -- exactly the vector-8-15
  ! collision this project's own idt.f90 header comment already named
  ! as a real hazard (Stage 2), which this ordering bug reintroduced
  ! specifically for the ring-3 test path. Moved PIC_REMAP and every
  ! IRQ-setup step needed for correct, safe interrupt delivery to
  ! BEFORE USERMODE_TEST, so the PIC is correctly remapped (IRQ0-15 ->
  ! vectors 32-47) before the first time this project ever runs with
  ! interrupts enabled, at ring 3 or otherwise.
  CALL PIC_REMAP()
  CALL SAY("fort0-kernel: pic remapped (irq0-15 -> vectors 32-47)")

  CALL IRQ_REGISTER_HANDLER(0, TIMER_IRQ_HANDLER)
  CALL IRQ_REGISTER_HANDLER(1, KEYBOARD_IRQ_HANDLER)
  CALL TIMER_INIT(100_C_INT64_T)   ! 100 Hz -- arbitrary, convenient
                                    ! for a visible-but-not-overwhelming
                                    ! serial log rate; revisit once
                                    ! anything in this codebase actually
                                    ! depends on the tick rate for
                                    ! timing accuracy
  CALL SAY("fort0-kernel: timer programmed at 100hz, handlers registered")

  CALL PIC_SET_MASK(0, .FALSE._C_BOOL)   ! unmask timer
  CALL PIC_SET_MASK(1, .FALSE._C_BOOL)   ! unmask keyboard
  CALL SAY("fort0-kernel: irq0 (timer) and irq1 (keyboard) unmasked")

  ! USERMODE_TEST() (the standalone, pre-scheduler ring-3 entry test)
  ! is DELIBERATELY NOT CALLED HERE anymore -- it never returns (parks
  ! in a spin loop forever once its own test completes), which would
  ! permanently block SCHED_TEST_WRAPPER below from ever running. It
  ! served its purpose (RING0-BRIDGE-SPEC.md sections 31-33, proving
  ! the core ring-3 entry mechanism) and remains in the source as a
  ! standalone, callable subroutine, but the SCHEDULED ring-3 task
  ! created inside SCHED_TEST_WRAPPER (usermode_test_scheduled) now
  ! supersedes it as the more complete, real test -- a task that
  ! actually runs THROUGH the scheduler alongside other tasks, rather
  ! than a one-off standalone entry with nothing to return to.

  CALL SCHED_TEST_WRAPPER()
  ! RE-ENABLED, CONFIRMED WORKING: both bugs documented in RING0-
  ! BRIDGE-SPEC.md sections 20-23 are fixed. (1) gfortran tail-call-
  ! optimizing the CALL into fort0k_context_switch into a bare `jmp`
  ! (section 20) -- fixed via -fno-optimize-sibling-calls (Makefile).
  ! (2) SCHED_CREATE_TASK fabricating new tasks with IF set, causing a
  ! non-deterministic fault mid-switch (section 22) -- fixed by
  ! clearing IF in the fabricated RFLAGS. (3) fort0k_context_switch's
  ! `jmp *%rax` never consuming the 8-byte return-address slot `call
  ! fort0k_context_switch` itself pushed, leaving every resumed task's
  ! stack permanently misaligned by one qword relative to what its own
  ! compiled code expected (section 23, the actual final root cause)
  ! -- fixed by advancing %rsp by 8 immediately before the jump, making
  ! the transfer indistinguishable from a real `ret` from the resumed
  ! code's perspective. Verified via 4 consecutive clean boots (both
  ! demo tasks completing their full 5-iteration interleave, zero
  ! faults) after all three fixes were in place together.

  CALL VGA_CLEAR()
  CALL SAY("fort0-kernel: vga cleared")

  CALL VGA_PRINT_BANNER()
  CALL SAY("fort0-kernel: vga banner written")

  ! Stage 1's milestone (deliberate divide-by-zero proving the IDT/
  ! exception-handler chain works without triple-faulting) served its
  ! purpose and is removed now that stage 2 has a more informative
  ! milestone: real hardware IRQs (timer, keyboard) delivered through
  ! the exact same IDT/trampoline/dispatch machinery, proving that
  ! path handles the CASE THAT MATTERS FOR AN ACTUAL RUNNING KERNEL
  ! (recoverable, resumed interrupts) and not just the fatal-exception
  ! case stage 1 proved. The exception path itself (interrupts.f90's
  ! FORT0K_DISPATCH, vector < 32 branch) is unchanged and still covers
  ! every CPU exception exactly as stage 1 left it. PIC_REMAP/
  ! TIMER_INIT/PIC_SET_MASK themselves now run EARLIER (before
  ! USERMODE_TEST, see that call site's own comment for why) -- this
  ! is simply where FORT0K_STI globally enables interrupts, the
  ! correct final step once every IRQ-handling prerequisite is
  ! already in place.
  CALL FORT0K_STI()
  CALL SAY("fort0-kernel: interrupts enabled -- stage 2 milestone live")

  CALL IDLE_LOOP()

CONTAINS

  ! PMM_ALLOC_TEST() -- stage 3's concrete milestone, in the same
  ! spirit as stage 1's deliberate divide-by-zero and stage 2's live
  ! tick counter: don't just trust a summary NUMBER (PMM_FREE_PAGES),
  ! prove the allocator actually WORKS by allocating real pages,
  ! writing a distinct pattern to each, reading it back to confirm no
  ! two allocations aliased the same physical page, then freeing one
  ! and re-allocating to confirm the freed page comes back.
  SUBROUTINE PMM_ALLOC_TEST()
    INTEGER(C_INT64_T) :: A1, A2, A3, A4
    INTEGER(C_INT32_T), POINTER :: P1, P2, P3

    A1 = PMM_ALLOC_PAGE()
    A2 = PMM_ALLOC_PAGE()
    A3 = PMM_ALLOC_PAGE()
    CALL SAY_HEX("fort0-kernel: pmm alloc 1 = ", A1)
    CALL SAY_HEX("fort0-kernel: pmm alloc 2 = ", A2)
    CALL SAY_HEX("fort0-kernel: pmm alloc 3 = ", A3)

    IF (A1 < 0_C_INT64_T .OR. A2 < 0_C_INT64_T .OR. A3 < 0_C_INT64_T) THEN
      CALL SAY("fort0-kernel: PMM TEST FAILED - allocation returned -1")
      RETURN
    END IF
    IF (A1 == A2 .OR. A2 == A3 .OR. A1 == A3) THEN
      CALL SAY("fort0-kernel: PMM TEST FAILED - two allocations aliased")
      RETURN
    END IF

    ! Write a distinct, recognizable pattern into each page (via the
    ! current 1GiB identity map, so the physical address IS the
    ! virtual address this project can dereference directly -- true
    ! only because stage 0's boot.s built an identity map this far;
    ! this test would need translation through a real page-table walk
    ! once a non-identity virtual memory layout exists, a future
    ! stage's concern per this project's own README).
    CALL C_F_POINTER(TRANSFER(A1, C_NULL_PTR), P1)
    CALL C_F_POINTER(TRANSFER(A2, C_NULL_PTR), P2)
    CALL C_F_POINTER(TRANSFER(A3, C_NULL_PTR), P3)
    P1 = INT(Z'11111111', C_INT32_T)
    P2 = INT(Z'22222222', C_INT32_T)
    P3 = INT(Z'33333333', C_INT32_T)

    IF (P1 /= INT(Z'11111111', C_INT32_T) .OR. &
        P2 /= INT(Z'22222222', C_INT32_T) .OR. &
        P3 /= INT(Z'33333333', C_INT32_T)) THEN
      CALL SAY("fort0-kernel: PMM TEST FAILED - readback mismatch (pages alias?)")
      RETURN
    END IF

    CALL PMM_FREE_PAGE(A2)
    A4 = PMM_ALLOC_PAGE()
    CALL SAY_HEX("fort0-kernel: pmm freed alloc 2, re-alloc = ", A4)
    IF (A4 /= A2) THEN
      CALL SAY("fort0-kernel: pmm note - re-alloc did not reuse freed page (not a failure, just not the first-fit result expected)")
    END IF

    CALL SAY("fort0-kernel: pmm alloc test passed - distinct pages, correct readback, free/realloc worked")
  END SUBROUTINE PMM_ALLOC_TEST

  ! VMM_TEST() -- stage 4's concrete milestone, same spirit as every
  ! prior stage's proof: don't just call VMM_INIT and trust it worked
  ! silently, prove the higher-half mapping is REAL by writing a
  ! distinct pattern through the PHYSICAL/identity address, reading it
  ! back through the NEW HIGHER-HALF VIRTUAL address, and confirming
  ! they see the same memory -- the only way to be sure CR3 was
  ! actually reloaded with a table that correctly maps both, rather
  ! than e.g. silently continuing to run on the old tables the whole
  ! time (which would make the identity-address check below pass but
  ! the higher-half check fault or read garbage).
  SUBROUTINE VMM_TEST()
    INTEGER(C_INT64_T) :: NEW_PML4, TEST_PHYS, TEST_VIRT_HH
    INTEGER(C_INT32_T), POINTER :: P_PHYS, P_HH

    NEW_PML4 = VMM_INIT(FORT0K_KERNEL_START(), FORT0K_KERNEL_END())
    IF (NEW_PML4 < 0_C_INT64_T) THEN
      CALL SAY("fort0-kernel: VMM TEST FAILED - VMM_INIT returned -1 (out of memory)")
      RETURN
    END IF
    CALL SAY_HEX("fort0-kernel: vmm new pml4 (cr3) = ", NEW_PML4)
    CALL SAY("fort0-kernel: cr3 reloaded, still running -- identity map survived the switch")

    ! Allocate a fresh page via PMM for the actual cross-mapping test
    ! (rather than reusing kernel image memory, so a bug here can't be
    ! confused with a kernel-image mapping bug specifically).
    TEST_PHYS = PMM_ALLOC_PAGE()
    IF (TEST_PHYS < 0_C_INT64_T) THEN
      CALL SAY("fort0-kernel: VMM TEST FAILED - no free page for cross-mapping test")
      RETURN
    END IF

    ! This test page is fresh PMM memory, not part of [kernel_start,
    ! kernel_end), so VMM_INIT's mappings do not already cover it --
    ! map it explicitly at both its identity address and a higher-half
    ! address of our choosing (arbitrary offset from HIGHER_HALF_BASE,
    ! chosen not to collide with the kernel image's own higher-half
    ! range mapped by VMM_INIT).
    TEST_VIRT_HH = HIGHER_HALF_BASE + INT(Z'10000000', C_INT64_T)
    CALL VMM_MAP_4K(NEW_PML4, TEST_PHYS, TEST_PHYS, IOR(PTE_PRESENT, PTE_WRITABLE))
    CALL VMM_MAP_4K(NEW_PML4, TEST_VIRT_HH, TEST_PHYS, IOR(PTE_PRESENT, PTE_WRITABLE))

    CALL C_F_POINTER(TRANSFER(TEST_PHYS, C_NULL_PTR), P_PHYS)
    CALL C_F_POINTER(TRANSFER(TEST_VIRT_HH, C_NULL_PTR), P_HH)

    P_PHYS = INT(Z'DEADBEEF', C_INT32_T)
    IF (P_HH /= INT(Z'DEADBEEF', C_INT32_T)) THEN
      CALL SAY("fort0-kernel: VMM TEST FAILED - write via identity addr not visible via higher-half addr")
      RETURN
    END IF

    P_HH = INT(Z'C0FFEE00', C_INT32_T)
    IF (P_PHYS /= INT(Z'C0FFEE00', C_INT32_T)) THEN
      CALL SAY("fort0-kernel: VMM TEST FAILED - write via higher-half addr not visible via identity addr")
      RETURN
    END IF

    CALL SAY_HEX("fort0-kernel: vmm test page identity addr = ", TEST_PHYS)
    CALL SAY_HEX("fort0-kernel: vmm test page higher-half addr = ", TEST_VIRT_HH)
    CALL SAY("fort0-kernel: vmm test passed - same physical page, two virtual addresses, both read/write correctly")
  END SUBROUTINE VMM_TEST

  ! ACPI_TEST() -- stage 5's first checkpoint, deliberately separate
  ! from and before the much riskier APIC-MMIO/AP-trampoline work: on
  ! its own, this proves ACPI table discovery and parsing work
  ! correctly (a real CPU count and a real set of APIC IDs, not just
  ! "no crash") before anything in this stage touches the APIC or
  ! writes a trampoline other cores will execute -- if this checkpoint
  ! reports something implausible (0 CPUs, a CPU count wildly larger
  ! than QEMU's -smp setting, garbage-looking APIC IDs), that is
  ! caught here, isolated from any AP-bring-up bug, rather than
  ! discovered only once cores are already being woken with bad data.
  SUBROUTINE ACPI_TEST()
    LOGICAL :: OK
    INTEGER :: I

    OK = ACPI_INIT(MB2_INFO_ADDR)
    IF (.NOT. OK) THEN
      CALL SAY("fort0-kernel: ACPI TEST - MADT not found (no SMP possible)")
      RETURN
    END IF

    CALL SAY_HEX("fort0-kernel: acpi cpu count = ", INT(ACPI_CPU_COUNT, C_INT64_T))
    CALL SAY_HEX("fort0-kernel: acpi local apic phys addr = ", ACPI_LOCAL_APIC_PHYS)
    DO I = 1, ACPI_CPU_COUNT
      CALL SAY_HEX("fort0-kernel: acpi cpu apic id = ", INT(ACPI_CPU_APIC_IDS(I), C_INT64_T))
    END DO
  END SUBROUTINE ACPI_TEST

  ! APIC_TEST() -- stage 5's second checkpoint: maps the Local APIC's
  ! MMIO page (a real address outside this project's 1GiB identity
  ! map, so this also incidentally re-exercises VMM_MAP_4K on a fresh
  ! address after VMM_INIT's own bulk mapping, a useful sanity check
  ! in itself) and reads its own APIC ID back. Deliberately does NOT
  ! send any IPI yet -- a working register READ (this checkpoint)
  ! confirms MMIO access itself is correct in isolation, before this
  ! stage's next, riskier step (sending an INIT/Startup IPI to a real
  ! target core) risks confusing "MMIO access is broken" with "IPI
  ! sequencing is broken" if something goes wrong there instead.
  SUBROUTINE APIC_TEST()
    INTEGER(C_INT8_T) :: MY_ID

    CALL APIC_INIT()
    MY_ID = APIC_GET_ID()
    CALL SAY_HEX("fort0-kernel: apic mmio mapped, own apic id = ", INT(MY_ID, C_INT64_T))

    IF (ACPI_CPU_COUNT > 0) THEN
      IF (MY_ID == ACPI_CPU_APIC_IDS(1)) THEN
        CALL SAY("fort0-kernel: apic id matches first MADT entry (BSP identified correctly)")
      ELSE
        CALL SAY("fort0-kernel: apic id note - first MADT entry mismatch (BSP-first is convention, not guarantee)")
      END IF
    END IF
  END SUBROUTINE APIC_TEST

  ! SMP_TEST() -- the actual stage 5 milestone: wake every ACPI-
  ! enumerated core other than the BSP and confirm each one reports in
  ! via serial with its own APIC ID, proving the full chain (trampoline
  ! copy, per-core stack allocation, INIT-SIPI-SIPI, real-to-long-mode
  ! transition on a SECOND core, landing in Fortran) actually works --
  ! not just "no crash," a real count of cores that checked in,
  ! checked against ACPI_CPU_COUNT - 1 (every core except the BSP
  ! itself).
  SUBROUTINE SMP_TEST()
    INTEGER(C_INT64_T) :: EXPECTED
    INTEGER(C_INT8_T), POINTER :: CHECKPOINT_BYTE

    EXPECTED = INT(ACPI_CPU_COUNT - 1, C_INT64_T)
    CALL SAY_HEX("fort0-kernel: smp - waking all aps, expected count = ", EXPECTED)

    CALL C_F_POINTER(TRANSFER(INT(Z'9000', C_INT64_T), C_NULL_PTR), CHECKPOINT_BYTE)
    CHECKPOINT_BYTE = 0_C_INT8_T   ! clear before waking, so a stale
                                     ! value from a previous run (or
                                     ! garbage boot memory) can't be
                                     ! mistaken for real progress

    CALL SMP_WAKE_ALL_APS()

    CALL SAY_HEX("fort0-kernel: smp - trampoline checkpoint byte = ", INT(CHECKPOINT_BYTE, C_INT64_T))
    CALL SAY_HEX("fort0-kernel: smp - aps started = ", INT(AP_STARTED_COUNT, C_INT64_T))
    IF (INT(AP_STARTED_COUNT, C_INT64_T) == EXPECTED) THEN
      CALL SAY("fort0-kernel: smp test passed - every detected AP checked in")
    ELSE
      CALL SAY("fort0-kernel: smp test INCOMPLETE - not every AP checked in (see counts above)")
    END IF
  END SUBROUTINE SMP_TEST

  ! SCHED_TEST() -- the scheduler's first checkpoint (single core,
  ! cooperative yield only, no preemption yet, per this stage's
  ! agreed two-checkpoint plan): creates two demo tasks that each
  ! print a distinct message and call SCHED_YIELD repeatedly, then
  ! starts the scheduler on the BSP (core 0) and lets them run for a
  ! bounded number of total switches. Proves the context-switch
  ! primitive genuinely preserves per-task state across a round trip
  ! (each task's own loop counter survives being switched away from
  ! and back) rather than merely "not crashing," matching every prior
  ! stage's insistence on a real, checkable proof.
  !
  ! DOES NOT RETURN in the normal sense: SCHED_START's first switch
  ! jumps into TASK_A_BODY and never comes back to this call site
  ! (see SCHED_START's own comment) -- everything after the
  ! CALL SCHED_START line below is dead code, kept only as a
  ! documented statement of that fact rather than silently omitted,
  ! matching this project's practice of naming non-obvious control-
  ! flow properties rather than leaving them implicit.
  ! USERMODE_TEST() -- the actual, real proof this session's work
  ! exists for: enters ring 3 for the first time in this project's
  ! history. Allocates a fresh page for the user-mode stack (via
  ! PMM_ALLOC_PAGE, matching every other stack-allocation convention
  ! in this codebase -- top of the page, growing down), resolves
  ! USERMODE_TEST_BODY's address (a hand-written asm symbol,
  ! usermode_test.s, not a Fortran BIND(C) procedure -- so its address
  ! is obtained via a bare INTERFACE-less external reference, the same
  ! "asm symbol, Fortran reads its address via `lea`-backed accessor"
  ! pattern this project already uses for boot.s/ap_trampoline.s's own
  ! linker-only symbols, here needing no accessor at all since the
  ! symbol is a genuine function and its address can be taken directly
  ! via C_FUNLOC-equivalent... actually a plain EXTERNAL declaration
  ! plus TRANSFER, since usermode_test_body has no Fortran-visible
  ! declaration to attach BIND(C) to -- see the accessor function
  ! immediately below), then calls FORT0K_ENTER_USERMODE.
  !
  ! DOES NOT RETURN, by construction -- see usermode_enter.s's own
  ! header comment. The syscall gate (SYS_EXIT, interrupts.f90) is
  ! the only way this project has for the ring-3 code entered here to
  ! ever hand control back to anything resembling this call site's
  ! continuation, and even that returns into SCHED_TEST_WRAPPER (the
  ! NEXT statement after this call, per this project's linear boot
  ! sequence) only in the sense that execution eventually reaches
  ! that point in the INSTRUCTION STREAM -- not via any actual
  ! function return from this subroutine.
  SUBROUTINE USERMODE_TEST()
    INTEGER(C_INT64_T) :: USER_STACK_PHYS
    INTEGER(C_INT64_T) :: ENTRY_ADDR
    INTEGER(C_INT64_T) :: CODE_PAGE

    CALL SAY("fort0-kernel: usermode test - entering ring 3 now")

    USER_STACK_PHYS = PMM_ALLOC_PAGE()
    IF (USER_STACK_PHYS < 0_C_INT64_T) THEN
      CALL SAY("fort0-kernel: USERMODE TEST FAILED - could not allocate user stack")
      RETURN
    END IF

    ENTRY_ADDR = FORT0K_USERMODE_TEST_BODY_ADDR()

    ! BUG FOUND AND FIXED THIS SESSION: every mapping this project has
    ! ever built (vmm.f90, since Stage 4) omitted PTE_USER (the U/S
    ! bit) -- meaning every page, including the kernel code page
    ! USERMODE_TEST_BODY itself lives on, was Supervisor-only. A ring
    ! 3 attempt to fetch even the FIRST instruction from such a page
    ! faults immediately -- confirmed via a real boot test this
    ! session (zero ring-3 instructions ever executed; a double fault
    ! occurred with no expected 'U' syscall output ever reaching
    ! serial). Fixed by explicitly re-mapping the SPECIFIC pages this
    ! test needs (the code page and the stack page) with PTE_USER
    ! added -- NOT the entire identity map, which would defeat the
    ! actual point of a privilege boundary by making every page,
    ! including page tables themselves, accessible from ring 3.
    ! CODE_PAGE rounds ENTRY_ADDR down to its containing 4KiB page --
    ! VMM_MAP_4K operates on whole pages, and USERMODE_TEST_BODY's
    ! exact address is very unlikely to itself be page-aligned.
    CODE_PAGE = IAND(ENTRY_ADDR, NOT(4095_C_INT64_T))
    CALL VMM_MAP_4K(VMM_CURRENT_PML4, CODE_PAGE, CODE_PAGE, &
                     IOR(PTE_PRESENT, PTE_USER))
    ! Deliberately NOT PTE_WRITABLE -- this is CODE, and this
    ! project's kernel code segment is not writable at ring 0 either
    ! (matching ordinary W^X practice, even though this project does
    ! not yet enforce NX broadly -- not making ring-3-readable code
    ! ALSO ring-3-writable is a real, if small, security-relevant
    ! choice worth making correctly from the start rather than
    ! defaulting to "writable" out of convenience).
    CALL VMM_MAP_4K(VMM_CURRENT_PML4, USER_STACK_PHYS, USER_STACK_PHYS, &
                     IOR(PTE_PRESENT, IOR(PTE_WRITABLE, PTE_USER)))

    CALL FORT0K_ENTER_USERMODE(ENTRY_ADDR, USER_STACK_PHYS + 4096_C_INT64_T)
    ! Unreachable -- see header comment.
    CALL SAY("fort0-kernel: ERROR - reached past FORT0K_ENTER_USERMODE, should be impossible")
  END SUBROUTINE USERMODE_TEST

  SUBROUTINE SCHED_TEST_WRAPPER()
    ! Thin wrapper: the real test logic and demo task bodies live in
    ! sched.f90 as MODULE-LEVEL procedures, not here as internal
    ! (CONTAINS) ones. BUG FOUND THIS SESSION: an internal procedure
    ! referenced only via C_FUNLOC (never CALLed directly) is not
    ! reliably compiled/linked by gfortran at all -- confirmed via a
    ! real link failure (undefined reference to a mangled, numbered
    ! internal-procedure name) and an isolated probe showing the
    ! procedure body vanishes entirely from `nm` output at -O2, and
    ! remains undefined even at -O0. See RING0-BRIDGE-SPEC.md for the
    ! full account. Fix: any procedure this project needs the address
    ! of via C_FUNLOC must be module-level (matching AP_MAIN's
    ! existing, already-working pattern in smp.f90), never internal.
    !
    ! NN_TASK created and enqueued HERE, before SCHED_TEST() runs --
    ! SCHED_TEST()'s own SCHED_START call never returns (jumps
    ! directly into the first task), so this is the only point after
    ! which nothing further in this subroutine would execute. Creating
    ! it here rather than inside sched.f90's SCHED_TEST keeps
    ! sched.f90 free of any dependency on sched_nn.f90 (the reverse
    ! dependency, sched_nn.f90 -> sched.f90, is the correct direction
    ! and already exists) -- kernel_main.f90 already depends on both
    ! modules, so it is the natural place to wire them together.
    INTEGER :: NN_TASK
    INTEGER :: EXIT_TASK
    NN_TASK = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_NN_DEMO_TASK), 0_C_INT64_T))
    IF (NN_TASK > 0) THEN
      CALL SCHED_ENQUEUE(NN_TASK)
    END IF

    ! EXIT_TASK: proves the real task-lifecycle work this session
    ! (TASK_STATE_ZOMBIE, SCHED_EXIT_TASK, SCHED_REAP_ZOMBIES,
    ! sched.f90) end to end -- yields a couple of times, then
    ! genuinely exits via SCHED_EXIT_TASK, and the idle task (also new
    ! this session) reaps its stack once the ready queue empties out.
    EXIT_TASK = SCHED_CREATE_TASK(TRANSFER(C_FUNLOC(SCHED_DEMO_TASK_EXIT), 0_C_INT64_T))
    IF (EXIT_TASK > 0) THEN
      CALL SCHED_ENQUEUE(EXIT_TASK)
    END IF

    ! RING3_TASK: the actual proof of this session's second item --
    ! a REAL, SCHEDULED ring-3 task, created via SCHED_CREATE_TASK_
    ! USERMODE (which sets CS/SS to the user selectors and remaps the
    ! task's STACK page with PTE_USER), running alongside the ring-0
    ! demo tasks above through the SAME ready queue and the SAME
    ! fort0k_context_switch primitive -- now ring-3-aware (this
    ! session's sched_switch.s work: a RING CHECK on the incoming
    ! task's saved CS, branching to a genuine iretq-based resume path
    ! for RPL=3 tasks instead of the ordinary jmp path). The task's
    ! CODE page (not its stack) must ALSO be remapped with PTE_USER
    ! separately -- SCHED_CREATE_TASK_USERMODE does not do this (it
    ! has no way to know the code's extent, only its entry address),
    ! matching USERMODE_TEST's own identical requirement above.
    BLOCK
      INTEGER :: RING3_TASK
      INTEGER(C_INT64_T) :: RING3_ENTRY, RING3_CODE_PAGE
      RING3_ENTRY = FORT0K_USERMODE_TEST_SCHEDULED_ADDR()
      RING3_CODE_PAGE = IAND(RING3_ENTRY, NOT(4095_C_INT64_T))
      CALL VMM_MAP_4K(VMM_CURRENT_PML4, RING3_CODE_PAGE, RING3_CODE_PAGE, &
                       IOR(PTE_PRESENT, PTE_USER))
      RING3_TASK = SCHED_CREATE_TASK_USERMODE(RING3_ENTRY)
      IF (RING3_TASK > 0) THEN
        CALL SCHED_ENQUEUE(RING3_TASK)
        CALL SAY("fort0-kernel: ring-3 scheduled task created and enqueued")
      ELSE
        CALL SAY("fort0-kernel: RING3 TASK CREATION FAILED")
      END IF
    END BLOCK

    ! Activate the real scored-dequeue policy -- from this point on,
    ! every scheduling decision (SCHED_TEST's cooperative switching,
    ! below) picks the highest-NN-scored READY task instead of plain
    ! FIFO order. See RING0-BRIDGE-SPEC.md's neural-net-policy section
    ! for what this changes and does not change.
    CALL SCHED_NN_ENABLE_POLICY()

    CALL SCHED_TEST()
  END SUBROUTINE SCHED_TEST_WRAPPER

  ! IDLE_LOOP() -- HLT's in a loop (the standard idle-CPU idiom: HLT
  ! stops fetching instructions until the next interrupt, rather than
  ! busy-spinning) and, once every ~5 seconds of tick count, prints
  ! the current TICK_COUNT to serial -- a live, ongoing signal that
  ! IRQ0 keeps firing and being correctly EOI'd (if EOI were ever
  ! wrong, the PIC would stop delivering further timer interrupts and
  ! this printout would stop advancing, an easy-to-notice symptom).
  SUBROUTINE IDLE_LOOP()
    INTEGER(C_INT64_T) :: LAST_PRINTED
    LAST_PRINTED = -1_C_INT64_T
    DO
      CALL FORT0K_HLT()
      IF (TICK_COUNT - LAST_PRINTED >= 500_C_INT64_T) THEN
        ! 500 ticks at 100Hz = ~5 seconds.
        CALL SAY_HEX("fort0-kernel: tick_count = ", TICK_COUNT)
        LAST_PRINTED = TICK_COUNT
      END IF
    END DO
  END SUBROUTINE IDLE_LOOP

  ! TRIGGER_DIVIDE_BY_ZERO() -- stage 1's milestone test. No longer
  ! called by default (stage 2's IRQ path, above, is the current
  ! milestone), but kept as a standing regression check: uncomment the
  ! call site in KERNEL_MAIN if a future change to idt.f90/isr_stubs.s/
  ! interrupts.f90 needs re-verifying against a real CPU exception,
  ! rather than only against the IRQ path -- the two paths share
  ! trampoline_common but diverge at FORT0K_DISPATCH's vector<32
  ! branch, so a regression specific to the exception side would not
  ! necessarily show up from IRQ testing alone.
  !
  ! Deliberately executes an integer division by zero to prove the
  ! IDT/exception-handler chain works: vector 0 (#DE) fires,
  ! isr_stubs.s's trampoline catches it, FORT0K_DISPATCH prints a
  ! report to serial and halts cleanly rather than triple-faulting.
  !
  ! TWO SEPARATE OPTIMIZER LANDMINES HAD TO BE DEFEATED HERE, FOUND
  ! VIA A REAL FAILED BOOT TEST (not anticipated in advance): the
  ! first attempt at this routine computed RESULT = 42 / DIVISOR and
  ! never used RESULT afterward, and gfortran at -O2 eliminated the
  ! entire division as dead code (confirmed via objdump: zero div/idiv
  ! instructions anywhere in the final binary) -- the DIVISOR-from-a-
  ! function-call trick defeats compile-time CONSTANT FOLDING but does
  ! nothing to defeat DEAD CODE ELIMINATION of a computation whose
  ! result is provably never read. Fix: RESULT is passed to SAY_HEX,
  ! an external call gfortran cannot see through, so the division is
  ! observably live and cannot be eliminated. Both defenses (opaque
  ! divisor AND observable result) are required together; either
  ! alone was insufficient.
  SUBROUTINE TRIGGER_DIVIDE_BY_ZERO()
    INTEGER(C_INT64_T) :: DIVISOR, RESULT
    DIVISOR = FORT0K_GET_ZERO()
    RESULT = 42_C_INT64_T / DIVISOR
    CALL SAY_HEX("fort0-kernel: (unreachable) division result: ", RESULT)
  END SUBROUTINE TRIGGER_DIVIDE_BY_ZERO

  ! SAY(MSG) -- convenience wrapper so call sites above read as plain
  ! text instead of repeating LEN_TRIM-avoidance boilerplate at every
  ! checkpoint.
  !
  ! LANDMINE FOUND THIS SESSION, not previously catalogued by
  ! CALL-BRIDGE-SPEC.md: a local automatic-size array dimensioned from
  ! LEN(dummy-argument) -- CHARACTER(LEN=1) :: BUF(LEN(MSG)) -- compiles
  ! to a genuine malloc/free pair (confirmed via -S assembly output:
  ! `movabsq $malloc,%rax ... call *%rax` at entry, `movabsq
  ! $free,%rax ... jmp *%rax` at exit) when MSG is a CHARACTER(LEN=*)
  ! dummy argument, even though every actual argument at every call
  ! site is a compile-time string literal. This is a DIFFERENT
  ! mechanism from CALL-BRIDGE-SPEC.md section 4's TRIM/
  ! LEN_TRIM/component-assignment findings (those are intrinsic calls;
  ! this is gfortran's general strategy for "automatic" arrays whose
  ! size is a dummy-argument expression, unconditional on how that
  ! expression resolves at any specific call site) -- the compiler
  ! does not appear to attempt per-call-site constant-size
  ! specialization for an internal CONTAINS procedure with multiple
  ! call sites of differing literal length, even though each
  ! individual call site's length IS a compile-time constant. Fix:
  ! never dimension a local array from LEN(dummy-arg); use a fixed
  ! maximum-size buffer instead, exactly as VGA_PRINT_BANNER already
  ! does below with its own fixed LINE1(45)/LINE2(45) declarations.
  SUBROUTINE SAY(MSG)
    CHARACTER(LEN=*), INTENT(IN) :: MSG
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(SAY_BUF_MAX)
    INTEGER :: N
    N = LEN(MSG)
    IF (N > SAY_BUF_MAX) N = SAY_BUF_MAX   ! truncate rather than overrun
    CALL FILL_STR(BUF(1:N), MSG(1:N))
    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SAY

  SUBROUTINE VGA_PRINT_BANNER()
    CHARACTER(LEN=1, KIND=C_CHAR) :: LINE1(45)
    CHARACTER(LEN=1, KIND=C_CHAR) :: LINE2(45)
    INTEGER(C_INT16_T) :: ATTR_OK

    ! "fort0-kernel :: stage 0 :: long mode reached" one char at a
    ! time -- no string literal length-mismatch surprises, no // .
    CALL FILL_STR(LINE1, "fort0-kernel :: stage 0 :: long mode reached")
    CALL FILL_STR(LINE2, "100% Fortran above the boot stub. Ring 0.    ")

    ATTR_OK = INT(Z'0A00', C_INT16_T)   ! bright green on black

    CALL VGA_PUTS_AT(1_C_INT32_T, 2_C_INT32_T, LINE1, 45_C_INT32_T, ATTR_OK)
    CALL VGA_PUTS_AT(3_C_INT32_T, 2_C_INT32_T, LINE2, 45_C_INT32_T, ATTR_OK)
  END SUBROUTINE VGA_PRINT_BANNER

  ! Element-wise literal-to-array copy -- CALL-BRIDGE-SPEC.md section 4
  ! precedent: never assign a runtime CHARACTER value with = or //,
  ! always DO-loop element by element. Here S is a compile-time literal
  ! actual argument, which that same document's own precedent notes
  ! IS constant-folded safely by gfortran -- but this project follows
  ! the blanket safe-default rule (element-wise always) rather than
  ! relying on the literal-folding exception per file, since re-
  ! verifying the exception with nm for every call site is more work
  ! than just never needing to.
  SUBROUTINE FILL_STR(DEST, S)
    CHARACTER(LEN=1, KIND=C_CHAR), INTENT(OUT) :: DEST(:)
    CHARACTER(LEN=*), INTENT(IN) :: S
    INTEGER :: I
    DO I = 1, SIZE(DEST)
      DEST(I) = S(I:I)
    END DO
  END SUBROUTINE FILL_STR

  ! SAY_HEX(PREFIX, VAL) -- prints PREFIX followed by VAL as
  ! zero-padded hex. Exists specifically to keep TRIGGER_DIVIDE_BY_ZERO's
  ! RESULT observably live (see that subroutine's header comment) --
  ! not a general-purpose logging facility this file otherwise needs,
  ! which is why it stays local here rather than being promoted to
  ! SERIAL or a shared module; promote it if a second, unrelated call
  ! site for hex-printing a value shows up later.
  !
  ! DOES NOT CALL FILL_STR, DELIBERATELY: an earlier version of this
  ! routine called FILL_STR(BUF(1:PLEN), PREFIX(1:PLEN)) and hit a
  ! real build failure -- gfortran's -O2 constant-propagation cloned
  ! FILL_STR for this specific call site (visible in the emitted
  ! assembly as `fill_str.1.constprop.0`) and, in that clone
  ! specifically, replaced the element-wise DO-loop body with a real
  ! `call memcpy` (confirmed via -S output), even though the identical
  ! loop shape at every OTHER call site in this codebase (VGA_PRINT_
  ! BANNER's fixed-size LINE1/LINE2, interrupts.f90's APPEND_LIT) does
  ! not trigger this. Narrowed down to being specific to this exact
  ! call site's combination of factors (a runtime-clamped substring
  ! length feeding an assumed-shape dummy argument, in a routine also
  ! called from a fault-reporting path the optimizer may be
  ! specializing around) but NOT reproduced in isolation in a smaller
  ! probe, meaning the precise trigger condition remains unconfirmed --
  ! recorded here as "avoid, not solved" rather than claiming a root
  ! cause this project cannot actually demonstrate. Fix: this
  ! subroutine copies PREFIX's characters directly, inline, never
  ! calling through FILL_STR at all, sidestepping whatever specific
  ! combination triggered the optimizer's recognition rather than
  ! chasing it further.
  SUBROUTINE SAY_HEX(PREFIX, VAL)
    CHARACTER(LEN=*), INTENT(IN) :: PREFIX
    INTEGER(C_INT64_T), INTENT(IN) :: VAL
    CHARACTER(LEN=1, KIND=C_CHAR) :: BUF(80)
    CHARACTER(LEN=16), PARAMETER :: HEXDIGITS = "0123456789abcdef"
    INTEGER :: N, I, PLEN, SHIFT_AMT
    INTEGER(C_INT64_T) :: NIBBLE

    PLEN = LEN(PREFIX)
    IF (PLEN > 60) PLEN = 60
    DO I = 1, PLEN
      BUF(I) = PREFIX(I:I)
    END DO
    N = PLEN

    N = N + 1
    BUF(N) = '0'
    N = N + 1
    BUF(N) = 'x'
    DO I = 15, 0, -1
      SHIFT_AMT = I * 4
      NIBBLE = IAND(ISHFT(VAL, -SHIFT_AMT), INT(Z'F', C_INT64_T))
      N = N + 1
      BUF(N) = HEXDIGITS(INT(NIBBLE) + 1 : INT(NIBBLE) + 1)
    END DO

    CALL SERIAL_PUTS_NL(BUF, INT(N, C_INT32_T))
  END SUBROUTINE SAY_HEX

END SUBROUTINE KERNEL_MAIN
