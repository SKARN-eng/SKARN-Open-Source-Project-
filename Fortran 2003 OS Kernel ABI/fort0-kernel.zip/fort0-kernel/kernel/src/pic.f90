! pic.f90 -- 8259 Programmable Interrupt Controller: remap and control.
!
! WHY THIS IS NOT OPTIONAL, AND WHY IT MUST HAPPEN BEFORE STI: the
! legacy 8259 pair's power-on-default vector mapping sends IRQ0-7 to
! CPU vectors 8-15 and IRQ8-15 to vectors 0x70-0x77. Vectors 8-15
! overlap directly with several CPU-reserved exception vectors this
! project's IDT already uses (8 = #DF double fault, 10 = #TS, 11 =
! #NP, 12 = #SS, 13 = #GP, 14 = #PF) -- if interrupts were ever
! enabled without remapping first, an ordinary timer tick would be
! indistinguishable from a double fault to the CPU, and this
! project's own exception handler (interrupts.f90) would report every
! timer tick as a fatal double fault and halt the machine within
! milliseconds of enabling interrupts. This is a well-known, standard
! reason every x86 kernel remaps the PIC before the first STI, not a
! fort0-kernel-specific design choice -- documented here because
! RING0-BRIDGE-SPEC.md's discipline is to explain WHY, not just WHAT,
! for every piece of privileged setup.
MODULE PIC
  USE ISO_C_BINDING
  USE RING0
  IMPLICIT NONE

  INTEGER(C_INT16_T), PARAMETER :: PIC1_CMD  = INT(Z'0020', C_INT16_T)
  INTEGER(C_INT16_T), PARAMETER :: PIC1_DATA = INT(Z'0021', C_INT16_T)
  INTEGER(C_INT16_T), PARAMETER :: PIC2_CMD  = INT(Z'00A0', C_INT16_T)
  INTEGER(C_INT16_T), PARAMETER :: PIC2_DATA = INT(Z'00A1', C_INT16_T)

  INTEGER(C_INT8_T), PARAMETER :: ICW1_INIT = INT(Z'11', C_INT8_T)
  ! 0x11: ICW1_INIT | ICW1_ICW4 -- start initialization sequence,
  ! signal that ICW4 will be sent (needed for 8086/8088 mode, which
  ! is what every mode this project cares about descends from).

  INTEGER(C_INT8_T), PARAMETER :: ICW4_8086 = INT(Z'01', C_INT8_T)

  ! Remap targets: IRQ0-7 -> vectors 32-39, IRQ8-15 -> vectors 40-47.
  ! 32 is the conventional first-available vector after the CPU's
  ! reserved 0-31 range -- not a hardware requirement, a software
  ! convention this project follows because deviating from it buys
  ! nothing and every reference OS/kernel doc assumes it.
  INTEGER(C_INT8_T), PARAMETER :: PIC1_OFFSET = 32_C_INT8_T
  INTEGER(C_INT8_T), PARAMETER :: PIC2_OFFSET = 40_C_INT8_T

  INTEGER(C_INT8_T), PARAMETER :: PIC_EOI = INT(Z'20', C_INT8_T)

CONTAINS

  ! PIC_REMAP() -- standard 8259 initialization sequence (4 command
  ! words, ICW1-ICW4, to each PIC) moving IRQ0-15 to vectors 32-47.
  ! Must be called before FORT0K_STI() anywhere in this codebase, and
  ! is, in kernel_main.f90's boot sequence -- see this module's header
  ! comment for why the ordering is not merely a style preference.
  SUBROUTINE PIC_REMAP() BIND(C, NAME="pic_remap")
    INTEGER(C_INT8_T) :: MASK1, MASK2

    ! Save current interrupt masks (both PICs start fully masked from
    ! boot.s's initial CLI + this project never having touched them,
    ! but saving and restoring the actual value rather than assuming
    ! "all masked" is more robust to a future change earlier in boot
    ! that might unmask something before PIC_REMAP runs).
    MASK1 = FORT0K_INB(PIC1_DATA)
    MASK2 = FORT0K_INB(PIC2_DATA)

    CALL FORT0K_OUTB(PIC1_CMD, ICW1_INIT)
    CALL FORT0K_OUTB(PIC2_CMD, ICW1_INIT)

    CALL FORT0K_OUTB(PIC1_DATA, PIC1_OFFSET)   ! ICW2: vector offset
    CALL FORT0K_OUTB(PIC2_DATA, PIC2_OFFSET)

    CALL FORT0K_OUTB(PIC1_DATA, 4_C_INT8_T)    ! ICW3: PIC1 has a
                                                ! slave on IRQ2
                                                ! (bit 2 = 0x04)
    CALL FORT0K_OUTB(PIC2_DATA, 2_C_INT8_T)    ! ICW3: PIC2's own
                                                ! cascade identity
                                                ! is IRQ2 (value 2)

    CALL FORT0K_OUTB(PIC1_DATA, ICW4_8086)     ! ICW4
    CALL FORT0K_OUTB(PIC2_DATA, ICW4_8086)

    CALL FORT0K_OUTB(PIC1_DATA, MASK1)         ! restore masks
    CALL FORT0K_OUTB(PIC2_DATA, MASK2)
  END SUBROUTINE PIC_REMAP

  ! PIC_SEND_EOI(IRQ) -- must be called at the end of every IRQ
  ! handler (interrupts.f90's dispatch, for vectors >= 32), or the PIC
  ! will never signal any further interrupt on that line (and, for
  ! IRQ8-15, on any PIC1 line either, since PIC1 also needs an EOI
  ! when the interrupt came via its cascaded PIC2 slave connection).
  SUBROUTINE PIC_SEND_EOI(IRQ) BIND(C, NAME="pic_send_eoi")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: IRQ
    IF (IRQ >= 8) THEN
      CALL FORT0K_OUTB(PIC2_CMD, PIC_EOI)
    END IF
    CALL FORT0K_OUTB(PIC1_CMD, PIC_EOI)
  END SUBROUTINE PIC_SEND_EOI

  ! PIC_SET_MASK(IRQ, MASKED) -- enables (MASKED=.FALSE.) or disables
  ! (MASKED=.TRUE.) one IRQ line. Every line starts masked after
  ! PIC_REMAP (inherits whatever mask was saved/restored above, which
  ! for a fresh boot is "everything masked" -- the 8259's own power-on
  ! default) -- kernel_main.f90 unmasks specific lines (timer,
  ! keyboard) explicitly once their handlers are ready, rather than
  ! this module unmasking anything itself, keeping "which IRQs are
  ! live" a decision made where the handlers are wired up, not buried
  ! in PIC setup.
  SUBROUTINE PIC_SET_MASK(IRQ, MASKED) BIND(C, NAME="pic_set_mask")
    INTEGER(C_INT32_T), INTENT(IN), VALUE :: IRQ
    LOGICAL(C_BOOL), INTENT(IN), VALUE :: MASKED
    INTEGER(C_INT16_T) :: PORT
    INTEGER(C_INT32_T) :: BIT_IRQ
    INTEGER(C_INT8_T) :: CUR

    IF (IRQ < 8) THEN
      PORT = PIC1_DATA
      BIT_IRQ = IRQ
    ELSE
      PORT = PIC2_DATA
      BIT_IRQ = IRQ - 8
    END IF

    CUR = FORT0K_INB(PORT)
    IF (MASKED) THEN
      CUR = INT(IOR(INT(CUR), ISHFT(1, BIT_IRQ)), C_INT8_T)
    ELSE
      CUR = INT(IAND(INT(CUR), NOT(ISHFT(1, BIT_IRQ))), C_INT8_T)
    END IF
    CALL FORT0K_OUTB(PORT, CUR)
  END SUBROUTINE PIC_SET_MASK

END MODULE PIC
