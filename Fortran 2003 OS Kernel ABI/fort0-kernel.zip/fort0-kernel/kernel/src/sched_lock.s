# sched_lock.s -- a basic spinlock: fort0k_spin_lock(lock_addr) /
# fort0k_spin_unlock(lock_addr).
#
# WHY THIS EXISTS NOW, NOT SOONER: every shared, concurrently-mutated
# structure in this codebase before now (AP_STARTED_FLAGS in smp.f90,
# the PMM bitmap during SMP bring-up) was written by exactly one core
# at a time, BY DESIGN -- smp.f90's wake sequence deliberately
# serializes waking cores one at a time specifically so no concurrent-
# write protection was needed yet (see that file's header comment).
# The scheduler's ready queue (sched.f90's READY_QUEUE/READY_QUEUE_
# HEAD/_TAIL/_COUNT) is different: once more than one core is
# actually running scheduled tasks and calling SCHED_YIELD
# independently, two cores can call SCHED_ENQUEUE/SCHED_DEQUEUE at
# genuinely the same moment, with no serialization forcing one to
# wait for the other. This is this project's first real need for a
# hardware-level mutual-exclusion primitive, not a convenience.
#
# MECHANISM: `xchg` with a memory operand is ARCHITECTURALLY GUARANTEED
# ATOMIC on x86 with no explicit `lock` prefix needed (Intel SDM) --
# confirmed via a direct probe this session that GNU as accepts and
# correctly encodes a bare `xchg %eax, (%rdi)` (no `lock` prefix
# present in the encoding, none needed). This is the simplest correct
# spin-acquire primitive: swap 1 into the lock word and read back
# what was there atomically; if it was already 1, someone else holds
# the lock and we spin; if it was 0, we just acquired it.
#
# 32-BIT LOCK WORD, NOT 8-BIT OR 64-BIT: chosen because `xchg` with a
# 32-bit register operand is the most standard/conventional width for
# this idiom in x86-64 kernel code generally, and because a 32-bit
# INTEGER(C_INT32_T) is a completely ordinary Fortran type this
# project already uses everywhere (no new KIND needed on the Fortran
# side) -- not chosen for any specific atomicity-width requirement,
# since xchg is atomic at every operand width the instruction supports.

    .text
    .globl fort0k_spin_lock
    .type fort0k_spin_lock, @function
fort0k_spin_lock:
    # lock_addr arrives in %rdi (VALUE, per RING0-BRIDGE-SPEC.md
    # section 6's confirmed plain-SysV convention for BIND(C)+VALUE
    # calls).
1:
    mov $1, %eax
    xchg %eax, (%rdi)
    test %eax, %eax
    jnz 2f          # was already 1 (locked) -- go spin-wait
    ret             # was 0 (unlocked) -- we now hold it, done
2:
    # PAUSE: an x86 hint instruction telling the CPU this is a spin-
    # wait loop, improving performance on hyper-threaded cores and
    # reducing power/memory-bus traffic during the spin -- has no
    # correctness effect either way (a plain `jmp 1b` without `pause`
    # would still be correct, just less efficient) -- included because
    # it costs nothing and is the standard idiom every reference
    # spinlock implementation uses for exactly this reason.
    pause
    mov (%rdi), %eax
    test %eax, %eax
    jnz 2b          # still locked -- keep spinning without re-
                     # attempting the xchg every iteration (cheaper:
                     # a plain read doesn't force cache-line
                     # ownership traffic the way xchg would on every
                     # single spin iteration)
    jmp 1b          # looked unlocked -- try the real atomic acquire
                     # again (the plain read above is only a hint,
                     # not itself a safe acquire -- another core could
                     # win the race between that read and this retry,
                     # which is fine: the retry's xchg is what
                     # actually decides ownership correctly regardless)
    .size fort0k_spin_lock, .-fort0k_spin_lock

    .globl fort0k_spin_unlock
    .type fort0k_spin_unlock, @function
fort0k_spin_unlock:
    movl $0, (%rdi)
    ret
    .size fort0k_spin_unlock, .-fort0k_spin_unlock

    .section .note.GNU-stack,"",@progbits
