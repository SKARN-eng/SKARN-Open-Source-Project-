# boot.s -- Multiboot2 entry point and 32-to-64-bit long mode transition.
#
# GRUB2 (or any Multiboot2-compliant loader) loads this ELF, verifies
# the header below, and jumps to _start in 32-bit protected mode with:
#   %eax = 0x36d76289 (Multiboot2 magic)
#   %ebx = physical address of the Multiboot2 info structure
# per the Multiboot2 spec. Nothing about this state is Fortran-callable
# yet -- no long mode, no stack guaranteed usable by gfortran's
# assumptions, no GDT of this project's own choosing. This file's job
# ends the moment it can `call` into a BIND(C) Fortran subroutine with
# all of that satisfied; see RING0-BRIDGE-SPEC.md section 2.
#
# Stage 0 scope: identity-mapped first 1GiB via a single 1GiB huge page
# (PDPE.PS=1), not a real virtual memory layout. RING0-BRIDGE-SPEC.md
# section 2 flags this as a deliberate later-stage concern, not an
# oversight -- a working long-mode jump into Fortran is stage 0's only
# goal, and paging complexity beyond "make long mode legal" would only
# obscure whether that goal was met.

    .code32
    .section .multiboot2, "a"
    .align 8
mb2_header_start:
    .long 0xe85250d6                      # Multiboot2 magic
    .long 0                               # architecture: 0 = i386/x86
    .long mb2_header_end - mb2_header_start   # header length
    .long -(0xe85250d6 + 0 + (mb2_header_end - mb2_header_start)) # checksum

    # end tag (required, type=0 size=8)
    .align 8
    .word 0    # type
    .word 0    # flags
    .long 8    # size
mb2_header_end:

# ---------------------------------------------------------------------
    .section .bss, "aw", @nobits
    .align 4096
# Four page tables: PML4 -> PDPT -> PD, each 4096 bytes, 512 entries of
# 8 bytes. Stage 0 uses PDPE.PS=1 (1GiB pages) so no PT level is built
# at all -- one PML4 entry, one PDPT entry, done. Covers the first
# 1GiB of physical address space, ample for stage 0/1's needs (kernel
# image, boot info, VGA buffer at 0xB8000 all fall well inside it).
pml4:
    .skip 4096
pdpt:
    .skip 4096

boot_stack_bottom:
    .skip 16384                # 16KiB boot stack -- generous for a
                                # 32-bit stub plus the Fortran entry's
                                # own prologue; sized down later if
                                # profiling ever justifies it
boot_stack_top:

    .section .data
    .align 8
gdt64:
    .quad 0                                    # null descriptor
gdt64_code:
    .quad 0x00AF9A000000FFFF   # 64-bit code: present, ring0, exec/read,
                                # L-bit (long mode) set, limit ignored
                                # in 64-bit mode
gdt64_data:
    .quad 0x00AF92000000FFFF   # 64-bit data: present, ring0, read/write
gdt64_end:
gdt64_ptr:
    .word gdt64_end - gdt64 - 1
    .quad gdt64

    .section .text
    .code32
    .globl _start
    .type _start, @function
_start:
    cli                        # no IDT exists yet; nothing may interrupt
                                # this sequence until stage 1 builds one
    mov $boot_stack_top, %esp
    mov %esp, %ebp

    # Multiboot2 loader guarantees do NOT include "stack is usable
    # long-term" or "%eax/%ebx survive past the first instruction we
    # choose to clobber them with" -- stash both immediately, before
    # any other work, mirroring fort0's start.s stashing argc/argv/envp
    # before its own first `call`.
    mov %eax, mb2_magic
    mov %ebx, mb2_info_ptr

    cmp $0x36d76289, %eax
    jne halt_forever            # wrong magic -- not actually a
                                 # Multiboot2 boot; nowhere safe to go

    # --- Build minimal identity-mapped page tables for long mode ---
    # PML4[0] -> pdpt, present+writable
    mov $pdpt, %eax
    or $0x03, %eax               # present | writable
    mov $pml4, %edi
    mov %eax, (%edi)

    # PDPT[0] -> 1GiB page covering physical 0x00000000-0x3FFFFFFF,
    # present+writable+PS(huge page)
    mov $0x00000083, %eax        # present | writable | page-size(1GiB)
    mov $pdpt, %edi
    mov %eax, (%edi)

    # --- Enable PAE (required for long mode) ---
    mov %cr4, %eax
    or $0x20, %eax                # CR4.PAE
    mov %eax, %cr4

    # --- Load PML4 into CR3 ---
    mov $pml4, %eax
    mov %eax, %cr3

    # --- Set EFER.LME (long mode enable) ---
    mov $0xC0000080, %ecx         # IA32_EFER MSR
    rdmsr
    or $0x100, %eax               # EFER.LME
    wrmsr

    # --- Enable paging (CR0.PG) -- this actually enters long mode,
    # specifically "compatibility mode" until a far jump loads a
    # 64-bit code segment below ---
    mov %cr0, %eax
    or $0x80000000, %eax          # CR0.PG
    mov %eax, %cr0

    # --- Load the 64-bit GDT and far-jump into 64-bit code ---
    lgdt gdt64_ptr
    ljmp $0x08, $long_mode_entry  # 0x08 = gdt64_code selector

halt_forever:
    hlt
    jmp halt_forever
    .size _start, .-_start

    .code64
    .type long_mode_entry, @function
long_mode_entry:
    mov $0x10, %ax                # 0x10 = gdt64_data selector
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss

    mov $boot_stack_top, %rsp     # SysV ABI guarantees Fortran's
                                   # codegen wants %rsp 16-byte aligned
                                   # before `call` -- boot_stack_top is
                                   # page-aligned (see .bss above), so
                                   # this holds without further
                                   # adjustment; re-verify if the stack
                                   # layout above ever changes
    mov %rsp, %rbp
    xor %rbp, %rbp                 # mark outermost frame, matching
                                    # fort0's start.s convention

    # --- FPU/SSE initialization ---
    # RING0-BRIDGE-SPEC.md section 1: gfortran can emit SSE
    # instructions (movaps/movdqa, confirmed via a real triple fault
    # this project hit and logged) even in code this project did not
    # ask to use floating point, via auto-vectorization of ordinary
    # integer array fills at -O2. The kernel-mode Fortran build now
    # also passes -mno-sse -mno-sse2 as a permanent belt-and-suspenders
    # measure (see that section), but this initialization is done
    # regardless -- Fortran's actual floating-point arithmetic will
    # want working SSE eventually, and CR0/CR4 not reflecting reality
    # is a landmine independent of whether any specific translation
    # unit currently happens to avoid emitting SSE.
    mov %cr0, %rax
    and $0xFFFFFFFB, %eax          # clear CR0.EM (bit 2)
    or $0x00000002, %eax           # set CR0.MP (bit 1)
    mov %rax, %cr0

    mov %cr4, %rax
    or $0x00000600, %eax           # set CR4.OSFXSR (bit 9) and
                                    # CR4.OSXMMEXCPT (bit 10)
    mov %rax, %cr4

    # BUG FOUND AND FIXED THIS SESSION, before it ever caused a real
    # fault (unlike the AP-SSE gap in ap_trampoline.s, found only
    # AFTER a real triple fault -- this one was caught by checking
    # before writing any real floating-point code, prompted by that
    # earlier incident): the x87 FPU itself was never initialized via
    # fninit anywhere in this project. CR0.EM/CR0.MP/CR4.OSFXSR above
    # only govern whether SSE/x87 instructions are ALLOWED to execute
    # without faulting -- they say nothing about the FPU's own
    # internal state (control word, status word, tag word), which is
    # architecturally undefined-but-typically-benign after power-on,
    # not guaranteed safe. Confirmed via web search this session that
    # every reference source checked (the Linux kernel's own
    # arch/x86/kernel/fpu/init.c, the OSDev wiki's FPU page, a
    # standard x86 assembly tutorial) treats fninit as a required
    # step before the first real x87 floating-point instruction,
    # specifically to avoid inconsistent/undefined FPU state -- not
    # merely a defensive nicety. gfortran DOES emit real x87
    # instructions (fld/fmul/faddp, confirmed via a direct probe this
    # session) for REAL(C_DOUBLE) arithmetic under this project's
    # -mno-sse baseline (falls back to the legacy x87 stack rather
    # than SSE registers when SSE is disabled), so this gap was
    # genuinely reachable the moment any kernel-mode Fortran code
    # used floating point, not merely a theoretical concern.
    fninit

    # Pass the saved Multiboot2 info pointer to Fortran as this
    # project's only boot-time argument.
    #
    # BUG FOUND AND FIXED THIS SESSION: this comment previously
    # claimed kernel_main's dummy argument uses gfortran's default
    # by-reference convention (justifying `mov $mb2_info_ptr, %rdi` --
    # passing the ADDRESS of the storage word) -- but kernel_main.f90
    # actually declares MB2_INFO_ADDR as BIND(C) with the VALUE
    # attribute, which RING0-BRIDGE-SPEC.md section 6 confirmed uses
    # PLAIN SYSV C ABI (the value itself in the register, not its
    # address) -- the exact same distinction that section documents
    # for ring0.s's own primitives, which this comment failed to
    # apply to kernel_main's own signature. The mismatch meant
    # MB2_INFO_ADDR inside Fortran received the ADDRESS of
    # mb2_info_ptr (a boot.s .bss location) instead of the Multiboot2
    # info structure's real address -- confirmed via a real, reproduced
    # bug: MB2_FIND_MEMORY_MAP read plausible-looking but wrong data
    # from the wrong location and never found the memory map tag.
    # Fixed: load the VALUE from mb2_info_ptr into %rdi, not its
    # address.
    mov mb2_info_ptr(%rip), %rdi
    call kernel_main

    # Should never return; if it does, halt rather than run off into
    # undefined memory.
    cli
halt_forever_64:
    hlt
    jmp halt_forever_64
    .size long_mode_entry, .-long_mode_entry

    .section .bss
    .align 8
mb2_magic:
    .skip 4
    .align 8
mb2_info_ptr:
    .skip 8

    .section .note.GNU-stack,"",@progbits
