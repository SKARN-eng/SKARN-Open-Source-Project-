/* SPDX-License-Identifier: MIT */
/* cudez.h -- a CUDA Driver API + NVRTC convenience layer, in C99.
 * Boot once, compile kernel strings at runtime, launch, teardown cleanly --
 * a plain C99 front door to the CUDA Driver API and NVRTC.
 *
 * v0.1.0 -- BASE LAYER ONLY. This is deliberately the boring half: context
 * setup, runtime compilation, memory, streams, kernel launch, and CUDA
 * Graph capture/replay. No tensor-core wrappers, no game logic, no
 * convenience macros beyond what any CUDA host program needs. That is
 * on purpose -- a probe-driven capability layer belongs ON TOP of a
 * working base, not tangled into it. A future higher-level layer
 * (wmma / mma.sync / mma.sp wrappers) is the natural next step and is
 * out of scope here.
 *
 * WHY THIS DOESN'T NEED TO PROBE FOR CAPABILITY
 * The Driver API is NVIDIA's own first-class, documented, stable C
 * interface, and NVRTC is NVIDIA's own first-class runtime compiler.
 * Nothing in this header is a trick. Everything here is exactly as
 * supported as CUDA itself, which means real capability queries
 * (cuDeviceGetAttribute) exist and are used directly rather than
 * inferred by probing.
 *
 * REQUIRES
 *   <cuda.h>   the CUDA Driver API (link -lcuda)
 *   <nvrtc.h>  the NVRTC runtime compiler (link -lnvrtc)
 *   A C99 compiler. No C++ required anywhere in the host program -- kernel
 *   STRINGS may use CUDA C++ (templates, wmma::, etc); NVRTC compiles them
 *   to PTX before your C99 host code ever sees them.
 *
 * USAGE
 *   #include "cudez.h"
 *   cudez cz = cudez_boot(0, NULL);              // device ordinal 0
 *   const char *src =
 *     "extern \"C\" __global__ void addk(float *a, const float *b, int n) {\n"
 *     "  int i = blockIdx.x * blockDim.x + threadIdx.x;\n"
 *     "  if (i < n) a[i] += b[i];\n"
 *     "}\n";
 *   cudez_program p = cudez_build(&cz, src, "add.cu", NULL, 0);
 *   cudez_kernel  k = cudez_kernel_get(&p, "addk");
 *   cudez_buffer  A = cudez_buffer_write(&cz, hostA, bytes);
 *   cudez_buffer  B = cudez_buffer_write(&cz, hostB, bytes);
 *   void *args[] = { &A.ptr, &B.ptr, &n };
 *   cudez_launch1d(&cz, k, n, 256, args);
 *   cudez_read(&cz, A, hostA, bytes);
 *   cudez_teardown(&cz);
 *
 * NOTE ON extern "C". Kernel strings are compiled by NVRTC as CUDA C++,
 * which name-mangles __global__ functions like any other C++ function.
 * Wrap kernel definitions in extern "C" { ... } (as above) so
 * cuModuleGetFunction can find them by their plain name; otherwise you
 * must look up the mangled name yourself (nvrtcGetLoweredName, not
 * wrapped here -- name-expression handling is a front-end concern, left
 * for a future layer or your own code to add if you need C++ template
 * kernels).
 *
 * WHAT THIS BASE LAYER GIVES YOU
 *   - cudez_boot / cudez_teardown: context lifecycle, one default stream,
 *     a registry of everything this layer allocated so teardown is total.
 *   - cudez_build / cudez_try_build: NVRTC source -> PTX -> loaded CUmodule,
 *     with the compile log surfaced on failure.
 *   - cudez_kernel_get: CUmodule + name -> CUfunction.
 *   - cudez_buffer_new / _write / _read / _free: device memory, sync H2D/D2H.
 *   - cudez_launch1d / cudez_launch: kernel launch, 1D convenience or full
 *     3D grid/block control.
 *   - cudez_graph_begin / _end / _launch: CUDA Graph capture and replay --
 *     record a stream's sequence of launches once, replay it every frame
 *     with a single cuGraphLaunch instead of re-dispatching each kernel.
 *     This is the piece most relevant to a game loop: capture one tick's
 *     kernel sequence during warm-up, then replay it every subsequent tick.
 *
 * WHAT THIS BASE LAYER DOES NOT GIVE YOU (by design, not oversight)
 *   - No tensor-core / wmma / mma.sync / mma.sp wrappers of any kind.
 *   - No graphics interop (registering a GL/Vulkan buffer for CUDA to
 *     write into directly) -- a real API surface with real synchronization
 *     edge cases, deliberately left for a later, separately-verified layer.
 *   - No multi-GPU, no peer access, no unified memory helpers.
 *   - No cuBLAS/cuSPARSE/cuSPARSELt linkage -- those are separate shared
 *     libraries with their own linking story, not header-only.
 *   - No C++ name-expression / template-kernel lookup (see the extern "C"
 *     note above).
 *
 * CONTROL SURFACE (define before including)
 *   CUDEZ_LOG_FILE     FILE* to print build failures and warnings to.
 *                      Defaults to stderr.
 *   CUDEZ_ALLOC/FREE   Host allocator pair. Defaults to malloc/free.
 *   CUDEZ_NO_ABORT     If defined, the aborting *_boot/_build convenience
 *                      wrappers become no-ops on failure (return a
 *                      zeroed struct) instead of calling abort(). The
 *                      non-aborting cudez_try_* forms are always available
 *                      regardless of this flag and are the recommended
 *                      way to handle errors in real applications.
 *                      1.1.0 (AUDIT-8) -- READ THIS BEFORE RELYING ON IT:
 *                      this is a PARTIAL opt-out, not "nothing aborts."
 *                      It covers only the boot/build-shaped convenience
 *                      wrappers. buffer_new/_write, _read, launch, finish,
 *                      and the graph_* calls go through CUDEZ_CHECK
 *                      unconditionally and still abort on failure. If no
 *                      code path in your process may abort, use ONLY the
 *                      cudez_try_* forms. Collapsing the dozen hand-rolled
 *                      abort wrappers into one macro (so this flag can
 *                      honestly cover everything) is queued -- see the
 *                      1.2.0 roadmap.
 *
 * VERIFIED, AND ON WHAT (v0.1.0, honestly -- updated with real-NVRTC results)
 *   Every Driver API and NVRTC function signature referenced here was
 *   checked against NVIDIA's current published documentation while this
 *   header was written (docs.nvidia.com/cuda/cuda-driver-api,
 *   docs.nvidia.com/cuda/nvrtc). The host-side logic (registry bookkeeping,
 *   error formatting, the build/launch/graph control flow) was compiled
 *   and exercised against a STUB cuda.h/nvrtc.h that reproduces those
 *   signatures, since there is no NVIDIA GPU or CUDA driver in the
 *   environment that produced this file.
 *   The NVRTC-BACKED BUILD PATH SPECIFICALLY has since been upgraded to
 *   genuine confirmation: real libnvrtc.so (CUDA 12.9, obtained via the
 *   nvidia-cuda-nvrtc-cu12 wheel -- NVRTC is a pure host-side compiler,
 *   no GPU or driver needed to run it) compiled the exact extern "C"
 *   kernel string from Section usage example, produced real PTX, and the
 *   PTX confirmed the exported symbol is the plain name "addk" -- the
 *   extern "C" advice above is not a guess, it is checked. As a control,
 *   the same kernel WITHOUT extern "C" was compiled and its symbol came
 *   back mangled as "_Z4addkPfPKfi" (Itanium ABI), confirming the failure
 *   mode extern "C" avoids is real. Separately: real NVRTC on CUDA 12.9
 *   still accepts --gpu-architecture=compute_70 through compute_90, but
 *   emits, verbatim, "Architectures prior to '<compute/sm>_75' are
 *   deprecated and may be removed in a future release" for compute_70 --
 *   worth knowing if a future layer ever targets Volta through this
 *   base.
 *   STILL NOT verified: cuInit, context creation, device memory, kernel
 *   launch, and CUDA Graphs -- everything that requires an actual GPU and
 *   driver, which this environment does not have. Swap in the real
 *   <cuda.h>, link -lcuda, and re-run the full flow on real hardware
 *   before trusting anything past the compile step.
 *
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 * VERSION: see CUDEZ_VERSION_MAJOR/MINOR/PATCH below -- the macros are the
 * single version truth (audit-2 landmine 2; historical banners below record
 * the 0.x ladder and are deliberately preserved as provenance). MIT.
 * A correctness + input-sanitization pass over
 * the 0.6.0 strided-batched-GEMM path -- no new kernels, no new features, just
 * closing the silent-failure gaps that a batched GEMM opens up. Highlights:
 *   CORRECTNESS
 *   (1) 64-BIT STRIDES. strideA/B/C/D in cudez_mma_args and in the generated
 *       dense-float kernel signature widen from int to long long, and the packed
 *       defaults (M*K, K*N, M*N) are now computed in long long on the host. In
 *       0.6.0 a large-enough hidden-dim x sequence GEMM overflowed the 32-bit
 *       stride ON THE HOST before it ever reached the kernel's 64-bit promotion;
 *       the value was already wrong. tiles/blocks in the launcher likewise widen
 *       from long to long long (long is 32-bit on LLP64/Windows) and the grid-x
 *       extent is range-checked against the gridDim.x limit before the cast.
 *   (2) NEGATIVE STRIDES REJECTED. 0.6.0's `stride > 0 ? stride : packed` treated
 *       "unset (0)" and "typo'd negative" identically, silently substituting the
 *       packed default for a mistake. Only exactly 0 now means "use default"; a
 *       negative stride returns CUDA_ERROR_INVALID_VALUE naming the offender.
 *   INPUT SANITIZATION (no more silent no-ops -- the one thing worth eliminating)
 *   (3) broadcast_mask and an explicit nonzero stride for the same operand used
 *       to silently let the mask win. That combination is now a loud
 *       CUDA_ERROR_INVALID_VALUE: pick one mechanism. Named CUDEZ_BROADCAST_A/B/C
 *       constants replace bare bit magic, and any mask bit outside them (notably
 *       an attempt to broadcast D, which cannot be expressed) is rejected too.
 *   (4) A zero-initialized config that skipped cudez_mma_defaults (k_chunks==0)
 *       no longer emits `#pragma unroll(0)`: k_chunks<=0 is validated at build
 *       and the generators omit the pragma entirely (plain loop) as a backstop.
 *   (5) The launch-argument array is sized from a named CUDEZ_MAX_LAUNCH_ARGS and
 *       asserted, so a future signature that outgrows it fails loudly.
 *   ERGONOMICS / TESTS
 *   (6) cudez_mma_args_batched(M,N,K,batch_count): one-call fill for the common
 *       "packed, no broadcast" batched case, mirroring cudez_mma_defaults'/
 *       cudez_gemm's one-call ergonomics.
 *   (7) The single-GEMM (batch_count<=1, no strides/mask) launch skips the
 *       stride-resolution/broadcast work entirely -- pure host-side, no behavior
 *       or signature change (the kernel is still the one 13-arg batched kernel).
 *   smoke_mma_gpu.c gains batched BF16 + TF32 diffs (0.6.0 only diffed batched
 *   F16, so "batched dense verified" was an overclaim for BF16/TF32), a cache-
 *   identity check (batch_count is a launch arg, never part of the cache key),
 *   and host-side arithmetic checks for the stride widening / negative-stride
 *   rejection that need no GPU. DEFERRED (documented, not silently dropped): M/N/K
 *   themselves stay `int` this release -- widening them to size_t touches every
 *   dtype path and needs its own on-device regression pass, so it is a separate
 *   0.8.0 decision rather than a rider on the stride fix. Everything the 0.6.0
 *   note below states about kernels, sparse status, and verification remains
 *   accurate; 0.7.0 changes only the dense-float launch/marshalling path (plus
 *   the shared build-time k_chunks guard) and the host struct.
 * ----------------------------------------------------------------------------
 * VERSION 0.6.0. MIT. Builds on the 0.5.0 kernel surface.
 * Headline: MEMORY & BATCHING. Three additions, all host-side C except the
 * batched kernel, and all shipping with cudez_try_* forms:
 *   (1) DEVICE ARENA / BATCH ALLOCATOR -- one cuMemAlloc, bump-allocated
 *       windows (cudez_arena, cudez_buffer_batch). Replaces the per-tile
 *       cuMemAlloc's compounding cost (per-alloc padding, address fragmentation,
 *       registry churn, serialized driver calls) with one allocation and one
 *       registry entry. Cohort-lifetime: reset/destroy frees the whole arena,
 *       never one window.
 *   (2) PINNED HOST POOL -- the host mirror of the arena (cudez_host_pool over
 *       cuMemHostAlloc), with cudez_pool_write_async/_read_async staging pageable
 *       data through a pinned window into an async copy. Pays the slow pinned
 *       alloc once.
 *   (3) STRIDED BATCHED GEMM (dense F16/BF16/TF32) -- one launch computes many
 *       same-shape GEMMs via gridDim.z; blockIdx.z selects the element, offset
 *       by per-operand strides in ELEMENTS (0 stride broadcasts a shared operand
 *       across the batch). This is LAUNCH-overhead amortization for many small
 *       GEMMs (attention heads, MoE experts), NOT new per-GEMM efficiency --
 *       every warp still streams its own tiles from global memory.
 * Also: reentrant cudez_strerror_r + single-write cudez_log_ remove the shared-
 * static-buffer aliasing the old cudez_strerror had when two error strings hit
 * one printf. *** BREAKING (pre-1.0): the generated dense-FLOAT kernel signature
 * gained 4 stride ints; cudez_try_mma_launch marshals them, so only code that
 * hand-launches cudez_mma_source() output must update. *** The batched kernel
 * compiles under NVRTC and assembles under ptxas, but its NUMERICAL correctness
 * (like all generated kernels here) is gated on the on-device diff in
 * smoke_mma_gpu.c -- run it on the Ampere+ card. 0.6.0 changes NOTHING about the
 * 0.5.0 sparse status: the 2:4 metadata bit-layout is still awaiting that same
 * on-device confirmation. The 0.5.0 and 0.4.0 notes below remain accurate.
 * ----------------------------------------------------------------------------
 * VERSION 0.5.0. MIT. Builds on the 0.4.0 stable control surface.
 * Headline: 2:4 STRUCTURED SPARSITY is now a REAL kernel, not a skeleton --
 * compressed-A load + dense-B load + per-lane metadata + plain mma.sp + output
 * scatter, launchable through cudez_try_mma_launch, with cudez_mma_compress_2to4
 * producing the compressed values and metadata. Also new: cudez_gemm(), a
 * one-call dense GEMM for float dtypes. Every generated kernel (dense F16/BF16/
 * TF32, dense INT8/INT4, and now 2:4 sparse F16/BF16) compiles under real NVRTC
 * 12.9 and assembles under real ptxas (sm_80/sm_86). The sparse VALUES path is
 * exact; the sparse METADATA bit-layout is implemented to the PTX ISA spec but
 * is the one piece still awaiting on-device numerical confirmation -- run
 * smoke_mma_gpu.c on an Ampere+ card (it now includes a 2:4 diff) to confirm or
 * localize a fix. sm_90+ needs mma.sp::ordered_metadata (tracked follow-up).
 * The 0.4.0 notes below remain accurate for the dense control surface.
 * ----------------------------------------------------------------------------
 *
 * VERSION 0.4.0 -- STABLE CONTROL SURFACE. MIT.
 * The historical notes above describe how the base layer (0.1.x) and the MMA
 * layer (0.2.x/0.3.x) were brought up in stages; they remain accurate as
 * history. What is new in 0.4.0 is a reworked, smaller PUBLIC INTERFACE built
 * for day-to-day use, plus the fixes found in the 0.3.1 real-tools pass:
 *
 *   NEW ergonomics (the parts you actually touch):
 *     - cudez_mma_defaults(dtype): a correctly-shaped config in one call, so
 *       you never memorize which tile goes with which dtype.
 *     - cudez_mma_supported(cz, dtype, sparse): a capability predicate, so you
 *       can branch on the device (e.g. INT8 on Ampere, F16 fallback on Volta)
 *       BEFORE building.
 *     - cudez_try_mma_launch(cz, mm, &args): fills grid/block from the tile
 *       shape and marshals kernel arguments in the right order for the dtype
 *       and requant mode. This removes the single biggest 0.3.x footgun --
 *       hand-computing the launch geometry and argument array.
 *
 *   FIXES folded in from the 0.3.1 verification pass:
 *     - warps_per_block LEFT the config struct: it is launch geometry, not
 *       kernel identity. In 0.3.x it sat in the byte-compared cache key while
 *       never affecting generated code, silently defeating the cache (the same
 *       bug k_chunks had). cudez_mma_config is now a pure identity key.
 *     - Dense TF32 now applies wmma::__float_to_tf32 to each loaded fragment
 *       element, matching NVIDIA's documented TF32 WMMA pattern (0.3.x omitted
 *       it, leaving the truncation unperformed).
 *     - Dense K-loop now requires K %% WK == 0 and iterates K/WK, instead of a
 *       ceil-div that silently dropped the final ragged K-tile. Same explicit
 *       M/N/K contract the INT8/INT4 path already states; enforced by
 *       cudez_try_mma_launch.
 *
 *   VERIFICATION BOUNDARY (unchanged honesty standard): every generated INT8/
 *   INT4 variant compiles under real NVRTC 12.9 and assembles under real ptxas
 *   (sm_80..sm_120); the per-lane fragment layout matches the PTX ISA tables
 *   as enumerated from CUTLASS CuTe. What is still NOT done in-tree is a
 *   NUMERICAL diff on real tensor cores. That step needs a GPU; the shipped
 *   harness (smoke_mma_gpu.c) performs exactly that diff and is the thing to
 *   run once, per architecture, to turn "assembles" into "correct."
 * ----------------------------------------------------------------------------
 */
#ifndef CUDEZ_H
#define CUDEZ_H

#include <cuda.h>
#include <nvrtc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>

#define CUDEZ_VERSION_MAJOR 1
#define CUDEZ_VERSION_MINOR 0
#define CUDEZ_VERSION_PATCH 3

#if defined(__cplusplus)
# define CUDEZ_INLINE static inline
#elif defined(__GNUC__) || defined(__clang__)
# define CUDEZ_INLINE static __inline__ __attribute__((unused))
#else
# define CUDEZ_INLINE static
#endif

#ifndef CUDEZ_ALLOC
# define CUDEZ_ALLOC(n) malloc(n)
# define CUDEZ_FREE(p)  free(p)
#endif

#ifndef CUDEZ_LOG_FILE
# define CUDEZ_LOG_FILE stderr
#endif

/* Upper bound on the kernel-argument pointer array cudez_try_mma_launch builds.
   The widest current signature (dense batched: A,B,C,D,M,N,K,sA,sB,sC,sD,alpha,
   beta) uses 13 slots; this leaves headroom and is asserted at each launch so a
   future dtype/parameter addition that pushes past it fails loudly instead of
   scribbling past the array (0.7.0, BUG-6). */
#ifndef CUDEZ_MAX_LAUNCH_ARGS
# define CUDEZ_MAX_LAUNCH_ARGS 16
#endif

/* broadcast_mask bit values for cudez_mma_args (0.7.0, UX-3). Only A/B/C can be
   broadcast; there is deliberately NO D bit -- broadcasting the output would make
   every batch element write the same tile, so D-broadcast is not expressible.
   cudez_try_mma_launch rejects any mask bit outside these three. */
#define CUDEZ_BROADCAST_A 1u
#define CUDEZ_BROADCAST_B 2u
#define CUDEZ_BROADCAST_C 4u
#define CUDEZ_BROADCAST_ALL (CUDEZ_BROADCAST_A | CUDEZ_BROADCAST_B | CUDEZ_BROADCAST_C)

/* ============================================================================
 * ERROR HANDLING
 * ========================================================================== */

/* Human-readable CUresult text: cuGetErrorName + cuGetErrorString, joined.
   cudez_strerror_r writes into a CALLER buffer -- reentrant, thread-safe, and
   free of the aliasing hazard a shared static buffer has when two error strings
   appear in one printf (e.g. a batch reporting several CUresults). Prefer it in
   new code. cudez_strerror is kept for source compatibility and is thread-local
   where the compiler supports it. */
#if defined(__cplusplus) && __cplusplus >= 201103L
# define CUDEZ_TLS thread_local
#elif defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L
# define CUDEZ_TLS _Thread_local
#elif defined(__GNUC__) || defined(__clang__)
# define CUDEZ_TLS __thread          /* available under -std=c99 on gcc/clang */
#else
# define CUDEZ_TLS
#endif

CUDEZ_INLINE char *cudez_strerror_r(CUresult err, char *buf, size_t n) {
    const char *name = NULL, *desc = NULL;
    cuGetErrorName(err, &name);
    cuGetErrorString(err, &desc);
    snprintf(buf, n, "%s: %s",
             name ? name : "CUDA_ERROR_UNKNOWN",
             desc ? desc : "(no description available)");
    return buf;
}

CUDEZ_INLINE const char *cudez_strerror(CUresult err) {
    static CUDEZ_TLS char buf[256];
    return cudez_strerror_r(err, buf, sizeof buf);
}

#if defined(__GNUC__) || defined(__clang__)
# define CUDEZ_PRINTF_FMT_ __attribute__((format(printf, 1, 2)))
#else
# define CUDEZ_PRINTF_FMT_
#endif

/* One formatted record -> one write. stderr is unbuffered by default, so a
   single fputs keeps a log record intact even when threads log concurrently,
   and avoids the stdout/stderr interleave piecemeal fprintf can produce. */
CUDEZ_INLINE void cudez_log_(const char *fmt, ...) CUDEZ_PRINTF_FMT_;
CUDEZ_INLINE void cudez_log_(const char *fmt, ...) {
    char line[512];
    va_list ap;
    int m;
    va_start(ap, fmt);
    m = vsnprintf(line, sizeof line, fmt, ap);
    va_end(ap);
    if (m < 0) return;
    fputs(line, CUDEZ_LOG_FILE);
}

CUDEZ_INLINE const char *cudez_nvrtc_strerror(nvrtcResult err) {
    return nvrtcGetErrorString(err);
}

#define CUDEZ_CHECK(err) do { \
    CUresult cudez_e_ = (err); \
    if (cudez_e_ != CUDA_SUCCESS) { \
        cudez_log_("cudez: CUDA error at %s:%d: %s\n", \
                __FILE__, __LINE__, cudez_strerror(cudez_e_)); \
        abort(); \
    } \
} while (0)

/* ============================================================================
 * REGISTRY -- everything cudez_boot's context owns, freed in one call
 * ========================================================================== */

typedef struct {
    CUdeviceptr *ptrs;   size_t n_ptrs,   cap_ptrs;
    CUmodule    *mods;   size_t n_mods,   cap_mods;
    CUstream    *streams;size_t n_streams,cap_streams;
    CUevent     *events; size_t n_events, cap_events;
    CUdeviceptr *arenas;    size_t n_arenas,    cap_arenas;    /* 0.6.0 device arenas */
    void       **host_ptrs; size_t n_host_ptrs, cap_host_ptrs; /* 0.6.0 pinned pools  */
} cudez_registry_;

/* Grows a registry array via the configurable allocator (CUDEZ_ALLOC/FREE),
   not raw realloc, so an overridden allocator stays consistent. Returns 1 on
   success, 0 if the allocation failed -- callers MUST NOT append on 0 (state
   is left unchanged, so nothing is corrupted; the resource simply isn't tracked
   for bulk teardown, which is the honest OOM degradation rather than a crash). */
CUDEZ_INLINE int cudez_reg_grow_(void **arr, size_t *n, size_t *cap, size_t elemsz) {
    void *nu; size_t newcap;
    if (*n < *cap) return 1;
    newcap = *cap ? *cap * 2 : 8;
    nu = CUDEZ_ALLOC(newcap * elemsz);
    if (!nu) {
        cudez_log_("cudez: registry growth failed (%lu bytes) -- "
                "resource will not be auto-tracked for teardown\n",
                (unsigned long)(newcap * elemsz));
        return 0;
    }
    if (*arr && *n) memcpy(nu, *arr, *n * elemsz);
    if (*arr) CUDEZ_FREE(*arr);
    *arr = nu; *cap = newcap;
    return 1;
}

/* ============================================================================
 * THE CONTEXT HANDLE
 * ========================================================================== */

typedef struct {
    CUdevice  device;
    CUcontext context;
    CUstream  stream;      /* default stream this layer launches on */
    int       cc_major, cc_minor;
    char      name[256];
    unsigned long long boot_gen; /* 1.0.3: monotonic boot counter, see
        cudez_mma_cache's doc comment -- distinguishes "same CUcontext
        pointer value" from "same actual context," since the driver API
        does not guarantee a destroyed context's handle value is never
        reused by a later cuCtxCreate. */
    cudez_registry_ reg_;
} cudez;

/* 1.0.3: monotonic boot counter, incremented once per successful
   cudez_try_boot. CUDEZ_INLINE is unconditionally `static` (see its
   #define above), so -- like every function in this header -- this has
   internal linkage and its local `counter_` is one instance PER
   TRANSLATION UNIT, not truly process-wide. That is the right scope here,
   not a limitation: cudez_mma_cache itself is equally per-TU (see
   cudez_gemm's own `static cache_` below), so a counter sharing that same
   granularity is exactly what a cache instance needs to distinguish "same
   CUcontext pointer value" from "same actual context" within its own
   visibility. Deliberately not thread-safe, matching this header's
   single-threaded setup/teardown model (CUDEZ.md Sec.9). */
CUDEZ_INLINE unsigned long long cudez_next_boot_gen_(void) {
    static unsigned long long counter_ = 0;
    return ++counter_;
}

/* Non-aborting boot. dev_ordinal selects among cuDeviceGetCount() devices;
   -1 (or any negative) means "device 0". flags is reserved (pass 0). */
CUDEZ_INLINE CUresult cudez_try_boot(cudez *out, int dev_ordinal, unsigned int flags) {
    CUresult err;
    int count = 0;
    memset(out, 0, sizeof *out);
    (void)flags;

    err = cuInit(0);
    if (err != CUDA_SUCCESS) { memset(out, 0, sizeof *out); return err; }

    err = cuDeviceGetCount(&count);
    if (err != CUDA_SUCCESS) { memset(out, 0, sizeof *out); return err; }
    if (count == 0) return CUDA_ERROR_NO_DEVICE;

    /* 1.1.0 (AUDIT-2): the clamp used to be SILENT -- requesting device 3
       on a 1-GPU box quietly booted device 0, and on a multi-GPU box could
       quietly route work to the wrong physical GPU (wrong power envelope,
       wrong PCIe topology). Behavior is preserved (clamp, don't fail) but
       it is now loud. */
    {
        int requested = dev_ordinal;
        if (dev_ordinal < 0) dev_ordinal = 0;
        if (dev_ordinal >= count) dev_ordinal = count - 1;
        if (dev_ordinal != requested)
            cudez_log_("cudez_boot: device ordinal %d out of range [0,%d) -- "
                       "CLAMPED to %d; pass a valid ordinal to silence this\n",
                       requested, count, dev_ordinal);
    }

    err = cuDeviceGet(&out->device, dev_ordinal);
    if (err != CUDA_SUCCESS) { memset(out, 0, sizeof *out); return err; }

    {
        CUresult name_err = cuDeviceGetName(out->name, (int)sizeof out->name, out->device);
        if (name_err != CUDA_SUCCESS) {
            /* Cosmetic only (cz->name feeds cudez_print_device and error strings,
               nothing safety-relevant) -- loud but non-fatal. Leave the buffer
               visibly empty rather than whatever cuDeviceGetName left it as. */
            out->name[0] = '\0';
            cudez_log_("cudez_boot: cuDeviceGetName failed (%s) -- device name "
                       "will read as empty; boot continues\n",
                       cudez_strerror(name_err));
        }
    }
    {
        CUresult cc_err = cuDeviceGetAttribute(&out->cc_major,
            CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, out->device);
        if (cc_err == CUDA_SUCCESS)
            cc_err = cuDeviceGetAttribute(&out->cc_minor,
                CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, out->device);
        if (cc_err != CUDA_SUCCESS) {
            /* NOT cosmetic: cc_major/cc_minor gate every architecture check in
               cudez_mma_cfg_valid_, including the sm_90+ sparse refusal that
               exists because cudez emits the wrong mma.sp form there. A silent
               failure here would leave cc=0, under which that refusal's
               `cc >= 90` test can never fire on a real sm_90+ device --
               fail boot rather than hand back a cudez that will pass sparse
               configs cudez_mma_cfg_valid_ exists specifically to reject. */
            cudez_log_("cudez_boot: cuDeviceGetAttribute(compute capability) "
                       "failed (%s) -- refusing to boot, since architecture "
                       "gating (incl. the sm_90+ sparse refusal) depends on "
                       "a real cc_major/cc_minor\n", cudez_strerror(cc_err));
            memset(out, 0, sizeof *out);
            return cc_err;
        }
    }

    err = cuCtxCreate(&out->context, CU_CTX_SCHED_AUTO, out->device);
    if (err != CUDA_SUCCESS) { memset(out, 0, sizeof *out); return err; }
    out->boot_gen = cudez_next_boot_gen_();

    err = cuStreamCreate(&out->stream, CU_STREAM_DEFAULT);
    if (err != CUDA_SUCCESS) {
        cuCtxDestroy(out->context);
        memset(out, 0, sizeof *out);   /* Landmine-1 (1.0.2): the doc promises a
            ZEROED struct on failure; leaving the destroyed context populated
            let a CUDEZ_NO_ABORT caller double-destroy it in teardown. */
        return err;
    }

    return CUDA_SUCCESS;
}

/* Aborting convenience form, for callers who want a boot-or-die path. */
CUDEZ_INLINE cudez cudez_boot(int dev_ordinal, unsigned int flags) {
    cudez cz;
    CUresult err = cudez_try_boot(&cz, dev_ordinal, flags);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_boot: %s\n", cudez_strerror(err));
        abort();
    }
#else
    (void)err;
#endif
    return cz;
}

CUDEZ_INLINE void cudez_print_device(const cudez *cz) {
    cudez_log_("cudez device: %s (sm_%d%d)\n",
            cz->name, cz->cc_major, cz->cc_minor);
}

/* Frees every buffer, module, stream, and event this cudez allocated
   (via the *_new/_write/_build/etc. calls below), then the default
   stream and context. Safe to call on a partially-booted struct.

   Synchronizes cz->context before freeing anything (1.0.3, deferred-item
   fix): cuMemFree/cuModuleUnload/cuStreamDestroy/cuCtxDestroy do not by
   themselves guarantee that async work still in flight on cz->stream or
   on a caller-created stream in reg_.streams has finished -- the driver
   API places that burden on the caller (cuCtxDestroy's own doc: "It is
   the responsibility of the calling function to ensure that no API call
   issues using ctx while cuCtxDestroy() is executing"). Without this, a
   teardown that races a pending cudez_launch or async H2D/D2H copy frees
   or unmaps memory the GPU is still reading/writing -- silent corruption
   or a driver-level fault, and worse, non-deterministic (races only show
   up under load/timing that differs from whatever the caller tested).
   cuCtxSynchronize() only drains the CURRENT context, so this makes
   cz->context current first rather than assuming this thread's context
   stack still matches it -- cheap (a push/pop) and turns a silent wrong-
   context sync into a defined no-op-if-already-current on the documented
   single-threaded setup/teardown usage model (see CUDEZ.md Sec.9). */
CUDEZ_INLINE void cudez_teardown(cudez *cz) {
    size_t i;
    CUcontext prev_ctx_ = NULL;
    int switched_ctx_ = 0;
    if (!cz) return;
    if (cz->context) {
        cuCtxGetCurrent(&prev_ctx_);
        if (prev_ctx_ != cz->context) {
            cuCtxSetCurrent(cz->context);
            switched_ctx_ = 1;
        }
        /* Drain every stream in THIS context (default + reg_.streams) before
           any free/unload/destroy below touches their memory or modules. */
        cuCtxSynchronize();
    }
    for (i = 0; i < cz->reg_.n_ptrs; i++) cuMemFree(cz->reg_.ptrs[i]);
    for (i = 0; i < cz->reg_.n_arenas; i++) cuMemFree(cz->reg_.arenas[i]);
    for (i = 0; i < cz->reg_.n_host_ptrs; i++) cuMemFreeHost(cz->reg_.host_ptrs[i]);
    for (i = 0; i < cz->reg_.n_mods; i++) cuModuleUnload(cz->reg_.mods[i]);
    for (i = 0; i < cz->reg_.n_events; i++) cuEventDestroy(cz->reg_.events[i]);
    for (i = 0; i < cz->reg_.n_streams; i++) cuStreamDestroy(cz->reg_.streams[i]);
    CUDEZ_FREE(cz->reg_.ptrs); CUDEZ_FREE(cz->reg_.mods);
    CUDEZ_FREE(cz->reg_.streams); CUDEZ_FREE(cz->reg_.events);
    CUDEZ_FREE(cz->reg_.arenas); CUDEZ_FREE(cz->reg_.host_ptrs);
    if (cz->stream)  cuStreamDestroy(cz->stream);
    if (cz->context) cuCtxDestroy(cz->context);
    /* Restore the caller's own current context, if teardown changed it and
       that context is still someone else's live context (not the one we
       just destroyed -- restoring a destroyed context would just fail). */
    if (switched_ctx_ && prev_ctx_ != NULL && prev_ctx_ != cz->context)
        cuCtxSetCurrent(prev_ctx_);
    memset(cz, 0, sizeof *cz);
}

/* ============================================================================
 * NVRTC-BACKED BUILD -- source string -> PTX -> loaded CUmodule
 * ========================================================================== */

typedef struct {
    const cudez *owner;
    CUmodule module;
} cudez_program;

/* Non-aborting build. opts/nopts are NVRTC compile options, e.g.
   {"--gpu-architecture=compute_80"}; pass NULL/0 to let NVRTC pick a
   default target for the current device (recent NVRTC versions support
   this; older ones require an explicit --gpu-architecture). On failure,
   the NVRTC compile log is printed to CUDEZ_LOG_FILE before returning. */
CUDEZ_INLINE CUresult cudez_try_build(const cudez *cz, const char *src,
                                      const char *prog_name,
                                      const char * const *opts, int nopts,
                                      cudez_program *out) {
    nvrtcProgram prog;
    nvrtcResult nres;
    CUresult err = CUDA_SUCCESS;
    size_t ptx_size;
    char *ptx;

    out->owner = cz; out->module = NULL;
    if (!src) return CUDA_ERROR_INVALID_VALUE;

    nres = nvrtcCreateProgram(&prog, src, prog_name ? prog_name : "cudez_program.cu",
                              0, NULL, NULL);
    if (nres != NVRTC_SUCCESS) {
        cudez_log_("cudez: nvrtcCreateProgram failed: %s\n",
                cudez_nvrtc_strerror(nres));
        return CUDA_ERROR_INVALID_VALUE;
    }

    nres = nvrtcCompileProgram(prog, nopts, opts);
    if (nres != NVRTC_SUCCESS) {
        size_t log_size = 0;
        nvrtcGetProgramLogSize(prog, &log_size);
        if (log_size > 1) {
            char *log = (char *)CUDEZ_ALLOC(log_size);
            if (log) {
                nvrtcGetProgramLog(prog, log);
                fprintf(CUDEZ_LOG_FILE, "cudez: NVRTC compile failed:\n%s\n", log);
                CUDEZ_FREE(log);
            }
        } else {
            cudez_log_("cudez: NVRTC compile failed: %s (no log)\n",
                    cudez_nvrtc_strerror(nres));
        }
        nvrtcDestroyProgram(&prog);
        return CUDA_ERROR_INVALID_VALUE;
    }

    nres = nvrtcGetPTXSize(prog, &ptx_size);
    if (nres != NVRTC_SUCCESS) { nvrtcDestroyProgram(&prog); return CUDA_ERROR_INVALID_VALUE; }
    ptx = (char *)CUDEZ_ALLOC(ptx_size);
    if (!ptx) { nvrtcDestroyProgram(&prog); return CUDA_ERROR_OUT_OF_MEMORY; }
    nvrtcGetPTX(prog, ptx);
    nvrtcDestroyProgram(&prog);

    err = cuModuleLoadDataEx(&out->module, ptx, 0, NULL, NULL);
    CUDEZ_FREE(ptx);
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez: cuModuleLoadDataEx failed: %s\n", cudez_strerror(err));
        return err;
    }

    {
        cudez_registry_ *r = (cudez_registry_ *)&cz->reg_;
        if (cudez_reg_grow_((void **)&r->mods, &r->n_mods, &r->cap_mods, sizeof(CUmodule)))
            r->mods[r->n_mods++] = out->module;
    }
    return CUDA_SUCCESS;
}

CUDEZ_INLINE cudez_program cudez_build(const cudez *cz, const char *src,
                                       const char *prog_name,
                                       const char * const *opts, int nopts) {
    cudez_program p;
    CUresult err = cudez_try_build(cz, src, prog_name, opts, nopts, &p);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) abort();
#else
    (void)err;
#endif
    return p;
}

typedef struct { CUfunction fn; } cudez_kernel;

/* Raw CUfunction lookup by name from an already-compiled cudez_program.
   NOTE if you use this to hand-construct a cudez_mma_kernel (instead of
   going through cudez_try_mma_build, which does this for you): for
   smem_stage 7 or 8 configs, YOU are responsible for calling
   cuFuncSetAttribute(out->fn, CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES,
   cudez_mma_dyn_smem_(cfg)) yourself before first launch (1.0.3: this used
   to happen automatically inside cudez_mma_launch on every launch; it is
   now hoisted into cudez_try_mma_build as a one-time build-time step, so a
   hand-built kernel that skips cudez_try_mma_build no longer gets it for
   free). Skipping it fails loudly at cuLaunchKernel, not silently. */
CUDEZ_INLINE CUresult cudez_try_kernel_get(const cudez_program *p, const char *name,
                                           cudez_kernel *out) {
    out->fn = NULL;
    return cuModuleGetFunction(&out->fn, p->module, name);
}

CUDEZ_INLINE cudez_kernel cudez_kernel_get(const cudez_program *p, const char *name) {
    cudez_kernel k;
    CUresult err = cuModuleGetFunction(&k.fn, p->module, name);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_kernel_get(\"%s\"): %s\n", name, cudez_strerror(err));
        abort();
    }
#else
    (void)err;
#endif
    return k;
}

/* ============================================================================
 * DEVICE MEMORY
 * ========================================================================== */

typedef struct { CUdeviceptr ptr; size_t size; } cudez_buffer;

/* Returns a zero buffer ({0,0}) for bytes==0 (1.0.3, deferred item) instead
   of calling cuMemAlloc(&ptr, 0), which the driver documents as always
   returning CUDA_ERROR_INVALID_VALUE -- CUDEZ_CHECK turned that into an
   unconditional abort() with just the bare driver error string, no mention
   that the actual cause was a zero-byte request. That's a bad failure mode
   for what's often an upstream size calculation landing on 0 (e.g. an M*K
   that came out 0), not a driver problem. Mirrors cudez_arena_alloc, which
   already treats bytes==0 as a legitimate empty-buffer case and returns
   {0,0} without touching the driver; cudez_buffer_new calls cuMemAlloc
   directly so it never got the same treatment. Check .ptr before using the
   result, same convention as cudez_arena_alloc's doc comment. */
CUDEZ_INLINE cudez_buffer cudez_buffer_new(const cudez *cz, size_t bytes) {
    cudez_buffer b; b.ptr = 0; b.size = 0;
    if (bytes == 0) {
        cudez_log_("cudez_buffer_new: bytes=0 -- returning an empty buffer "
                   "(ptr=0, size=0) rather than calling cuMemAlloc, which "
                   "the driver refuses for a zero-byte request\n");
        return b;
    }
    b.size = bytes;
    CUDEZ_CHECK(cuMemAlloc(&b.ptr, bytes));
    {
        cudez_registry_ *r = (cudez_registry_ *)&cz->reg_;
        if (cudez_reg_grow_((void **)&r->ptrs, &r->n_ptrs, &r->cap_ptrs, sizeof(CUdeviceptr)))
            r->ptrs[r->n_ptrs++] = b.ptr;
    }
    return b;
}

/* Allocate + synchronous host->device copy in one call. bytes==0 returns the
   empty buffer from cudez_buffer_new above and skips the copy (a zero-byte
   cuMemcpyHtoD against a null device pointer is not a case worth relying on
   undocumented driver behavior for). */
CUDEZ_INLINE cudez_buffer cudez_buffer_write(const cudez *cz, const void *host, size_t bytes) {
    cudez_buffer b = cudez_buffer_new(cz, bytes);
    if (bytes == 0) return b;
    CUDEZ_CHECK(cuMemcpyHtoD(b.ptr, host, bytes));
    return b;
}

CUDEZ_INLINE void cudez_read(const cudez *cz, cudez_buffer b, void *host, size_t bytes) {
    (void)cz;
    if (!b.ptr && bytes) {
        cudez_log_("cudez_read: bytes=%zu requested from an empty "
                "buffer (ptr=0) -- refusing rather than copy from a null "
                "device pointer\n", bytes);
        return;
    }
    if (b.size && bytes > b.size) {
        cudez_log_("cudez_read: bytes=%zu exceeds buffer size=%zu -- "
                "refusing out-of-bounds device copy\n", bytes, b.size);
        return;
    }
    CUDEZ_CHECK(cuMemcpyDtoH(host, b.ptr, bytes));
}

/* Async variants on the context's default stream; caller must cudez_finish
   (or otherwise synchronize) before touching host after a read, or before
   host must not be reused before a write completes. */
CUDEZ_INLINE void cudez_write_async(const cudez *cz, cudez_buffer b, const void *host, size_t bytes) {
    if (!b.ptr && bytes) {
        cudez_log_("cudez_write_async: bytes=%zu requested into an "
                "empty buffer (ptr=0) -- refusing rather than copy into a null "
                "device pointer\n", bytes);
        return;
    }
    if (b.size && bytes > b.size) {
        cudez_log_("cudez_write_async: bytes=%zu exceeds buffer size=%zu "
                "-- refusing out-of-bounds device copy\n", bytes, b.size);
        return;
    }
    CUDEZ_CHECK(cuMemcpyHtoDAsync(b.ptr, host, bytes, cz->stream));
}
CUDEZ_INLINE void cudez_read_async(const cudez *cz, cudez_buffer b, void *host, size_t bytes) {
    if (!b.ptr && bytes) {
        cudez_log_("cudez_read_async: bytes=%zu requested from an "
                "empty buffer (ptr=0) -- refusing rather than copy from a null "
                "device pointer\n", bytes);
        return;
    }
    if (b.size && bytes > b.size) {
        cudez_log_("cudez_read_async: bytes=%zu exceeds buffer size=%zu "
                "-- refusing out-of-bounds device copy\n", bytes, b.size);
        return;
    }
    CUDEZ_CHECK(cuMemcpyDtoHAsync(host, b.ptr, bytes, cz->stream));
}

/* Buffers are normally freed in bulk by cudez_teardown; this is for
   freeing one early. Removes it from the registry so teardown does not
   double-free. O(n) in current buffer count -- fine for setup/teardown
   code, not meant for a hot per-frame path. */
CUDEZ_INLINE void cudez_buffer_free(cudez *cz, cudez_buffer b) {
    size_t i;
    cudez_registry_ *r = &cz->reg_;
    for (i = 0; i < r->n_ptrs; i++) {
        if (r->ptrs[i] == b.ptr) {
            cuMemFree(b.ptr);
            r->ptrs[i] = r->ptrs[--r->n_ptrs];
            return;
        }
    }
}


/* ============================================================================
 * BATCH / ARENA ALLOCATION (0.6.0)
 *
 * The selective path above (cudez_buffer_new/_write) is one cuMemAlloc per
 * tile. For many tiles that COMPOUNDS: each alloc rounds up to the driver's
 * ~256 B granularity (padding paid n times), fragments the address space into
 * n holes, adds n registry entries (with repeated geometric-growth memcpy
 * churn), and serializes n synchronous driver calls. An arena replaces all of
 * that with ONE cuMemAlloc and bump-allocated windows: padding is paid once at
 * the tail, the address space stays contiguous, the registry gains ONE entry,
 * allocation is one driver call. It is also the substrate the batched GEMM
 * below rides on (a batch's A/B/C/D in one allocation, reset once per step).
 *
 * The arena suits COHORT-LIFETIME buffers -- allocated together, freed together
 * (a layer's weights, a batch's operands). It deliberately cannot free one
 * tile; a workload with mixed lifetimes wants several arenas or the (roadmap)
 * stream-ordered pool backend.
 *
 * OWNERSHIP: a sub-view is a WINDOW, not a separate allocation. Do NOT pass it
 * to cudez_buffer_free -- it is released by cudez_arena_reset (rewind) or
 * cudez_arena_destroy, or at teardown. Arenas live in a DEDICATED registry list
 * (not ptrs), so cudez_buffer_free never sees them and a zero-offset view can
 * never be mistaken for a standalone buffer.
 * ========================================================================== */

#ifndef CUDEZ_ARENA_ALIGN
# define CUDEZ_ARENA_ALIGN 256   /* matches cuMemAlloc granularity; safe for
                                    128-bit vector loads and ldmatrix staging */
#endif

typedef struct {
    const cudez *owner;
    CUdeviceptr  base;   /* single backing allocation */
    size_t       size;   /* bytes reserved */
    size_t       used;   /* bump offset */
    size_t       align;  /* sub-allocation alignment */
} cudez_arena;

CUDEZ_INLINE size_t cudez_align_up_(size_t x, size_t a) {
    return (a <= 1) ? x : ((x + (a - 1)) / a) * a;
}

CUDEZ_INLINE CUresult cudez_try_arena_create(const cudez *cz, size_t bytes,
                                             size_t align, cudez_arena *out) {
    CUresult err;
    memset(out, 0, sizeof *out);
    out->owner = cz;
    out->align = align ? align : CUDEZ_ARENA_ALIGN;
    if (bytes == 0) return CUDA_ERROR_INVALID_VALUE;
    err = cuMemAlloc(&out->base, bytes);
    if (err != CUDA_SUCCESS) {
        char eb[256];
        cudez_log_("cudez_arena: cuMemAlloc(%lu) failed: %s\n",
                   (unsigned long)bytes, cudez_strerror_r(err, eb, sizeof eb));
        return err;
    }
    out->size = bytes;
    {   /* tracked in the ARENA list; freed at teardown; invisible to
           cudez_buffer_free (see ownership note above). */
        cudez_registry_ *r = (cudez_registry_ *)&cz->reg_;
        if (cudez_reg_grow_((void **)&r->arenas, &r->n_arenas, &r->cap_arenas,
                            sizeof(CUdeviceptr)))
            r->arenas[r->n_arenas++] = out->base;
    }
    return CUDA_SUCCESS;
}

CUDEZ_INLINE cudez_arena cudez_arena_create(const cudez *cz, size_t bytes) {
    cudez_arena ar;
    CUresult err = cudez_try_arena_create(cz, bytes, CUDEZ_ARENA_ALIGN, &ar);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_arena_create: %s\n", cudez_strerror(err));
        abort();
    }
#else
    (void)err;
#endif
    return ar;
}

/* Bump-allocate an aligned window. No device allocation, no registry entry.
   Returns a zero buffer ({0,0}) if the request does not fit -- check .ptr. */
CUDEZ_INLINE cudez_buffer cudez_arena_alloc(cudez_arena *ar, size_t bytes) {
    cudez_buffer b;
    size_t off;
    b.ptr = 0; b.size = 0;
    if (bytes == 0) return b;
    {
        /* Arena-absolute-alignment fix (1.0.3, deferred item): align the
           ABSOLUTE candidate address (ar->base + ar->used), not the
           relative offset alone. cudez_align_up_(ar->used, ar->align) was
           only correct if ar->base itself happened to already be a
           multiple of ar->align -- true for the CUDEZ_ARENA_ALIGN default
           (256) under cuMemAlloc's empirically observed floor, but
           cudez_try_arena_create lets a caller request any align value
           with no upper bound, and cuMemAlloc's OFFICIAL contract never
           actually promises a specific byte alignment ("suitably aligned
           for any kind of variable" is unspecified). A caller asking for
           e.g. 1024-byte alignment could silently get a pointer that
           isn't, if ar->base is not itself a multiple of 1024. */
        CUdeviceptr want = ar->base + (CUdeviceptr)ar->used;
        CUdeviceptr aligned = (CUdeviceptr)cudez_align_up_((size_t)want, ar->align);
        off = (size_t)(aligned - ar->base);
    }
    if (off > ar->size || bytes > ar->size - off) {   /* overflow-safe */
        cudez_log_("cudez_arena: sub-alloc of %lu B exceeds arena "
                   "(%lu used / %lu total)\n", (unsigned long)bytes,
                   (unsigned long)ar->used, (unsigned long)ar->size);
        return b;
    }
    b.ptr  = ar->base + off;
    b.size = bytes;
    ar->used = off + bytes;
    return b;
}

/* Rewind: all outstanding views become invalid; the memory is reused. */
CUDEZ_INLINE void cudez_arena_reset(cudez_arena *ar) { ar->used = 0; }

/* Free the backing allocation early (else teardown does it). */
CUDEZ_INLINE void cudez_arena_destroy(cudez *cz, cudez_arena *ar) {
    size_t i; cudez_registry_ *r;
    if (!ar || !ar->base) return;
    r = &cz->reg_;
    for (i = 0; i < r->n_arenas; i++) {
        if (r->arenas[i] == ar->base) {
            cuMemFree(ar->base);
            r->arenas[i] = r->arenas[--r->n_arenas];
            memset(ar, 0, sizeof *ar);
            return;
        }
    }
}

/* Batch allocate n tiles from ONE backing allocation. Fills out_bufs[0..n) with
   views and hands back the owning arena (for reset/destroy). This is the call
   that circumvents the compounding penalty: n cuMemAllocs become one, and the
   registry gains ONE entry, not n. Zero-sized entries yield a zero buffer. */
CUDEZ_INLINE CUresult cudez_try_buffer_batch(const cudez *cz,
                                             const size_t *bytes, int n,
                                             cudez_arena *out_arena,
                                             cudez_buffer *out_bufs) {
    size_t total = 0, align = CUDEZ_ARENA_ALIGN;
    int i;
    CUresult err;
    if (n <= 0 || !bytes || !out_arena || !out_bufs) return CUDA_ERROR_INVALID_VALUE;
    for (i = 0; i < n; i++) {
        size_t a = cudez_align_up_(bytes[i], align);
        if (a < bytes[i] || total > (size_t)-1 - a) {   /* size_t overflow */
            cudez_log_("cudez_buffer_batch: total size overflows size_t\n");
            return CUDA_ERROR_INVALID_VALUE;
        }
        total += a;
    }
    err = cudez_try_arena_create(cz, total, align, out_arena);
    if (err != CUDA_SUCCESS) return err;
    for (i = 0; i < n; i++) out_bufs[i] = cudez_arena_alloc(out_arena, bytes[i]);
    return CUDA_SUCCESS;
}

/* As cudez_try_buffer_batch, plus a synchronous H2D into each tile whose
   srcs[i] is non-NULL (srcs=NULL allocates only). One arena, one round of
   copies. */
CUDEZ_INLINE CUresult cudez_try_buffer_batch_write(const cudez *cz,
                                                   const size_t *bytes,
                                                   const void *const *srcs, int n,
                                                   cudez_arena *out_arena,
                                                   cudez_buffer *out_bufs) {
    int i;
    CUresult err = cudez_try_buffer_batch(cz, bytes, n, out_arena, out_bufs);
    if (err != CUDA_SUCCESS) return err;
    if (!srcs) return CUDA_SUCCESS;
    for (i = 0; i < n; i++) {
        if (srcs[i] && out_bufs[i].ptr) {
            err = cuMemcpyHtoD(out_bufs[i].ptr, srcs[i], bytes[i]);
            if (err != CUDA_SUCCESS) {
                char eb[256];
                cudez_log_("cudez_buffer_batch_write: H2D tile %d failed: %s\n",
                           i, cudez_strerror_r(err, eb, sizeof eb));
                return err;
            }
        }
    }
    return CUDA_SUCCESS;
}

/* Aborting convenience: returns the arena; out_bufs is filled. */
CUDEZ_INLINE cudez_arena cudez_buffer_batch(const cudez *cz,
                                            const size_t *bytes, int n,
                                            cudez_buffer *out_bufs) {
    cudez_arena ar;
    CUresult err = cudez_try_buffer_batch(cz, bytes, n, &ar, out_bufs);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_buffer_batch: %s\n", cudez_strerror(err));
        abort();
    }
#else
    (void)err;
    if (err != CUDA_SUCCESS) memset(&ar, 0, sizeof ar);
#endif
    return ar;
}

/* ============================================================================
 * PINNED HOST-MEMORY POOL (0.6.0) -- the host-side mirror of the device arena.
 *
 * cuMemHostAlloc (pinned/page-locked host memory) is slow and inconsistent per
 * call and has platform ceilings; the standard fix is to allocate ONE pinned
 * block and sub-allocate from it forever. This is that. It pairs with the async
 * copies: cudez_pool_write_async stages pageable data through a pinned window
 * and enqueues an async H2D, so the slow pinned alloc is paid once at create.
 *
 * Size the pool DELIBERATELY: pinned RAM is non-pageable, so an over-large pool
 * starves the system and is what hits those ceilings -- reserve what a step
 * stages, not the maximum available.
 *
 * LIFETIME (as the arena): a window is a WINDOW; never free it individually; it
 * is released by pool_reset / pool_destroy / teardown. Because the async
 * helpers hand the copy engine a pointer INTO the pool, cudez_finish() (or your
 * own sync) BEFORE reset/reuse -- an in-flight DMA out of a rewound window is a
 * silent data race.
 * ========================================================================== */

#ifndef CUDEZ_HOST_POOL_ALIGN
# define CUDEZ_HOST_POOL_ALIGN 256
#endif

typedef struct {
    const cudez *owner;
    void    *base;
    size_t   size;
    size_t   used;
    size_t   align;
    unsigned flags;   /* CU_MEMHOSTALLOC_* used at create, for reference */
} cudez_host_pool;

CUDEZ_INLINE CUresult cudez_try_host_pool_create(const cudez *cz, size_t bytes,
                                                 unsigned flags, size_t align,
                                                 cudez_host_pool *out) {
    CUresult err;
    memset(out, 0, sizeof *out);
    out->owner = cz;
    out->align = align ? align : CUDEZ_HOST_POOL_ALIGN;
    out->flags = flags;
    if (bytes == 0) return CUDA_ERROR_INVALID_VALUE;
    err = cuMemHostAlloc(&out->base, bytes, flags);
    if (err != CUDA_SUCCESS) {
        char eb[256];
        cudez_log_("cudez_host_pool: cuMemHostAlloc(%lu) failed: %s\n",
                   (unsigned long)bytes, cudez_strerror_r(err, eb, sizeof eb));
        return err;
    }
    out->size = bytes;
    {
        cudez_registry_ *r = (cudez_registry_ *)&cz->reg_;
        if (cudez_reg_grow_((void **)&r->host_ptrs, &r->n_host_ptrs,
                            &r->cap_host_ptrs, sizeof(void *)))
            r->host_ptrs[r->n_host_ptrs++] = out->base;
    }
    return CUDA_SUCCESS;
}

CUDEZ_INLINE cudez_host_pool cudez_host_pool_create(const cudez *cz, size_t bytes) {
    cudez_host_pool p;
    CUresult err = cudez_try_host_pool_create(cz, bytes, 0, CUDEZ_HOST_POOL_ALIGN, &p);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_host_pool_create: %s\n", cudez_strerror(err));
        abort();
    }
#else
    (void)err;
#endif
    return p;
}

/* Bump-allocate an aligned pinned window. Returns NULL if it does not fit,
   if bytes==0, or if the pool itself is NULL (BUGREPORT 1.3.0 SS1: the NULL
   guard must run BEFORE the p->used read -- the callers' log ternaries
   assumed this case was handled, and it was not). Three failure modes,
   all named, per the AUDIT-6 convention. */
CUDEZ_INLINE void *cudez_host_pool_alloc(cudez_host_pool *p, size_t bytes) {
    size_t off;
    if (!p) {
        cudez_log_("cudez_host_pool: sub-alloc of %lu B from a NULL pool "
                   "(create one with cudez_host_pool_create)\n",
                   (unsigned long)bytes);
        return NULL;
    }
    off = cudez_align_up_(p->used, p->align);
    if (bytes == 0) return NULL;
    if (off > p->size || bytes > p->size - off) {
        cudez_log_("cudez_host_pool: sub-alloc of %lu B exceeds pool "
                   "(%lu used / %lu total)\n", (unsigned long)bytes,
                   (unsigned long)p->used, (unsigned long)p->size);
        return NULL;
    }
    p->used = off + bytes;
    return (char *)p->base + off;
}

CUDEZ_INLINE void cudez_host_pool_reset(cudez_host_pool *p) { p->used = 0; }

CUDEZ_INLINE void cudez_host_pool_destroy(cudez *cz, cudez_host_pool *p) {
    size_t i; cudez_registry_ *r;
    if (!p || !p->base) return;
    r = &cz->reg_;
    for (i = 0; i < r->n_host_ptrs; i++) {
        if (r->host_ptrs[i] == p->base) {
            cuMemFreeHost(p->base);
            r->host_ptrs[i] = r->host_ptrs[--r->n_host_ptrs];
            memset(p, 0, sizeof *p);
            return;
        }
    }
}

/* Stage `bytes` from pageable host_src through a pinned window, then async H2D
   into device buffer dst on cz->stream. `dst` may be an arena tile, so a whole
   batch stages through one pool into one arena. Returns the window (keep alive
   until the copy completes; sync before reset) or NULL on failure. */
CUDEZ_INLINE void *cudez_pool_write_async(const cudez *cz, cudez_host_pool *pool,
                                          cudez_buffer dst, const void *host_src,
                                          size_t bytes) {
    void *stage;
    /* 1.1.0 (AUDIT-6): NULL used to mean three different things (bad args,
       pool exhaustion, copy failure) with only the copy failure logged.
       All three are now loud and named; the return contract is unchanged. */
    if (!host_src && bytes) {
        cudez_log_("cudez_pool_write_async: NULL host_src with bytes=%zu\n", bytes);
        return NULL;
    }
    stage = cudez_host_pool_alloc(pool, bytes);
    if (!stage) {
        cudez_log_("cudez_pool_write_async: pinned pool exhausted "
                   "(%zu bytes requested, %zu/%zu used) -- size the pool up "
                   "or reset it after a sync\n", bytes, pool ? pool->used : 0,
                   pool ? pool->size : 0);
        return NULL;
    }
    memcpy(stage, host_src, bytes);
    {
        CUresult err = cuMemcpyHtoDAsync(dst.ptr, stage, bytes, cz->stream);
        if (err != CUDA_SUCCESS) {
            char eb[256];
            cudez_log_("cudez_pool_write_async: H2D failed: %s\n",
                       cudez_strerror_r(err, eb, sizeof eb));
            return NULL;
        }
    }
    return stage;
}

/* Async D2H from src into a pinned window; data is valid there only AFTER a
   sync. Copy it to pageable storage before resetting the pool. */
CUDEZ_INLINE void *cudez_pool_read_async(const cudez *cz, cudez_host_pool *pool,
                                         cudez_buffer src, size_t bytes) {
    void *stage = cudez_host_pool_alloc(pool, bytes);
    if (!stage) {
        /* 1.1.0 (AUDIT-6): named failure, same contract -- see write_async */
        cudez_log_("cudez_pool_read_async: pinned pool exhausted "
                   "(%zu bytes requested, %zu/%zu used) -- size the pool up "
                   "or reset it after a sync\n", bytes, pool ? pool->used : 0,
                   pool ? pool->size : 0);
        return NULL;
    }
    {
        CUresult err = cuMemcpyDtoHAsync(stage, src.ptr, bytes, cz->stream);
        if (err != CUDA_SUCCESS) {
            char eb[256];
            cudez_log_("cudez_pool_read_async: D2H failed: %s\n",
                       cudez_strerror_r(err, eb, sizeof eb));
            return NULL;
        }
    }
    return stage;
}
/* ============================================================================
 * KERNEL LAUNCH
 * ========================================================================== */

/* Full control: explicit 3D grid/block, shared memory, and a target stream
   (pass NULL to use the context's default stream). */
CUDEZ_INLINE void cudez_launch(const cudez *cz, cudez_kernel k,
                               unsigned int gx, unsigned int gy, unsigned int gz,
                               unsigned int bx, unsigned int by, unsigned int bz,
                               unsigned int shmem_bytes, CUstream stream, void **args) {
    CUDEZ_CHECK(cuLaunchKernel(k.fn, gx, gy, gz, bx, by, bz, shmem_bytes,
                               stream ? stream : cz->stream, args, NULL));
}

/* 1D convenience: n work-items, block_size threads per block (grid size
   computed to cover n). Launches on the context's default stream. */
CUDEZ_INLINE void cudez_launch1d(const cudez *cz, cudez_kernel k,
                                 size_t n, unsigned int block_size, void **args) {
    unsigned int grid;
    if (block_size == 0) {
        cudez_log_("cudez_launch1d: block_size==0 (would divide by "
                "zero) -- pass a positive block size\n");
        return;
    }
    {   /* 64-bit so a size_t n above 2^32 does not truncate to too few blocks
           (silently dropping the tail); same gridDim.x ceiling the mma launcher
           enforces. */
        unsigned long long g = ((unsigned long long)n + block_size - 1) / block_size;
        if (g > 2147483647ULL) {
            cudez_log_("cudez_launch1d: grid %llu exceeds the gridDim.x "
                    "limit of 2147483647 (n=%zu, block_size=%u) -- split the launch\n",
                    g, n, block_size);
            return;
        }
        grid = (unsigned int)g;
    }
    cudez_launch(cz, k, grid, 1, 1, block_size, 1, 1, 0, NULL, args);
}

CUDEZ_INLINE void cudez_finish(const cudez *cz) {
    CUDEZ_CHECK(cuStreamSynchronize(cz->stream));
}

/* ============================================================================
 * CUDA GRAPHS -- capture a stream's launch sequence once, replay it cheaply
 *
 * The pattern for a game loop: during warm-up (first tick), call
 * cudez_graph_begin, issue exactly the kernel launches / copies one tick
 * needs on cz->stream (or a stream you pass to cudez_launch's stream
 * argument), then cudez_graph_end. Every subsequent tick calls only
 * cudez_graph_launch -- one driver call replays the whole captured
 * sequence, skipping per-kernel host-side dispatch overhead.
 *
 * CAVEAT: a captured graph's operations (pointers, launch dimensions) are
 * FIXED at capture time. If your per-tick unit count changes, you either
 * capture for a fixed upper bound and mask off unused work, or re-capture
 * -- captured graphs are not a substitute for dynamic control flow.
 *
 * VERSION FLOOR (1.0.3, deferred item, documentation-only): cudez_graph_end
 * calls the CUDA 12+ form of cuGraphInstantiate -- 3 args, a plain
 * `unsigned long long flags` (here always 0). CUDA 11.x's cuGraphInstantiate
 * resolved to the older 5-arg cuGraphInstantiate_v2 instead (phGraphExec,
 * hGraph, phErrorNode, logBuffer, bufferSize) -- building this header
 * against an 11.x toolkit fails the 3-arg call below with a "too few
 * arguments" compiler error. That error is expected, not a cudez bug: this
 * header targets CUDA 12+ (matching the NVRTC 12.9 the rest of the codebase
 * is verified against -- see the top-of-file provenance note). If a future
 * change needs to support 11.x too, that is an #if CUDA_VERSION branch to
 * add here, not a reason to "fix" this call back to the 5-arg form (which
 * would just break every 12+ caller instead).
 * ========================================================================== */

typedef struct { CUgraph graph; CUgraphExec exec; } cudez_graph;

CUDEZ_INLINE void cudez_graph_begin(const cudez *cz) {
    CUDEZ_CHECK(cuStreamBeginCapture(cz->stream, CU_STREAM_CAPTURE_MODE_GLOBAL));
}

/* Ends capture, instantiates an executable graph. Call cudez_graph_launch
   each tick thereafter; call cudez_graph_destroy when done with it
   (independent of cudez_teardown -- graphs are not auto-tracked, since a
   long-lived game loop typically wants explicit control over when its
   one captured graph is torn down and re-captured).
   CUDA 12+ required -- see the VERSION FLOOR note on the section above. */
CUDEZ_INLINE cudez_graph cudez_graph_end(const cudez *cz) {
    cudez_graph g; g.graph = NULL; g.exec = NULL;
    CUDEZ_CHECK(cuStreamEndCapture(cz->stream, &g.graph));
    CUDEZ_CHECK(cuGraphInstantiate(&g.exec, g.graph, 0));
    return g;
}

CUDEZ_INLINE void cudez_graph_launch(const cudez *cz, cudez_graph g) {
    CUDEZ_CHECK(cuGraphLaunch(g.exec, cz->stream));
}

CUDEZ_INLINE void cudez_graph_destroy(cudez_graph g) {
    if (g.exec)  cuGraphExecDestroy(g.exec);
    if (g.graph) cuGraphDestroy(g.graph);
}


/* ============================================================================
 * CUDEZ_MMA -- mid-level tensor-core (WMMA) and sparse-tensor-core (MMA.SP)
 * kernel generation, layered on top of the NVRTC build path above.
 *
 * WHAT "MID-LEVEL" MEANS HERE (read this before using anything below)
 * This is NOT a "just multiply my matrices" GEMM call. You choose the
 * WMMA tile shape, warp count per block, and K-loop chunking; cudez turns
 * that config into a real CUDA C++ kernel-source string using NVIDIA's
 * documented nvcuda::wmma:: API (mma.h), compiles it via the SAME
 * cudez_try_build path used for ordinary kernels, and hands you back a
 * cudez_kernel you launch yourself with cudez_launch -- exactly like any
 * other cudez kernel. cudez does not pick your grid/block dims, does not
 * auto-tune, and does not call cuBLAS. If you want "just multiply my
 * matrices, I don't care how," use cuBLAS; that is what it is for.
 *
 * WHY MID-LEVEL, ON PURPOSE
 * A high-level cudez_gemm(cz, A, B, C, M, N, K) call would hide the tile
 * shape and warp mapping that determines whether your kernel is anywhere
 * close to cuBLAS performance -- and since this layer does NOT call
 * cuBLAS (it generates its own WMMA kernels), hiding those knobs would
 * produce a black box that is both slower than cuBLAS and impossible to
 * tune. Exposing tile/warp/K-chunk config is the same tradeoff CUTLASS
 * makes for the same reason. If you know what a 16x16x16 WMMA tile is,
 * this layer gets out of your way fast; if you don't yet, NVIDIA's own
 * "Programming Tensor Cores in CUDA 9" blog post and the mma.h reference
 * are the right five minutes to spend first.
 *
 * PRECISION PATHS SUPPORTED (v0.2.0)
 *   CUDEZ_MMA_F16   half inputs,  float accumulate  -- sm_70+ (Volta+)
 *   CUDEZ_MMA_BF16  bfloat16 inputs, float accumulate -- sm_80+ (Ampere+)
 *   CUDEZ_MMA_TF32  float inputs (rounded to TF32 on load), float accumulate
 *                   -- sm_80+ (Ampere+). WMMA tile is m16n16k8 for TF32,
 *                   NOT m16n16k16 -- cudez sets this automatically; do not
 *                   pass a manual tile_k of 16 for TF32 (cudez_try_mma_build
 *                   rejects it, see below).
 *
 * PRECISION PATHS SUPPORTED, NEW IN v0.3.0
 *   CUDEZ_MMA_INT8  int8 inputs,  int32 accumulate -- sm_80+ (Ampere+;
 *                   0.3.0 wrongly claimed sm_75 -- real ptxas rejects
 *                   m16n8k32 integer mma below sm_80), inline-PTX
 *                   mma.sync.aligned.m16n8k32.s8 (NOT WMMA C++
 *                   -- see cudez_mma_int_source_'s doc comment for why).
 *                   Requires tile_m=16,tile_n=8,tile_k=32.
 *   CUDEZ_MMA_INT4  int4 inputs,  int32 accumulate -- sm_80+ (Ampere+,
 *                   same correction as INT8), inline-PTX
 *                   mma.sync.aligned.m16n8k64.s4.
 *                   Requires tile_m=16,tile_n=8,tile_k=64.
 *   Both are CORRECTNESS-FIRST (0.3.0, still true in 0.9.0): no shared-
 *   memory pipelining or cp.async yet -- the dense F16 pipelines (v3/v4)
 *   are the template that will be ported here (see roadmap note),
 *   which matters here specifically because performance, not just
 *   coverage, is the actual point of adding these two dtypes. Both
 *   support requantization from their int32 accumulator via
 *   cfg.requant_mode (NONE / PERTENSOR / PERCHANNEL) -- see the doc
 *   comment on cudez_mma_config.requant_mode, and Section 5.9 of the
 *   guide, for the accuracy tradeoffs between the three modes.
 *
 * FP8 (e4m3/e5m2, Hopper+) is NOT included in v0.3.0 -- deferred, see
 * roadmap note at the end of this section.
 *
 * SPARSE (2:4 STRUCTURED SPARSITY) -- sm_80+ ONLY
 * Ampere introduced sparse Tensor Cores that operate on a 2:4 structured
 * sparse encoding of matrix A (2 nonzero values per 4-element group, plus
 * a metadata index recording which 2). cudez's sparse path (cfg.sparse=1)
 * generates a kernel using the mma.sp PTX instruction family via inline
 * PTX asm (NVRTC's CUDA C++ front end does not expose a documented
 * nvcuda::wmma:: sparse fragment type the way it does for dense WMMA, so
 * the sparse kernel body is hand-assembled inline PTX -- this is the ONE
 * place in cudez where the generated kernel is not pure high-level
 * CUDA C++, and it is called out here for exactly that reason). YOU are
 * responsible for producing correctly 2:4-pruned data and the matching
 * metadata array before calling a sparse kernel; cudez_mma_prune_2to4
 * below is a REFERENCE host-side pruning helper (correctness-oriented,
 * not performance-tuned) to produce both from a dense fp16 matrix.
 *
 * VERIFIED, AND ON WHAT (honestly, matching cudez 0.1.0/0.1.1's standard)
 * As of 0.2.0, the kernel-source TEMPLATES below have been checked against
 * NVIDIA's PUBLISHED documented WMMA API signatures (fragment, mma_sync,
 * load_matrix_sync, store_matrix_sync, fill_fragment, wmma::precision::tf32)
 * as reference material -- they have NOT yet been compiled by real NVRTC
 * or run on a real GPU, because (same as cudez 0.1.0's original baseline)
 * no GPU was available in the environment that produced this release.
 * This is a STUB-VERIFIED state, matching cudez 0.1.0's honesty standard
 * before 0.1.1 upgraded the plain-kernel NVRTC path to real confirmation.
 * The mock backend distributed alongside this header exercises the
 * HOST-SIDE config validation, source-generation, and caching logic under
 * ASan/UBSan -- it does NOT compile the generated CUDA C++ (the mock
 * NVRTC never actually parses source), so a syntactically broken
 * generated kernel would NOT be caught by the mock test suite. Treat
 * every kernel string generated below as "believed correct against
 * NVIDIA's docs, not yet proven by a real compiler" until a future
 * revision upgrades this section the way 0.1.1 upgraded the base NVRTC
 * path -- real libnvrtc compilation of each generated template, on each
 * supported tile/dtype combination, plus real-GPU numerical verification
 * against a reference CPU GEMM. Until then, ALWAYS inspect
 * cudez_mma_source() output before trusting it in anything beyond
 * experimentation, and treat sparse (inline-PTX) kernels with additional
 * suspicion, since inline asm gets none of the compiler-frontend type
 * checking the WMMA C++ path gets.
 *
 * UPDATED IN 0.3.1: the INT8/INT4 dense path has moved from "illustrative"
 * to "compiles + assembles on real tools, per-lane layout from CUTLASS,
 * numerics not yet hardware-checked." Specifically:
 *   - 0.3.0 shipped a real BUG, not merely an unverified layout: the
 *     generated kernels NEVER LOADED A or B (operand registers stayed
 *     zero) and scattered output PER-WARP (all 32 lanes wrote the same 4
 *     cells). On real hardware every 0.3.0 int kernel returned all-zero
 *     (or all-zero_point) output for any input. This is fixed.
 *   - The per-lane load and store now follow the fragment layouts
 *     enumerated mechanically from NVIDIA CUTLASS's CuTe MMA_Traits
 *     (include/cute/atom/mma_traits_sm80.hpp: SM80_16x8x32_S32S8S8S32_TN,
 *     SM80_16x8x64_S32S4S4S32_TN), which encode the PTX ISA "Matrix
 *     Fragments" tables. An independent CPU index-coverage check confirms
 *     the loads cover A and B exactly once and the scatter hits all 128
 *     output cells with no cross-lane collision.
 *   - Every generated INT8/INT4 variant (NONE/PERTENSOR/PERCHANNEL, both
 *     dtypes) compiles under REAL NVRTC 12.9 and assembles under REAL
 *     ptxas for sm_80..sm_120. The cc-floor was corrected from the wrong
 *     sm_75 to sm_80: real ptxas rejects m16n8k32/m16n8k64 integer mma
 *     below sm_80 ("Feature '.m16n8k32' requires .target sm_80 or higher").
 *   - STILL NOT DONE: numerical verification on real tensor cores against
 *     a reference GEMM. Compile+assemble is necessary, not sufficient.
 *     Diff a small case against a CPU reference before trusting results.
 * The SPARSE path warrants MORE caution than the int path, but for a different
 * reason than an earlier version of this note claimed: its operand load (4+4
 * vectors, corrected from a wrong 2+2 in 0.3.0) and output scatter ARE
 * implemented (see cudez_mma_sparse_source_) -- it is a real 2:4 GEMM, not a
 * skeleton. What is NOT yet hardware-verified is the metadata bit-layout: cudez
 * emits Ampere-form mma.sp, whose per-lane metadata packing was already
 * re-derived once after an on-device probe (see that function's note), and which
 * sm_90+ reject in favor of mma.sp::ordered_metadata (refused at validation
 * until that variant lands, roadmap item 4). Trust sparse results only after the
 * on-silicon numerical diff.
 * ========================================================================== */

typedef enum {
    CUDEZ_MMA_F16  = 0,   /* half,     load as-is,             sm_70+ */
    CUDEZ_MMA_BF16 = 1,   /* bfloat16, load as-is,              sm_80+ */
    CUDEZ_MMA_TF32 = 2,   /* float,    rounded via wmma load path, sm_80+ */
    /* -- NEW in 0.3.0. Both accumulate in int32, NOT float -- this is a
       real difference from the three dtypes above, not a detail. Getting
       from an int32 accumulator to a usable output is the requant step
       (see cfg.requant_mode below and Section 5.9 of the guide). Both are
       generated as inline PTX mma.sync (NOT nvcuda::wmma:: C++), because,
       same as the sparse path above, NVRTC's C++ front end does not
       expose a documented dense-integer WMMA fragment type at the tile
       shapes that are actually competitive (m16n8k32 / m16n8k64) -- only
       an older, narrower wmma::experimental::precision path exists, which
       cudez does not use. See cudez_mma_int_source_'s doc comment. */
    CUDEZ_MMA_INT8 = 3,   /* int8,  int32 accumulate, sm_80+ (Ampere+),
                              inline PTX mma.sync.aligned.m16n8k32.s8.
                              (NOT sm_75: ptxas rejects this mma shape below
                              sm_80 -- Turing's integer tensor cores are only
                              reachable at m8n8k16, not generated yet.) */
    CUDEZ_MMA_INT4 = 4,   /* int4,  int32 accumulate, sm_80+ (Ampere+),
                              inline PTX mma.sync.aligned.m16n8k64.s4.
                              Same sm_80 floor note as INT8. */
    /* -- NEW scaffold, dense codegen NOT YET IMPLEMENTED (1.1.0).
       CUDEZ_MMA_F64 = double-precision (DMMA), inline PTX
       mma.sync.aligned.m8n8k4.row.col.f64.f64.f64.f64, sm_80+.
       HARDWARE CAVEAT, stated up front because it changes whether this
       feature is worth anything on a given GPU: NVIDIA deliberately cripples
       FP64 tensor-core throughput on consumer Ampere dies (GA102/GA104/
       GA106 -- includes this project's sm_86 reference GPU). Full-rate DMMA
       (~19.5 TFLOPS documented for A100/GA100) is a datacenter-die feature;
       consumer Ampere's FP64 CUDA-core rate is independently documented at
       1/64 of FP32, and DMMA on GA10x is expected to be similarly gimped or
       entirely absent in practice even though it may compile and assemble
       (PTX/ptxas target sm_80 as the *virtual* architecture gate, which does
       not guarantee the physical die has usable DMMA units). PROBE THIS
       BEFORE INVESTING FURTHER: build a trivial single-mma smoke kernel,
       run it, and time it against plain double CUDA-core FMA on the same
       shape. If DMMA is not meaningfully faster than CUDA cores on the
       reference GPU, this dtype's only path to a real benchmark number is
       an A100/H100-class rental instance, not the 0.8.0-0.9.0 laptop box. */
    CUDEZ_MMA_F64 = 5     /* double, double accumulate, sm_80+ (Ampere+),
                              inline PTX mma.sync.aligned.m8n8k4.f64. See the
                              hardware caveat above. cudez_mma_build()
                              currently returns CUDA_ERROR_INVALID_VALUE for
                              this dtype via the validator's named refusal --
                              scaffolded: dtype enum, tile/cache-key identity,
                              ctype, supported()=0; deliberately NOT written:
                              the inline-PTX load/mma/store body (fragment
                              layout must be sourced, not guessed -- see the
                              validator message). */
} cudez_mma_dtype;

/* Requantization mode for the int32 accumulator produced by INT8/INT4
   kernels. Irrelevant (ignored) for F16/BF16/TF32 configs, whose
   accumulator is already float and whose existing alpha/beta epilogue
   (Section 5.6 of the guide) covers the same need.
   CUDEZ_MMA_REQUANT_NONE:     kernel writes raw int32 accumulator to D.
                               Caller does any scaling themselves. Simplest,
                               and the only mode with zero extra kernel
                               arguments.
   CUDEZ_MMA_REQUANT_PERTENSOR: one (scale, zero_point) pair for the whole
                               output. D[i] = (int32_acc[i]) * scale + zp,
                               written as float. Cheap, coarse.
   CUDEZ_MMA_REQUANT_PERCHANNEL: one (scale, zero_point) pair PER OUTPUT
                               COLUMN (i.e. per-N, matching the common
                               "one scale per output channel" quantized-
                               model convention). D[row][col] =
                               int32_acc[row][col] * scale[col] + zp[col].
                               This is the mode real quantized-model
                               accuracy needs -- per-tensor scale is not
                               enough once a layer's output channels have
                               meaningfully different dynamic ranges. */
typedef enum {
    CUDEZ_MMA_REQUANT_NONE       = 0,
    CUDEZ_MMA_REQUANT_PERTENSOR  = 1,
    CUDEZ_MMA_REQUANT_PERCHANNEL = 2
} cudez_mma_requant_mode;

/* cudez_mma_config is a PURE KERNEL-IDENTITY key (0.4.0): every field here
   changes the generated source. Launch geometry (warps_per_block) and matrix
   size (M/N/K) are NOT here -- they are passed to cudez_try_mma_launch via
   cudez_mma_args, so two launches that differ only in block shape or matrix
   size share one compiled kernel. Zero-initialize with cudez_mma_defaults()
   (recommended) before setting fields. The cache compares configs FIELD BY FIELD
   (cudez_mma_cfg_eq_), so struct padding is irrelevant -- but a newly added field
   must also be added to cudez_mma_cfg_eq_ or it will not participate in the cache
   key and distinct kernels could collide. */
typedef struct {
    cudez_mma_dtype dtype_ab;   /* precision of A and B inputs. Accumulate is
                                    float (F16/BF16/TF32) or int32 (INT8/INT4). */
    int tile_m, tile_n, tile_k; /* MMA tile shape. Prefer cudez_mma_defaults():
                                    F16/BF16 16,16,16; TF32 16,16,8; INT8 16,8,32;
                                    INT4 16,8,64. Validated per-dtype below. */
    int k_chunks;               /* #pragma unroll factor on the K-loop (>=1).
                                    Affects generated source, hence in the key. */
    int sparse;                 /* 0 = dense (default). 1 = 2:4 structured sparse
                                    mma.sp (sm_80+, F16/BF16 only). 0.5.0: a REAL
                                    kernel (compressed load + metadata + scatter),
                                    launchable via cudez_try_mma_launch. Prepare A
                                    with cudez_mma_compress_2to4. Numerics are
                                    reference-grade until confirmed by the harness
                                    on hardware -- see that helper's note. */
    cudez_mma_requant_mode requant_mode; /* INT8/INT4 only. Validation error on
                                    F16/BF16/TF32 (those already accumulate in
                                    float; use alpha/beta). scale/zero_point VALUES
                                    are launch args (cudez_mma_args), not identity:
                                    one compiled kernel serves many scale tensors. */
    int smem_stage;             /* 0 = streaming kernel (default; the 0.7.1
                                    hardware-verified path, untouched).
                                    1 = the 0.8.0 shared-memory pipeline, v3:
                                    one block = 2x2 warps, each warp computing
                                    a 2x2 grid of WMMA tiles (register
                                    blocking), a (4*tile_m)x(4*tile_n) block-
                                    tile. Per BK = 4*tile_k step the block
                                    stages its A/B panels into padded shared
                                    memory once; each staged element feeds
                                    four tiles of compute (rung history v1/v2
                                    in the 0.8.0 changelog).
                                    2 = the 0.9.0 pipeline, v4: v3's block-
                                    tile plus cp.async DOUBLE BUFFERING --
                                    stage K-step s+1 into the other half of a
                                    2-deep smem queue while computing step s,
                                    hiding staging latency behind the
                                    mma_syncs (sm_80+; the Ampere analogue of
                                    Hopper's TMA producer/consumer queues).
                                    Doubles staged smem (~36.9 KB static for
                                    default tiles), so expect lower occupancy
                                    traded against the overlap; the bench
                                    judges the trade per shape.
                                    3 = v5 (1.1.0): v4 + L2-aware grouped
                                    rasterization (GROUP_M swizzle) for block
                                    scheduling. 4 = v6 (1.2.0): v5's body with
                                    wmma replaced by raw ldmatrix.m8n8.x4 +
                                    mma.sync.m16n8k16 inline PTX. 5 = v7: v6 +
                                    a smem-staged float4-coalesced epilogue.
                                    6 = v8 (1.4.0): v7 tiled to a 128x128 block
                                    (16 warps, BK halved to 32 to stay under the
                                    48 KB static-smem ceiling at 2 blocks/SM);
                                    for large/DRAM-bound shapes. Launch contract
                                    for stage 6: warps_per_block==16,
                                    M % 128 == 0, N % 128 == 0, K % 32 == 0.
                                    Stages 0-6 are CUDEZ_MMA_F16; stages 4-6
                                    (v6/v7/v8, the raw-mma pipelines) also accept
                                    CUDEZ_MMA_BF16 (identical ldmatrix/mma layout,
                                    f32 accumulate). BF16 on v3/v4/v5 and TF32
                                    staging follow (validation error otherwise).
                                    Stages 1-5 share the launch contract
                                    warps_per_block==4, M % (4*tile_m) == 0,
                                    N % (4*tile_n) == 0, K % (4*tile_k) == 0.
                                    Changes the generated source, hence part
                                    of the cache key. */
    int store_hint;             /* 0 = plain wmma epilogue stores (default;
                                    with 0 every kernel is byte-identical to
                                    its 0.9.0 build). 1 = rung (h), 0.10.0:
                                    EVICT-FIRST D stores. Output tiles are
                                    write-once and never re-read by the
                                    kernel, so the epilogue streams them out
                                    with st.global.cs (the __stcs policy)
                                    instead of letting D evict the L2 lines
                                    the A/B panels want -- the sm_86
                                    analogue of Hopper's L2-bypassing TMA
                                    stores. Route: the accumulator fragment
                                    layout is opaque (and vendor layout
                                    diagrams have been wrong before), so
                                    acc goes store_matrix_sync -> the
                                    staging smem (dead after the K-loop;
                                    zero extra footprint) -> per-element
                                    .cs stores. Requires smem_stage=2
                                    (pipeline v4); validation error
                                    otherwise -- streaming/v3/sparse/INT
                                    epilogue hints are roadmap. Same launch
                                    contract and numerics as v4. Changes
                                    the generated source, hence part of the
                                    cache key. */
} cudez_mma_config;

/* Compiled+cached tensor-core kernel. Behaves exactly like cudez_kernel
   for launch purposes (cudez_launch(cz, mm.kernel, ...)) -- the extra
   fields exist for cudez_mma_source() introspection and cache lookups. */
typedef struct {
    cudez_kernel kernel;
    cudez_mma_config cfg;
    char generated_name[64];    /* the extern "C" symbol name used, unique
                                    per cfg so caching by shape is safe */
} cudez_mma_kernel;

/* v9 (smem_stage=7) dynamic shared memory: 3 ring slots of the padded A/B
   panels. v9's geometry is fixed (BM=BN=128, BK=32, SKA=BK+8=40, SKB=BN+8=136),
   so this is a compile-time constant. Single source of truth for BOTH the launch
   site (cuFuncSetAttribute + cuLaunchKernel) and the occupancy helper, so they
   can never disagree. */
#define CUDEZ_V9_DYN_SMEM (3u*128u*40u*2u + 3u*32u*136u*2u)   /* = 56832 */
/* v10 (smem_stage=8): 4 ring slots, same panel geometry. */
#define CUDEZ_V10_DYN_SMEM (4u*128u*40u*2u + 4u*32u*136u*2u)  /* = 75776 */

/* Return a config with the correct tile shape for a dtype and sane defaults
   (dense, k_chunks=1, requant NONE). The learnable entry point: start here,
   then override only what you mean to. */
CUDEZ_INLINE cudez_mma_config cudez_mma_defaults(cudez_mma_dtype dtype) {
    cudez_mma_config c;
    memset(&c, 0, sizeof c);
    c.dtype_ab = dtype;
    c.k_chunks = 1;
    c.sparse = 0;
    c.store_hint = 0;
    c.requant_mode = CUDEZ_MMA_REQUANT_NONE;
    switch (dtype) {
        case CUDEZ_MMA_TF32: c.tile_m = 16; c.tile_n = 16; c.tile_k = 8;  break;
        case CUDEZ_MMA_INT8: c.tile_m = 16; c.tile_n = 8;  c.tile_k = 32; break;
        case CUDEZ_MMA_INT4: c.tile_m = 16; c.tile_n = 8;  c.tile_k = 64; break;
        case CUDEZ_MMA_F64:  c.tile_m = 8;  c.tile_n = 8;  c.tile_k = 4;  break;
        case CUDEZ_MMA_F16:
        case CUDEZ_MMA_BF16:
        default:             c.tile_m = 16; c.tile_n = 16; c.tile_k = 16; break;
    }
    return c;
}

/* Capability predicate: does THIS device's compute capability support this
   dtype (and, if sparse!=0, 2:4 sparse) at the shapes cudez generates? Uses
   the same floors as the validator, so you can branch before building --
   e.g. pick INT8 on Ampere, fall back to F16 on Volta. Returns 1/0.
   NOTE (1.0.3-dev): still returns 0 for (INT8, sparse=1) even though INT8
   sparse v7 (smem_stage=5, UNVERIFIED on real hardware -- see
   CUDEZ_SPI8_PIPE_SRC_) now exists, because this function's contract for
   F16/BF16 sparse is "works at ANY smem_stage" (streaming, v7, and v9 are
   all implemented) -- that isn't true for INT8 sparse yet (only stage 5
   exists; there is no INT8 sparse streaming or ring fallback). Build with
   cudez_mma_defaults(CUDEZ_MMA_INT8) + .sparse=1 + .smem_stage=5 directly
   and check cudez_try_mma_build's return instead of relying on this
   predicate for that specific combination. */
CUDEZ_INLINE int cudez_mma_supported(const cudez *cz, cudez_mma_dtype dtype, int sparse) {
    int cc = cz->cc_major * 10 + cz->cc_minor;
    if (sparse) {
        if (cc < 80) return 0;
        return dtype == CUDEZ_MMA_F16 || dtype == CUDEZ_MMA_BF16;
    }
    switch (dtype) {
        case CUDEZ_MMA_F16:  return cc >= 70;
        case CUDEZ_MMA_BF16: return cc >= 80;
        case CUDEZ_MMA_TF32: return cc >= 80;
        case CUDEZ_MMA_INT8: return cc >= 80;
        case CUDEZ_MMA_INT4: return cc >= 80;
        /* Deliberately 0, not cc>=80: (a) codegen for this dtype does not
           exist yet (see CUDEZ_MMA_F64's doc comment), and (b) even once it
           does, cc>=80 is the PTX/ptxas VIRTUAL architecture gate, not proof
           the physical die has usable DMMA throughput -- consumer Ampere is
           documented to cripple FP64 tensor cores relative to A100/GA100.
           "Supported" here means "you can build and expect a real number,"
           which is not yet true for F64 on any device. */
        case CUDEZ_MMA_F64:  return 0;
        default:             return 0;
    }
}

/* ---- internal: cfg validation --------------------------------------- */

CUDEZ_INLINE int cudez_mma_cfg_valid_(const cudez *cz, const cudez_mma_config *c,
                                      char *errbuf, size_t errbuf_sz) {
    int cc = cz->cc_major * 10 + cz->cc_minor;
    if (c->smem_stage) {
        if (c->smem_stage < 1 || c->smem_stage > 8) { snprintf(errbuf, errbuf_sz,
            "smem_stage must be 0 (streaming), 1 (pipeline v3), 2 (v4, "
            "cp.async double buffer), 3 (v5, + L2-aware rasterization), "
            "4 (v6, raw ldmatrix+mma.sync), 5 (v7, + staged float4 epilogue; "
            "also the INT8 pipeline), 6 (v8, 128x128 block for large shapes), "
            "7 (v9, v8 + 3-stage cp.async ring in dynamic smem), or 8 (v10, "
            "4-stage ring) (got %d)",
            c->smem_stage); return 0; }
        if (c->smem_stage >= 2 && cc < 80) { snprintf(errbuf, errbuf_sz,
            "smem_stage=%d (pipeline v4/v5/v6/v7/v8) uses cp.async, an sm_80+ (Ampere) "
            "instruction; device is sm_%d%d -- use smem_stage=1 (v3) there",
            c->smem_stage, cz->cc_major, cz->cc_minor); return 0; }
        if (c->sparse && c->smem_stage != 5 && c->smem_stage != 7) {
            snprintf(errbuf, errbuf_sz,
            "sparse supports smem_stage=0 (streaming), 5 (v7-class pipeline), "
            "or 7 (1.9.0-dev: v9-class 128-tile ring); other stages are "
            "dense-only (got %d)",
            c->smem_stage); return 0; }
        if (c->dtype_ab != CUDEZ_MMA_F16 &&
            !(c->dtype_ab == CUDEZ_MMA_BF16 && c->smem_stage >= 4) &&
            !(c->dtype_ab == CUDEZ_MMA_INT8 && c->smem_stage == 5) &&
            !(c->dtype_ab == CUDEZ_MMA_INT4 && c->smem_stage == 5) &&
            !(c->dtype_ab == CUDEZ_MMA_TF32 && (c->smem_stage == 5 ||
                                                c->smem_stage == 7))) {
            snprintf(errbuf, errbuf_sz,
            "smem_stage=%d supports CUDEZ_MMA_F16 (all pipelines), "
            "CUDEZ_MMA_BF16 (stages 4-8, the raw-mma pipelines), and "
            "CUDEZ_MMA_INT8/INT4/TF32 (stage 5 = the v7-class 64x64 cp.async "
            "pipeline); BF16 on v3/v4/v5 lands after (roadmap)",
            c->smem_stage); return 0; }
    }
    if (c->dtype_ab == CUDEZ_MMA_F16) {
        if (cc < 70) { snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_F16 requires sm_70 (Volta) or newer; device is sm_%d%d",
            cz->cc_major, cz->cc_minor); return 0; }
        if (!(c->tile_m == 16 && c->tile_n == 16 && c->tile_k == 16)) {
            snprintf(errbuf, errbuf_sz,
                "CUDEZ_MMA_F16 requires tile_m=tile_n=tile_k=16 (got %d,%d,%d)",
                c->tile_m, c->tile_n, c->tile_k); return 0;
        }
    } else if (c->dtype_ab == CUDEZ_MMA_BF16) {
        if (cc < 80) { snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_BF16 requires sm_80 (Ampere) or newer; device is sm_%d%d",
            cz->cc_major, cz->cc_minor); return 0; }
        if (!(c->tile_m == 16 && c->tile_n == 16 && c->tile_k == 16)) {
            snprintf(errbuf, errbuf_sz,
                "CUDEZ_MMA_BF16 requires tile_m=tile_n=tile_k=16 (got %d,%d,%d)",
                c->tile_m, c->tile_n, c->tile_k); return 0;
        }
    } else if (c->dtype_ab == CUDEZ_MMA_TF32) {
        if (cc < 80) { snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_TF32 requires sm_80 (Ampere) or newer; device is sm_%d%d",
            cz->cc_major, cz->cc_minor); return 0; }
        if (!(c->tile_m == 16 && c->tile_n == 16 && c->tile_k == 8)) {
            snprintf(errbuf, errbuf_sz,
                "CUDEZ_MMA_TF32 requires tile_m=16,tile_n=16,tile_k=8 (got %d,%d,%d) "
                "-- TF32's WMMA tile is m16n16k8, not m16n16k16",
                c->tile_m, c->tile_n, c->tile_k); return 0;
        }
    } else if (c->dtype_ab == CUDEZ_MMA_INT8) {
        if (cc < 80) { snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_INT8 requires sm_80 (Ampere) or newer; device is sm_%d%d "
            "-- ptxas rejects the m16n8k32 integer mma shape below sm_80; "
            "Turing exposes integer tensor cores only at m8n8k16, which "
            "cudez does not generate yet", cz->cc_major, cz->cc_minor); return 0; }
        if (!(c->tile_m == 16 && c->tile_n == 8 && c->tile_k == 32)) {
            snprintf(errbuf, errbuf_sz,
                "CUDEZ_MMA_INT8 requires tile_m=16,tile_n=8,tile_k=32 (got %d,%d,%d) "
                "-- this is the documented mma.sync.aligned.m16n8k32.s8 shape (sm_80+)",
                c->tile_m, c->tile_n, c->tile_k); return 0;
        }
    } else if (c->dtype_ab == CUDEZ_MMA_INT4) {
        if (cc < 80) { snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_INT4 requires sm_80 (Ampere) or newer; device is sm_%d%d "
            "-- ptxas rejects the m16n8k64 integer mma shape below sm_80; "
            "Turing exposes integer tensor cores only at m8n8k32, which "
            "cudez does not generate yet", cz->cc_major, cz->cc_minor); return 0; }
        if (!(c->tile_m == 16 && c->tile_n == 8 && c->tile_k == 64)) {
            snprintf(errbuf, errbuf_sz,
                "CUDEZ_MMA_INT4 requires tile_m=16,tile_n=8,tile_k=64 (got %d,%d,%d) "
                "-- this is the documented mma.sync.aligned.m16n8k64.s4 shape (sm_80+)",
                c->tile_m, c->tile_n, c->tile_k); return 0;
        }
    } else if (c->dtype_ab == CUDEZ_MMA_F64) {
        /* Full sourcing instructions live in the enum doc comment above and
           HANDOFF_1_1_0.md; this message must fit the 256 B errbuf UNTRUNCATED
           (caught by -Wformat-truncation at -O2 during the 1.1.0 merge). */
        snprintf(errbuf, errbuf_sz,
            "CUDEZ_MMA_F64: scaffolded, dense codegen NOT YET IMPLEMENTED. "
            "Source the m8n8k4.f64 per-lane layout from the PTX ISA docs or "
            "CUTLASS mma_traits_sm80.hpp (as INT8/INT4 did) -- see "
            "HANDOFF_1_1_0.md, incl. the consumer-Ampere DMMA caveat."); return 0;
    } else {
        snprintf(errbuf, errbuf_sz, "unknown cudez_mma_dtype %d", (int)c->dtype_ab);
        return 0;
    }
    /* 1.1.0 (AUDIT-4): validated AFTER the dtype dispatch above, so a bad
       dtype surfaces the fundamental error first instead of a store_hint
       message pointing the user at the wrong problem. */
    if (c->store_hint) {
        if (c->store_hint != 1) { snprintf(errbuf, errbuf_sz,
            "store_hint must be 0 (plain wmma stores) or 1 (evict-first "
            "st.global.cs epilogue) (got %d)", c->store_hint); return 0; }
        if (c->requant_mode != CUDEZ_MMA_REQUANT_NONE && c->smem_stage == 5) {
            snprintf(errbuf, errbuf_sz,
            "requant_mode=%d with smem_stage=5: the pipelined INT8/INT4 kernels "
            "have NO requant epilogue yet (raw s32 D only) -- a validated build "
            "would silently drop scale/zero_point (BUG-2, 1.0.2). Use "
            "smem_stage=0 for requantized output, or requant on the host; a "
            "requant epilogue for the pipelines is a roadmap MINOR",
            (int)c->requant_mode); return 0; }
        if (c->smem_stage != 2 && c->smem_stage != 3 &&
            !(c->smem_stage == 5 && c->dtype_ab == CUDEZ_MMA_INT8)) { snprintf(errbuf, errbuf_sz,
            "store_hint=1 requires smem_stage=2 or 3 (v4/v5 evict-first) or "
            "smem_stage=5 + INT8 (rung 2: B chunk-swizzle + staged s32 epilogue) "
            "(got smem_stage=%d, dtype=%d); other epilogue hints are roadmap, and "
            "v6-v10 bake in their own epilogues", c->smem_stage, (int)c->dtype_ab); return 0; }
    }
    if (c->k_chunks < 1) {
        snprintf(errbuf, errbuf_sz, "k_chunks must be >= 1 (got %d)", c->k_chunks);
        return 0;
    }
    if ((c->smem_stage == 7 || c->smem_stage == 8) && c->k_chunks > 1) {
        /* Not fatal, but v9's steady loop body is stage()+compute()+wait_group;
           unrolling it replicates all three and inflates register pressure on a
           kernel already register-bound to 1 block/SM -- it can cost the very
           occupancy v9 exists to preserve. Warn; k_chunks=1 (no unroll) is best. */
        cudez_log_("cudez: note -- smem_stage=%d (ring pipeline) with k_chunks=%d "
                "unrolls the steady K-loop; ring pipelines are register-bound to 1 block/SM, so "
                ">1 may reduce occupancy. k_chunks=1 is recommended.\n", c->smem_stage, c->k_chunks);
    }
    if (c->sparse && cc < 80) {
        snprintf(errbuf, errbuf_sz,
            "sparse (2:4 structured) MMA requires sm_80 (Ampere) or newer; "
            "device is sm_%d%d", cz->cc_major, cz->cc_minor);
        return 0;
    }
    if (c->sparse && cc >= 90) {
        /* cudez emits the Ampere-form `mma.sp` (see cudez_mma_sparse_source_).
           sm_90+ (Hopper/Blackwell) require `mma.sp::ordered_metadata` (PTX ISA
           8.5+), a different metadata layout cudez does not generate yet. Whether
           plain mma.sp mis-assembles or miscomputes there is unverified (no
           sm_90 hardware in reach), but cudez cannot produce CORRECT 2:4 sparse
           output on sm_90+ either way -- so refuse rather than risk it. Remove
           this once the ordered_metadata variant exists (roadmap item 4). */
        snprintf(errbuf, errbuf_sz,
            "sparse (2:4) on sm_%d%d: cudez generates Ampere-form mma.sp, but "
            "sm_90+ needs mma.sp::ordered_metadata (PTX ISA 8.5+), which cudez "
            "does not emit yet -- refusing rather than risk incorrect results "
            "(roadmap item 4). Use a dense kernel, or sm_80..sm_89 for sparse.",
            cz->cc_major, cz->cc_minor);
        return 0;
    }
    if (c->sparse && c->dtype_ab == CUDEZ_MMA_TF32) {
        snprintf(errbuf, errbuf_sz,
            "sparse TF32 mma.sp is not generated by cudez 0.2.0 -- only "
            "sparse F16/BF16 are (see roadmap note)");
        return 0;
    }
    if (c->sparse && c->dtype_ab == CUDEZ_MMA_INT4) {
        snprintf(errbuf, errbuf_sz,
            "sparse INT4 mma.sp is not generated by cudez -- Ampere's native "
            "INT4 sparse pattern is 4:8, not 2:4, a genuinely different "
            "metadata scheme from what cudez implements for F16/BF16/INT8 "
            "sparse (see roadmap note)");
        return 0;
    }
    if (c->sparse && c->dtype_ab == CUDEZ_MMA_INT8 && c->smem_stage != 5) {
        snprintf(errbuf, errbuf_sz,
            "sparse INT8 mma.sp is only generated at smem_stage=5 (v7-class "
            "pipeline, CUDEZ_SPI8_PIPE_SRC_ -- UNVERIFIED on real hardware, "
            "see that template's doc comment in cudez.h); streaming "
            "(smem_stage=0) and ring (smem_stage=7) sparse INT8 are not "
            "generated yet (got smem_stage=%d)", c->smem_stage);
        return 0;
    }
    /* 1.0.3-dev: sparse INT8 at smem_stage==5 falls through here and is
       ACCEPTED -- CUDEZ_SPI8_PIPE_SRC_ exists (UNVERIFIED on real hardware).
       This validator used to unconditionally reject ALL sparse INT8/INT4
       with a stale "not generated by cudez 0.3.0" message, well before that
       kernel was ever built; the message survived the kernel's own addition
       because this check was never revisited when the kernel was wired
       in elsewhere (generator, cudez_mma_launch's arg-push, grid math).
       Every sparse INT8 config that reaches cudez_mma_build/cudez_try_mma_build
       for smem_stage==5 was aborting here, on every device, unconditionally
       -- not an environment-specific failure. */
    if (c->requant_mode != CUDEZ_MMA_REQUANT_NONE &&
        c->dtype_ab != CUDEZ_MMA_INT8 && c->dtype_ab != CUDEZ_MMA_INT4) {
        snprintf(errbuf, errbuf_sz,
            "requant_mode is only meaningful for CUDEZ_MMA_INT8/_INT4 "
            "(F16/BF16/TF32 already accumulate in float -- use the "
            "existing alpha/beta epilogue instead)");
        return 0;
    }
    return 1;
}

/* ---- internal: dtype -> generated CUDA C++ tokens -------------------- */

CUDEZ_INLINE const char *cudez_mma_dtype_ctype_(cudez_mma_dtype d) {
    switch (d) {
        case CUDEZ_MMA_F16:  return "half";
        case CUDEZ_MMA_BF16: return "__nv_bfloat16";
        case CUDEZ_MMA_TF32: return "float"; /* stored as float, rounded on load */
        case CUDEZ_MMA_INT8: return "signed char";   /* packed 4-per-32-bit at the PTX level */
        case CUDEZ_MMA_F64:  return "double";        /* no packing; DMMA takes one f64 per element */
        case CUDEZ_MMA_INT4: return "signed char";   /* caller packs 2 int4 values per byte
                                                          (low nibble = even/lower element index);
                                                          see doc comment on cudez_mma_int_source_ */
        default: return "half";
    }
}

CUDEZ_INLINE const char *cudez_mma_dtype_fragtype_(cudez_mma_dtype d) {
    switch (d) {
        case CUDEZ_MMA_F16:  return "half";
        case CUDEZ_MMA_BF16: return "__nv_bfloat16";
        case CUDEZ_MMA_TF32: return "wmma::precision::tf32";
        default: return "half";
    }
}

/* ---- dense WMMA source generation ------------------------------------
 * Generates a tiled GEMM: D = alpha*A*B + beta*C, A is MxK row-major, B is
 * KxN row-major, C/D are MxN row-major, all in device global memory. One
 * warp computes one (tile_m x tile_n) output tile; warps are laid out in
 * a 1D strip along N (grid/block dims are caller-computed and passed to
 * your own cudez_launch call). K is looped in tile_k-sized steps, with a
 * #pragma unroll(k_chunks) hint on that loop (a compile-time unroll hint
 * only, not a shared-memory software-pipelining stage count -- see the
 * roadmap note at the end of this section on that distinction).
 * ---------------------------------------------------------------------- */

/* In-place replace-all of `from` with `to` in a NUL-terminated buffer of
   capacity `cap`. Bounds-checked: if a growing replacement would overrun `cap`
   it stops (leaves the remainder unmodified) rather than corrupt memory. */
/* Returns 1 if every occurrence was replaced, 0 if it ran out of buffer (in
   which case it stops -- the caller MUST treat 0 as a build failure rather than
   ship a half-retargeted kernel). */
CUDEZ_INLINE int cudez_strreplace_all_(char *buf, size_t cap,
                                       const char *from, const char *to) {
    size_t lf = strlen(from), lt = strlen(to);
    size_t used = strlen(buf);   /* running total length, kept in sync below so the
                                    loop no longer strlen's the whole buffer each pass */
    char *p = buf;
    if (lf == 0) return 1;
    while ((p = strstr(p, from)) != NULL) {
        size_t tail = used - (size_t)(p - buf) - lf;          /* chars after the match */
        if (lt > lf && used + (lt - lf) + 1 > cap) return 0;  /* no room -- report */
        memmove(p + lt, p + lf, tail + 1);                    /* shift incl NUL */
        memcpy(p, to, lt);
        used = used - lf + lt;                                /* new length (>=0: used>=lf) */
        p += lt;
    }
    return 1;
}

/* BF16 shares ldmatrix.b16 + mma register layout EXACTLY with F16 -- a raw-mma
   pipeline kernel (v6/v7/v8) differs only in the AB element type and the mma
   AB dtype. So the generator emits the proven F16 body and retargets just those
   two tokens here; the F16 output is byte-for-byte unchanged (this runs only
   for BF16). Ordering is irrelevant: the three needles are disjoint. Returns 0
   if any replacement truncated (buffer too small) so the build fails loudly
   instead of emitting a mixed __half/__nv_bfloat16 kernel. */
/* Retarget an emitted F16 raw-mma kernel to BF16 in place. INVARIANT (F9): this
   is a substring rewrite, so every generator that will be retargeted must use the
   BARE tokens `__half` / `__half2` for its AB type (both map correctly:
   __half->__nv_bfloat16, __half2->__nv_bfloat162) and must NOT emit a suffixed
   form like `__half_t`, an identifier containing `half`, or a comment/string
   containing `.f32.f16.f16.f32` that is not the mma op -- any of those would be
   silently corrupted. The current generators satisfy this (checked: only bare
   `__half` tokens). A future dtype-parameterized `typedef ... cz_ab_t;` would
   remove the constraint; until then, keep new AB-typed kernels to bare tokens. */
CUDEZ_INLINE int cudez_bf16_retarget_(char *buf, size_t cap) {
    return cudez_strreplace_all_(buf, cap, "#include <cuda_fp16.h>\n",
                                 "#include <cuda_fp16.h>\n#include <cuda_bf16.h>\n") &&
           cudez_strreplace_all_(buf, cap, "__half", "__nv_bfloat16") &&
           cudez_strreplace_all_(buf, cap, ".f32.f16.f16.f32", ".f32.bf16.bf16.f32") &&
           /* keep the CUTLASS-provenance comment honest for the BF16 op (else it
              still advertises the F16 trait the docs tell users to verify). */
           cudez_strreplace_all_(buf, cap, "F32F16F16F32_TN", "F32BF16BF16F32_TN");
}

static const char CUDEZ_I8_PIPE_SRC_[] =
    "#define CZ_LD4_(p, s) ((unsigned)(unsigned char)(p)[0] | ((unsigned)(unsigned char)(p)[(s)] << 8) | ((unsigned)(unsigned char)(p)[2*(s)] << 16) | ((unsigned)(unsigned char)(p)[3*(s)] << 24))\n"
    "extern \"C\" __global__ void %s(\n"
    "    const signed char *A, const signed char *B,\n"
    "    int *D, int M, int N, int K) {\n"
    "  /* smem_stage=5 + INT8 (1.7.0-dev): the streaming s8 kernel's exact\n"
    "     mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 fragment layouts (CUTLASS\n"
    "     mma_traits_sm80.hpp -- byte b of each 32-bit reg = ascending k), moved from\n"
    "     per-fragment GLOBAL gathers (the streaming kernel's bottleneck: ~2 TOPS,\n"
    "     11-17%% of cuBLAS) onto the v7-class cp.async pipeline: 64x64 block, 4\n"
    "     warps (each a 32x32 region = 2 m16 x 4 n8 fragments), BK=64 (two k32 mma\n"
    "     steps), 2-stage double buffer, STATIC smem 2*(64*80 + 64*80) = 20,480 B.\n"
    "     A fragments: four 4 B ld.shared each. B fragments: 4-byte column gathers\n"
    "     from the row-major panel (a later rung can swizzle these; correctness and\n"
    "     the cp.async win first -- one change per rung). Epilogue: direct s32\n"
    "     stores (no staged epilogue yet -- same policy). Index flow proven bit-exact\n"
    "     GPU-free: emu_all.py i8 gate. REQUIRES warps_per_block==4, M %% 64 == 0,\n"
    "     N %% 64 == 0, K %% 64 == 0 (launch-enforced), sm_80+. */\n"
    "  const int BK = 64, SKA = 80, SKB = 80;\n"
    "  __shared__ __align__(16) signed char As[2][64 * 80];\n"
    "  __shared__ __align__(16) signed char Bs[2][64 * 80];\n"
    "  int tid = (int)threadIdx.x;\n"
    "  int warp = tid >> 5, lane = tid & 31;\n"
    "  int grp = lane >> 2, tg = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcol = pid_n * 64;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    int k0 = ks * BK;\n"
    "    for (int i = tid; i < 64 * (BK / 16); i += (int)blockDim.x) {\n"
    "      int r = i / (BK / 16), c = (i %% (BK / 16)) * 16;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(A + (size_t)(brow + r) * K + k0 + c));\n"
    "    }\n"
    "    for (int i = tid; i < BK * (64 / 16); i += (int)blockDim.x) {\n"
    "      int r = i / (64 / 16), c = (i %% (64 / 16)) * 16;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(B + (size_t)(k0 + r) * N + bcol + c));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  int acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++)\n"
    "    for (int j = 0; j < 4; j++)\n"
    "      for (int e = 0; e < 4; e++) acc[i][j][e] = 0;\n"
    "  int k_stages = K / BK;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) {\n"
    "      stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else {\n"
    "      asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
    "    }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int kk = 0; kk < BK; kk += 32) {\n"
    "      unsigned a[2][4];\n"
    "#pragma unroll\n"
    "      for (int i = 0; i < 2; i++) {\n"
    "        const signed char *ap = &As[cur][(wr + i * 16 + grp) * SKA + kk + tg * 4];\n"
    "        a[i][0] = *(const unsigned *)(ap);\n"
    "        a[i][1] = *(const unsigned *)(ap + 8 * SKA);\n"
    "        a[i][2] = *(const unsigned *)(ap + 16);\n"
    "        a[i][3] = *(const unsigned *)(ap + 8 * SKA + 16);\n"
    "      }\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        const signed char *bp = &Bs[cur][(kk + tg * 4) * SKB + wc + j * 8 + grp];\n"
    "        unsigned b0 = CZ_LD4_(bp, SKB);\n"
    "        unsigned b1 = CZ_LD4_(bp + 16 * SKB, SKB);\n"
    "#pragma unroll\n"
    "        for (int i = 0; i < 2; i++) {\n"
    "          asm volatile(\n"
    "            \"mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 \"\n"
    "            \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
    "            : \"+r\"(acc[i][j][0]), \"+r\"(acc[i][j][1]),\n"
    "              \"+r\"(acc[i][j][2]), \"+r\"(acc[i][j][3])\n"
    "            : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
    "              \"r\"(b0), \"r\"(b1));\n"
    "        }\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  for (int i = 0; i < 2; i++) {\n"
    "    for (int j = 0; j < 4; j++) {\n"
    "      int m0 = brow + wr + i * 16 + grp;\n"
    "      int n0 = bcol + wc + j * 8 + tg * 2;\n"
    "      D[(size_t)m0 * N + n0]           = acc[i][j][0];\n"
    "      D[(size_t)m0 * N + n0 + 1]       = acc[i][j][1];\n"
    "      D[(size_t)(m0 + 8) * N + n0]     = acc[i][j][2];\n"
    "      D[(size_t)(m0 + 8) * N + n0 + 1] = acc[i][j][3];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

static const char CUDEZ_I8R2_PIPE_SRC_[] =
    "#define CZ_LD4S_(p) ((unsigned)(unsigned char)(p)[0] | ((unsigned)(unsigned char)(p)[1] << 8) | ((unsigned)(unsigned char)(p)[2] << 16) | ((unsigned)(unsigned char)(p)[3] << 24))\n"
    "extern \"C\" __global__ void %s(\n"
    "    const signed char *A, const signed char *B,\n"
    "    int *D, int M, int N, int K) {\n"
    "  /* smem_stage=5 + INT8, RUNG 2 (store_hint=1, 1.8.0-dev): rung 1's kernel with\n"
    "     (a) a 16-byte-chunk XOR swizzle on the B panel (chunk c4 stored at\n"
    "     c4 ^ (row & 3)) so the column gathers spread across banks, and (b) a staged\n"
    "     s32 epilogue: accumulators staged in the (dead) smem, then int4 (16 B)\n"
    "     coalesced stores, two 32-row passes. Fragment math identical to rung 1.\n"
    "     Proven: emu_all.py i8 rung-2 gate (bit-exact int32 incl. write-once staging\n"
    "     asserts). Same contract: warps_per_block==4, M/N/K %% 64 == 0, sm_80+. */\n"
    "  const int BK = 64, SKA = 80, SKB = 80, SGE = 68;\n"
    "  __shared__ __align__(16) signed char As[2][64 * 80];\n"
    "  __shared__ __align__(16) signed char Bs[2][64 * 80];\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int grp = lane >> 2, tg = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcol = pid_n * 64;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    int k0 = ks * BK;\n"
    "    for (int i = tid; i < 64 * (BK / 16); i += (int)blockDim.x) {\n"
    "      int r = i / (BK / 16), c = (i %% (BK / 16)) * 16;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(A + (size_t)(brow + r) * K + k0 + c));\n"
    "    }\n"
    "    for (int i = tid; i < BK * (64 / 16); i += (int)blockDim.x) {\n"
    "      int r = i / (64 / 16), c4 = i %% (64 / 16);\n"
    "      int d4 = c4 ^ (r & 3);                        /* rung-2 chunk swizzle */\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + d4 * 16]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(B + (size_t)(k0 + r) * N + bcol + c4 * 16));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  int acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0;\n"
    "  int k_stages = K / BK;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) { stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else { asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\"); }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int kk = 0; kk < BK; kk += 32) {\n"
    "      unsigned a[2][4];\n"
    "#pragma unroll\n"
    "      for (int i = 0; i < 2; i++) {\n"
    "        const signed char *ap = &As[cur][(wr + i * 16 + grp) * SKA + kk + tg * 4];\n"
    "        a[i][0] = *(const unsigned *)(ap);\n"
    "        a[i][1] = *(const unsigned *)(ap + 8 * SKA);\n"
    "        a[i][2] = *(const unsigned *)(ap + 16);\n"
    "        a[i][3] = *(const unsigned *)(ap + 8 * SKA + 16);\n"
    "      }\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        int col = wc + j * 8 + grp;\n"
    "        int cch = (col >> 4) & 3, cin = col & 15;   /* chunk index + byte-in-chunk */\n"
    "        unsigned char q0[4], q1[4];\n"
    "#pragma unroll\n"
    "        for (int b = 0; b < 4; b++) {\n"
    "          int r0 = kk + tg * 4 + b, r1 = r0 + 16;\n"
    "          q0[b] = (unsigned char)Bs[cur][r0 * SKB + ((cch ^ (r0 & 3)) << 4) + cin];\n"
    "          q1[b] = (unsigned char)Bs[cur][r1 * SKB + ((cch ^ (r1 & 3)) << 4) + cin];\n"
    "        }\n"
    "        unsigned b0 = CZ_LD4S_(q0), b1 = CZ_LD4S_(q1);\n"
    "#pragma unroll\n"
    "        for (int i = 0; i < 2; i++) {\n"
    "          asm volatile(\n"
    "            \"mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 \"\n"
    "            \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
    "            : \"+r\"(acc[i][j][0]), \"+r\"(acc[i][j][1]),\n"
    "              \"+r\"(acc[i][j][2]), \"+r\"(acc[i][j][3])\n"
    "            : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
    "              \"r\"(b0), \"r\"(b1));\n"
    "        }\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  /* staged s32 epilogue: two 32-row passes through smem (As+Bs = 10,240 B holds\n"
    "     32*68 ints = 8,704 B), then int4 coalesced stores. */\n"
    "  int *stg = (int *)&As[0][0];\n"
    "  for (int pas = 0; pas < 2; pas++) {\n"
    "    __syncthreads();\n"
    "    if ((warp >> 1) == pas) {\n"
    "      int wcp = (warp & 1) * 32;\n"
    "      for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "        int mr = i * 16 + grp, nc = wcp + j * 8 + tg * 2;\n"
    "        stg[mr * SGE + nc]           = acc[i][j][0];\n"
    "        stg[mr * SGE + nc + 1]       = acc[i][j][1];\n"
    "        stg[(mr + 8) * SGE + nc]     = acc[i][j][2];\n"
    "        stg[(mr + 8) * SGE + nc + 1] = acc[i][j][3];\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "    for (int i = tid; i < 32 * (64 / 4); i += (int)blockDim.x) {\n"
    "      int row = i / (64 / 4), c4 = (i %% (64 / 4)) * 4;\n"
    "      *(int4 *)&D[(size_t)(brow + pas * 32 + row) * N + bcol + c4] =\n"
    "          *(const int4 *)&stg[row * SGE + c4];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

static const char CUDEZ_TF32_PIPE_SRC_[] =
    "extern \"C\" __global__ void %s(\n"
    "    const float *A, const float *B, const float *Cin, float *D,\n"
    "    int M, int N, int K,\n"
    "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
    "    float alpha, float beta) {\n"
    "  /* smem_stage=5 + TF32 (1.8.0-dev): mma.sync.m16n8k8.row.col.f32.tf32.tf32.f32\n"
    "     on the v7-class cp.async pipeline. 64x64 block, 4 warps (32x32 each = 2 m16\n"
    "     x 4 n8), BK=32 (four k8 steps), 2-stage double buffer, static smem 35,840 B.\n"
    "     Each operand reg passes through cvt.rna.tf32.f32 (round-to-nearest), matching\n"
    "     cuBLAS's TF32 semantics. Direct f32 alpha/beta stores (staged epilogue is a\n"
    "     later rung). Index flow proven bit-exact: emu_all.py tf32 gate. REQUIRES\n"
    "     warps_per_block==4, M %% 64==0, N %% 64==0, K %% 32==0, sm_80+. */\n"
    "  const int BK = 32, SKA = 36, SKB = 68;\n"
    "  __shared__ __align__(16) float As[2][64 * 36];\n"
    "  __shared__ __align__(16) float Bs[2][32 * 68];\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int g = lane >> 2, tau = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcol = pid_n * 64;\n"
    "  const float *Az = A + (size_t)blockIdx.z * strideA;\n"
    "  const float *Bz = B + (size_t)blockIdx.z * strideB;\n"
    "  const float *Cz = Cin + (size_t)blockIdx.z * strideC;\n"
    "  float *Dz = D + (size_t)blockIdx.z * strideD;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    int k0 = ks * BK;\n"
    "    for (int i = tid; i < 64 * (BK / 4); i += (int)blockDim.x) {\n"
    "      int r = i / (BK / 4), c = (i %% (BK / 4)) * 4;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(Az + (size_t)(brow + r) * K + k0 + c));\n"
    "    }\n"
    "    for (int i = tid; i < BK * (64 / 4); i += (int)blockDim.x) {\n"
    "      int r = i / (64 / 4), c = (i %% (64 / 4)) * 4;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(Bz + (size_t)(k0 + r) * N + bcol + c));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  float acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0.f;\n"
    "  int k_stages = K / BK;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) { stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else { asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\"); }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int kk = 0; kk < BK; kk += 8) {\n"
    "      unsigned a[2][4];\n"
    "#pragma unroll\n"
    "      for (int i = 0; i < 2; i++) {\n"
    "        const float *ap = &As[cur][(wr + i * 16 + g) * SKA + kk + tau];\n"
    "        float f0 = ap[0], f1 = ap[8 * SKA], f2 = ap[4], f3 = ap[8 * SKA + 4];\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][0]) : \"f\"(f0));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][1]) : \"f\"(f1));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][2]) : \"f\"(f2));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][3]) : \"f\"(f3));\n"
    "      }\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        const float *bp = &Bs[cur][(kk + tau) * SKB + wc + j * 8 + g];\n"
    "        unsigned b0, b1;\n"
    "        float g0 = bp[0], g1 = bp[4 * SKB];\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(b0) : \"f\"(g0));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(b1) : \"f\"(g1));\n"
    "#pragma unroll\n"
    "        for (int i = 0; i < 2; i++) {\n"
    "          asm volatile(\n"
    "            \"mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 \"\n"
    "            \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
    "            : \"+f\"(acc[i][j][0]), \"+f\"(acc[i][j][1]),\n"
    "              \"+f\"(acc[i][j][2]), \"+f\"(acc[i][j][3])\n"
    "            : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
    "              \"r\"(b0), \"r\"(b1));\n"
    "        }\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i * 16 + g, n0 = bcol + wc + j * 8 + tau * 2;\n"
    "    size_t i00 = (size_t)m0 * N + n0, i10 = (size_t)(m0 + 8) * N + n0;\n"
    "    if (beta != 0.f) {\n"
    "      Dz[i00]   = alpha * acc[i][j][0] + beta * Cz[i00];\n"
    "      Dz[i00+1] = alpha * acc[i][j][1] + beta * Cz[i00+1];\n"
    "      Dz[i10]   = alpha * acc[i][j][2] + beta * Cz[i10];\n"
    "      Dz[i10+1] = alpha * acc[i][j][3] + beta * Cz[i10+1];\n"
    "    } else {\n"
    "      Dz[i00]   = alpha * acc[i][j][0]; Dz[i00+1] = alpha * acc[i][j][1];\n"
    "      Dz[i10]   = alpha * acc[i][j][2]; Dz[i10+1] = alpha * acc[i][j][3];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

static const char CUDEZ_I4_PIPE_SRC_[] =
    "#define CZ_NIB_(p, s, j, sh) ((unsigned)(((p)[(j)*(s)] >> (sh)) & 0xF))\n"
    "extern \"C\" __global__ void %s(\n"
    "    const signed char *A, const signed char *B,\n"
    "    int *D, int M, int N, int K) {\n"
    "  /* smem_stage=5 + INT4 (1.8.0-dev): the streaming s4 kernel's silicon-proven\n"
    "     m16n8k64.s4 fragment layouts (packed 2/byte, low nibble = even element) on\n"
    "     the v7-class cp.async pipeline. 64x64 block, 4 warps, BK=128 (two k64\n"
    "     steps), static smem 2*(64*80 + 128*48) = 22,528 B. A fragments = 32-bit\n"
    "     ld.shared (8 s4); B fragments = 8-row nibble gathers (swizzle later).\n"
    "     Direct s32 stores. Proven: emu_all.py i4 gate. REQUIRES warps_per_block==4,\n"
    "     M %% 64==0, N %% 64==0, K %% 128==0, sm_80+. */\n"
    "  const int SKA = 80, SKB = 48;\n"
    "  __shared__ __align__(16) unsigned char As[2][64 * 80];\n"
    "  __shared__ __align__(16) unsigned char Bs[2][128 * 48];\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int g = lane >> 2, tg = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcolb = (pid_n * 64) >> 1;   /* B/D col base; B in bytes */\n"
    "  int Kb = K >> 1, Nb = N >> 1;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    int kb = ks * 64;                                  /* 128 s4 = 64 bytes */\n"
    "    for (int i = tid; i < 64 * 4; i += (int)blockDim.x) {\n"
    "      int r = i / 4, c = (i %% 4) * 16;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(A + (size_t)(brow + r) * Kb + kb + c));\n"
    "    }\n"
    "    for (int i = tid; i < 128 * 2; i += (int)blockDim.x) {\n"
    "      int r = i / 2, c = (i %% 2) * 16;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(B + (size_t)(ks * 128 + r) * Nb + bcolb + c));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  int acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0;\n"
    "  int k_stages = K / 128;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) { stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else { asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\"); }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int kk = 0; kk < 128; kk += 64) {\n"
    "      unsigned a[2][4];\n"
    "#pragma unroll\n"
    "      for (int i = 0; i < 2; i++) {\n"
    "        const unsigned char *ap = &As[cur][(wr + i*16 + g) * SKA + (kk >> 1) + tg*4];\n"
    "        a[i][0] = *(const unsigned *)(ap);\n"
    "        a[i][1] = *(const unsigned *)(ap + 8 * SKA);\n"
    "        a[i][2] = *(const unsigned *)(ap + 16);\n"
    "        a[i][3] = *(const unsigned *)(ap + 8 * SKA + 16);\n"
    "      }\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        int col = wc + j*8 + g;\n"
    "        const unsigned char *bp = &Bs[cur][(kk + tg*8) * SKB + (col >> 1)];\n"
    "        int sh = (col & 1) * 4;\n"
    "        unsigned b0 = 0, b1 = 0;\n"
    "#pragma unroll\n"
    "        for (int v = 0; v < 8; v++) {\n"
    "          b0 |= CZ_NIB_(bp, SKB, v, sh) << (4 * v);\n"
    "          b1 |= CZ_NIB_(bp + 32 * SKB, SKB, v, sh) << (4 * v);\n"
    "        }\n"
    "#pragma unroll\n"
    "        for (int i = 0; i < 2; i++) {\n"
    "          asm volatile(\n"
    "            \"mma.sync.aligned.m16n8k64.row.col.s32.s4.s4.s32 \"\n"
    "            \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
    "            : \"+r\"(acc[i][j][0]), \"+r\"(acc[i][j][1]),\n"
    "              \"+r\"(acc[i][j][2]), \"+r\"(acc[i][j][3])\n"
    "            : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
    "              \"r\"(b0), \"r\"(b1));\n"
    "        }\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  int bcol = bcolb << 1;\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i*16 + g, n0 = bcol + wc + j*8 + tg*2;\n"
    "    D[(size_t)m0 * N + n0]         = acc[i][j][0];\n"
    "    D[(size_t)m0 * N + n0 + 1]     = acc[i][j][1];\n"
    "    D[(size_t)(m0+8) * N + n0]     = acc[i][j][2];\n"
    "    D[(size_t)(m0+8) * N + n0 + 1] = acc[i][j][3];\n"
    "  }\n"
    "}\n"
    "\n";

static const char CUDEZ_SP_PIPE_SRC_[] =
    "#include <cuda_fp16.h>\n"
    "%sextern \"C\" __global__ void %s(\n"
    "    const %s *A_vals, const unsigned *A_meta,\n"
    "    const %s *B, const float *Cin, float *D,\n"
    "    int M, int N, int K, float alpha, float beta) {\n"
    "  /* smem_stage=5 + 2:4 SPARSE (1.8.0-dev): the streaming mma.sp kernel's\n"
    "     silicon-proven fragments + HARDWARE-CONFIRMED metadata layout (0.7.1),\n"
    "     with A_vals and B staged through the v7-class cp.async double buffer.\n"
    "     64x64 block, 4 warps (32x32 = 2 m16 x 4 n8 sp-tiles), WK=32 -> BK=32,\n"
    "     static smem 2*(64*24 + 32*72)*2 = 15,360 B. Metadata stays in GLOBAL\n"
    "     (128 B per 16x32 tile, L2-resident, reused across pid_n). Direct\n"
    "     alpha/beta stores. Proven: emu_all.py sp gate (bit-exact through staged\n"
    "     vals + meta reconstruction). REQUIRES warps_per_block==4, M %% 64==0,\n"
    "     N %% 64==0, K %% 32==0, sm_80+. */\n"
    "  const int SKA = 24, SKB = 72;\n"
    "  __shared__ __align__(16) %s As[2][64 * 24];\n"
    "  __shared__ __align__(16) %s Bs[2][32 * 72];\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int g = lane >> 2, tau = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcol = pid_n * 64;\n"
    "  int Kc = K >> 1, k_stages = K / 32;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    for (int i = tid; i < 64 * 2; i += (int)blockDim.x) {   /* A_vals: 32 B rows */\n"
    "      int r = i / 2, c = (i %% 2) * 8;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(A_vals + (size_t)(brow + r) * Kc + ks * 16 + c));\n"
    "    }\n"
    "    for (int i = tid; i < 32 * 8; i += (int)blockDim.x) {   /* B: 128 B rows */\n"
    "      int r = i / 8, c = (i %% 8) * 8;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(B + (size_t)(ks * 32 + r) * N + bcol + c));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  float acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0.f;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) { stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else { asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\"); }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int i = 0; i < 2; i++) {\n"
    "      const %s *Ab = &As[cur][(wr + i * 16) * SKA];\n"
    "      unsigned a0 = *(const unsigned*)(Ab + (g  ) * SKA + 2*tau    );\n"
    "      unsigned a1 = *(const unsigned*)(Ab + (g+8) * SKA + 2*tau    );\n"
    "      unsigned a2 = *(const unsigned*)(Ab + (g  ) * SKA + 2*tau + 8);\n"
    "      unsigned a3 = *(const unsigned*)(Ab + (g+8) * SKA + 2*tau + 8);\n"
    "      unsigned meta = A_meta[((size_t)((brow + wr + i*16) >> 4) * k_stages + ks) * 32 + lane];\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        const %s *Bb = &Bs[cur][wc + j * 8 + g];\n"
    "        unsigned b0 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 1)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 0)*SKB);\n"
    "        unsigned b1 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 9)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 8)*SKB);\n"
    "        unsigned b2 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+17)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+16)*SKB);\n"
    "        unsigned b3 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+25)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+24)*SKB);\n"
    "        asm volatile(\n"
    "          \"%s \"\n"
    "          \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, \"\n"
    "          \"{%%8,%%9,%%10,%%11}, {%%0,%%1,%%2,%%3}, %%12, 0x0;\\n\"\n"
    "          : \"+f\"(acc[i][j][0]), \"+f\"(acc[i][j][1]),\n"
    "            \"+f\"(acc[i][j][2]), \"+f\"(acc[i][j][3])\n"
    "          : \"r\"(a0), \"r\"(a1), \"r\"(a2), \"r\"(a3),\n"
    "            \"r\"(b0), \"r\"(b1), \"r\"(b2), \"r\"(b3), \"r\"(meta));\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i * 16 + g, n0 = bcol + wc + j * 8 + 2 * tau;\n"
    "    size_t i00 = (size_t)m0 * N + n0, i10 = (size_t)(m0 + 8) * N + n0;\n"
    "    if (beta != 0.f) {\n"
    "      D[i00]   = alpha * acc[i][j][0] + beta * Cin[i00];\n"
    "      D[i00+1] = alpha * acc[i][j][1] + beta * Cin[i00+1];\n"
    "      D[i10]   = alpha * acc[i][j][2] + beta * Cin[i10];\n"
    "      D[i10+1] = alpha * acc[i][j][3] + beta * Cin[i10+1];\n"
    "    } else {\n"
    "      D[i00]   = alpha * acc[i][j][0]; D[i00+1] = alpha * acc[i][j][1];\n"
    "      D[i10]   = alpha * acc[i][j][2]; D[i10+1] = alpha * acc[i][j][3];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

/* 1.0.3-dev, INT8 2:4 SPARSE via mma.sp.m16n8k32.s8.s8 (UNVERIFIED ON REAL
   HARDWARE -- shipped per explicit instruction to proceed anyway, clearly
   flagged). Ampere's sparse tensor cores genuinely support this: 2:4
   structured sparsity at INT8 is real hardware, same pattern F16/BF16
   sparse already use (confirmed via PTX ISA section 9.7.14.6.2.5, "Matrix
   Fragments for sparse mma.m16n8k32 with .u8/.s8 integer type", and
   independently via the Jigsaw paper's Ampere sparse-shape table: "u8/s8:
   m16n8k32, m16n8k64" -- the SAME M x N fragment geometry, 16x8, that
   F16's own sparse m16n8k32 form uses).

   What IS confirmed and reused directly:
     - Block/warp/tile geometry: identical to CUDEZ_SP_PIPE_SRC_ above
       (64x64 block, 4 warps, 2 m16 x 4 n8 sp-tiles per warp) -- sparsity
       ratio and warp count don't depend on element width.
     - Metadata handling: GLOBAL, same addressing formula as F16 sparse --
       the 2:4 metadata encoding (which 2 of 4 positions survived pruning)
       is a hardware-level scheme independent of the sparse operand's
       element type in principle (same claim the BF16 sparse smoke test
       added this session is checking).
     - A/B staging byte-packing: independently re-derived for INT8's 1-byte
       elements (vs F16's 2-byte), keeping every cp.async transfer at
       exactly 16 bytes (the hardware's async-copy granularity) -- worked
       out by hand: A's per-stage load is 16 real int8 K-elements/row (one
       16-byte cp.async, HALF the chunk-count F16 needed since int8
       elements are half the byte-width); B mirrors this at 4 chunks/row
       instead of F16's 8. Padding (SKA/SKB) kept at F16's same NUMBER of
       pad elements, re-checked to still land on a non-power-of-2 byte
       stride mod 128 (i.e., still avoids the naive bank-conflict trap).

   What is NOT independently confirmed -- the highest-risk part:
     - The compute loop's exact a0/a1 register-packing for mma.sp.s8.s8 is
       the single least-confident part of this kernel. Byte-coverage math
       says a 2:4-compressed A row-group (K=32 real -> 16 stored int8
       elements = 16 B) split the way F16 sparse splits it (row-groups g
       and g+8, i.e. this code's a0/a1) only accounts for 8 B total (one
       4-byte register per row-group) -- HALF of the 16 B a full K=32
       row-group should need by that same accounting. Either a0/a1 (2
       registers) is wrong and this needs 4 (a0..a3, matching F16 sparse's
       register count exactly), or the per-thread data split for INT8's
       mma.sp genuinely differs from F16's in a way this derivation didn't
       anticipate. I could not resolve this discrepancy without real
       hardware -- it is exactly the kind of thing this codebase's own
       history (F16 sparse needing a "candidate probe" against real
       silicon, not just PTX ISA docs) says needs a real GPU to nail down.
       THIS is the single most likely point of a silent wrong-answer if
       this kernel is wrong at all -- confirm or refute this file's own
       numerical smoke test result first, before trusting anything
       downstream of this kernel's output. If it fails, this exact
       register-count question is where to look first.
     - b0 register count and packing: similarly derived, similarly
       unconfirmed. F16 sparse needs 4 B registers; this code uses 1
       (`b0`), reasoning that INT8's 1-byte elements need proportionally
       fewer registers for the same K coverage -- unverified against real
       SASS, same caveat as the A-side above.
   REQUIRES warps_per_block==4, M %% 64==0, N %% 64==0, K %% 32==0, sm_80+. */
static const char CUDEZ_SPI8_PIPE_SRC_[] =
    "%sextern \"C\" __global__ void %s(\n"
    "    const signed char *A_vals, const unsigned *A_meta,\n"
    "    const signed char *B, int *D,\n"
    "    int M, int N, int K) {\n"
    "  /* UNVERIFIED (see cudez.h doc comment above CUDEZ_SPI8_PIPE_SRC_ for the\n"
    "     full derivation and specific risk areas -- read that before trusting\n"
    "     this kernel's output). 64x64 block, 4 warps, WK=32 real K/stage,\n"
    "     Kc=K/2 compressed A columns. Static smem: 2*(64*16 + 32*64) = 6,144 B\n"
    "     (see the SKA/SKB fix note below -- was 7,680 B before removing the\n"
    "     misalignment-causing padding; unpadded is also SMALLER, not a tradeoff).\n"
    "     REQUIRES warps_per_block==4, M %% 64==0, N %% 64==0, K %% 32==0, sm_80+.\n"
    "     SKA/SKB FIXED (1.0.3-dev r3, after a real CUDA_ERROR_MISALIGNED_ADDRESS\n"
    "     on sm_86): the original SKA=24/SKB=72 were padded away from the real\n"
    "     16B/64B row sizes for bank-conflict avoidance, without checking a\n"
    "     SEPARATE, stricter requirement -- cp.async's 16-byte transfers need a\n"
    "     16-byte-ALIGNED destination for EVERY row, and 24/72 are not multiples\n"
    "     of 16, so half of every A-row and half of every B-row transfer faulted\n"
    "     (confirmed: i*24 %% 16 != 0 for every odd i, r*72 %% 16 != 0 for half of\n"
    "     r in [0,32)). Any multiple of 16 satisfies alignment; re-checked bank\n"
    "     distribution for the actual concern (the compute loop's a0/a1 reads,\n"
    "     unsigned* casts) rather than assuming padding helps -- SKA=16 (NO\n"
    "     padding) gives PERFECT bank distribution (32/32 banks hit across a\n"
    "     warp), better than the broken SKA=24 (26/32) and far better than the\n"
    "     naively-safer-looking SKA=32 (16/32, worst option). SKB's compute-loop\n"
    "     reads are single-byte (unsigned char) with no alignment requirement of\n"
    "     their own, so SKB=64 (no padding) is correctness-safe; a real bank-\n"
    "     conflict throughput pass for B can follow once numerics are confirmed.\n"
    "     Also checked (separate from the smem-destination fix above): the\n"
    "     GLOBAL-memory cp.async SOURCE addresses (A_vals+.../B+...) need the\n"
    "     same 16B alignment. This kernel's existing launch contract (K %% 32==0,\n"
    "     N %% 64==0, already enforced by cudez_mma_launch) is sufficient --\n"
    "     K%%32==0 makes Kc=K/2 a multiple of 16, and N%%64==0 makes N a multiple\n"
    "     of 16, so every stride term in both cp.async source-address formulas\n"
    "     is itself a multiple of 16 given a 16B-aligned base pointer (true for\n"
    "     any cuMemAlloc-backed buffer, per the empirical >=256B floor). No new\n"
    "     constraint needed; this was a real thing to check, not assumed. */\n"
    "  const int SKA = 16, SKB = 64;\n"
    "  __shared__ __align__(16) signed char As[2][64 * 16];\n"
    "  __shared__ __align__(16) signed char Bs[2][32 * 64];\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int grp = lane >> 2, lid = lane & 3;\n"
    "  int bt_per_row = N / 64;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 64, bcol = pid_n * 64;\n"
    "  int Kc = K >> 1, k_stages = K / 32;\n"
    "  auto stage = [&](int ks, int bf) {\n"
    "    /* 1.0.3-dev: A (64 iterations) and B (128 iterations) merged into one\n"
    "       flat 192-element grid-stride loop across all blockDim.x=128 threads,\n"
    "       applying the same fix the sparse v9 A-staging rebalance used earlier\n"
    "       this session (confirmed a real win on real hardware there): the\n"
    "       original two-loop form left A's bound (64) below blockDim.x (128),\n"
    "       so 64 of 128 threads sat idle while A staged, then all 128 worked\n"
    "       during B. Verified by construction: this mapping produces the exact\n"
    "       same 64 A-destinations and 128 B-destinations as two separate loops\n"
    "       would (checked computationally, not just by inspection -- same\n"
    "       discipline as the v9 fix). Every cp.async transfer stays 16 bytes. */\n"
    "    for (int i = tid; i < 64 + 128; i += (int)blockDim.x) {\n"
    "      if (i < 64) {\n"
    "        unsigned dst = (unsigned)__cvta_generic_to_shared(&As[bf][i * SKA]);\n"
    "        asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                     :: \"r\"(dst), \"l\"(A_vals + (size_t)(brow + i) * Kc + ks * 16));\n"
    "      } else {\n"
    "        int j = i - 64, r = j / 4, c = (j %% 4) * 16;\n"
    "        unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[bf][r * SKB + c]);\n"
    "        asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                     :: \"r\"(dst), \"l\"(B + (size_t)(ks * 32 + r) * N + bcol + c));\n"
    "      }\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 1) * 32, wc = (warp & 1) * 32;\n"
    "  int acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0;\n"
    "  stage(0, 0);\n"
    "%sfor (int ks = 0; ks < k_stages; ks++) {\n"
    "    int cur = ks & 1;\n"
    "    if (ks + 1 < k_stages) { stage(ks + 1, cur ^ 1);\n"
    "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    } else { asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\"); }\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int i = 0; i < 2; i++) {\n"
    "      /* a0/a1 packing: CZ_LD4_-style 4-byte unaligned load, mirroring\n"
    "         confirmed dense INT8's pattern. Re-derived and confirmed by an\n"
    "         invariant check (1.0.3-dev r2, after a real ptxas rejection):\n"
    "         sparse A's compressed elements/thread should equal F16 sparse's\n"
    "         compressed elements/thread (8) divided by int8's larger\n"
    "         elements-per-register (4 vs F16's 2) = 2 registers. Matches what\n"
    "         was already here. */\n"
    "      const signed char *Ab = &As[cur][(wr + i * 16) * SKA];\n"
    "      const signed char *a_lo = Ab + grp * SKA + lid * 4;\n"
    "      const signed char *a_hi = Ab + (grp + 8) * SKA + lid * 4;\n"
    "      unsigned a0 = *(const unsigned*)(a_lo);\n"
    "      unsigned a1 = *(const unsigned*)(a_hi);\n"
    "      unsigned meta = A_meta[((size_t)((brow + wr + i*16) >> 4) * k_stages + ks) * 32 + lane];\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        /* b0/b1 packing FIXED (1.0.3-dev r2): the original draft had\n"
    "           only ONE B register -- ptxas rejected the resulting mma.sp as\n"
    "           malformed PTX (CUDA_ERROR_INVALID_PTX at cuModuleLoadDataEx,\n"
    "           confirmed on real sm_86 hardware). Re-derivation: B is dense/\n"
    "           uncompressed in BOTH sparse and dense mma -- 2:4 sparsity only\n"
    "           ever compresses A -- so B's fragment element count per thread\n"
    "           must be IDENTICAL between dense and sparse forms of the same\n"
    "           instruction shape. Dense INT8's confirmed m16n8k32 B fragment\n"
    "           is 2 registers (b_reg[0]/b_reg[1], offset by 16 K-rows, same\n"
    "           column stride) -- sparse INT8 needs the same 2, not 1. b1\n"
    "           mirrors b0 exactly, offset 16 rows into the staged K-panel\n"
    "           (SKB row stride, matching dense INT8's `bp + 16*N` pattern\n"
    "           adapted to this kernel's padded smem layout). */\n"
    "        const signed char *Bb = &Bs[cur][wc + j * 8 + grp];\n"
    "        const signed char *b_lo = Bb + lid * 4 * SKB;\n"
    "        const signed char *b_hi = b_lo + 16 * SKB;\n"
    "        unsigned b0 = ((unsigned)(unsigned char)b_lo[0])\n"
    "                    | ((unsigned)(unsigned char)b_lo[SKB] << 8)\n"
    "                    | ((unsigned)(unsigned char)b_lo[2*SKB] << 16)\n"
    "                    | ((unsigned)(unsigned char)b_lo[3*SKB] << 24);\n"
    "        unsigned b1 = ((unsigned)(unsigned char)b_hi[0])\n"
    "                    | ((unsigned)(unsigned char)b_hi[SKB] << 8)\n"
    "                    | ((unsigned)(unsigned char)b_hi[2*SKB] << 16)\n"
    "                    | ((unsigned)(unsigned char)b_hi[3*SKB] << 24);\n"
    "        asm volatile(\n"
    "          \"mma.sp.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 \"\n"
    "          \"{%%0,%%1,%%2,%%3}, {%%4,%%5}, \"\n"
    "          \"{%%6,%%7}, {%%0,%%1,%%2,%%3}, %%8, 0x0;\\n\"\n"
    "          : \"+r\"(acc[i][j][0]), \"+r\"(acc[i][j][1]),\n"
    "            \"+r\"(acc[i][j][2]), \"+r\"(acc[i][j][3])\n"
    "          : \"r\"(a0), \"r\"(a1), \"r\"(b0), \"r\"(b1), \"r\"(meta));\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  }\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i * 16 + grp, n0 = bcol + wc + j * 8 + 2 * lid;\n"
    "    D[(size_t)m0 * N + n0]       = acc[i][j][0];\n"
    "    D[(size_t)m0 * N + n0 + 1]   = acc[i][j][1];\n"
    "    D[(size_t)(m0+8) * N + n0]   = acc[i][j][2];\n"
    "    D[(size_t)(m0+8) * N + n0+1] = acc[i][j][3];\n"
    "  }\n"
    "}\n"
    "\n";

static const char CUDEZ_SP9_PIPE_SRC_[] =
    "#include <cuda_fp16.h>\n"
    "%sextern \"C\" __global__ void %s(\n"
    "    const %s *A_vals, const unsigned *A_meta,\n"
    "    const %s *B, const float *Cin, float *D,\n"
    "    int M, int N, int K, float alpha, float beta) {\n"
    "  /* sparse + smem_stage=7 (1.9.0-dev): the sparse v7 kernel's fragments and\n"
    "     HARDWARE-CONFIRMED metadata layout, scaled to the dense-v9 recipe: 128x128\n"
    "     block, 16 warps (4x4 of 32x32 regions), BK=32 (one mma.sp step per tile),\n"
    "     3-STAGE cp.async ring. Compressed A halves the panel, so the ring is\n"
    "     3*(128*24 + 32*136)*2 = 44,544 B and fits STATIC smem -- no dynamic-smem\n"
    "     opt-in, unlike dense v9. Ring schedule byte-identical to v9 (prologue\n"
    "     fills 2, steady wait_group 2, drain 1 -> 0). Metadata stays GLOBAL\n"
    "     (L2-resident, reused across pid_n). Direct alpha/beta stores (sparse v7's\n"
    "     epilogue, unchanged -- the ring is the one change this rung makes).\n"
    "     Proven: emu_all.py sp-ring gate, bit-exact + write-once + ring-hazard\n"
    "     asserts on 4 shapes incl. num_k < depth. REQUIRES warps_per_block==16,\n"
    "     M %% 128==0, N %% 128==0, K %% 32==0, sm_80+. */\n"
    "  const int SKA = 24, SKB = 136, ASLOT = 128 * 24, BSLOT = 32 * 136;\n"
    "  __shared__ __align__(16) %s ring[3 * (128 * 24 + 32 * 136)];\n"
    "  %s *As = ring;\n"
    "  %s *Bs = ring + 3 * ASLOT;\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int g = lane >> 2, tau = lane & 3;\n"
    "  int bt_per_row = N / 128;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 128, bcol = pid_n * 128;\n"
    "  int Kc = K >> 1, k_stages = K / 32;\n"
    "  /* 1.0.3-dev, UNVERIFIED on real hardware: A_vals (256 elements) and B\n"
    "     (512 elements) used to be staged in two separate grid-stride loops,\n"
    "     each `for (i = tid; i < N; i += blockDim.x)` with blockDim.x == 512.\n"
    "     Because A's loop bound (256) is HALF of blockDim.x, threads 256-511\n"
    "     never entered that loop at all -- only the first 256 threads did any\n"
    "     work while A staged, then all 512 threads worked while B staged. The\n"
    "     dense v9 kernel this rung is based on has no such gap: its A-stage\n"
    "     bound is BM*(BK/8) = 128*4 = 512, exactly blockDim.x, so every thread\n"
    "     participates throughout. Structural finding, not a measured one (no\n"
    "     GPU access here): this asymmetry is a plausible contributor to sparse\n"
    "     v9 losing to dense v9 despite moving LESS total smem traffic per\n"
    "     stage (A+B = 4096+8192=12288 B sparse vs 8192+8192=16384 B dense) --\n"
    "     mma.sp halves the compute but wall-clock barely moves, consistent\n"
    "     with the kernel not being mma-bound. Below: A and B merged into one\n"
    "     flat 768-element index space split across all 512 threads (256\n"
    "     threads issue 2 cp.async each, 256 issue 1 -- vs the old split's\n"
    "     effective 256-issue-2/256-issue-1 split happening in two idle-then-\n"
    "     busy phases instead of one evenly-scheduled phase). Total cp.async\n"
    "     issues, bytes moved, and every (destination, source) pair are BYTE-\n"
    "     FOR-BYTE unchanged from the original two loops -- only which thread\n"
    "     issues which transfer changes. MUST be re-verified with ncu on real\n"
    "     hardware before being promoted past this dev branch: a merged loop\n"
    "     can look correct and still lose to the two-loop form if e.g. the\n"
    "     compiler schedules the now-branchier index math worse than the\n"
    "     original's simpler bound checks, or if cp.async queue-depth effects\n"
    "     dominate over idle-warp effects. */\n"
    "  auto stage = [&](int ks, int slot) {\n"
    "    for (int i = tid; i < 256 + 512; i += (int)blockDim.x) {\n"
    "      if (i < 256) {          /* A_vals: 32 B rows, 256 elements total */\n"
    "        int r = i / 2, c = (i %% 2) * 8;\n"
    "        unsigned dst = (unsigned)__cvta_generic_to_shared(&As[slot * ASLOT + r * SKA + c]);\n"
    "        asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                     :: \"r\"(dst), \"l\"(A_vals + (size_t)(brow + r) * Kc + ks * 16 + c));\n"
    "      } else {                /* B: 256 B rows, 512 elements total */\n"
    "        int j = i - 256, r = j / 16, c = (j %% 16) * 8;\n"
    "        unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[slot * BSLOT + r * SKB + c]);\n"
    "        asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                     :: \"r\"(dst), \"l\"(B + (size_t)(ks * 32 + r) * N + bcol + c));\n"
    "      }\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 2) * 32, wc = (warp & 3) * 32;\n"
    "  float acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0.f;\n"
    "  auto compute = [&](int ks, int slot) {\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int i = 0; i < 2; i++) {\n"
    "      const %s *Ab = &As[slot * ASLOT + (wr + i * 16) * SKA];\n"
    "      unsigned a0 = *(const unsigned*)(Ab + (g  ) * SKA + 2*tau    );\n"
    "      unsigned a1 = *(const unsigned*)(Ab + (g+8) * SKA + 2*tau    );\n"
    "      unsigned a2 = *(const unsigned*)(Ab + (g  ) * SKA + 2*tau + 8);\n"
    "      unsigned a3 = *(const unsigned*)(Ab + (g+8) * SKA + 2*tau + 8);\n"
    "      unsigned meta = A_meta[((size_t)((brow + wr + i*16) >> 4) * k_stages + ks) * 32 + lane];\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        const %s *Bb = &Bs[slot * BSLOT + wc + j * 8 + g];\n"
    "        unsigned b0 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 1)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 0)*SKB);\n"
    "        unsigned b1 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 9)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 8)*SKB);\n"
    "        unsigned b2 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+17)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+16)*SKB);\n"
    "        unsigned b3 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+25)*SKB) << 16)\n"
    "                    |  (unsigned)*(const unsigned short*)(Bb + (2*tau+24)*SKB);\n"
    "        asm volatile(\n"
    "          \"%s \"\n"
    "          \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, \"\n"
    "          \"{%%8,%%9,%%10,%%11}, {%%0,%%1,%%2,%%3}, %%12, 0x0;\\n\"\n"
    "          : \"+f\"(acc[i][j][0]), \"+f\"(acc[i][j][1]),\n"
    "            \"+f\"(acc[i][j][2]), \"+f\"(acc[i][j][3])\n"
    "          : \"r\"(a0), \"r\"(a1), \"r\"(a2), \"r\"(a3),\n"
    "            \"r\"(b0), \"r\"(b1), \"r\"(b2), \"r\"(b3), \"r\"(meta));\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  };\n"
    "  stage(0, 0);\n"
    "  if (k_stages > 1) stage(1, 1);\n"
    "%sfor (int ks = 0; ks + 2 < k_stages; ks++) {\n"
    "    stage(ks + 2, (ks + 2) %% 3);\n"
    "    asm volatile(\"cp.async.wait_group 2;\\n\" ::: \"memory\");\n"
    "    compute(ks, ks %% 3);\n"
    "  }\n"
    "  if (k_stages >= 2) {\n"
    "    asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    compute(k_stages - 2, (k_stages - 2) %% 3);\n"
    "  }\n"
    "  asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
    "  compute(k_stages - 1, (k_stages - 1) %% 3);\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i * 16 + g, n0 = bcol + wc + j * 8 + 2 * tau;\n"
    "    size_t i00 = (size_t)m0 * N + n0, i10 = (size_t)(m0 + 8) * N + n0;\n"
    "    if (beta != 0.f) {\n"
    "      D[i00]   = alpha * acc[i][j][0] + beta * Cin[i00];\n"
    "      D[i00+1] = alpha * acc[i][j][1] + beta * Cin[i00+1];\n"
    "      D[i10]   = alpha * acc[i][j][2] + beta * Cin[i10];\n"
    "      D[i10+1] = alpha * acc[i][j][3] + beta * Cin[i10+1];\n"
    "    } else {\n"
    "      D[i00]   = alpha * acc[i][j][0]; D[i00+1] = alpha * acc[i][j][1];\n"
    "      D[i10]   = alpha * acc[i][j][2]; D[i10+1] = alpha * acc[i][j][3];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

/* ---- pick_pipeline dispatcher (1.9.0-dev) ----------------------------------
   Returns cudez_mma_defaults(dt) with smem_stage (and store_hint) set to the
   JUDGED best pipeline for the shape, per the 1.6.0-1.8.0 verdict ledger:
     F16/BF16 : v7 (stage 5) <= 1024-class, v9 (stage 7) >= 2048-class;
                v8 if v9's dynamic smem is unavailable is the CALLER's fallback.
                KNEE IS PROVISIONAL at max(M,N,K) >= 2048 -- the 1280/1536/1792
                sweep refines it (roadmap; ask the box).
     TF32/INT8/INT4 : stage-5 pipeline wherever the 64-multiple (128 for INT4 K)
                contract admits; streaming otherwise. INT8 rung 1 (hint=0) --
                rung 2 was retired tried-and-negative.
     sparse   : stage 5 within the sparse lane (stage 7 pending its verdict).
   Falls back toward streaming whenever the shape misses a pipeline contract,
   preferring correctness over cleverness. */
CUDEZ_INLINE cudez_mma_config cudez_mma_pick(cudez_mma_dtype dt, int sparse,
                                             int M, int N, int K) {
    cudez_mma_config c = cudez_mma_defaults(dt);
    int m64  = (M % 64 == 0)  && (N % 64 == 0);
    int m128 = (M % 128 == 0) && (N % 128 == 0);
    c.sparse = sparse ? 1 : 0;
    if (sparse) {
        /* 1.0.3-dev: INT8 sparse v7 exists (CUDEZ_SPI8_PIPE_SRC_) but is
           UNVERIFIED on real hardware -- never auto-select it here. An
           ordinary cudez_gemm(..., CUDEZ_MMA_INT8, ...) call with a
           sparse-shaped GEMM must NOT silently route through unverified
           code; INT8 sparse stays streaming-only (smem_stage=0, which
           does not exist for INT8 sparse either -- see is_int rejection
           in cudez_mma_launch) via this picker. A caller who wants it
           must set smem_stage=5 by hand, which is itself the signal that
           they've read the warning on that kernel. */
        if (dt == CUDEZ_MMA_INT8) return c;
        if (m128 && (K % 32 == 0))     c.smem_stage = 7;  /* 1.9.0: ring, in-lane pick */
        else if (m64 && (K % 32 == 0)) c.smem_stage = 5;
        return c;                                   /* else streaming sparse */
    }
    switch (dt) {
    case CUDEZ_MMA_F16: case CUDEZ_MMA_BF16: {
        int big = (M >= 2048 || N >= 2048 || K >= 2048);   /* provisional knee */
        if (big && m128 && (K % 32 == 0))      c.smem_stage = 7;   /* v9 */
        else if (m64 && (K % 64 == 0))         c.smem_stage = 5;   /* v7 */
        /* BUG-1 (1.0.2): a stage-4 (v6) branch lived here gated on K%32 --
           but v6's LAUNCH contract is K%64, identical to v7's, so this
           branch fired ONLY for K = 32 mod 64: exactly the shapes v6
           rejects. After 1.0.1 routed cudez_gemm through pick, legal
           shapes (64x64x96 etc.) errored instead of streaming. The
           dispatcher now does what its doc always promised: falls
           through to streaming. */
        break; }
    case CUDEZ_MMA_TF32: {
        int big = (M >= 2048 || N >= 2048 || K >= 2048);
        if (big && m128 && (K % 16 == 0))      c.smem_stage = 7;  /* 1.10.0 ring */
        else if (m64 && (K % 32 == 0))         c.smem_stage = 5;
        break; }
    case CUDEZ_MMA_INT8: if (m64 && (K % 64 == 0))  c.smem_stage = 5; break;
    case CUDEZ_MMA_INT4: if (m64 && (K % 128 == 0)) c.smem_stage = 5; break;
    default: break;
    }
    return c;
}

static const char CUDEZ_TF32R_PIPE_SRC_[] =
    "extern \"C\" __global__ void %s(\n"
    "    const float *A, const float *B, const float *Cin, float *D,\n"
    "    int M, int N, int K,\n"
    "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
    "    float alpha, float beta) {\n"
    "  /* smem_stage=7 + TF32 (1.10.0-dev): the tf32 v7 pipeline scaled to the\n"
    "     v9-class ring. TF32's 4 B elements double the panels, so the ring runs\n"
    "     BK=16 (two k8 steps per tile): 3*(128*20 + 16*136)*4 = 56,832 B of\n"
    "     DYNAMIC smem -- numerically the same blob dense v9 allocates, so the\n"
    "     launch path needs no new size. 128x128 block, 16 warps, v9 schedule\n"
    "     byte-identical (prologue 2, wait_group 2, drain 1 -> 0). cvt.rna on all\n"
    "     operands. Proven: emu_all.py tf32-ring gate. REQUIRES warps_per_block==16,\n"
    "     M %% 128==0, N %% 128==0, K %% 16==0, sm_80+, 56,832 B dyn smem. */\n"
    "  const int SKA = 20, SKB = 136, ASLOT = 128 * 20, BSLOT = 16 * 136;\n"
    "  extern __shared__ __align__(16) unsigned char cz_smem[];\n"
    "  float *As = (float *)cz_smem;\n"
    "  float *Bs = (float *)(cz_smem + 3 * ASLOT * 4);\n"
    "  int tid = (int)threadIdx.x, warp = tid >> 5, lane = tid & 31;\n"
    "  int g = lane >> 2, tau = lane & 3;\n"
    "  int bt_per_row = N / 128;\n"
    "  int pid_m = (int)blockIdx.x / bt_per_row, pid_n = (int)blockIdx.x %% bt_per_row;\n"
    "  int brow = pid_m * 128, bcol = pid_n * 128;\n"
    "  const float *Az = A + (size_t)blockIdx.z * strideA;\n"
    "  const float *Bz = B + (size_t)blockIdx.z * strideB;\n"
    "  const float *Cz = Cin + (size_t)blockIdx.z * strideC;\n"
    "  float *Dz = D + (size_t)blockIdx.z * strideD;\n"
    "  int k_stages = K / 16;\n"
    "  auto stage = [&](int ks, int slot) {\n"
    "    for (int i = tid; i < 128 * 4; i += (int)blockDim.x) {\n"
    "      int r = i / 4, c = (i %% 4) * 4;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&As[slot * ASLOT + r * SKA + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(Az + (size_t)(brow + r) * K + ks * 16 + c));\n"
    "    }\n"
    "    for (int i = tid; i < 16 * 32; i += (int)blockDim.x) {\n"
    "      int r = i / 32, c = (i %% 32) * 4;\n"
    "      unsigned dst = (unsigned)__cvta_generic_to_shared(&Bs[slot * BSLOT + r * SKB + c]);\n"
    "      asm volatile(\"cp.async.cg.shared.global [%%0], [%%1], 16;\\n\"\n"
    "                   :: \"r\"(dst), \"l\"(Bz + (size_t)(ks * 16 + r) * N + bcol + c));\n"
    "    }\n"
    "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
    "  };\n"
    "  int wr = (warp >> 2) * 32, wc = (warp & 3) * 32;\n"
    "  float acc[2][4][4];\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++)\n"
    "    for (int e = 0; e < 4; e++) acc[i][j][e] = 0.f;\n"
    "  auto compute = [&](int ks, int slot) {\n"
    "    (void)ks;\n"
    "    __syncthreads();\n"
    "#pragma unroll\n"
    "    for (int kk = 0; kk < 16; kk += 8) {\n"
    "      unsigned a[2][4];\n"
    "#pragma unroll\n"
    "      for (int i = 0; i < 2; i++) {\n"
    "        const float *ap = &As[slot * ASLOT + (wr + i * 16 + g) * SKA + kk + tau];\n"
    "        float f0 = ap[0], f1 = ap[8 * SKA], f2 = ap[4], f3 = ap[8 * SKA + 4];\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][0]) : \"f\"(f0));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][1]) : \"f\"(f1));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][2]) : \"f\"(f2));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(a[i][3]) : \"f\"(f3));\n"
    "      }\n"
    "#pragma unroll\n"
    "      for (int j = 0; j < 4; j++) {\n"
    "        const float *bp = &Bs[slot * BSLOT + (kk + tau) * SKB + wc + j * 8 + g];\n"
    "        unsigned b0, b1;\n"
    "        float g0 = bp[0], g1 = bp[4 * SKB];\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(b0) : \"f\"(g0));\n"
    "        asm volatile(\"cvt.rna.tf32.f32 %%0, %%1;\" : \"=r\"(b1) : \"f\"(g1));\n"
    "#pragma unroll\n"
    "        for (int i = 0; i < 2; i++) {\n"
    "          asm volatile(\n"
    "            \"mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 \"\n"
    "            \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
    "            : \"+f\"(acc[i][j][0]), \"+f\"(acc[i][j][1]),\n"
    "              \"+f\"(acc[i][j][2]), \"+f\"(acc[i][j][3])\n"
    "            : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
    "              \"r\"(b0), \"r\"(b1));\n"
    "        }\n"
    "      }\n"
    "    }\n"
    "    __syncthreads();\n"
    "  };\n"
    "  stage(0, 0);\n"
    "  if (k_stages > 1) stage(1, 1);\n"
    "%sfor (int ks = 0; ks + 2 < k_stages; ks++) {\n"
    "    stage(ks + 2, (ks + 2) %% 3);\n"
    "    asm volatile(\"cp.async.wait_group 2;\\n\" ::: \"memory\");\n"
    "    compute(ks, ks %% 3);\n"
    "  }\n"
    "  if (k_stages >= 2) {\n"
    "    asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
    "    compute(k_stages - 2, (k_stages - 2) %% 3);\n"
    "  }\n"
    "  asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
    "  compute(k_stages - 1, (k_stages - 1) %% 3);\n"
    "  for (int i = 0; i < 2; i++) for (int j = 0; j < 4; j++) {\n"
    "    int m0 = brow + wr + i * 16 + g, n0 = bcol + wc + j * 8 + tau * 2;\n"
    "    size_t i00 = (size_t)m0 * N + n0, i10 = (size_t)(m0 + 8) * N + n0;\n"
    "    if (beta != 0.f) {\n"
    "      Dz[i00]   = alpha * acc[i][j][0] + beta * Cz[i00];\n"
    "      Dz[i00+1] = alpha * acc[i][j][1] + beta * Cz[i00+1];\n"
    "      Dz[i10]   = alpha * acc[i][j][2] + beta * Cz[i10];\n"
    "      Dz[i10+1] = alpha * acc[i][j][3] + beta * Cz[i10+1];\n"
    "    } else {\n"
    "      Dz[i00]   = alpha * acc[i][j][0]; Dz[i00+1] = alpha * acc[i][j][1];\n"
    "      Dz[i10]   = alpha * acc[i][j][2]; Dz[i10+1] = alpha * acc[i][j][3];\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n";

CUDEZ_INLINE int cudez_mma_source_(const cudez_mma_config *c, const char *name,
                                   char *buf, size_t bufsz) {
    const char *fragtype = cudez_mma_dtype_fragtype_(c->dtype_ab);
    const char *ctype = (c->dtype_ab == CUDEZ_MMA_TF32) ? "float"
                       : cudez_mma_dtype_ctype_(c->dtype_ab);
    int is_bf16 = (c->dtype_ab == CUDEZ_MMA_BF16);
    int is_tf32 = (c->dtype_ab == CUDEZ_MMA_TF32);
    /* TF32: load_matrix_sync does NOT truncate the mantissa on its own --
       NVIDIA's documented pattern applies wmma::__float_to_tf32 per element.
       Emit the conversion for TF32 only; "" for the others. */
    const char *tf32a = is_tf32
        ? "    for (int i = 0; i < a_frag.num_elements; i++)\n"
          "      a_frag.x[i] = wmma::__float_to_tf32(a_frag.x[i]);\n"
        : "";
    const char *tf32b = is_tf32
        ? "    for (int i = 0; i < b_frag.num_elements; i++)\n"
          "      b_frag.x[i] = wmma::__float_to_tf32(b_frag.x[i]);\n"
        : "";
    /* k_chunks<=0 must never reach NVRTC as "#pragma unroll(0)". The build path
       already rejects it (cudez_mma_cfg_valid_), but cudez_mma_source() is a
       public introspection entry that bypasses that validator, so guard here too
       (0.7.0, BUG-5): omit the pragma entirely and let the compiler decide. */
    char unroll[32];
    if (c->k_chunks > 0) snprintf(unroll, sizeof unroll, "#pragma unroll(%d)\n", c->k_chunks);
    else                 unroll[0] = '\0';
    int len;

    if (c->smem_stage == 6) {
        /* ---- rung (f), 1.4.0-dev: pipeline v8 (opt-in) --------------------
           v6/v7's raw ldmatrix.m8n8.x4 + mma.sync.m16n8k16 inner loop,
           UNCHANGED, tiled to a 128x128 BLOCK: 16 warps (512 threads), each
           the same 32x32 (2x2 tiles) warp-region v7 used. MOTIVE (LEDGER 1.3.0
           4096 finding): at large shapes cudez is DRAM-bound -- the 64x64 tile
           reloads A/B panels too often. 128x128 doubles arithmetic intensity
           BM*BN/(2*(BM+BN)) from 16 to 32 FLOP/byte, the specific gap to cuBLAS.
           DESIGN: BK=32 (not v7's 64) is deliberate -- it lands the A/B panels
           at 37,888 B, UNDER the 48 KB static-smem ceiling (no dynamic smem
           plumbing) AND fits 2 blocks/SM, the occupancy a wide tile needs to
           hide latency. So intensity goes up while occupancy goes UP too.
           Epilogue: v7's float4-coalesced staging, in TWO passes (upper/lower
           64 rows) so each 64x128 half-tile (33,792 B) reuses the now-dead
           panel blob -- v7's trick, split to fit the wider block with zero
           extra footprint. NEW launch contract: warps_per_block==16,
           M %% 128==0, N %% 128==0, K %% 32==0 (major-version rung).
           Index flow proven GPU-free: emu_v8.py -- bit-exact + write-once +
           cp.async/float4 alignment asserts, 4 gate shapes incl. 2x2 blocks. */
        const char *v8_stage =
            "  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BK/8), col = (i % (BK/8)) * 8;\n"
            "      const __half *g = Ab + (long long)(brow + row) * K + (k0 + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&As[bf*BM*SKA + row*SKA + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BN/8), col = (i % (BN/8)) * 8;\n"
            "      const __half *g = Bb + (long long)(k0 + row) * N + (bcol + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&Bs[bf*BK*SKB + row*SKB + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n"
            "  stage(0, 0);\n";
        const char *v8_loop =
            "  for (int ks = 0; ks < k_stages; ks++) {\n"
            "    int cur = ks & 1;\n"
            "    if (ks + 1 < k_stages) {\n"
            "      stage(ks + 1, cur ^ 1);\n"
            "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    } else {\n"
            "      asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "    }\n"
            "    __syncthreads();\n"
            "#pragma unroll\n"
            "    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* A: one ldmatrix.x4 per 16-row tile (M0..M3 = the m16k16 A frag). */\n"
            "      unsigned a[2][4];\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++) {\n"
            "        unsigned sa = (unsigned)__cvta_generic_to_shared(\n"
            "            &As[cur*BM*SKA + (wr + i*WM + (lane & 15))*SKA + kk + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(a[i][0]), \"=r\"(a[i][1]), \"=r\"(a[i][2]), \"=r\"(a[i][3])\n"
            "                     : \"r\"(sa));\n"
            "      }\n"
            "      /* B: one ldmatrix.x4.trans per 16-col tile; regs {0,1}->n+0..7, {2,3}->n+8..15. */\n"
            "      unsigned b[2][4];\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        unsigned sb = (unsigned)__cvta_generic_to_shared(\n"
            "            &Bs[cur*BK*SKB + (kk + (lane & 15))*SKB + wc + j*WN + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(b[j][0]), \"=r\"(b[j][1]), \"=r\"(b[j][2]), \"=r\"(b[j][3])\n"
            "                     : \"r\"(sb));\n"
            "      }\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "        for (int j = 0; j < 2; j++) {\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][0][0]), \"+f\"(acc[i][j][0][1]),\n"
            "                         \"+f\"(acc[i][j][0][2]), \"+f\"(acc[i][j][0][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][0]), \"r\"(b[j][1]));\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][1][0]), \"+f\"(acc[i][j][1][1]),\n"
            "                         \"+f\"(acc[i][j][1][2]), \"+f\"(acc[i][j][1][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][2]), \"r\"(b[j][3]));\n"
            "        }\n"
            "    }\n"
            "    __syncthreads();\n"
            "  }\n";
        const char *v8_epi =
            "  /* epilogue, rung (f): v7's float4 store path, TWO passes. Each pass\n"
            "     stages a 64x128 half-tile (33,792 B) through the dead panel blob\n"
            "     (37,888 B) at stride SG=132 (16B-aligned float4), then streams it\n"
            "     out as st.global.v4. Warps 0-7 own rows 0-63 (pass 0), 8-15 own\n"
            "     64-127 (pass 1); the launch contract (N %% 128==0, bcol %% 128==0)\n"
            "     aligns the global side. */\n"
            "  {\n"
            "    int g = lane >> 2, r = lane & 3;\n"
            "#pragma unroll\n"
            "    for (int pass = 0; pass < 2; pass++) {\n"
            "      if ((warp >> 3) == pass) {\n"
            "#pragma unroll\n"
            "        for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "          for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "            for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "              for (int e = 0; e < 4; e++) {\n"
            "                int m = wr + i*WM + g + 8*(e >> 1);\n"
            "                int n = wc + j*WN + h*8 + 2*r + (e & 1);\n"
            "                stg[(m - pass*64) * SG + n] = acc[i][j][h][e];\n"
            "              }\n"
            "      }\n"
            "      __syncthreads();\n"
            "      for (int idx = (int)threadIdx.x; idx < 64 * (BN/4); idx += (int)blockDim.x) {\n"
            "        int row = idx / (BN/4), c4 = (idx % (BN/4)) * 4;\n"
            "        float4 v = *(const float4 *)&stg[row * SG + c4];\n"
            "        long long out = (long long)(brow + pass*64 + row) * N + (bcol + c4);\n"
            "        if (beta != 0.0f) {\n"
            "          float4 c = *(const float4 *)&Cb[out];\n"
            "          v.x = alpha*v.x + beta*c.x; v.y = alpha*v.y + beta*c.y;\n"
            "          v.z = alpha*v.z + beta*c.z; v.w = alpha*v.w + beta*c.w;\n"
            "        } else if (alpha != 1.0f) {\n"
            "          v.x *= alpha; v.y *= alpha; v.z *= alpha; v.w *= alpha;\n"
            "        }\n"
            "        *(float4 *)&Db[out] = v;\n"
            "      }\n"
            "      __syncthreads();\n"
            "    }\n"
            "  }\n"
            "}\n";
        len = snprintf(buf, bufsz,
            "#include <cuda_fp16.h>\n"
            "extern \"C\" __global__ void %s(\n"
            "    const __half *A, const __half *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=6 (pipeline v8, rung (f)): v6/v7's raw ldmatrix+mma.sync\n"
            "     inner loop at a 128x128 block (16 warps). BK=32 keeps the A/B panels\n"
            "     under 48 KB (static smem, 2 blocks/SM); the wider tile doubles\n"
            "     arithmetic intensity to 32 FLOP/byte -- the DRAM-traffic gap to cuBLAS\n"
            "     at large shapes (LEDGER 1.3.0). Fragment layouts sourced from CUTLASS\n"
            "     MMA_Traits SM80_16x8x16_F32F16F16F32_TN + PTX ISA tables, NOT\n"
            "     hand-derived. REQUIRES warps_per_block==16, M %% 128==0, N %% 128==0,\n"
            "     K %% 32==0 (launch-enforced), sm_80+. */\n"
            "  const int WM = 16, WN = 16, WK = 16;\n"
            "  const int BM = 128, BN = 128, BK = 32;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;     /* padded row strides */\n"
            "  const int SG  = BN + 4;                   /* epilogue float staging stride */\n"
            "  /* single static blob: As | Bs during compute (37,888 B < 48 KB),\n"
            "     reused as the float4 staging tile in the epilogue. */\n"
            "  __shared__ __align__(16) unsigned char cz_smem[2*BM*SKA*2 + 2*BK*SKB*2];\n"
            "  __half *As  = (__half *)cz_smem;                       /* [bf][row*SKA+col] */\n"
            "  __half *Bs  = (__half *)(cz_smem + 2*BM*SKA*2);        /* [bf][row*SKB+col] */\n"
            "  float  *stg = (float  *)cz_smem;                       /* [row*SG+col] */\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const __half *Ab = A   + bz * strideA;\n"
            "  const __half *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int bt_per_col = M / BM;\n"
            "  const int GROUP_M = 8;\n"
            "  long long pid = (long long)blockIdx.x;\n"
            "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
            "  int group_id = (int)(pid / pid_in_group);\n"
            "  int first_m = group_id * GROUP_M;\n"
            "  int group_m = bt_per_col - first_m;\n"
            "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
            "  int pid_m = first_m + (int)(pid %% group_m);\n"
            "  int pid_n = (int)((pid %% pid_in_group) / group_m);\n"
            "  int brow = pid_m * BM;\n"
            "  int bcol = pid_n * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);       /* 0..15 */\n"
            "  int lane = (int)(threadIdx.x & 31);\n"
            "  int wr = (warp >> 2) * (2*WM), wc = (warp & 3) * (2*WN);  /* 4x4 warp grid */\n"
            "  /* per-thread accumulators: [A-tile i][B-tile j][n8 half][4 regs] = 32 floats,\n"
            "     the same count v7 held -- the warp does the identical 32x32 region. */\n"
            "  float acc[2][2][2][4];\n"
            "#pragma unroll\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "      for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "        for (int e = 0; e < 4; e++) acc[i][j][h][e] = 0.0f;\n"
            "  int k_stages = K / BK;\n",
            name);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len, "%s%s%s%s",
                            v8_stage, unroll, v8_loop, v8_epi);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        }
        if (c->dtype_ab == CUDEZ_MMA_BF16 && !cudez_bf16_retarget_(buf, bufsz)) return 0;
        return 1;
    }

    if (c->smem_stage == 7 && c->dtype_ab == CUDEZ_MMA_TF32) {
        /* TF32 on the v9-class ring (1.10.0-dev). Frozen bar: smoke PASS AND
           beats TF32 v7 (incumbent) at 2048^3 + 4096^3 with disjoint trials;
           target band 80-90%% of cuBLAS TF32. */
        len = snprintf(buf, bufsz, CUDEZ_TF32R_PIPE_SRC_, name, unroll);
        return (len > 0 && (size_t)len < bufsz);
    }
    if (c->smem_stage == 7) {
        if (c->dtype_ab != CUDEZ_MMA_F16 && c->dtype_ab != CUDEZ_MMA_BF16)
            return 0;   /* tripwire: dtype-specific stage-7 kernels dispatch
                           ABOVE this block; falling through here emitted the
                           F16 v9 kernel for TF32 (garbage numerics at K%%32==0,
                           ILLEGAL ADDRESS at K<32 via k_stages==0 -> tile -1). */
        /* ---- v9 (smem_stage=7): v8's 128x128 raw-mma kernel, BK=32, with a
           3-STAGE cp.async RING BUFFER replacing v8's 2-stage double buffer.
           MOTIVE (sm_86 ptxas: v8 = 70 regs -> register-bound to 1 block/SM):
           a 3rd smem stage is occupancy-free and buys 2 K-tiles of cp.async
           lookahead (v8 has 1) to hide DRAM latency at the low occupancy a
           128x128 tile is stuck with -- the specific ceiling v8 hit (~69%% of
           cuBLAS at 4096). Ring blob = 56,832 B: ABOVE the 48 KB static ceiling
           so DYNAMIC smem (launch opts in via cuFuncSetAttribute
           MAX_DYNAMIC_SHARED_SIZE_BYTES); below the 100 KB sm_86 cap so still
           1 block/SM. Same 16-warp/128-tile launch contract as v8. Inner loop,
           ldmatrix/mma fragments, and the 2-pass float4 epilogue are BYTE-FOR-
           BYTE v8. Schedule (prologue fills 2, steady keeps 2 in flight via
           wait_group 2, drain unwinds wait_group 1 then 0; ring slot = ks%%3)
           proven GPU-free: emu_v9.py -- bit-exact + write-once + ring-safety
           (prefetch slot != compute slot; slot holds the right tile; a prefetch
           only evicts an already-computed tile), 7 shapes incl. num_k<depth and
           12-tile deep wraps. */
        const char *v9_stage =
"  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BK/8), col = (i % (BK/8)) * 8;\n"
            "      const __half *g = Ab + (long long)(brow + row) * K + (k0 + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&As[bf*BM*SKA + row*SKA + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BN/8), col = (i % (BN/8)) * 8;\n"
            "      const __half *g = Bb + (long long)(k0 + row) * N + (bcol + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&Bs[bf*BK*SKB + row*SKB + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n";
        const char *v9_compute =
            "  auto compute = [&](int cur) {\n"
            "    __syncthreads();\n"
"    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* A: one ldmatrix.x4 per 16-row tile (M0..M3 = the m16k16 A frag). */\n"
            "      unsigned a[2][4];\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++) {\n"
            "        unsigned sa = (unsigned)__cvta_generic_to_shared(\n"
            "            &As[cur*BM*SKA + (wr + i*WM + (lane & 15))*SKA + kk + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(a[i][0]), \"=r\"(a[i][1]), \"=r\"(a[i][2]), \"=r\"(a[i][3])\n"
            "                     : \"r\"(sa));\n"
            "      }\n"
            "      /* B: one ldmatrix.x4.trans per 16-col tile; regs {0,1}->n+0..7, {2,3}->n+8..15. */\n"
            "      unsigned b[2][4];\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        unsigned sb = (unsigned)__cvta_generic_to_shared(\n"
            "            &Bs[cur*BK*SKB + (kk + (lane & 15))*SKB + wc + j*WN + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(b[j][0]), \"=r\"(b[j][1]), \"=r\"(b[j][2]), \"=r\"(b[j][3])\n"
            "                     : \"r\"(sb));\n"
            "      }\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "        for (int j = 0; j < 2; j++) {\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][0][0]), \"+f\"(acc[i][j][0][1]),\n"
            "                         \"+f\"(acc[i][j][0][2]), \"+f\"(acc[i][j][0][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][0]), \"r\"(b[j][1]));\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][1][0]), \"+f\"(acc[i][j][1][1]),\n"
            "                         \"+f\"(acc[i][j][1][2]), \"+f\"(acc[i][j][1][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][2]), \"r\"(b[j][3]));\n"
            "        }\n"
            "    }\n"
            "    __syncthreads();\n"
            "  };\n";
        const char *v9_prologue =
            "  stage(0, 0);\n"
            "  if (k_stages > 1) stage(1, 1);\n";
        const char *v9_steady =
            "  for (int ks = 0; ks + 2 < k_stages; ks++) {\n"
            "    stage(ks + 2, (ks + 2) % 3);\n"
            "    asm volatile(\"cp.async.wait_group 2;\\n\" ::: \"memory\");\n"
            "    compute(ks % 3);\n"
            "  }\n"
            "  if (k_stages >= 2) {\n"
            "    asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    compute((k_stages - 2) % 3);\n"
            "  }\n"
            "  asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "  compute((k_stages - 1) % 3);\n";
        const char *v9_epi =
            "  /* epilogue, rung (f): v7's float4 store path, TWO passes. Each pass\n"
            "     stages a 64x128 half-tile (33,792 B) through the dead panel blob\n"
            "     (37,888 B) at stride SG=132 (16B-aligned float4), then streams it\n"
            "     out as st.global.v4. Warps 0-7 own rows 0-63 (pass 0), 8-15 own\n"
            "     64-127 (pass 1); the launch contract (N %% 128==0, bcol %% 128==0)\n"
            "     aligns the global side. */\n"
            "  {\n"
            "    int g = lane >> 2, r = lane & 3;\n"
            "#pragma unroll\n"
            "    for (int pass = 0; pass < 2; pass++) {\n"
            "      if ((warp >> 3) == pass) {\n"
            "#pragma unroll\n"
            "        for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "          for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "            for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "              for (int e = 0; e < 4; e++) {\n"
            "                int m = wr + i*WM + g + 8*(e >> 1);\n"
            "                int n = wc + j*WN + h*8 + 2*r + (e & 1);\n"
            "                stg[(m - pass*64) * SG + n] = acc[i][j][h][e];\n"
            "              }\n"
            "      }\n"
            "      __syncthreads();\n"
            "      for (int idx = (int)threadIdx.x; idx < 64 * (BN/4); idx += (int)blockDim.x) {\n"
            "        int row = idx / (BN/4), c4 = (idx % (BN/4)) * 4;\n"
            "        float4 v = *(const float4 *)&stg[row * SG + c4];\n"
            "        long long out = (long long)(brow + pass*64 + row) * N + (bcol + c4);\n"
            "        if (beta != 0.0f) {\n"
            "          float4 c = *(const float4 *)&Cb[out];\n"
            "          v.x = alpha*v.x + beta*c.x; v.y = alpha*v.y + beta*c.y;\n"
            "          v.z = alpha*v.z + beta*c.z; v.w = alpha*v.w + beta*c.w;\n"
            "        } else if (alpha != 1.0f) {\n"
            "          v.x *= alpha; v.y *= alpha; v.z *= alpha; v.w *= alpha;\n"
            "        }\n"
            "        *(float4 *)&Db[out] = v;\n"
            "      }\n"
            "      __syncthreads();\n"
            "    }\n"
            "  }\n"
            "}\n";
        len = snprintf(buf, bufsz,
            "#include <cuda_fp16.h>\n"
            "extern \"C\" __global__ void %s(\n"
            "    const __half *A, const __half *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=7 (pipeline v9): v8's raw ldmatrix+mma.sync inner loop at\n"
            "     a 128x128 block (16 warps), with v8's 2-stage cp.async double buffer\n"
            "     replaced by a 3-STAGE ring buffer. The 3-deep A/B panels are 56,832 B\n"
            "     -- above the 48 KB static ceiling, so DYNAMIC smem (the launcher opts\n"
            "     in via cuFuncSetAttribute); below the 100 KB sm_86 cap, so still 1\n"
            "     block/SM. v8 is register-bound to 1 block/SM (70 regs on sm_86), so\n"
            "     the 3rd stage is occupancy-free and buys a 2nd K-tile of cp.async\n"
            "     lookahead to hide DRAM latency. Fragment layouts sourced from CUTLASS\n"
            "     MMA_Traits SM80_16x8x16_F32F16F16F32_TN + PTX ISA tables, NOT hand-\n"
            "     derived. REQUIRES warps_per_block==16, M %% 128==0, N %% 128==0,\n"
            "     K %% 32==0 (launch-enforced), sm_80+. */\n"
            "  const int WM = 16, WN = 16, WK = 16;\n"
            "  const int BM = 128, BN = 128, BK = 32;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;     /* padded row strides */\n"
            "  const int SG  = BN + 4;                   /* epilogue float staging stride */\n"
            "  /* single static blob: As | Bs during compute (37,888 B < 48 KB),\n"
            "     reused as the float4 staging tile in the epilogue. */\n"
            "  extern __shared__ __align__(16) unsigned char cz_smem[];\n"
            "  __half *As  = (__half *)cz_smem;                       /* [bf][row*SKA+col] */\n"
            "  __half *Bs  = (__half *)(cz_smem + 3*BM*SKA*2);\n"
            "  float  *stg = (float  *)cz_smem;                       /* [row*SG+col] */\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const __half *Ab = A   + bz * strideA;\n"
            "  const __half *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int bt_per_col = M / BM;\n"
            "  const int GROUP_M = 8;\n"
            "  long long pid = (long long)blockIdx.x;\n"
            "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
            "  int group_id = (int)(pid / pid_in_group);\n"
            "  int first_m = group_id * GROUP_M;\n"
            "  int group_m = bt_per_col - first_m;\n"
            "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
            "  int pid_m = first_m + (int)(pid %% group_m);\n"
            "  int pid_n = (int)((pid %% pid_in_group) / group_m);\n"
            "  int brow = pid_m * BM;\n"
            "  int bcol = pid_n * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);       /* 0..15 */\n"
            "  int lane = (int)(threadIdx.x & 31);\n"
            "  int wr = (warp >> 2) * (2*WM), wc = (warp & 3) * (2*WN);  /* 4x4 warp grid */\n"
            "  /* per-thread accumulators: [A-tile i][B-tile j][n8 half][4 regs] = 32 floats,\n"
            "     the same count v7 held -- the warp does the identical 32x32 region. */\n"
            "  float acc[2][2][2][4];\n"
            "#pragma unroll\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "      for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "        for (int e = 0; e < 4; e++) acc[i][j][h][e] = 0.0f;\n"
            "  int k_stages = K / BK;\n",
            name);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len, "%s%s%s%s%s%s",
                            v9_stage, v9_compute, v9_prologue, unroll, v9_steady, v9_epi);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        }
        if (c->dtype_ab == CUDEZ_MMA_BF16 && !cudez_bf16_retarget_(buf, bufsz)) return 0;
        return 1;
    }


    if (c->smem_stage == 8) {
        /* ---- v10 (smem_stage=8): the v9 ring DEEPENED to 4 STAGES.
           MOTIVE (run 1784082434): 2->3 stages bought +7.2%% at 4096^3 and the
           margin GREW with size -- classic latency-hiding still paying out, so
           buy one more K-tile of cp.async lookahead (3 in flight vs v9's 2).
           Ring blob = 4 slots = 75,776 B: dynamic smem, still under the 100 KB
           sm_86 cap -> still 1 block/SM, occupancy unchanged. Inner loop,
           fragments, and epilogue remain BYTE-FOR-BYTE v8/v9. Schedule
           (prologue fills 3, steady keeps 3 in flight via wait_group 3, drain
           unwinds 2 -> 1 -> 0; slot = ks%%4) proven GPU-free: emu_all.py v10
           gate -- bit-exact + write-once + ring-safety on 7 shapes incl.
           num_k<depth and 16-tile wraps. Judged by the same frozen pattern as
           v9: accept iff it CLEARS v9 at >=2048^3 (disjoint trials) with no
           small-shape regression; expect diminishing returns vs v9's +7%%. */
        const char *v10_stage =
"  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BK/8), col = (i % (BK/8)) * 8;\n"
            "      const __half *g = Ab + (long long)(brow + row) * K + (k0 + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&As[bf*BM*SKA + row*SKA + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      int row = i / (BN/8), col = (i % (BN/8)) * 8;\n"
            "      const __half *g = Bb + (long long)(k0 + row) * N + (bcol + col);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(&Bs[bf*BK*SKB + row*SKB + col]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n";
        const char *v10_compute =
            "  auto compute = [&](int cur) {\n"
            "    __syncthreads();\n"
"    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* A: one ldmatrix.x4 per 16-row tile (M0..M3 = the m16k16 A frag). */\n"
            "      unsigned a[2][4];\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++) {\n"
            "        unsigned sa = (unsigned)__cvta_generic_to_shared(\n"
            "            &As[cur*BM*SKA + (wr + i*WM + (lane & 15))*SKA + kk + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(a[i][0]), \"=r\"(a[i][1]), \"=r\"(a[i][2]), \"=r\"(a[i][3])\n"
            "                     : \"r\"(sa));\n"
            "      }\n"
            "      /* B: one ldmatrix.x4.trans per 16-col tile; regs {0,1}->n+0..7, {2,3}->n+8..15. */\n"
            "      unsigned b[2][4];\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        unsigned sb = (unsigned)__cvta_generic_to_shared(\n"
            "            &Bs[cur*BK*SKB + (kk + (lane & 15))*SKB + wc + j*WN + (lane >> 4)*8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(b[j][0]), \"=r\"(b[j][1]), \"=r\"(b[j][2]), \"=r\"(b[j][3])\n"
            "                     : \"r\"(sb));\n"
            "      }\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "        for (int j = 0; j < 2; j++) {\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][0][0]), \"+f\"(acc[i][j][0][1]),\n"
            "                         \"+f\"(acc[i][j][0][2]), \"+f\"(acc[i][j][0][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][0]), \"r\"(b[j][1]));\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][1][0]), \"+f\"(acc[i][j][1][1]),\n"
            "                         \"+f\"(acc[i][j][1][2]), \"+f\"(acc[i][j][1][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][2]), \"r\"(b[j][3]));\n"
            "        }\n"
            "    }\n"
            "    __syncthreads();\n"
            "  };\n";
        const char *v10_prologue =
            "  stage(0, 0);\n"
            "  if (k_stages > 1) stage(1, 1);\n"
            "  if (k_stages > 2) stage(2, 2);\n";
        const char *v10_steady =
            "  for (int ks = 0; ks + 3 < k_stages; ks++) {\n"
            "    stage(ks + 3, (ks + 3) % 4);\n"
            "    asm volatile(\"cp.async.wait_group 3;\\n\" ::: \"memory\");\n"
            "    compute(ks % 4);\n"
            "  }\n"
            "  if (k_stages >= 3) {\n"
            "    asm volatile(\"cp.async.wait_group 2;\\n\" ::: \"memory\");\n"
            "    compute((k_stages - 3) % 4);\n"
            "  }\n"
            "  if (k_stages >= 2) {\n"
            "    asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    compute((k_stages - 2) % 4);\n"
            "  }\n"
            "  asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "  compute((k_stages - 1) % 4);\n";
        const char *v10_epi =
            "  /* epilogue, rung (f): v7's float4 store path, TWO passes. Each pass\n"
            "     stages a 64x128 half-tile (33,792 B) through the dead panel blob\n"
            "     (37,888 B) at stride SG=132 (16B-aligned float4), then streams it\n"
            "     out as st.global.v4. Warps 0-7 own rows 0-63 (pass 0), 8-15 own\n"
            "     64-127 (pass 1); the launch contract (N %% 128==0, bcol %% 128==0)\n"
            "     aligns the global side. */\n"
            "  {\n"
            "    int g = lane >> 2, r = lane & 3;\n"
            "#pragma unroll\n"
            "    for (int pass = 0; pass < 2; pass++) {\n"
            "      if ((warp >> 3) == pass) {\n"
            "#pragma unroll\n"
            "        for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "          for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "            for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "              for (int e = 0; e < 4; e++) {\n"
            "                int m = wr + i*WM + g + 8*(e >> 1);\n"
            "                int n = wc + j*WN + h*8 + 2*r + (e & 1);\n"
            "                stg[(m - pass*64) * SG + n] = acc[i][j][h][e];\n"
            "              }\n"
            "      }\n"
            "      __syncthreads();\n"
            "      for (int idx = (int)threadIdx.x; idx < 64 * (BN/4); idx += (int)blockDim.x) {\n"
            "        int row = idx / (BN/4), c4 = (idx % (BN/4)) * 4;\n"
            "        float4 v = *(const float4 *)&stg[row * SG + c4];\n"
            "        long long out = (long long)(brow + pass*64 + row) * N + (bcol + c4);\n"
            "        if (beta != 0.0f) {\n"
            "          float4 c = *(const float4 *)&Cb[out];\n"
            "          v.x = alpha*v.x + beta*c.x; v.y = alpha*v.y + beta*c.y;\n"
            "          v.z = alpha*v.z + beta*c.z; v.w = alpha*v.w + beta*c.w;\n"
            "        } else if (alpha != 1.0f) {\n"
            "          v.x *= alpha; v.y *= alpha; v.z *= alpha; v.w *= alpha;\n"
            "        }\n"
            "        *(float4 *)&Db[out] = v;\n"
            "      }\n"
            "      __syncthreads();\n"
            "    }\n"
            "  }\n"
            "}\n";
        len = snprintf(buf, bufsz,
            "#include <cuda_fp16.h>\n"
            "extern \"C\" __global__ void %s(\n"
            "    const __half *A, const __half *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=8 (pipeline v10): v8's raw ldmatrix+mma.sync inner loop at\n"
            "     a 128x128 block (16 warps), with v8's 2-stage cp.async double buffer\n"
            "     replaced by a 4-STAGE ring buffer. The 4-deep A/B panels are 75,776 B\n"
            "     -- above the 48 KB static ceiling, so DYNAMIC smem (the launcher opts\n"
            "     in via cuFuncSetAttribute); below the 100 KB sm_86 cap, so still 1\n"
            "     block/SM. v8 is register-bound to 1 block/SM (70 regs on sm_86), so\n"
            "     the extra stages are occupancy-free and buy a 3rd K-tile of cp.async\n"
            "     lookahead to hide DRAM latency. Fragment layouts sourced from CUTLASS\n"
            "     MMA_Traits SM80_16x8x16_F32F16F16F32_TN + PTX ISA tables, NOT hand-\n"
            "     derived. REQUIRES warps_per_block==16, M %% 128==0, N %% 128==0,\n"
            "     K %% 32==0 (launch-enforced), sm_80+. */\n"
            "  const int WM = 16, WN = 16, WK = 16;\n"
            "  const int BM = 128, BN = 128, BK = 32;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;     /* padded row strides */\n"
            "  const int SG  = BN + 4;                   /* epilogue float staging stride */\n"
            "  /* single static blob: As | Bs during compute (37,888 B < 48 KB),\n"
            "     reused as the float4 staging tile in the epilogue. */\n"
            "  extern __shared__ __align__(16) unsigned char cz_smem[];\n"
            "  __half *As  = (__half *)cz_smem;                       /* [bf][row*SKA+col] */\n"
            "  __half *Bs  = (__half *)(cz_smem + 4*BM*SKA*2);\n"
            "  float  *stg = (float  *)cz_smem;                       /* [row*SG+col] */\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const __half *Ab = A   + bz * strideA;\n"
            "  const __half *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int bt_per_col = M / BM;\n"
            "  const int GROUP_M = 8;\n"
            "  long long pid = (long long)blockIdx.x;\n"
            "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
            "  int group_id = (int)(pid / pid_in_group);\n"
            "  int first_m = group_id * GROUP_M;\n"
            "  int group_m = bt_per_col - first_m;\n"
            "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
            "  int pid_m = first_m + (int)(pid %% group_m);\n"
            "  int pid_n = (int)((pid %% pid_in_group) / group_m);\n"
            "  int brow = pid_m * BM;\n"
            "  int bcol = pid_n * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);       /* 0..15 */\n"
            "  int lane = (int)(threadIdx.x & 31);\n"
            "  int wr = (warp >> 2) * (2*WM), wc = (warp & 3) * (2*WN);  /* 4x4 warp grid */\n"
            "  /* per-thread accumulators: [A-tile i][B-tile j][n8 half][4 regs] = 32 floats,\n"
            "     the same count v7 held -- the warp does the identical 32x32 region. */\n"
            "  float acc[2][2][2][4];\n"
            "#pragma unroll\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "      for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "        for (int e = 0; e < 4; e++) acc[i][j][h][e] = 0.0f;\n"
            "  int k_stages = K / BK;\n",
            name);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len, "%s%s%s%s%s%s",
                            v10_stage, v10_compute, v10_prologue, unroll, v10_steady, v10_epi);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        }
        if (c->dtype_ab == CUDEZ_MMA_BF16 && !cudez_bf16_retarget_(buf, bufsz)) return 0;
        return 1;
    }



    if (c->smem_stage == 5 && c->dtype_ab == CUDEZ_MMA_TF32) {
        /* TF32 on the v7-class pipeline (1.8.0-dev). Frozen bar: smoke-correct
           AND >=2x the streaming TF32 kernel at >=1024^3. */
        len = snprintf(buf, bufsz, CUDEZ_TF32_PIPE_SRC_, name, unroll);
        return (len > 0 && (size_t)len < bufsz);
    }
    if (c->smem_stage == 5 && c->dtype_ab == CUDEZ_MMA_INT4) {
        /* INT4 on the v7-class pipeline (1.8.0-dev). Frozen bar: smoke-correct
           AND >=2x the streaming INT4 kernel at >=1024^3 (no external baseline). */
        len = snprintf(buf, bufsz, CUDEZ_I4_PIPE_SRC_, name, unroll);
        return (len > 0 && (size_t)len < bufsz);
    }
    if (c->smem_stage == 5 && c->dtype_ab == CUDEZ_MMA_INT8) {
        /* ---- INT8 on the v7-class pipeline (1.7.0-dev) ---------------------
           See the generated kernel comment for the design; frozen judgment:
           accept iff smoke-correct on silicon AND bench clears the streaming
           i8 kernel by >=2x at >=1024^3 (it is a different design class, so
           the bar is the incumbent, not cuBLAS parity in one rung). */
        len = snprintf(buf, bufsz,
                       c->store_hint == 1 ? CUDEZ_I8R2_PIPE_SRC_ : CUDEZ_I8_PIPE_SRC_,
                       name, unroll);
        return (len > 0 && (size_t)len < bufsz);
    }
    if (c->smem_stage == 5) {
        /* ---- rung (e), 1.3.0-dev: pipeline v7 (opt-in) --------------------
           Pipeline v6's body -- identical ldmatrix + mma.sync inner loop --
           with the register-direct epilogue replaced by a smem-staged,
           float4-coalesced write-out. WHY: v6's epilogue compiled to 96
           scalar st.global.f32 (PTX receipt, LEDGER 1.2.0 follow-up);
           wmma.store had been giving v5 internal 128-bit row coalescing for
           free, and losing it cost ~6%% at 1024^3. v7 stages the 64x64
           float tile through the idle As buffer (17,408 B needed, 18,432 B
           available: smem footprint and occupancy UNCHANGED, ptxas sm_86:
           72 reg, 0 spills, 36,864 B) and streams it out as st.global.v4
           (13 vector stores in PTX vs v6's 96 scalar). Stage stride 68
           floats keeps every float4 16 B-aligned; the launch contract
           (N %% 64 == 0) aligns the global side. Index flow proven
           GPU-free: emu_v67.py, bit-exact + write-once + alignment asserts
           at both gate shapes. F16 dense only, same launch contract. */
        const char *v7_stage =
            "  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      const __half *g = Ab + (long long)(brow + i / (BK/8)) * K\n"
            "                       + (k0 + (i % (BK/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &As[bf][(i / (BK/8)) * SKA + (i % (BK/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      const __half *g = Bb + (long long)(k0 + i / (BN/8)) * N\n"
            "                       + (bcol + (i % (BN/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &Bs[bf][(i / (BN/8)) * SKB + (i % (BN/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n"
            "  stage(0, 0);\n";
        const char *v7_loop =
            "  for (int ks = 0; ks < k_stages; ks++) {\n"
            "    int cur = ks & 1;\n"
            "    if (ks + 1 < k_stages) {\n"
            "      stage(ks + 1, cur ^ 1);\n"
            "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    } else {\n"
            "      asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "    }\n"
            "    __syncthreads();\n"
            "#pragma unroll\n"
            "    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* A: one ldmatrix.x4 per 16-row tile. Thread t supplies the row\n"
            "         address for 8x8 matrix t/8; matrices land in registers as\n"
            "         M0=[rows 0-7, cols 0-7], M1=[8-15, 0-7], M2=[0-7, 8-15],\n"
            "         M3=[8-15, 8-15] -- exactly the m16k16 A-fragment register order. */\n"
            "      unsigned a[2][4];\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++) {\n"
            "        unsigned sa = (unsigned)__cvta_generic_to_shared(\n"
            "            &As[cur][(wr + i*WM + (lane & 15)) * SKA + kk + (lane >> 4) * 8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(a[i][0]), \"=r\"(a[i][1]), \"=r\"(a[i][2]), \"=r\"(a[i][3])\n"
            "                     : \"r\"(sa));\n"
            "      }\n"
            "      /* B: one ldmatrix.x4.trans per 16-col tile over the k16 x n16\n"
            "         region; the transpose delivers the col-major B fragment\n"
            "         m16n8k16.row.col expects. Regs {0,1} feed the n+0..7 mma,\n"
            "         {2,3} the n+8..15 mma. */\n"
            "      unsigned b[2][4];\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        unsigned sb = (unsigned)__cvta_generic_to_shared(\n"
            "            &Bs[cur][(kk + (lane & 15)) * SKB + wc + j*WN + (lane >> 4) * 8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(b[j][0]), \"=r\"(b[j][1]), \"=r\"(b[j][2]), \"=r\"(b[j][3])\n"
            "                     : \"r\"(sb));\n"
            "      }\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "        for (int j = 0; j < 2; j++) {\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][0][0]), \"+f\"(acc[i][j][0][1]),\n"
            "                         \"+f\"(acc[i][j][0][2]), \"+f\"(acc[i][j][0][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][0]), \"r\"(b[j][1]));\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][1][0]), \"+f\"(acc[i][j][1][1]),\n"
            "                         \"+f\"(acc[i][j][1][2]), \"+f\"(acc[i][j][1][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][2]), \"r\"(b[j][3]));\n"
            "        }\n"
            "    }\n"
            "    __syncthreads();\n"
            "  }\n";
        const char *v7_epi =
            "  /* epilogue, rung (e): v6's 96 scalar st.global.f32 (PTX receipt,\n"
            "     LEDGER 1.2.0 follow-up) cost ~6% at 1024^3 vs wmma.store's internal\n"
            "     row coalescing. Stage the tile through the now-idle As buffer\n"
            "     (17,408 B needed, 18,432 B available -- smem footprint and occupancy\n"
            "     UNCHANGED), then stream it out as 128-bit st.global.v4. Stage stride\n"
            "     68 floats: row base 272 B keeps every float4 16B-aligned; the launch\n"
            "     contract (N % 64 == 0, bcol % 64 == 0) aligns the global side. */\n"
            "  {\n"
            "    const int SG = 68;                     /* staging stride, floats */\n"
            "    float *stg = (float *)&As[0][0];\n"
            "    int g = lane >> 2, r = lane & 3;\n"
            "#pragma unroll\n"
            "    for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "        for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "          for (int e = 0; e < 4; e++) {\n"
            "            int m = wr + i*WM + g + 8*(e >> 1);\n"
            "            int n = wc + j*WN + h*8 + 2*r + (e & 1);\n"
            "            stg[m * SG + n] = acc[i][j][h][e];\n"
            "          }\n"
            "    __syncthreads();\n"
            "    for (int idx = (int)threadIdx.x; idx < BM * (BN/4); idx += (int)blockDim.x) {\n"
            "      int row = idx / (BN/4), c4 = (idx % (BN/4)) * 4;\n"
            "      float4 v = *(const float4 *)&stg[row * SG + c4];\n"
            "      long long out = (long long)(brow + row) * N + (bcol + c4);\n"
            "      if (beta != 0.0f) {\n"
            "        float4 c = *(const float4 *)&Cb[out];\n"
            "        v.x = alpha*v.x + beta*c.x; v.y = alpha*v.y + beta*c.y;\n"
            "        v.z = alpha*v.z + beta*c.z; v.w = alpha*v.w + beta*c.w;\n"
            "      } else if (alpha != 1.0f) {\n"
            "        v.x *= alpha; v.y *= alpha; v.z *= alpha; v.w *= alpha;\n"
            "      }\n"
            "      *(float4 *)&Db[out] = v;\n"
            "    }\n"
            "  }\n"
            "}\n";
        len = snprintf(buf, bufsz,
            "#include <cuda_fp16.h>\n"
            "extern \"C\" __global__ void %s(\n"
            "    const __half *A, const __half *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=5 (pipeline v7, rung (e)): pipeline v6's body with a\n"
            "     smem-staged, float4-coalesced epilogue replacing v6's register-direct\n"
            "     scalar stores. Inner loop identical to v6: explicit\n"
            "     ldmatrix.sync.aligned.m8n8.x4 + mma.sync.aligned.m16n8k16 inline PTX.\n"
            "     Fragment layouts sourced from CUTLASS MMA_Traits\n"
            "     SM80_16x8x16_F32F16F16F32_TN (cute/atom/mma_traits_sm80.hpp) and the\n"
            "     PTX ISA m16n8k16 fragment tables -- NOT hand-derived. REQUIRES\n"
            "     warps_per_block==4, M %% 64==0, N %% 64==0, K %% 64==0\n"
            "     (launch-enforced), sm_80+. */\n"
            "  const int WM = 16, WN = 16, WK = 16;\n"
            "  const int BM = 4*WM, BN = 4*WN, BK = 4*WK;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;   /* padded row strides */\n"
            "  __shared__ __align__(16) __half As[2][(4*16)*(4*16 + 8)];\n"
            "  __shared__ __half Bs[2][(4*16)*(4*16 + 8)];\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const __half *Ab = A   + bz * strideA;\n"
            "  const __half *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int bt_per_col = M / BM;\n"
            "  const int GROUP_M = 8;\n"
            "  long long pid = (long long)blockIdx.x;\n"
            "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
            "  int group_id = (int)(pid / pid_in_group);\n"
            "  int first_m = group_id * GROUP_M;\n"
            "  int group_m = bt_per_col - first_m;\n"
            "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
            "  int pid_m = first_m + (int)(pid %% group_m);\n"
            "  int pid_n = (int)((pid %% pid_in_group) / group_m);\n"
            "  int brow = pid_m * BM;\n"
            "  int bcol = pid_n * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);\n"
            "  int lane = (int)(threadIdx.x & 31);\n"
            "  int wr = (warp >> 1) * (2*WM), wc = (warp & 1) * (2*WN);\n"
            "  /* raw accumulators: [A-tile i][B-tile j][n8 half][4 regs] = 32 floats,\n"
            "     the same count wmma's 4 opaque acc fragments held */\n"
            "  float acc[2][2][2][4];\n"
            "#pragma unroll\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "      for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "        for (int e = 0; e < 4; e++) acc[i][j][h][e] = 0.0f;\n"
            "  int k_stages = K / BK;\n",
            name);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len, "%s%s%s%s",
                            v7_stage, unroll, v7_loop, v7_epi);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        }
        if (c->dtype_ab == CUDEZ_MMA_BF16 && !cudez_bf16_retarget_(buf, bufsz)) return 0;
        return 1;
    }

    if (c->smem_stage == 4) {
        /* ---- rung (b), 1.2.0: pipeline v6 (opt-in) -------------------------
           Pipeline v5's block tile, cp.async double buffering and GROUP_M=8
           grouped rasterization, with the wmma fragment API in the inner
           loop replaced by explicit ldmatrix.sync.aligned.m8n8.x4 +
           mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 inline PTX.
           WHY: wmma's opaque fragments force the padded-stride smem layout
           and forbid the XOR-swizzle rung (d); raw mma halves the abstraction
           and exposes the A-operand register reuse wmma hides (ptxas sm_86:
           63 registers vs v5's 69, zero spills, same 36,864 B smem).
           PROVENANCE: fragment layouts sourced mechanically from CUTLASS
           MMA_Traits<SM80_16x8x16_F32F16F16F32_TN> (cute/atom/
           mma_traits_sm80.hpp) and the PTX ISA m16n8k16 fragment tables --
           NOT hand-derived -- then the complete index flow (swizzle, padded
           staging, ldmatrix address->register semantics, fragment tables,
           register-direct epilogue) verified GPU-free by a bit-exact CPU
           emulation against a float32 reference with a write-once coverage
           mask at BOTH release gate shapes, 128x128x192 (K wrap) and
           768x128x128 (partial rasterization band) -- emu_v6.py in the
           release drop. The epilogue needs no store_matrix_sync round-trip:
           with raw mma the accumulator layout is KNOWN, so tiles store
           straight from registers. F16 dense only, and the asm is
           .f16-specific, so this branch hardcodes __half and the 16x16x16
           tile rather than parameterizing what the validator already pins.
           Same launch contract as v3/v4/v5. */
        const char *v6_stage =
            "  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      const __half *g = Ab + (long long)(brow + i / (BK/8)) * K\n"
            "                       + (k0 + (i % (BK/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &As[bf][(i / (BK/8)) * SKA + (i % (BK/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      const __half *g = Bb + (long long)(k0 + i / (BN/8)) * N\n"
            "                       + (bcol + (i % (BN/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &Bs[bf][(i / (BN/8)) * SKB + (i % (BN/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%0], [%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n"
            "  stage(0, 0);\n";
        const char *v6_loop =
            "  for (int ks = 0; ks < k_stages; ks++) {\n"
            "    int cur = ks & 1;\n"
            "    if (ks + 1 < k_stages) {\n"
            "      stage(ks + 1, cur ^ 1);\n"
            "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    } else {\n"
            "      asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "    }\n"
            "    __syncthreads();\n"
            "#pragma unroll\n"
            "    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* A: one ldmatrix.x4 per 16-row tile. Thread t supplies the row\n"
            "         address for 8x8 matrix t/8; matrices land in registers as\n"
            "         M0=[rows 0-7, cols 0-7], M1=[8-15, 0-7], M2=[0-7, 8-15],\n"
            "         M3=[8-15, 8-15] -- exactly the m16k16 A-fragment register order. */\n"
            "      unsigned a[2][4];\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++) {\n"
            "        unsigned sa = (unsigned)__cvta_generic_to_shared(\n"
            "            &As[cur][(wr + i*WM + (lane & 15)) * SKA + kk + (lane >> 4) * 8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(a[i][0]), \"=r\"(a[i][1]), \"=r\"(a[i][2]), \"=r\"(a[i][3])\n"
            "                     : \"r\"(sa));\n"
            "      }\n"
            "      /* B: one ldmatrix.x4.trans per 16-col tile over the k16 x n16\n"
            "         region; the transpose delivers the col-major B fragment\n"
            "         m16n8k16.row.col expects. Regs {0,1} feed the n+0..7 mma,\n"
            "         {2,3} the n+8..15 mma. */\n"
            "      unsigned b[2][4];\n"
            "#pragma unroll\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        unsigned sb = (unsigned)__cvta_generic_to_shared(\n"
            "            &Bs[cur][(kk + (lane & 15)) * SKB + wc + j*WN + (lane >> 4) * 8]);\n"
            "        asm volatile(\"ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 \"\n"
            "                     \"{%0,%1,%2,%3}, [%4];\\n\"\n"
            "                     : \"=r\"(b[j][0]), \"=r\"(b[j][1]), \"=r\"(b[j][2]), \"=r\"(b[j][3])\n"
            "                     : \"r\"(sb));\n"
            "      }\n"
            "#pragma unroll\n"
            "      for (int i = 0; i < 2; i++)\n"
            "#pragma unroll\n"
            "        for (int j = 0; j < 2; j++) {\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][0][0]), \"+f\"(acc[i][j][0][1]),\n"
            "                         \"+f\"(acc[i][j][0][2]), \"+f\"(acc[i][j][0][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][0]), \"r\"(b[j][1]));\n"
            "          asm volatile(\"mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 \"\n"
            "                       \"{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\\n\"\n"
            "                       : \"+f\"(acc[i][j][1][0]), \"+f\"(acc[i][j][1][1]),\n"
            "                         \"+f\"(acc[i][j][1][2]), \"+f\"(acc[i][j][1][3])\n"
            "                       : \"r\"(a[i][0]), \"r\"(a[i][1]), \"r\"(a[i][2]), \"r\"(a[i][3]),\n"
            "                         \"r\"(b[j][2]), \"r\"(b[j][3]));\n"
            "        }\n"
            "    }\n"
            "    __syncthreads();\n"
            "  }\n";
        const char *v6_epi =
            "  /* epilogue: the C-fragment layout is KNOWN with raw mma (sourced,\n"
            "     m16n8: reg e -> row g + 8*(e>>1), col 2r + (e&1)), so accumulators\n"
            "     store straight from registers -- no store_matrix_sync staging. Same\n"
            "     alpha/beta math as v4/v5, element for element. */\n"
            "  {\n"
            "    int g = lane >> 2, r = lane & 3;\n"
            "#pragma unroll\n"
            "    for (int i = 0; i < 2; i++)\n"
            "      for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "        for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "          for (int e = 0; e < 4; e++) {\n"
            "            long long m = (long long)(brow + wr + i*WM + g + 8*(e >> 1));\n"
            "            long long n = (long long)(bcol + wc + j*WN + h*8 + 2*r + (e & 1));\n"
            "            long long out = m * N + n;\n"
            "            float v = acc[i][j][h][e];\n"
            "            if (beta != 0.0f) v = alpha * v + beta * Cb[out];\n"
            "            else if (alpha != 1.0f) v *= alpha;\n"
            "            Db[out] = v;\n"
            "          }\n"
            "  }\n"
            "}\n";
        len = snprintf(buf, bufsz,
            "#include <cuda_fp16.h>\n"
            "extern \"C\" __global__ void %s(\n"
            "    const __half *A, const __half *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=4 (pipeline v6, rung (b)): pipeline v5's block tile,\n"
            "     cp.async double buffering and L2-aware rasterization, with the wmma\n"
            "     fragment API in the inner loop replaced by explicit\n"
            "     ldmatrix.sync.aligned.m8n8.x4 + mma.sync.aligned.m16n8k16 inline PTX.\n"
            "     Fragment layouts sourced from CUTLASS MMA_Traits\n"
            "     SM80_16x8x16_F32F16F16F32_TN (cute/atom/mma_traits_sm80.hpp) and the\n"
            "     PTX ISA m16n8k16 fragment tables -- NOT hand-derived. REQUIRES\n"
            "     warps_per_block==4, M %% 64==0, N %% 64==0, K %% 64==0\n"
            "     (launch-enforced), sm_80+. */\n"
            "  const int WM = 16, WN = 16, WK = 16;\n"
            "  const int BM = 4*WM, BN = 4*WN, BK = 4*WK;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;   /* padded row strides */\n"
            "  __shared__ __half As[2][(4*16)*(4*16 + 8)];\n"
            "  __shared__ __half Bs[2][(4*16)*(4*16 + 8)];\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const __half *Ab = A   + bz * strideA;\n"
            "  const __half *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int bt_per_col = M / BM;\n"
            "  const int GROUP_M = 8;\n"
            "  long long pid = (long long)blockIdx.x;\n"
            "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
            "  int group_id = (int)(pid / pid_in_group);\n"
            "  int first_m = group_id * GROUP_M;\n"
            "  int group_m = bt_per_col - first_m;\n"
            "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
            "  int pid_m = first_m + (int)(pid %% group_m);\n"
            "  int pid_n = (int)((pid %% pid_in_group) / group_m);\n"
            "  int brow = pid_m * BM;\n"
            "  int bcol = pid_n * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);\n"
            "  int lane = (int)(threadIdx.x & 31);\n"
            "  int wr = (warp >> 1) * (2*WM), wc = (warp & 1) * (2*WN);\n"
            "  /* raw accumulators: [A-tile i][B-tile j][n8 half][4 regs] = 32 floats,\n"
            "     the same count wmma's 4 opaque acc fragments held */\n"
            "  float acc[2][2][2][4];\n"
            "#pragma unroll\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++)\n"
            "#pragma unroll\n"
            "      for (int h = 0; h < 2; h++)\n"
            "#pragma unroll\n"
            "        for (int e = 0; e < 4; e++) acc[i][j][h][e] = 0.0f;\n"
            "  int k_stages = K / BK;\n",
            name);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len, "%s%s%s%s",
                            v6_stage, unroll, v6_loop, v6_epi);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        }
        if (c->dtype_ab == CUDEZ_MMA_BF16 && !cudez_bf16_retarget_(buf, bufsz)) return 0;
        return 1;
    }

    if (c->smem_stage == 2 || c->smem_stage == 3) {
        /* ---- 0.9.0 shared-memory data pipeline v4 (opt-in) ----------------
           v3's register-blocked block-tile with the K-stage loop DOUBLE
           BUFFERED through cp.async (sm_80+, validator-enforced): while the
           tensor cores consume staged step s, asynchronous 16-byte copies
           stage step s+1 into the other half of a 2-deep shared-memory
           queue. This is the Ampere-honest translation of the Hopper-class
           producer/consumer designs (TMA + mbarrier circular queues, warp
           specialization) publicized by the "Outperforming cuBLAS on H100"
           worklog: sm_86 has no TMA/wgmma/clusters, but cp.async gives the
           same load/compute overlap without burning registers on in-flight
           data. Software-pipelined rather than warp-specialized on purpose:
           with synchronous per-warp wmma there is no async compute to give
           a dedicated loader warpgroup, so all 128 threads both stage and
           compute. Costs: staged smem doubles (~36.9 KB static, default
           tiles) so residency drops vs v3's ~5 blocks/SM -- the bench
           judges whether overlap buys more than occupancy pays. Same
           launch contract and epilogue as v3. */
        /* rung (i), smem_stage=3 only (pipeline v5): remap the linear block
           id so blocks resident at the same time share more of the same
           A-row panel in L2, instead of the plain row-major div/mod v3/v4
           use. Standard "grouped rasterization" swizzle (Triton/CUTLASS):
           iterate N fully within a GROUP_M-row band before advancing to the
           next band. Bijective over [0, bt_per_row*bt_per_col) including a
           partial final band -- hand-traced on a 3x5 grid with GROUP_M=2
           when first coded, brute-force verified over 1..16 x 1..16 grids
           at merge time, and gated on hardware by the 768x128x128 smoke
           (bt_per_col=12: spans two GROUP_M=8 bands, the second PARTIAL).
           Emitted as a "%s" ARGUMENT into the shared v4/v5 body, so the
           stage-2 output stays byte-for-byte the 0.9.0 v4 kernel -- same
           bit-identity discipline as the store_hint epilogue below. */
        const char *blockmap = (c->smem_stage == 3)
            ? "  int bt_per_row = N / BN;\n"
              "  int bt_per_col = M / BM;\n"
              "  const int GROUP_M = 8;   /* rung (i): L2-aware rasterization (pipeline v5) */\n"
              "  long long pid = (long long)blockIdx.x;\n"
              "  long long pid_in_group = (long long)GROUP_M * bt_per_row;\n"
              "  int group_id = (int)(pid / pid_in_group);\n"
              "  int first_m = group_id * GROUP_M;\n"
              "  int group_m = bt_per_col - first_m;\n"
              "  if (group_m > GROUP_M) group_m = GROUP_M;\n"
              "  int pid_m = first_m + (int)(pid % group_m);\n"
              "  int pid_n = (int)((pid % pid_in_group) / group_m);\n"
              "  int brow = pid_m * BM;\n"
              "  int bcol = pid_n * BN;\n"
            : "  int bt_per_row = N / BN;\n"
              "  int brow = (int)((long long)blockIdx.x / bt_per_row) * BM;\n"
              "  int bcol = (int)((long long)blockIdx.x % bt_per_row) * BN;\n";
        const char *tf32v4 = is_tf32
            ? "      for (int f = 0; f < 2; f++) {\n"
              "        for (int e = 0; e < a_frag[f].num_elements; e++)\n"
              "          a_frag[f].x[e] = wmma::__float_to_tf32(a_frag[f].x[e]);\n"
              "        for (int e = 0; e < b_frag[f].num_elements; e++)\n"
              "          b_frag[f].x[e] = wmma::__float_to_tf32(b_frag[f].x[e]);\n"
              "      }\n"
            : "";
        len = snprintf(buf, bufsz,
            "%s"
            "#include <mma.h>\n"
            "using namespace nvcuda;\n"
            "extern \"C\" __global__ void %s(\n"
            "    const %s *A, const %s *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=2 (pipeline v4): 2x2 warps x 2x2 WMMA tiles each\n"
            "     (v3's register blocking) + cp.async double buffering: step\n"
            "     s+1 streams into buffer s+1&1 while step s computes from\n"
            "     buffer s&1. REQUIRES warps_per_block==4, M %% (4*%d)==0,\n"
            "     N %% (4*%d)==0, K %% (4*%d)==0 (launch-enforced), sm_80+. */\n"
            "  const int WM = %d, WN = %d, WK = %d;\n"
            "  const int BM = 4*WM, BN = 4*WN, BK = 4*WK;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;   /* padded row strides */\n"
            "  /* the +8-element pad is 16 B, so padded rows keep the 16-B\n"
            "     alignment cp.async needs; the pad is never copied into. */\n"
            "  __shared__ %s As[2][(4*%d)*(4*%d + 8)];  /* 2 x (BM x BK), ld=SKA */\n"
            "  __shared__ %s Bs[2][(4*%d)*(4*%d + 8)];  /* 2 x (BK x BN), ld=SKB */\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const %s *Ab = A   + bz * strideA;\n"
            "  const %s *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "%s"
            "  int warp = (int)(threadIdx.x >> 5);\n"
            "  int wr = (warp >> 1) * (2*WM), wc = (warp & 1) * (2*WN);\n"
            "  wmma::fragment<wmma::matrix_a, WM, WN, WK, %s, wmma::row_major> a_frag[2];\n"
            "  wmma::fragment<wmma::matrix_b, WM, WN, WK, %s, wmma::row_major> b_frag[2];\n"
            "  wmma::fragment<wmma::accumulator, WM, WN, WK, float> acc[2][2];\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++) wmma::fill_fragment(acc[i][j], 0.0f);\n"
            "  int k_stages = K / BK;\n",
            is_bf16 ? "#include <cuda_bf16.h>\n" : "",
            name, ctype, ctype,
            c->tile_m, c->tile_n, c->tile_k,     /* REQUIRES comment */
            c->tile_m, c->tile_n, c->tile_k,     /* const WM,WN,WK */
            ctype, c->tile_m, c->tile_k,         /* As decl (2 x BM x BK, padded) */
            ctype, c->tile_k, c->tile_n,         /* Bs decl (2 x BK x BN, padded) */
            ctype, ctype,                        /* Ab, Bb declarations */
            blockmap,                            /* rung (i): plain (v4) or swizzled (v5) block map */
            fragtype, fragtype);                 /* fragment dtypes */
        if (len < 0 || (size_t)len >= bufsz) return 0;
        /* second half appended separately: the whole v4 kernel in one
           literal would exceed the 4095-char minimum ISO C99 requires
           translators to accept, tripping the header's own -Wpedantic
           gate. Two appends, same generated source. */
        {
        int len2 = snprintf(buf + len, bufsz - (size_t)len,
            "  /* producer: one K-step's A/B panels -> As[bf]/Bs[bf], as one\n"
            "     cp.async group. 16 B (8 elements) per copy; a row of A is\n"
            "     BK/8 chunks, of B is BN/8; consecutive threads take\n"
            "     consecutive chunks of one row for coalescing. 64-bit row\n"
            "     products (in-kernel index audit). */\n"
            "  auto stage = [&](int ks, int bf) {\n"
            "    int k0 = ks * BK;\n"
            "    for (int i = (int)threadIdx.x; i < BM*(BK/8); i += (int)blockDim.x) {\n"
            "      const %s *g = Ab + (long long)(brow + i / (BK/8)) * K\n"
            "                       + (k0 + (i %% (BK/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &As[bf][(i / (BK/8)) * SKA + (i %% (BK/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%%0], [%%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    for (int i = (int)threadIdx.x; i < BK*(BN/8); i += (int)blockDim.x) {\n"
            "      const %s *g = Bb + (long long)(k0 + i / (BN/8)) * N\n"
            "                       + (bcol + (i %% (BN/8)) * 8);\n"
            "      unsigned s = (unsigned)__cvta_generic_to_shared(\n"
            "          &Bs[bf][(i / (BN/8)) * SKB + (i %% (BN/8)) * 8]);\n"
            "      asm volatile(\"cp.async.ca.shared.global [%%0], [%%1], 16;\\n\"\n"
            "                   :: \"r\"(s), \"l\"(g) : \"memory\");\n"
            "    }\n"
            "    asm volatile(\"cp.async.commit_group;\\n\" ::: \"memory\");\n"
            "  };\n"
            "  stage(0, 0);                    /* prologue: buffer 0 in flight */\n"
            "%s"
            "  for (int ks = 0; ks < k_stages; ks++) {\n"
            "    int cur = ks & 1;\n"
            "    if (ks + 1 < k_stages) {\n"
            "      stage(ks + 1, cur ^ 1);     /* overlap: next step's copies */\n"
            "      /* wait until only the newest group (step ks+1) is in\n"
            "         flight => step ks's copies have landed */\n"
            "      asm volatile(\"cp.async.wait_group 1;\\n\" ::: \"memory\");\n"
            "    } else {\n"
            "      asm volatile(\"cp.async.wait_group 0;\\n\" ::: \"memory\");\n"
            "    }\n"
            "    __syncthreads();              /* landed copies visible block-wide */\n"
            "#pragma unroll\n"
            "    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* 4 fragment loads feed 4 mma_syncs: each load serves two */\n"
            "      wmma::load_matrix_sync(a_frag[0], &As[cur][(wr       ) * SKA + kk], SKA);\n"
            "      wmma::load_matrix_sync(a_frag[1], &As[cur][(wr + WM  ) * SKA + kk], SKA);\n"
            "      wmma::load_matrix_sync(b_frag[0], &Bs[cur][kk * SKB + (wc       )], SKB);\n"
            "      wmma::load_matrix_sync(b_frag[1], &Bs[cur][kk * SKB + (wc + WN  )], SKB);\n"
            "%s"
            "      wmma::mma_sync(acc[0][0], a_frag[0], b_frag[0], acc[0][0]);\n"
            "      wmma::mma_sync(acc[0][1], a_frag[0], b_frag[1], acc[0][1]);\n"
            "      wmma::mma_sync(acc[1][0], a_frag[1], b_frag[0], acc[1][0]);\n"
            "      wmma::mma_sync(acc[1][1], a_frag[1], b_frag[1], acc[1][1]);\n"
            "    }\n"
            "    __syncthreads();              /* all reads of buffer cur done\n"
            "                                     before it is restaged */\n"
            "  }\n",
            ctype, ctype,                        /* staged A/B element pointers */
            unroll,                              /* guarded unroll pragma */
            tf32v4);
        if (len2 < 0 || (size_t)len2 >= bufsz - (size_t)len) return 0;
        len += len2;
        }
        /* Third append: the epilogue, selected by store_hint. Passed as a
           "%s" ARGUMENT (neither literal contains conversions), so the
           store_hint=0 output stays byte-for-byte the 0.9.0 v4 kernel --
           the same bit-identity promise the 0.9.0 release kept for v3. */
        {
        const char *epi = (c->store_hint == 1)
            ?
            /* ---- rung (h), 0.10.0: evict-first epilogue ---------------
               D tiles are write-once and never re-read by this kernel, so
               stream them out with st.global.cs (evict-first; the __stcs
               policy) instead of letting the output thrash the L2 lines
               the A/B panels want -- the sm_86 analogue of Hopper's
               L2-bypassing TMA stores. The accumulator fragment's
               register->matrix mapping is opaque (and vendor layout
               diagrams have been wrong before -- the v4 provenance note),
               so acc reaches matrix order the only contract-honest way:
               store_matrix_sync into the staging smem, which is dead after
               the K-loop (the final __syncthreads() above fenced the last
               reads), then each warp streams its own 32x32 tile out.
               Space: 4 warps x (2*WM)x(2*WN) floats = 16,384 B plus <=12 B
               alignment slack inside As's 2*BM*(BK+8)*2 = 18,432 B.
               Coalescing: lane l takes elements l, l+32, ... of its warp's
               row-major tile, so each step's 32 stores cover one 128 B row
               segment. */
            "  {\n"
            "    /* reuse As as a float staging tile: 16,388 B needed (incl.\n"
            "       alignment slack) inside As's 18,432 B, dead since the\n"
            "       final __syncthreads() of the K-loop */\n"
            "    unsigned long long pa_ = (unsigned long long)&As[0][0];\n"
            "    float *stg = (float *)((pa_ + 15ull) & ~15ull)\n"
            "               + warp * (2*WM) * (2*WN);\n"
            "    int lane = (int)(threadIdx.x & 31);\n"
            "    for (int i = 0; i < 2; i++)\n"
            "      for (int j = 0; j < 2; j++) {\n"
            "        if (alpha != 1.0f)\n"
            "          for (int e = 0; e < acc[i][j].num_elements; e++)\n"
            "            acc[i][j].x[e] *= alpha;\n"
            "        wmma::store_matrix_sync(stg + (i*WM)*(2*WN) + j*WN,\n"
            "                                acc[i][j], 2*WN, wmma::mem_row_major);\n"
            "      }\n"
            "    __syncwarp();      /* warp-private tile: no block barrier */\n"
            "    for (int t = lane; t < (2*WM)*(2*WN); t += 32) {\n"
            "      long long g = (long long)(brow + wr + t / (2*WN)) * N\n"
            "                  + (bcol + wc + t % (2*WN));\n"
            "      float v = stg[t];\n"
            "      if (beta != 0.0f) v += beta * Cb[g];\n"
            "      /* st.global.cs: evict-first, == __stcs(Db+g, v) */\n"
            "      asm volatile(\"st.global.cs.f32 [%0], %1;\\n\"\n"
            "                   :: \"l\"(Db + g), \"f\"(v) : \"memory\");\n"
            "    }\n"
            "  }\n"
            "}\n"
            :
            /* store_hint=0: the 0.9.0 epilogue, byte-for-byte */
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++) {\n"
            "      long long out = (long long)(brow + wr + i*WM) * N + (bcol + wc + j*WN);\n"
            "      if (beta != 0.0f) {\n"
            "        wmma::fragment<wmma::accumulator, WM, WN, WK, float> c_frag;\n"
            "        wmma::load_matrix_sync(c_frag, Cb + out, N, wmma::mem_row_major);\n"
            "        for (int e = 0; e < c_frag.num_elements; e++)\n"
            "          c_frag.x[e] = alpha * acc[i][j].x[e] + beta * c_frag.x[e];\n"
            "        wmma::store_matrix_sync(Db + out, c_frag, N, wmma::mem_row_major);\n"
            "      } else {\n"
            "        if (alpha != 1.0f)\n"
            "          for (int e = 0; e < acc[i][j].num_elements; e++) acc[i][j].x[e] *= alpha;\n"
            "        wmma::store_matrix_sync(Db + out, acc[i][j], N, wmma::mem_row_major);\n"
            "      }\n"
            "    }\n"
            "}\n";
        int len3 = snprintf(buf + len, bufsz - (size_t)len, "%s", epi);
        if (len3 < 0 || (size_t)len3 >= bufsz - (size_t)len) return 0;
        }
        return 1;
    }

    if (c->smem_stage) {
        /* ---- 0.8.0 shared-memory data pipeline v3 (opt-in) ----------------
           Same 13-arg extern-C signature as the streaming kernel; only the
           grid meaning changes (one block == one 64x64-class block-tile;
           cudez_try_mma_launch computes it). Rung history, each chosen by
           the bench on sm_86:
             v1  2x reuse, BK=WK, unpadded smem -> LOST to streaming.
             v2  BK=4*WK (4x fewer barriers) + padded smem (no bank
                 conflicts) -> beat streaming at 512^3, lost above it.
             v3  REGISTER BLOCKING: each warp computes a 2x2 grid of WMMA
                 tiles (32x32/warp, (4*WM)x(4*WN)/block), so every staged
                 element feeds four tiles of compute (4x reuse, and each
                 a/b fragment load from shared serves two mma_syncs).
           The next rung, cp.async double buffering, shipped in 0.9.0 as
           smem_stage=2 (pipeline v4, above); v3 stays intact as the
           sm_70-compatible pipeline and the v4 A/B baseline.
           Global indexing is 64-bit ((long long) row products). */
        const char *tf32v3 = is_tf32
            ? "      for (int f = 0; f < 2; f++) {\n"
              "        for (int e = 0; e < a_frag[f].num_elements; e++)\n"
              "          a_frag[f].x[e] = wmma::__float_to_tf32(a_frag[f].x[e]);\n"
              "        for (int e = 0; e < b_frag[f].num_elements; e++)\n"
              "          b_frag[f].x[e] = wmma::__float_to_tf32(b_frag[f].x[e]);\n"
              "      }\n"
            : "";
        len = snprintf(buf, bufsz,
            "%s"
            "#include <mma.h>\n"
            "using namespace nvcuda;\n"
            "extern \"C\" __global__ void %s(\n"
            "    const %s *A, const %s *B, const float *Cin, float *D,\n"
            "    int M, int N, int K,\n"
            "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
            "    float alpha, float beta) {\n"
            "  /* smem_stage=1 (pipeline v3): 2x2 warps x 2x2 WMMA tiles each =\n"
            "     one (4*WM)x(4*WN) block-tile. Per BK=4*WK step, 128 threads\n"
            "     stage A (BMxBK) and B (BKxBN) into PADDED shared memory once;\n"
            "     each warp then runs 4 k-steps x 2x2 tiles from shared before\n"
            "     the next barrier. REQUIRES warps_per_block==4,\n"
            "     M %% (4*%d)==0, N %% (4*%d)==0, K %% (4*%d)==0 (launch-\n"
            "     enforced). */\n"
            "  const int WM = %d, WN = %d, WK = %d;\n"
            "  const int BM = 4*WM, BN = 4*WN, BK = 4*WK;\n"
            "  const int SKA = BK + 8, SKB = BN + 8;   /* padded row strides */\n"
            "  __shared__ %s As[(4*%d)*(4*%d + 8)];    /* BM x BK, ld=SKA */\n"
            "  __shared__ %s Bs[(4*%d)*(4*%d + 8)];    /* BK x BN, ld=SKB */\n"
            "  long long bz = (long long)blockIdx.z;\n"
            "  const %s *Ab = A   + bz * strideA;\n"
            "  const %s *Bb = B   + bz * strideB;\n"
            "  const float  *Cb = Cin + bz * strideC;\n"
            "  float        *Db = D   + bz * strideD;\n"
            "  int bt_per_row = N / BN;\n"
            "  int brow = (int)((long long)blockIdx.x / bt_per_row) * BM;\n"
            "  int bcol = (int)((long long)blockIdx.x %% bt_per_row) * BN;\n"
            "  int warp = (int)(threadIdx.x >> 5);\n"
            "  int wr = (warp >> 1) * (2*WM), wc = (warp & 1) * (2*WN);\n"
            "  wmma::fragment<wmma::matrix_a, WM, WN, WK, %s, wmma::row_major> a_frag[2];\n"
            "  wmma::fragment<wmma::matrix_b, WM, WN, WK, %s, wmma::row_major> b_frag[2];\n"
            "  wmma::fragment<wmma::accumulator, WM, WN, WK, float> acc[2][2];\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++) wmma::fill_fragment(acc[i][j], 0.0f);\n"
            "  int k_stages = K / BK;\n"
            "%s"
            "  for (int ks = 0; ks < k_stages; ks++) {\n"
            "    int k0 = ks * BK;\n"
            "    /* cooperative stage; 64-bit row products (in-kernel index audit).\n"
            "       Consecutive threads walk consecutive columns of one row: a\n"
            "       BK-element contiguous run per A row for coalescing. */\n"
            "    for (int i = (int)threadIdx.x; i < BM*BK; i += (int)blockDim.x)\n"
            "      As[(i / BK) * SKA + (i %% BK)] =\n"
            "        Ab[(long long)(brow + i / BK) * K + (k0 + i %% BK)];\n"
            "    for (int i = (int)threadIdx.x; i < BK*BN; i += (int)blockDim.x)\n"
            "      Bs[(i / BN) * SKB + (i %% BN)] =\n"
            "        Bb[(long long)(k0 + i / BN) * N + (bcol + i %% BN)];\n"
            "    __syncthreads();\n"
            "#pragma unroll\n"
            "    for (int kk = 0; kk < BK; kk += WK) {\n"
            "      /* 4 fragment loads feed 4 mma_syncs: each load serves two */\n"
            "      wmma::load_matrix_sync(a_frag[0], As + (wr       ) * SKA + kk, SKA);\n"
            "      wmma::load_matrix_sync(a_frag[1], As + (wr + WM  ) * SKA + kk, SKA);\n"
            "      wmma::load_matrix_sync(b_frag[0], Bs + kk * SKB + (wc       ), SKB);\n"
            "      wmma::load_matrix_sync(b_frag[1], Bs + kk * SKB + (wc + WN  ), SKB);\n"
            "%s"
            "      wmma::mma_sync(acc[0][0], a_frag[0], b_frag[0], acc[0][0]);\n"
            "      wmma::mma_sync(acc[0][1], a_frag[0], b_frag[1], acc[0][1]);\n"
            "      wmma::mma_sync(acc[1][0], a_frag[1], b_frag[0], acc[1][0]);\n"
            "      wmma::mma_sync(acc[1][1], a_frag[1], b_frag[1], acc[1][1]);\n"
            "    }\n"
            "    __syncthreads();\n"
            "  }\n"
            "  for (int i = 0; i < 2; i++)\n"
            "    for (int j = 0; j < 2; j++) {\n"
            "      long long out = (long long)(brow + wr + i*WM) * N + (bcol + wc + j*WN);\n"
            "      if (beta != 0.0f) {\n"
            "        wmma::fragment<wmma::accumulator, WM, WN, WK, float> c_frag;\n"
            "        wmma::load_matrix_sync(c_frag, Cb + out, N, wmma::mem_row_major);\n"
            "        for (int e = 0; e < c_frag.num_elements; e++)\n"
            "          c_frag.x[e] = alpha * acc[i][j].x[e] + beta * c_frag.x[e];\n"
            "        wmma::store_matrix_sync(Db + out, c_frag, N, wmma::mem_row_major);\n"
            "      } else {\n"
            "        if (alpha != 1.0f)\n"
            "          for (int e = 0; e < acc[i][j].num_elements; e++) acc[i][j].x[e] *= alpha;\n"
            "        wmma::store_matrix_sync(Db + out, acc[i][j], N, wmma::mem_row_major);\n"
            "      }\n"
            "    }\n"
            "}\n",
            is_bf16 ? "#include <cuda_bf16.h>\n" : "",
            name, ctype, ctype,
            c->tile_m, c->tile_n, c->tile_k,     /* REQUIRES comment */
            c->tile_m, c->tile_n, c->tile_k,     /* const WM,WN,WK */
            ctype, c->tile_m, c->tile_k,         /* As decl (BM x BK, padded) */
            ctype, c->tile_k, c->tile_n,         /* Bs decl (BK x BN, padded) */
            ctype, ctype,                        /* Ab, Bb declarations */
            fragtype, fragtype, unroll,          /* frags + guarded unroll */
            tf32v3);
        if (len < 0 || (size_t)len >= bufsz) return 0;
        return 1;
    }

    len = snprintf(buf, bufsz,
        "%s"
        "#include <mma.h>\n"
        "using namespace nvcuda;\n"
        "extern \"C\" __global__ void %s(\n"
        "    const %s *A, const %s *B, const float *Cin, float *D,\n"
        "    int M, int N, int K,\n"
        "    long long strideA, long long strideB, long long strideC, long long strideD,\n"
        "    float alpha, float beta) {\n"
        "  /* D = alpha*A*B + beta*C; A MxK, B KxN, C/D MxN, all row-major.\n"
        "     BATCHED: gridDim.z is the batch count, blockIdx.z the element,\n"
        "     offset by stride* ELEMENTS (0 stride broadcasts that operand).\n"
        "     gridDim.z==1 / offset 0 is exactly the single-GEMM kernel.\n"
        "     Correctness-first (no edge predication): REQUIRES M %% %d == 0,\n"
        "     N %% %d == 0, K %% %d == 0. cudez_try_mma_launch enforces this. */\n"
        "  const int WM = %d, WN = %d, WK = %d;\n"
        "  long long bz = (long long)blockIdx.z;\n"
        "  /* strides are 64-bit (host resolves packed defaults in long long too),\n"
        "     so bz*stride cannot overflow for any in-range batch/shape. */\n"
        "  const %s *Ab = A   + bz * strideA;\n"
        "  const %s *Bb = B   + bz * strideB;\n"
        "  const float  *Cb = Cin + bz * strideC;\n"
        "  float        *Db = D   + bz * strideD;\n"
        "  long long warp_id = ((long long)threadIdx.x + (long long)blockIdx.x * blockDim.x) / 32;\n"
        "  int warps_per_row = N / WN;  /* N %% WN == 0 required */\n"
        "  int row0 = (warp_id / warps_per_row) * WM;\n"
        "  int col0 = (warp_id %% warps_per_row) * WN;\n"
        "  if (row0 >= M || col0 >= N) return;\n"
        "  wmma::fragment<wmma::matrix_a, WM, WN, WK, %s, wmma::row_major> a_frag;\n"
        "  wmma::fragment<wmma::matrix_b, WM, WN, WK, %s, wmma::row_major> b_frag;\n"
        "  wmma::fragment<wmma::accumulator, WM, WN, WK, float> acc_frag;\n"
        "  wmma::fill_fragment(acc_frag, 0.0f);\n"
        "  int k_tiles = K / WK;  /* exact; K %% WK == 0 required (see above) */\n"
        "%s"
        "  for (int kt = 0; kt < k_tiles; kt++) {\n"
        "    int k0 = kt * WK;\n"
        "    wmma::load_matrix_sync(a_frag, Ab + (long long)row0 * K + k0, K);\n"
        "    wmma::load_matrix_sync(b_frag, Bb + (long long)k0 * N + col0, N);\n"
        "%s"
        "%s"
        "    wmma::mma_sync(acc_frag, a_frag, b_frag, acc_frag);\n"
        "  }\n"
        "  if (beta != 0.0f) {\n"
        "    wmma::fragment<wmma::accumulator, WM, WN, WK, float> c_frag;\n"
        "    wmma::load_matrix_sync(c_frag, Cb + (long long)row0 * N + col0, N, wmma::mem_row_major);\n"
        "    for (int i = 0; i < c_frag.num_elements; i++)\n"
        "      c_frag.x[i] = alpha * acc_frag.x[i] + beta * c_frag.x[i];\n"
        "    wmma::store_matrix_sync(Db + (long long)row0 * N + col0, c_frag, N, wmma::mem_row_major);\n"
        "  } else {\n"
        "    if (alpha != 1.0f)\n"
        "      for (int i = 0; i < acc_frag.num_elements; i++) acc_frag.x[i] *= alpha;\n"
        "    wmma::store_matrix_sync(Db + (long long)row0 * N + col0, acc_frag, N, wmma::mem_row_major);\n"
        "  }\n"
        "}\n",
        is_bf16 ? "#include <cuda_bf16.h>\n" : "",
        name, ctype, ctype,
        c->tile_m, c->tile_n, c->tile_k,     /* REQUIRES comment */
        c->tile_m, c->tile_n, c->tile_k,     /* const WM,WN,WK */
        ctype, ctype,                        /* Ab, Bb declarations */
        fragtype, fragtype, unroll,          /* frags + guarded unroll pragma */
        tf32a, tf32b);

    if (len < 0 || (size_t)len >= bufsz) return 0;
    return 1;
}

/* ---- sparse (2:4) MMA source generation -------------------------------
 * DIFFERENT CODE PATH FROM DENSE: this emits inline PTX mma.sp.sync
 * instructions rather than nvcuda::wmma:: C++ calls, because NVRTC's
 * documented C++ front end does not expose a public sparse-fragment type
 * the way it does dense WMMA. This is the honest reason cudez keeps
 * dense and sparse in visibly separate functions rather than unifying
 * them behind one generator -- unifying them would hide that the sparse
 * path is a fundamentally less-checked kind of generated code (see the
 * verification note at the top of this section). Only F16/BF16 sparse
 * is generated in 0.2.0; only m16n8k32 (the documented sparse tile for
 * fp16, sm_80) is emitted regardless of the tile_* fields in cfg, which
 * are IGNORED for sparse kernels (a future revision may add a dedicated
 * cudez_mma_sparse_config instead of silently ignoring fields on the
 * shared struct -- flagged in the roadmap note at the end of this file).
 *
 * INCOMPLETE ON PURPOSE: the accumulator-to-D scatter is deliberately
 * left unfilled (see comment in the generated source itself). Writing it
 * without the PTX ISA guide's per-lane thread-to-fragment table in hand
 * would produce a kernel that compiles, runs, and silently returns wrong
 * numbers -- worse than a kernel that plainly does not finish the job.
 * ---------------------------------------------------------------------- */

CUDEZ_INLINE int cudez_mma_sparse_source_(const cudez_mma_config *c, const char *name,
                                          char *buf, size_t bufsz) {
    /* 1.0.3-dev: INT8 2:4 sparse (UNVERIFIED -- see the doc comment on
       CUDEZ_SPI8_PIPE_SRC_ above for the full derivation and specific risk
       areas). Only the v7-class pipeline (smem_stage==5) is built; INT8
       sparse streaming (stage 0) and ring (stage 7) remain unimplemented,
       so a request for either still falls through to this function's
       existing F16/BF16-only paths below, which cudez_mma_launch's
       existing is_int rejection continues to catch as
       CUDA_ERROR_NOT_SUPPORTED for anything this branch doesn't handle. */
    if (c->dtype_ab == CUDEZ_MMA_INT8 && c->smem_stage == 5) {
        char unroll8[32];
        int len2;
        if (c->k_chunks > 0) snprintf(unroll8, sizeof unroll8, "#pragma unroll(%d)\n", c->k_chunks);
        else                 unroll8[0] = '\0';
        len2 = snprintf(buf, bufsz, CUDEZ_SPI8_PIPE_SRC_, "", name, unroll8);
        return (len2 > 0 && (size_t)len2 < bufsz);
    }
    int is_bf16 = (c->dtype_ab == CUDEZ_MMA_BF16);
    const char *ct = is_bf16 ? "__nv_bfloat16" : "half";
    const char *pt = is_bf16 ? "bf16" : "f16";
    char op[160];
    int len;
    char unroll[32];
    if (c->k_chunks > 0) snprintf(unroll, sizeof unroll, "#pragma unroll(%d)\n", c->k_chunks);
    else                 unroll[0] = '\0';

    /* Plain mma.sp (NOT ::ordered_metadata): the ordered form is PTX ISA 8.5 /
       sm_90+. cudez targets Ampere sm_80 here, where plain mma.sp is the form
       ptxas accepts. See the sm_90+ note in cudez_mma_sparse_source_'s doc. */
    if (c->smem_stage == 7) {
        /* 2:4 sparse on the v9-class RING (1.9.0-dev). Frozen bar: smoke PASS
           AND beats sparse v7 (the in-lane incumbent) at >=2048 with disjoint
           trials AND beats dense v9 dense-equivalent at >=2048 -- this is the
           rung built to EARN the pruning claim sparse rung 1 missed. */
        char spop[160];
        snprintf(spop, sizeof spop,
            "mma.sp.sync.aligned.m16n8k32.row.col.f32.%s.%s.f32", pt, pt);
        len = snprintf(buf, bufsz, CUDEZ_SP9_PIPE_SRC_,
                       is_bf16 ? "#include <cuda_bf16.h>\n" : "",
                       name, ct, ct, ct, ct, ct, ct, ct, spop, unroll);
        return (len > 0 && (size_t)len < bufsz);
    }
    if (c->smem_stage == 5) {
        /* 2:4 sparse on the v7-class pipeline (1.8.0-dev). Frozen bar:
           smoke-correct AND beats cudez's OWN dense v9 dense-equivalent at
           >=2048^3 (if 2:4 cannot beat dense there is no reason to prune),
           judged also against the streaming sparse kernel (>=2x). */
        char spop[160];
        snprintf(spop, sizeof spop,
            "mma.sp.sync.aligned.m16n8k32.row.col.f32.%s.%s.f32", pt, pt);
        len = snprintf(buf, bufsz, CUDEZ_SP_PIPE_SRC_,
                       is_bf16 ? "#include <cuda_bf16.h>\n" : "",
                       name, ct, ct, ct, ct, unroll, ct, ct, spop);
        return (len > 0 && (size_t)len < bufsz);
    }
    snprintf(op, sizeof op,
        "mma.sp.sync.aligned.m16n8k32.row.col.f32.%s.%s.f32", pt, pt);

    len = snprintf(buf, bufsz,
        "#include <cuda_fp16.h>\n"
        "%s"
        "extern \"C\" __global__ void %s(\n"
        "    const %s *A_vals, const unsigned *A_meta,\n"
        "    const %s *B, const float *Cin, float *D,\n"
        "    int M, int N, int K, float alpha, float beta) {\n"
        "  /* 2:4 STRUCTURED SPARSE GEMM, D = alpha*(A*B) + beta*C.\n"
        "     A is the SPARSE operand: logically M x K but stored COMPRESSED as\n"
        "     A_vals (M x K/2, the two nonzeros of each 4-group in order) plus\n"
        "     A_meta (2-bit positions). B is dense K x N, C/D dense M x N. All\n"
        "     row-major. m16n8k32 is the documented fp16/bf16 sparse tile. */\n"
        "  const int WM = 16, WN = 8, WK = 32;\n"
        "  int lane = threadIdx.x & 31;\n"
        "  long long warp_id = ((long long)threadIdx.x + (long long)blockIdx.x * blockDim.x) >> 5;\n"
        "  int warps_per_row = N / WN;              /* N %% 8 == 0 required */\n"
        "  int row0 = (warp_id / warps_per_row) * WM;\n"
        "  int col0 = (warp_id %% warps_per_row) * WN;\n"
        "  if (row0 >= M || col0 >= N) return;\n"
        "  int g = lane >> 2, tau = lane & 3;       /* fragment lane mapping */\n"
        "  int Kc = K >> 1;                          /* compressed A columns */\n"
        "  int k_tiles = K / WK;                     /* K %% 32 == 0 required */\n"
        "  float acc[4] = {0.f, 0.f, 0.f, 0.f};\n"
        "  for (int kt = 0; kt < k_tiles; kt++) {\n"
        "    /* --- A fragment: compressed 16x16 block, rows {g,g+8}, cols\n"
        "       {2tau,2tau+1, 2tau+8,2tau+9}; contiguous pairs -> 32-bit loads. */\n"
        "    const %s *Ab = A_vals + (long long)row0 * Kc + kt * 16;\n"
        "    unsigned a0 = *(const unsigned*)(Ab + (g  ) * Kc + 2*tau    );\n"
        "    unsigned a1 = *(const unsigned*)(Ab + (g+8) * Kc + 2*tau    );\n"
        "    unsigned a2 = *(const unsigned*)(Ab + (g  ) * Kc + 2*tau + 8);\n"
        "    unsigned a3 = *(const unsigned*)(Ab + (g+8) * Kc + 2*tau + 8);\n"
        "    /* --- B fragment: dense 32x8 tile, n-col g, k-rows\n"
        "       {2tau(+0,1),(+8,9),(+16,17),(+24,25)}; row-major -> paired. */\n"
        "    const %s *Bb = B + (long long)(kt*WK) * N + col0;\n"
        "    unsigned b0 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 1)*N + g) << 16)\n"
        "                |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 0)*N + g);\n"
        "    unsigned b1 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+ 9)*N + g) << 16)\n"
        "                |  (unsigned)*(const unsigned short*)(Bb + (2*tau+ 8)*N + g);\n"
        "    unsigned b2 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+17)*N + g) << 16)\n"
        "                |  (unsigned)*(const unsigned short*)(Bb + (2*tau+16)*N + g);\n"
        "    unsigned b3 = ((unsigned)*(const unsigned short*)(Bb + (2*tau+25)*N + g) << 16)\n"
        "                |  (unsigned)*(const unsigned short*)(Bb + (2*tau+24)*N + g);\n"
        "    /* --- metadata: one .b32 per lane, produced by\n"
        "       cudez_mma_compress_2to4 in a MATCHING layout. Sparsity selector\n"
        "       is 0. NOTE: this per-lane metadata encoding is implemented to the\n"
        "       PTX ISA spec but is the piece NOT yet hardware-confirmed. */\n"
        "    unsigned meta = A_meta[((row0 / WM) * k_tiles + kt) * 32 + lane];\n"
        "    asm volatile(\n"
        "      \"%s \"\n"
        "      \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, \"\n"
        "      \"{%%8,%%9,%%10,%%11}, {%%0,%%1,%%2,%%3}, %%12, 0x0;\\n\"\n"
        "      : \"+f\"(acc[0]), \"+f\"(acc[1]), \"+f\"(acc[2]), \"+f\"(acc[3])\n"
        "      : \"r\"(a0), \"r\"(a1), \"r\"(a2), \"r\"(a3),\n"
        "        \"r\"(b0), \"r\"(b1), \"r\"(b2), \"r\"(b3), \"r\"(meta));\n"
        "  }\n"
        "  /* --- scatter: C/D fragment rows {g,g+8}, cols {2tau,2tau+1}. */\n"
        "  int r0 = g, r1 = g + 8, cc = 2*tau;\n"
        "  int i00 = (row0+r0)*N + col0+cc,   i01 = (row0+r0)*N + col0+cc+1;\n"
        "  int i10 = (row0+r1)*N + col0+cc,   i11 = (row0+r1)*N + col0+cc+1;\n"
        "  if (beta != 0.f) {\n"
        "    D[i00] = alpha*acc[0] + beta*Cin[i00];\n"
        "    D[i01] = alpha*acc[1] + beta*Cin[i01];\n"
        "    D[i10] = alpha*acc[2] + beta*Cin[i10];\n"
        "    D[i11] = alpha*acc[3] + beta*Cin[i11];\n"
        "  } else {\n"
        "    D[i00] = alpha*acc[0]; D[i01] = alpha*acc[1];\n"
        "    D[i10] = alpha*acc[2]; D[i11] = alpha*acc[3];\n"
        "  }\n"
        "}\n",
        is_bf16 ? "#include <cuda_bf16.h>\n" : "",
        name, ct, ct, ct, ct, op);

    if (len < 0 || (size_t)len >= bufsz) return 0;
    return 1;
}

/* ---- dense INT8/INT4 MMA source generation (0.3.0; fixed in 0.3.1) ----
 * DIFFERENT CODE PATH FROM DENSE F16/BF16/TF32, same reason the sparse
 * path already is: NVRTC's C++ front end does not reach the competitive
 * m16n8k32 (int8) / m16n8k64 (int4) dense-integer shapes -- those are only
 * reachable via inline PTX mma.sync, so this generator emits inline PTX
 * and gets none of the C++ front end's type checking.
 *
 * STATUS (0.3.1, honestly): the 0.3.0 revision of this generator emitted
 * kernels that NEVER LOADED A or B (the operand registers stayed zero) and
 * whose output scatter was computed per-WARP rather than per-LANE (all 32
 * lanes raced to write the same 4 cells). Both are fixed here:
 *   - Per-lane operand loads and the output scatter now follow the fragment
 *     layouts enumerated mechanically from NVIDIA CUTLASS's CuTe MMA_Traits
 *     (include/cute/atom/mma_traits_sm80.hpp, atoms
 *     SM80_16x8x32_S32S8S8S32_TN and SM80_16x8x64_S32S4S4S32_TN), which
 *     encode the PTX ISA "Matrix Fragments" tables:
 *       lane = tid.x & 31, grp = lane >> 2, tid = lane & 3, E = 4 (s8) / 8 (s4)
 *       A reg r: row = grp + 8*(r & 1), k = E*tid + (r >= 2 ? WK/2 : 0) + e
 *       B reg r: col = grp,             k = E*tid + r*(WK/2) + e
 *       C c0..c3 -> (grp,2*tid), (grp,2*tid+1), (grp+8,2*tid), (grp+8,2*tid+1)
 *     with elements packed ascending within each 32-bit register (lowest K
 *     index in the lowest byte/nibble; int4 low nibble = lower element).
 *   - Every generated variant compiles under real NVRTC 12.9 and assembles
 *     under real ptxas for sm_80 through sm_120.
 *   - NOT YET DONE: numerical verification on real tensor cores against a
 *     reference GEMM. Until that lands, diff a small case against a CPU
 *     reference before trusting results in production.
 *
 * DATA CONTRACT of the generated kernel (now enforced in comments and in
 * the K-loop bound, previously silently mishandled):
 *   A is M x K row-major; B is K x N row-major; D is M x N row-major.
 *   M %% 16 == 0, N %% 8 == 0, K %% WK == 0 (WK = 32 int8 / 64 int4) are
 *   REQUIRED -- there is no edge-tile predication in this correctness-first
 *   generator, and ragged sizes would read/write out of bounds.
 *   INT4: A and B hold 2 int4 values per byte, low nibble = even (lower)
 *   element index; K counts int4 ELEMENTS, so a row of A is K/2 bytes.
 *
 * CORRECTNESS-FIRST, NOT YET PIPELINED: one global->register load per
 * K-step, no shared-memory staging / double-buffering / cp.async, and no
 * ldmatrix. Deferred on purpose (roadmap), because this path needed to be
 * *correct* before it is made fast. k_chunks is honored as a #pragma
 * unroll hint on the K-loop (0.3.0 accepted the field but never emitted
 * it, so it silently did nothing while still being part of the cache key).
 *
 * REQUANT EPILOGUE: three bodies selected by cfg->requant_mode:
 *   NONE:       raw int32 accumulator written to D (D is int32*).
 *   PERTENSOR:  D[i] = acc[i] * scale + zero_point, scalar args, D float*.
 *   PERCHANNEL: D[row][col] = acc[row][col] * scale[col] + zero_point[col],
 *               one pair per output column (device pointers), D float*.
 * scale/zero_point are launch-time kernel arguments, NOT config fields --
 * see the doc comment on cudez_mma_config.requant_mode for why.
 * ---------------------------------------------------------------------- */

CUDEZ_INLINE int cudez_mma_int_source_(const cudez_mma_config *c, const char *name,
                                       char *buf, size_t bufsz) {
    const int is4 = (c->dtype_ab == CUDEZ_MMA_INT4);
    const char *mma_shape = is4
        ? "mma.sync.aligned.m16n8k64.row.col.s32.s4.s4.s32"
        : "mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32";
    const int WK = is4 ? 64 : 32;
    const char *loads;
    const char *epilogue;
    /* Same k_chunks<=0 backstop as the dense generator (0.7.0, BUG-5): omit the
       pragma rather than emit "#pragma unroll(0)". Build-path validation already
       rejects k_chunks<1, but cudez_mma_source() bypasses it. */
    char unroll[32];
    int len;

    if (c->k_chunks > 0) snprintf(unroll, sizeof unroll, "#pragma unroll(%d)\n", c->k_chunks);
    else                 unroll[0] = '\0';

    if (is4) loads =
        "    const int Kb = K >> 1, Nb = N >> 1;  /* int4: 2 elements per byte */\n"
        "    const signed char *a_lo = A + (long long)(trow + grp) * Kb + ((k0 + tid * 8) >> 1);\n"
        "    const signed char *a_hi = a_lo + 8 * Kb;\n"
        "    a_reg[0] = CZ_LD4_(a_lo, 1);       a_reg[1] = CZ_LD4_(a_hi, 1);\n"
        "    a_reg[2] = CZ_LD4_(a_lo + 16, 1);  a_reg[3] = CZ_LD4_(a_hi + 16, 1);\n"
        "    { int bn = tcol + grp, sh = (bn & 1) * 4;\n"
        "      const unsigned char *bp = (const unsigned char *)B\n"
        "          + (k0 + tid * 8) * Nb + (bn >> 1);\n"
        "      unsigned lo = 0, hi = 0;\n"
        "#pragma unroll\n"
        "      for (int j = 0; j < 8; j++) {\n"
        "        lo |= ((unsigned)((bp[j * Nb] >> sh) & 0xF)) << (4 * j);\n"
        "        hi |= ((unsigned)((bp[(j + 32) * Nb] >> sh) & 0xF)) << (4 * j);\n"
        "      }\n"
        "      b_reg[0] = lo; b_reg[1] = hi; }\n";
    else loads =
        "    const signed char *a_lo = A + (long long)(trow + grp) * K + k0 + tid * 4;\n"
        "    const signed char *a_hi = a_lo + 8 * K;\n"
        "    a_reg[0] = CZ_LD4_(a_lo, 1);       a_reg[1] = CZ_LD4_(a_hi, 1);\n"
        "    a_reg[2] = CZ_LD4_(a_lo + 16, 1);  a_reg[3] = CZ_LD4_(a_hi + 16, 1);\n"
        "    const signed char *bp = B + (long long)(k0 + tid * 4) * N + (tcol + grp);\n"
        "    b_reg[0] = CZ_LD4_(bp, N);         b_reg[1] = CZ_LD4_(bp + 16 * N, N);\n";

    if (c->requant_mode == CUDEZ_MMA_REQUANT_PERCHANNEL) {
        epilogue =
            "  D[(long long)row0 * N + col0]     = acc[0] * scale[col0]     + zero_point[col0];\n"
            "  D[(long long)row0 * N + col0 + 1] = acc[1] * scale[col0 + 1] + zero_point[col0 + 1];\n"
            "  D[(row0+8) * N + col0]     = acc[2] * scale[col0]     + zero_point[col0];\n"
            "  D[(row0+8) * N + col0 + 1] = acc[3] * scale[col0 + 1] + zero_point[col0 + 1];\n";
    } else if (c->requant_mode == CUDEZ_MMA_REQUANT_PERTENSOR) {
        epilogue =
            "  D[(long long)row0 * N + col0]     = acc[0] * scale + zero_point;\n"
            "  D[(long long)row0 * N + col0 + 1] = acc[1] * scale + zero_point;\n"
            "  D[(row0+8) * N + col0]     = acc[2] * scale + zero_point;\n"
            "  D[(row0+8) * N + col0 + 1] = acc[3] * scale + zero_point;\n";
    } else {
        epilogue =
            "  D[(long long)row0 * N + col0]     = acc[0];\n"
            "  D[(long long)row0 * N + col0 + 1] = acc[1];\n"
            "  D[(row0+8) * N + col0]     = acc[2];\n"
            "  D[(row0+8) * N + col0 + 1] = acc[3];\n";
    }

    len = snprintf(buf, bufsz,
        "/* pack 4 bytes at stride s into one register, little-endian */\n"
        "#define CZ_LD4_(p, s) ((unsigned)(unsigned char)(p)[0]"
        " | ((unsigned)(unsigned char)(p)[(s)] << 8)"
        " | ((unsigned)(unsigned char)(p)[2*(s)] << 16)"
        " | ((unsigned)(unsigned char)(p)[3*(s)] << 24))\n"
        "extern \"C\" __global__ void %s(\n"
        "    const signed char *A, const signed char *B,\n"
        "    %s *D, int M, int N, int K%s) {\n"
        "  /* One warp computes one 16x8 output tile of D = A * B via\n"
        "     %s.\n"
        "     REQUIRED: M %% 16 == 0, N %% 8 == 0, K %% %d == 0; A is M x K\n"
        "     row-major, B is K x N row-major%s.\n"
        "     Per-lane fragment layouts follow CUTLASS CuTe MMA_Traits\n"
        "     (mma_traits_sm80.hpp); source compiles under real NVRTC and\n"
        "     assembles under real ptxas (sm_80..sm_120) but is NOT YET\n"
        "     numerically verified on real hardware -- diff a small case\n"
        "     against a reference GEMM first. Correctness-first: no smem\n"
        "     staging / cp.async yet (see cudez.h roadmap). */\n"
        "  const int WM = 16, WN = 8, WK = %d;\n"
        "  long long warp_id = ((long long)threadIdx.x + (long long)blockIdx.x * blockDim.x) / 32;\n"
        "  int warps_per_row = (N + WN - 1) / WN;\n"
        "  int trow = (warp_id / warps_per_row) * WM;\n"
        "  int tcol = (warp_id %% warps_per_row) * WN;\n"
        "  if (trow >= M || tcol >= N) return;\n"
        "  int lane = threadIdx.x & 31;\n"
        "  int grp = lane >> 2, tid = lane & 3;\n"
        "  unsigned a_reg[4]; unsigned b_reg[2];\n"
        "  int acc[4] = {0, 0, 0, 0};\n"
        "  int k_tiles = K / WK;  /* K %% WK == 0 required, see above */\n"
        "%s"
        "  for (int kt = 0; kt < k_tiles; kt++) {\n"
        "    int k0 = kt * WK;\n"
        "%s"
        "    asm volatile(\n"
        "      \"%s \"\n"
        "      \"{%%0,%%1,%%2,%%3}, {%%4,%%5,%%6,%%7}, {%%8,%%9}, {%%0,%%1,%%2,%%3};\\n\"\n"
        "      : \"+r\"(acc[0]), \"+r\"(acc[1]), \"+r\"(acc[2]), \"+r\"(acc[3])\n"
        "      : \"r\"(a_reg[0]), \"r\"(a_reg[1]), \"r\"(a_reg[2]), \"r\"(a_reg[3]),\n"
        "        \"r\"(b_reg[0]), \"r\"(b_reg[1]));\n"
        "  }\n"
        "  int row0 = trow + grp;         /* this lane's accumulator coords: */\n"
        "  int col0 = tcol + (tid << 1);  /* c0..c3 -> (row0,col0), (row0,col0+1),\n"
        "                                    (row0+8,col0), (row0+8,col0+1) */\n"
        "%s"
        "}\n",
        name,
        (c->requant_mode == CUDEZ_MMA_REQUANT_NONE) ? "int" : "float",
        (c->requant_mode == CUDEZ_MMA_REQUANT_PERCHANNEL) ? ", const float *scale, const float *zero_point"
            : (c->requant_mode == CUDEZ_MMA_REQUANT_PERTENSOR) ? ", float scale, float zero_point" : "",
        mma_shape,
        WK,
        is4 ? ", packed 2 int4 per byte (low nibble = lower element)" : "",
        WK,
        unroll,
        loads,
        mma_shape,
        epilogue);

    if (len < 0 || (size_t)len >= bufsz) return 0;
    return 1;
}

/* ---- public entry points ---------------------------------------------- */

/* Fills buf with the generated CUDA C++ (or, for sparse, C++ + inline PTX)
   source for the given config, WITHOUT compiling it. Use this to inspect,
   log, or hand-modify a kernel before building -- recommended the first
   time you use any given config, given the verification status above.
   Returns 1 on success, 0 if buf was too small (caller should retry with
   a larger buffer). Source-size high-water in 1.3.0-dev is the pipeline v7
   kernel at ~7.7 KB; 8 KB still fits every config, 16 KB is what the
   internal build path allocates for headroom. */
CUDEZ_INLINE int cudez_mma_source(const cudez_mma_config *cfg, const char *kernel_name,
                                  char *buf, size_t bufsz) {
    if (cfg->sparse) return cudez_mma_sparse_source_(cfg, kernel_name, buf, bufsz);
    if (cfg->dtype_ab == CUDEZ_MMA_INT8 || cfg->dtype_ab == CUDEZ_MMA_INT4) {
        /* 1.7.0-dev: INT8 has a pipelined variant (smem_stage=5, the v7-class
           cp.async kernel) living in the main generator; everything else INT
           still routes to the streaming int generator. */
        if ((cfg->dtype_ab == CUDEZ_MMA_INT8 || cfg->dtype_ab == CUDEZ_MMA_INT4) &&
            cfg->smem_stage == 5) {
            /* Requant-epilogue guard (1.0.3, deferred item / BUG-2 follow-up):
               cudez_mma_cfg_valid_ rejects requant_mode!=NONE + smem_stage=5
               for exactly this reason, but this function is a public
               introspection entry (same as k_chunks<=0 just above) that
               callers -- and the `emit` tool -- can reach WITHOUT going
               through that validator. CUDEZ_I8_PIPE_SRC_/CUDEZ_I8R2_PIPE_SRC_
               have a fixed `int *D` signature with no scale/zero_point
               params; they ignore requant_mode entirely and always emit raw
               s32. Generating source for that combination would silently
               hand back C code that looks like it honors cfg->requant_mode
               but doesn't -- refuse here too rather than let the mismatch
               reach a caller as source they'd reasonably trust. */
            if (cfg->requant_mode != CUDEZ_MMA_REQUANT_NONE) {
                cudez_log_("cudez_mma_source: requant_mode=%d with smem_stage=5 "
                           "requested -- the pipelined INT8/INT4 kernel has NO "
                           "requant epilogue (raw s32 D only, no scale/zero_point "
                           "in its signature); refusing to generate source that "
                           "would silently ignore requant_mode. Use smem_stage=0 "
                           "for requantized output, or requant on the host.\n",
                           (int)cfg->requant_mode);
                return 0;
            }
            return cudez_mma_source_(cfg, kernel_name, buf, bufsz);
        }
        return cudez_mma_int_source_(cfg, kernel_name, buf, bufsz);
    }
    return cudez_mma_source_(cfg, kernel_name, buf, bufsz);
}

/* BUG-3 fix (1.0.2): the single source of truth the CUDEZ_V9_DYN_SMEM comment
   always promised. Build (below), launch, and occupancy ALL call this; they
   can no longer disagree (the sparse ring is STATIC smem and must price 0
   dynamic). Moved here (1.0.3) from just after cudez_try_mma_build so that
   function can call it at build time for the dynamic-smem opt-in hoist --
   plain definition-before-use ordering, this header has no forward
   declarations elsewhere and doesn't start using them just for this. */
CUDEZ_INLINE int cudez_mma_dyn_smem_(const cudez_mma_config *c) {
    if (c->smem_stage == 7 && !c->sparse) return CUDEZ_V9_DYN_SMEM;
    if (c->smem_stage == 8)               return CUDEZ_V10_DYN_SMEM;
    return 0;
}

/* Non-aborting build: validates cfg against cz's actual compute capability
   (real cuDeviceGetAttribute query from boot, not a guess), generates
   source, compiles via the ordinary NVRTC build path (cudez_try_build),
   and returns a launchable cudez_mma_kernel. No caching is performed by
   this call itself -- see cudez_try_mma_build_cached below for a cached
   variant, which is almost always what you want if you build the same
   config more than once (e.g. across frames). */
CUDEZ_INLINE CUresult cudez_try_mma_build(const cudez *cz, const cudez_mma_config *cfg,
                                          const char *kernel_name,
                                          cudez_mma_kernel *out) {
    char errbuf[256];
    char *src;
    cudez_program prog;
    CUresult err;
    size_t srcbuf_sz = 16384;   /* 1.3.0-dev high-water: v7 (staged epilogue)
                                ~7.7 KB; headroom for the BF16/TF32
                                staging extensions */

    memset(out, 0, sizeof *out);
    out->cfg = *cfg;

    if (!cudez_mma_cfg_valid_(cz, cfg, errbuf, sizeof errbuf)) {
        cudez_log_("cudez_mma: invalid config: %s\n", errbuf);
        return CUDA_ERROR_INVALID_VALUE;
    }

    {
        const char *nm = kernel_name ? kernel_name : "cudez_mma_kernel";
        size_t l = strlen(nm);
        if (l >= sizeof out->generated_name) l = sizeof(out->generated_name) - 1;
        memcpy(out->generated_name, nm, l);
        out->generated_name[l] = 0;
    }

    src = (char *)CUDEZ_ALLOC(srcbuf_sz);
    if (!src) return CUDA_ERROR_OUT_OF_MEMORY;

    if (!cudez_mma_source(cfg, out->generated_name, src, srcbuf_sz)) {
        cudez_log_("cudez_mma: generated source exceeded %lu byte "
                "internal buffer -- this is a cudez bug, please report it\n",
                (unsigned long)srcbuf_sz);
        CUDEZ_FREE(src);
        return CUDA_ERROR_INVALID_VALUE;
    }

    {
        /* NVRTC has NO idea what device is present -- with no options it
           targets compute_52, whose PTX ptxas then rejects on every arch
           because the .target directive gates instruction availability
           (verified against real NVRTC 12.9 + ptxas). Always pass the
           booted device's real compute capability. */
        char archopt[48];
        char incopt[560];
        const char *bopts[2];
        const char *incdir;
        int nb = 0;
        snprintf(archopt, sizeof archopt, "--gpu-architecture=compute_%d%d",
                 cz->cc_major, cz->cc_minor);
        bopts[nb++] = archopt;
        /* 0.7.1: NVRTC has NO default header search path either. The pip-wheel
           NVRTC resolves <mma.h> from its builtins, but distro-packaged NVRTC
           (e.g. Debian's) does not, failing with "no directories in search
           list". Set CUDEZ_NVRTC_INCLUDE to the directory containing mma.h
           (Debian: /usr/include) to pass it through; unset keeps the old
           builtins-only behavior. */
        incdir = getenv("CUDEZ_NVRTC_INCLUDE");
        if (incdir && incdir[0]) {
            int need = snprintf(incopt, sizeof incopt, "--include-path=%s", incdir);
            /* NVRTC-include-truncation fix (1.0.3, deferred item): incdir is
               env-controlled and arbitrary length; snprintf into a fixed
               buffer truncates silently on overflow with no error return of
               its own. need is the length that WOULD have been written --
               a value >= sizeof incopt (or negative, an encoding error) means
               the path was cut short and incopt now holds a corrupted
               directory that must NOT be handed to NVRTC as if it were real. */
            if (need < 0 || (size_t)need >= sizeof incopt) {
                cudez_log_("cudez: CUDEZ_NVRTC_INCLUDE is %zu bytes, "
                        "too long for the %zu-byte --include-path option buffer "
                        "-- refusing to pass a truncated/corrupted include path "
                        "to NVRTC. Shorten the path (e.g. a symlink) or raise "
                        "the buffer if you control this build.\n",
                        strlen(incdir), sizeof incopt);
                CUDEZ_FREE(src);
                return CUDA_ERROR_INVALID_VALUE;
            }
            bopts[nb++] = incopt;
        }
        err = cudez_try_build(cz, src, "cudez_mma.cu", bopts, nb, &prog);
    }
    CUDEZ_FREE(src);
    if (err != CUDA_SUCCESS) return err;

    err = cudez_try_kernel_get(&prog, out->generated_name, &out->kernel);
    if (err != CUDA_SUCCESS) return err;

    {
        /* Dynamic-smem opt-in hoist (1.0.3, deferred optimization): v9/v10
           exceed the 48 KB static smem ceiling, so the CUfunction must be
           granted a larger dynamic-smem budget via cuFuncSetAttribute
           before it can launch (sm_80+ opt-in) -- but that's a property of
           the FUNCTION/MODULE, set once, not of any individual launch.
           Previously this call fired on every cudez_mma_launch invocation
           (see that function's old comment: "could be hoisted to build
           time if it ever shows on a profile"). Doing it once here, right
           after the function handle exists, means a kernel built once via
           cudez_try_mma_build_cached and launched every frame pays this
           driver round-trip once per distinct kernel instead of once per
           frame. Idempotent either way, so this changes cost, not
           behavior: cuFuncSetAttribute caps at the device max, so a GPU
           that can't spare the requested budget still fails here, at
           build time, with the same clear message it used to fail with at
           first-launch time. */
        int dyn_smem = cudez_mma_dyn_smem_(cfg);
        if (dyn_smem) {
            CUresult ae = cuFuncSetAttribute(out->kernel.fn,
                CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES, dyn_smem);
            if (ae != CUDA_SUCCESS) {
                cudez_log_("cudez_mma_build: smem_stage=%d (ring "
                        "pipeline) needs %d B of dynamic shared memory; "
                        "cuFuncSetAttribute failed (%d). This GPU may cap "
                        "dynamic smem below that -- use smem_stage 6 (v8), "
                        "which fits the 48 KB static budget.\n",
                        cfg->smem_stage, dyn_smem, (int)ae);
                return ae;
            }
        }
    }
    return CUDA_SUCCESS;
}

/* Aborting convenience form, matching cudez_build's ergonomics. */
CUDEZ_INLINE cudez_mma_kernel cudez_mma_build(const cudez *cz, const cudez_mma_config *cfg,
                                              const char *kernel_name) {
    cudez_mma_kernel k;
    CUresult err = cudez_try_mma_build(cz, cfg, kernel_name, &k);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) abort();
#else
    (void)err;
#endif
    return k;
}

/* ---- launch helper (0.4.0) ----------------------------------------------
 * The single call that removes the biggest 0.3.x footgun: given a built
 * cudez_mma_kernel and this argument bundle, cudez computes grid/block from
 * the tile shape and marshals the kernel arguments in the exact order the
 * generated signature expects for this dtype and requant mode. You still
 * chose the tile / k_chunks at build time (mid-level, on purpose); this just
 * launches it correctly.
 *
 * WHICH FIELDS MATTER, by kernel:
 *   F16/BF16/TF32 dense : A, B, C, D, M, N, K, alpha, beta.  (C read only if
 *                         beta != 0; pass C=0 and beta=0 for a pure A*B.)
 *   F16/BF16 2:4 SPARSE : A (=compressed vals), meta, B, C, D, M,N,K, alpha,beta.
 *                         Produce A/meta with cudez_mma_compress_2to4. B/C/D are
 *                         dense. (Numerics are reference-grade -- see that
 *                         helper's note; run smoke_mma_gpu.c to confirm.)
 *   INT8/INT4 NONE      : A, B, D, M, N, K.                  D is int32*.
 *   INT8/INT4 PERTENSOR : ...+ scale, zero_point (scalars).  D is float*.
 *   INT8/INT4 PERCHANNEL: ...+ scale_ch, zp_ch (device arrays, length N).
 * warps_per_block sets the block width (warps_per_block*32 threads); <=0
 * defaults to 4. The grid is sized to cover (M/tile_m)*(N/tile_n) warp-tiles.
 *
 * Enforces the data contract (M%tile_m==0, N%tile_n==0, K%tile_k==0). Sparse
 * INT8/INT4 are not generated yet and are refused; F16/BF16 sparse launches.
 * Launches on cz->stream; cudez_finish() (or your own sync) before reading D. */
typedef struct {
    CUdeviceptr A, B, C, D;      /* device pointers; C used only for float+beta.
                                    For sparse, A is the compressed values array. */
    CUdeviceptr meta;            /* F16/BF16 sparse only: A_meta from compress_2to4. */
    int M, N, K;                 /* must satisfy the tile contract (checked). */
    int warps_per_block;         /* block = warps_per_block*32 threads; <=0 -> 4. */
    float alpha, beta;           /* F16/BF16/TF32 (dense or sparse). */
    float scale, zero_point;     /* INT + REQUANT_PERTENSOR (scalars). */
    CUdeviceptr scale_ch, zp_ch; /* INT + REQUANT_PERCHANNEL (device arrays len N). */
    /* --- 0.6.0: strided batched GEMM (dense F16/BF16/TF32 only) --- */
    int batch_count;         /* <=1: single GEMM (default). >1: that many GEMMs
                                in one launch via gridDim.z (max 65535). Because
                                callers zero-initialize this struct wholesale
                                (`= {0}` / memset), the 0-means-1 default keeps a
                                zeroed args a valid single GEMM (0.7.0, UX-4). */
    long long strideA, strideB, strideC, strideD; /* per-batch offsets, in ELEMENTS.
                                0.7.0: 64-bit so a large hidden-dim x sequence GEMM
                                cannot overflow the packed default on the host.
                                Exactly 0 -> packed default (M*K, K*N, M*N, M*N);
                                a NEGATIVE value is rejected (not treated as 0). */
    unsigned broadcast_mask; /* OR of CUDEZ_BROADCAST_A/B/C: force that operand's
                                stride to 0 so it is shared across the batch. There
                                is no D bit (0.7.0, UX-3) -- broadcasting the output
                                is meaningless (every element would overwrite the
                                same tile), and any mask bit outside A/B/C, or a bit
                                set together with an explicit nonzero stride for the
                                same operand, is rejected rather than silently
                                resolved (0.7.0, UX-2/UX-3). Shares the BUFFER; the
                                reads stay per-element (no cross-batch reuse yet). */
} cudez_mma_args;

/* Convenience constructor for the common "packed, no broadcast" batched case
   (0.7.0, UX-5), mirroring cudez_mma_defaults()/cudez_gemm()'s one-call ergonomics:
   returns a zeroed args with M/N/K/batch_count/alpha/beta and warps_per_block=4
   filled in. The caller still sets the A/B/C/D device pointers. Leaves every
   stride at 0 (packed) and broadcast_mask at 0. For batch_count<=1 this is just a
   convenient single-GEMM args initializer.
   NOTE: warps_per_block=4 is correct for streaming (smem_stage=0) or v7-class
   (smem_stage=5) kernels, but WRONG for v8/v9/v10-class kernels (smem_stage
   6/7/8), which require warps_per_block=16 -- if you build one of those for a
   batched launch, set a.warps_per_block = 16 yourself after calling this
   (cudez_mma_launch validates the mismatch and returns a clear error rather
   than launching wrong, but the error alone won't point back to this
   default). */
CUDEZ_INLINE cudez_mma_args cudez_mma_args_batched(int M, int N, int K,
                                                   int batch_count,
                                                   float alpha, float beta) {
    cudez_mma_args a;
    memset(&a, 0, sizeof a);
    a.M = M; a.N = N; a.K = K;
    a.batch_count = batch_count;
    a.alpha = alpha; a.beta = beta;
    a.warps_per_block = 4;
    return a;
}
CUDEZ_INLINE CUresult cudez_try_mma_launch(const cudez *cz, const cudez_mma_kernel *mm,
                                           const cudez_mma_args *a) {
    const cudez_mma_config *c = &mm->cfg;
    int wm = c->tile_m, wn = c->tile_n, wk = c->tile_k;
    int wpb = a->warps_per_block > 0 ? a->warps_per_block : 4;
    int is_int = (c->dtype_ab == CUDEZ_MMA_INT8 || c->dtype_ab == CUDEZ_MMA_INT4);
    int bc = a->batch_count > 0 ? a->batch_count : 1;
    long long tiles, blocks;   /* 0.7.0 (BUG-3): long is 32-bit on LLP64/Windows */
    unsigned bx, gx;
    unsigned dyn_smem = 0;     /* v9 (stage 7): >48 KB ring -> dynamic smem bytes */
    void *args[CUDEZ_MAX_LAUNCH_ARGS];   /* 0.7.0 (BUG-6); 1.1.0 (AUDIT-3):
        every push goes through the checked macro below. The 0.7.0 fix was an
        assert, which compiles to a NO-OP under -DNDEBUG (common in downstream
        release builds) -- "fails loudly" must not depend on a build flag, and
        the check must run BEFORE the write, not after. */
#define CUDEZ_PUSH_ARG_(p) do { \
        if (na >= CUDEZ_MAX_LAUNCH_ARGS) { \
            cudez_log_("cudez_mma_launch: launch-arg overflow (max %d) -- " \
                       "a kernel signature grew past CUDEZ_MAX_LAUNCH_ARGS; " \
                       "raise it and report this\n", CUDEZ_MAX_LAUNCH_ARGS); \
            return CUDA_ERROR_INVALID_VALUE; \
        } \
        args[na++] = (void *)(p); \
    } while (0)
    int na = 0;

    if (!mm->kernel.fn) return CUDA_ERROR_INVALID_VALUE;
    if (c->sparse && is_int) {
        /* 1.0.3-dev: INT8 sparse v7 (smem_stage==5) is now generated -- see
           CUDEZ_SPI8_PIPE_SRC_'s doc comment (UNVERIFIED on real hardware).
           Still rejected: INT4 sparse at any stage (Ampere's native INT4
           sparse pattern is 4:8, not 2:4 -- a genuinely different metadata
           scheme, not just "not built yet" the way this INT8 rung was), and
           INT8 sparse at any stage OTHER than 5 (streaming/ring remain
           unimplemented for INT8 sparse). */
        int int8_v7_built = (c->dtype_ab == CUDEZ_MMA_INT8 && c->smem_stage == 5);
        if (!int8_v7_built) {
            cudez_log_("cudez_mma_launch: 2:4 sparse for this INT dtype/stage "
                    "combo is not generated yet (INT8 sparse v7, smem_stage=5, "
                    "is; INT4 sparse and other INT8-sparse stages are roadmap "
                    "-- INT4's native sparse pattern is 4:8, not 2:4) -- "
                    "inspect roadmap\n");
            return CUDA_ERROR_NOT_SUPPORTED;
        }
    }
    if (bc > 1 && (is_int || c->sparse)) {
        cudez_log_("cudez_mma_launch: batched GEMM (batch_count>1) is "
                "dense F16/BF16/TF32 only in 0.6.0; INT/sparse batching is roadmap\n");
        return CUDA_ERROR_NOT_SUPPORTED;
    }
    if (bc > 65535) {
        cudez_log_("cudez_mma_launch: batch_count %d exceeds the "
                "gridDim.z limit of 65535; split the batch across launches\n", bc);
        return CUDA_ERROR_INVALID_VALUE;
    }
    if (wm <= 0 || wn <= 0 || wk <= 0 ||
        a->M <= 0 || a->N <= 0 || a->K <= 0 ||
        a->M % wm != 0 || a->N % wn != 0 || a->K % wk != 0) {
        cudez_log_("cudez_mma_launch: M,N,K must be positive with "
                "M%%%d==0, N%%%d==0, K%%%d==0 (got M=%d,N=%d,K=%d) -- this "
                "correctness-first generator has no edge predication\n",
                wm, wn, wk, a->M, a->N, a->K);
        return CUDA_ERROR_INVALID_VALUE;
    }

    /* A-2: v7 (stage 5) and v8 (stage 6) vectorize the GLOBAL C/D epilogue as
       float4 (*(float4*)&D[out]). The per-row offset is always a multiple of 4
       (N is a tile multiple, enforced above), so the only remaining requirement
       is a 16-byte-aligned base pointer -- true for a cuMemAlloc base, but NOT
       necessarily for an arena sub-view or element-offset sub-matrix. There is
       no scalar fallback on these stages, so a misaligned base would fault (or
       corrupt) at runtime. D is always written; C is read only when beta!=0.
       Refuse rather than risk it (use stage 3/4, or a 16B-aligned view). */
    if ((c->smem_stage == 5 || c->smem_stage == 6 || c->smem_stage == 7 ||
         c->smem_stage == 8) && !c->sparse &&
        (c->dtype_ab == CUDEZ_MMA_F16 || c->dtype_ab == CUDEZ_MMA_BF16 ||
         (c->dtype_ab == CUDEZ_MMA_INT8 && c->store_hint == 1))) {
        /* BUG-B fix (1.0.1): INT8 rung 2's staged epilogue does int4 (16 B)
           vector stores; a 4-B-aligned D passed validation and faulted. */
        if ((a->D & 0xF) || (a->beta != 0.0f && (a->C & 0xF))) {
            cudez_log_("cudez_mma_launch: smem_stage=%d uses a float4 "
                    "C/D epilogue requiring 16-byte-aligned base pointers; got "
                    "D=0x%llx C=0x%llx (beta=%g). Use smem_stage 3 or 4, or pass a "
                    "16-byte-aligned (sub)matrix.\n",
                    c->smem_stage, (unsigned long long)a->D,
                    (unsigned long long)a->C, (double)a->beta);
            return CUDA_ERROR_INVALID_VALUE;
        }
    }

    /* x-grid covers ONE GEMM's warp-tiles; z multiplies it by the batch. Compute
       in long long (BUG-3) so a large M*N with a small tile does not overflow, and
       range-check against the gridDim.x limit before narrowing to unsigned rather
       than letting an oversized count wrap silently. */
    if (c->smem_stage) {
        /* Staged pipelines: one block == one (bmm*wm)x(bmm*wn) block-tile of
           (bmm/2)x(bmm/2) warps; grid-x counts block-tiles directly. v3-v7 tile
           at 4x4 (64x64, 2x2=4 warps, BK=4*wk); v8 (stage 6) at 8x8 (128x128,
           4x4=16 warps, BK=2*wk=32 -- half BK keeps the wider panels under the
           48 KB static-smem ceiling at 2 blocks/SM). */
        int v8like = (c->smem_stage == 6 || c->smem_stage == 7 || c->smem_stage == 8);
        int bmm = v8like ? 8 : 4;   /* block tile = bmm*wm x bmm*wn */
        int bkm = v8like ? 2 : 4;   /* K stage step BK = bkm*wk */
        int req_warps = (bmm / 2) * (bmm / 2);     /* 4 (v3-v7) or 16 (v8/v9/v10) */
        if (c->smem_stage == 7 && c->dtype_ab == CUDEZ_MMA_TF32) {
            /* TF32 ring: 128x128 block from m16 x n8 frags; BK = 2*wk = 16. */
            wm = 16; wn = 16; wk = 8;
        }
        int i8pipe = (c->smem_stage == 5 &&
                      (c->dtype_ab == CUDEZ_MMA_INT8 || c->dtype_ab == CUDEZ_MMA_INT4 ||
                       c->dtype_ab == CUDEZ_MMA_TF32 || c->sparse));
        if (i8pipe) {
            /* INT8 pipeline: fixed 64x64 block / BK=64 / 4 warps. The f16 bmm*wn
               math would read tile_n=8 (the m16n8k32 fragment width) and derive a
               64x32 block, but the kernel builds its 32-wide warp region from FOUR
               n8 fragments -- geometry is fixed by the generator, not the frags. */
            wm = 16; wn = 16; wk = 16;   /* reuse the f16 tiling arithmetic: */
            bmm = 4;                     /* 64x64 block, 4 warps, for all of them */
            bkm = (c->dtype_ab == CUDEZ_MMA_INT4) ? 8   /* BK=128 (s4 k64 x2) */
                : (c->dtype_ab == CUDEZ_MMA_INT8 && !c->sparse) ? 4   /* dense: BK=64 (s8 k32 x2) */
                : 2;   /* tf32 k8 x4; F16/BF16/INT8 sparse k32 x1 (1.0.3-dev: INT8
                          sparse's CUDEZ_SPI8_PIPE_SRC_ uses k_stages=K/32, the SAME
                          BK=32 contract as existing F16/TF32 sparse -- this was
                          silently falling into the dense-INT8 bkm=4/BK=64 branch
                          above before this fix, since that branch only checked
                          dtype_ab, not sparse, which would have derived the WRONG
                          K-contract (K%%64==0 required) against a kernel that only
                          actually needs K%%32==0. Caught while wiring the launch
                          path, before ever reaching real hardware. */
            req_warps = 4;
        }
        if (wpb != req_warps) {
            cudez_log_("cudez_mma_launch: smem_stage=%d requires "
                    "warps_per_block==%d (the %dx%d-warp block-tile); got %d\n",
                    c->smem_stage, req_warps, bmm / 2, bmm / 2, wpb);
            return CUDA_ERROR_INVALID_VALUE;
        }
        if (a->M % (bmm * wm) != 0 || a->N % (bmm * wn) != 0) {
            cudez_log_("cudez_mma_launch: smem_stage=%d tiles blocks at "
                    "(%d*%d)x(%d*%d) (%dx%d warps x 2x2 tiles each); "
                    "requires M %% %d == 0 and N %% %d == 0 (got M=%d,N=%d)\n",
                    c->smem_stage, bmm, wm, bmm, wn, bmm / 2, bmm / 2,
                    bmm * wm, bmm * wn, a->M, a->N);
            return CUDA_ERROR_INVALID_VALUE;
        }
        if (a->K % (bkm * wk) != 0) {
            cudez_log_("cudez_mma_launch: smem_stage=%d stages K in "
                    "BK = %d*%d = %d element steps; requires "
                    "K %% %d == 0 (got K=%d)\n", c->smem_stage, bkm, wk,
                    bkm * wk, bkm * wk, a->K);
            return CUDA_ERROR_INVALID_VALUE;
        }
        tiles  = (long long)(a->M / (bmm * wm)) * (long long)(a->N / (bmm * wn));
        blocks = tiles;
        dyn_smem = cudez_mma_dyn_smem_(c);   /* BUG-3: shared helper */
        if (c->smem_stage == 8)
            dyn_smem = CUDEZ_V10_DYN_SMEM;
    } else {
        tiles  = (long long)(a->M / wm) * (long long)(a->N / wn);
        blocks = (tiles + wpb - 1) / wpb;
    }
    if (blocks > 2147483647LL) {   /* CUDA gridDim.x max is 2^31 - 1 */
        cudez_log_("cudez_mma_launch: grid-x block count %lld exceeds "
                "the gridDim.x limit of 2147483647 (M=%d,N=%d,tile=%dx%d, "
                "warps_per_block=%d) -- use a larger tile/block or split the GEMM\n",
                blocks, a->M, a->N, wm, wn, wpb);
        return CUDA_ERROR_INVALID_VALUE;
    }
    bx = (unsigned)(wpb * 32);
    gx = (unsigned)blocks;
    /* cuFuncSetAttribute(MAX_DYNAMIC_SHARED_SIZE_BYTES) used to be called here,
       on every launch. Hoisted to build time (1.0.3, deferred optimization --
       see cudez_try_mma_build): it is a property of the CUfunction, set once,
       not of any individual launch. dyn_smem itself is still needed below as
       cuLaunchKernel's own dynamic-smem-bytes argument, which is a required
       per-launch parameter distinct from the attribute ceiling.
       NOTE for hand-built kernels: if you construct a cudez_mma_kernel
       yourself (cudez_try_build + cudez_try_kernel_get, bypassing
       cudez_try_mma_build) with smem_stage 7 or 8, YOU must call
       cuFuncSetAttribute(fn, CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES,
       cudez_mma_dyn_smem_(cfg)) yourself before first launch -- this function
       no longer does it for you. Skipping it fails loudly at cuLaunchKernel
       (the kernel requests more dynamic smem than the function is configured
       to allow), not silently. */

    if (c->sparse && c->dtype_ab == CUDEZ_MMA_INT8) {
        /* 1.0.3-dev: INT8 sparse v7 (CUDEZ_SPI8_PIPE_SRC_, UNVERIFIED on real
           hardware) has its OWN 7-arg signature -- (A_vals, A_meta, B, D, M,
           N, K), no C/alpha/beta at all, matching dense INT8's no-epilogue-
           scaling convention. This must be its own branch, checked BEFORE
           the general `if (c->sparse)` branch below: that branch pushes the
           F16/BF16-sparse 10-arg layout (...C,D,M,N,K,alpha,beta), which
           would silently misinterpret this kernel's actual (D,M,N,K)
           parameters as if C/alpha/beta existed in between them -- caught
           while wiring this in, before ever reaching real hardware. */
        CUDEZ_PUSH_ARG_(&a->A);  CUDEZ_PUSH_ARG_(&a->meta);
        CUDEZ_PUSH_ARG_(&a->B);  CUDEZ_PUSH_ARG_(&a->D);
        CUDEZ_PUSH_ARG_(&a->M);  CUDEZ_PUSH_ARG_(&a->N);
        CUDEZ_PUSH_ARG_(&a->K);
        return cuLaunchKernel(mm->kernel.fn, gx, 1, 1, bx, 1, 1, 0, cz->stream, args, NULL);
    }

    if (c->sparse) {
        /* F16/BF16 sparse: single-GEMM signature (gridDim.z = 1). Routed through
           the same checked CUDEZ_PUSH_ARG_ path as the dense/int branches (B-2)
           so a future sparse-signature change gets the same launch-arg overflow
           protection everything else already has. (na == 0 here.) */
        CUDEZ_PUSH_ARG_(&a->A);     CUDEZ_PUSH_ARG_(&a->meta);
        CUDEZ_PUSH_ARG_(&a->B);     CUDEZ_PUSH_ARG_(&a->C);
        CUDEZ_PUSH_ARG_(&a->D);     CUDEZ_PUSH_ARG_(&a->M);
        CUDEZ_PUSH_ARG_(&a->N);     CUDEZ_PUSH_ARG_(&a->K);
        CUDEZ_PUSH_ARG_(&a->alpha); CUDEZ_PUSH_ARG_(&a->beta);
        return cuLaunchKernel(mm->kernel.fn, gx, 1, 1, bx, 1, 1, 0, cz->stream, args, NULL);
    }

    if (is_int) {
        /* INT8/INT4: unchanged single-GEMM signature. */
        CUDEZ_PUSH_ARG_(&a->A);
        CUDEZ_PUSH_ARG_(&a->B);
        CUDEZ_PUSH_ARG_(&a->D);
        CUDEZ_PUSH_ARG_(&a->M);
        CUDEZ_PUSH_ARG_(&a->N);
        CUDEZ_PUSH_ARG_(&a->K);
        if (c->requant_mode == CUDEZ_MMA_REQUANT_PERTENSOR) {
            CUDEZ_PUSH_ARG_(&a->scale);
            CUDEZ_PUSH_ARG_(&a->zero_point);
        } else if (c->requant_mode == CUDEZ_MMA_REQUANT_PERCHANNEL) {
            CUDEZ_PUSH_ARG_(&a->scale_ch);
            CUDEZ_PUSH_ARG_(&a->zp_ch);
        }
        return cuLaunchKernel(mm->kernel.fn, gx, 1, 1, bx, 1, 1, 0, cz->stream, args, NULL);
    }

    /* Dense float (F16/BF16/TF32): the one 13-arg batched kernel serves both the
       single and batched cases (gridDim.z==1 is the single GEMM). Resolve the four
       64-bit strides once; the locals must outlive the cuLaunchKernel call (they
       do -- the driver copies kernel params during the call). */
    {
        long long sA, sB, sC, sD;

        /* OPT-1: the hot path is a single GEMM called repeatedly. When bc==1 with
           no strides and no broadcast, blockIdx.z is always 0, so every stride is
           multiplied by 0 and their values are irrelevant -- skip the resolution
           and validation work entirely and pass zeros. */
        if (bc == 1 && a->strideA == 0 && a->strideB == 0 && a->strideC == 0 &&
            a->strideD == 0 && a->broadcast_mask == 0) {
            sA = sB = sC = sD = 0;
        } else {
            unsigned mask = a->broadcast_mask;
            /* UX-3: only A/B/C can be broadcast; any other bit (notably a D bit) is
               rejected rather than silently ignored. */
            if (mask & ~CUDEZ_BROADCAST_ALL) {
                cudez_log_("cudez_mma_launch: broadcast_mask 0x%x sets a "
                        "bit outside CUDEZ_BROADCAST_A/B/C (0x%x); D cannot be "
                        "broadcast and stray bits are not accepted\n",
                        mask, (unsigned)CUDEZ_BROADCAST_ALL);
                return CUDA_ERROR_INVALID_VALUE;
            }
            /* BUG-2: only exactly 0 means "use the packed default"; a negative
               stride is a caller mistake, not a request for the default. */
            if (a->strideA < 0 || a->strideB < 0 || a->strideC < 0 || a->strideD < 0) {
                cudez_log_("cudez_mma_launch: negative stride "
                        "(A=%lld,B=%lld,C=%lld,D=%lld) -- only 0 means 'use the "
                        "packed default'; pass a nonnegative element offset\n",
                        a->strideA, a->strideB, a->strideC, a->strideD);
                return CUDA_ERROR_INVALID_VALUE;
            }
            /* UX-2: broadcast and an explicit nonzero stride for the SAME operand
               are two ways to say different things; setting both is a mistake, so
               reject it instead of silently letting the mask win. */
            if (((mask & CUDEZ_BROADCAST_A) && a->strideA != 0) ||
                ((mask & CUDEZ_BROADCAST_B) && a->strideB != 0) ||
                ((mask & CUDEZ_BROADCAST_C) && a->strideC != 0)) {
                cudez_log_("cudez_mma_launch: broadcast_mask 0x%x "
                        "conflicts with an explicit nonzero stride for the same "
                        "operand (A=%lld,B=%lld,C=%lld) -- set a stride OR broadcast "
                        "it, not both\n", mask, a->strideA, a->strideB, a->strideC);
                return CUDA_ERROR_INVALID_VALUE;
            }
            /* BUG-1: compute the packed defaults in long long so M*K / K*N / M*N
               never overflow on the host (M/N/K are int; the product is 64-bit). */
            sA = a->strideA > 0 ? a->strideA : (long long)a->M * (long long)a->K;
            sB = a->strideB > 0 ? a->strideB : (long long)a->K * (long long)a->N;
            sC = a->strideC > 0 ? a->strideC : (long long)a->M * (long long)a->N;
            sD = a->strideD > 0 ? a->strideD : (long long)a->M * (long long)a->N;
            if (mask & CUDEZ_BROADCAST_A) sA = 0;   /* share A across the batch */
            if (mask & CUDEZ_BROADCAST_B) sB = 0;   /* share B */
            if (mask & CUDEZ_BROADCAST_C) sC = 0;   /* share C */
            /* No D broadcast: rejected above, never silently applied. */

            /* NULL-C-stride fix (1.0.3, deferred item): C is documented as
               unused when beta==0 ("pass C=0 and beta=0 for a pure A*B"),
               and every generated kernel gates the read behind
               `if (beta != 0.f)` -- but sC above was still resolved to a
               real per-batch offset (explicit or the packed M*N default)
               regardless of beta. A natural beta=0 batched call with C=NULL
               and strideC left at its 0 "use default" sentinel then computed
               `Cin + blockIdx.z * strideC` on a null base for every batch
               index > 0 on the device -- pointer arithmetic past a null
               pointer, UB even though the result is never read. Force sC to
               0 whenever beta==0 so the null base is never offset; matches
               the alignment guard just above, which already only checks
               `a->C`'s bits when beta != 0.0f. */
            if (a->beta == 0.0f) sC = 0;
        }

        CUDEZ_PUSH_ARG_(&a->A);
        CUDEZ_PUSH_ARG_(&a->B);
        CUDEZ_PUSH_ARG_(&a->C);
        CUDEZ_PUSH_ARG_(&a->D);
        CUDEZ_PUSH_ARG_(&a->M);
        CUDEZ_PUSH_ARG_(&a->N);
        CUDEZ_PUSH_ARG_(&a->K);
        CUDEZ_PUSH_ARG_(&sA);
        CUDEZ_PUSH_ARG_(&sB);
        CUDEZ_PUSH_ARG_(&sC);
        CUDEZ_PUSH_ARG_(&sD);
        CUDEZ_PUSH_ARG_(&a->alpha);
        CUDEZ_PUSH_ARG_(&a->beta);
        return cuLaunchKernel(mm->kernel.fn, gx, 1, (unsigned)bc,
                              bx, 1, 1, dyn_smem, cz->stream, args, NULL);
    }
}
#undef CUDEZ_PUSH_ARG_

/* Aborting convenience form, matching the rest of the layer. */
CUDEZ_INLINE void cudez_mma_launch(const cudez *cz, const cudez_mma_kernel *mm,
                                   const cudez_mma_args *a) {
    CUresult err = cudez_try_mma_launch(cz, mm, a);
#ifndef CUDEZ_NO_ABORT
    if (err != CUDA_SUCCESS) {
        cudez_log_("cudez_mma_launch: %s\n", cudez_strerror(err));
        abort();
    }
#else
    (void)err;
#endif
}


/* ---- occupancy reporting (0.5.0) ----------------------------------------
 * Thin pass-through to cuOccupancyMaxActiveBlocksPerMultiprocessor so a caller
 * can reason about the warps_per_block / block-tile tradeoff before launching.
 * Returns the max resident blocks per SM for this kernel at the given block
 * width (warps_per_block*32 threads), or 0 on error. Pipelines v3-v8 declare
 * their staging as STATIC __shared__ arrays sized by the compile-time tile config,
 * so their dynamic smem is 0 and the driver already prices the static usage
 * (v3 ~18.4 KB, v4 ~36.9 KB with default tiles). v9 (smem_stage=7) is the
 * exception: it launches with CUDEZ_V9_DYN_SMEM (56,832 B) of DYNAMIC smem, so
 * that figure must be handed to the occupancy query or it would over-report
 * residency in v9's favour (it caps at 1 block/SM on sm_86). */
CUDEZ_INLINE int cudez_mma_max_active_blocks(const cudez_mma_kernel *mm, int warps_per_block) {
    int blocks = 0;
    int threads = (warps_per_block > 0 ? warps_per_block : 4) * 32;
    size_t dyn = (size_t)cudez_mma_dyn_smem_(&mm->cfg);   /* BUG-3: shared helper --
        the sparse ring is static smem and must price 0 dynamic here too. */
    if (!mm->kernel.fn) return 0;
    if (cuOccupancyMaxActiveBlocksPerMultiprocessor(&blocks, mm->kernel.fn, threads, dyn) != CUDA_SUCCESS)
        return 0;
    return blocks;
}

/* ---- config-keyed cache -------------------------------------------------
 * A tiny fixed-size cache (linear scan, CUDEZ_MMA_CACHE_MAX entries) so
 * repeatedly building "the same" mma kernel (e.g. once per frame, or once
 * per distinct shape in a model's layer stack) does not re-invoke NVRTC
 * every time. An entry hits only if ALL of (a) every cudez_mma_config field
 * matches (explicit field-by-field compare, not memcmp -- so the cache is
 * correct regardless of enum width / struct padding on any toolchain, and
 * callers need not zero-pad), (b) the owning CUcontext matches, AND
 * (c) the owning boot_gen matches (1.0.3, deferred item). The context check
 * alone is load-bearing but not sufficient: a module lives in the context
 * that built it, so a cached CUfunction from context X must never be
 * launched under a different (or torn-down-and-rebooted) context -- that
 * would launch on a freed module (AUDIT: cross-context cache hazard, fixed
 * in 1.0.2 with the ctx check alone). What the ctx check by itself cannot
 * catch: the driver API does not guarantee a destroyed context's CUcontext
 * handle value is never reused by a later cuCtxCreate -- if it were, a
 * cache entry from the OLD (now-freed) context would look like a same-
 * context hit against the NEW context that happens to share its pointer
 * value. boot_gen (a counter incremented on every successful cudez_try_boot)
 * disambiguates "same pointer value" from "same actual boot," closing that
 * gap without needing the driver to promise anything about handle reuse. */
#ifndef CUDEZ_MMA_CACHE_MAX
# define CUDEZ_MMA_CACHE_MAX 32
#endif

typedef struct {
    cudez_mma_config keys[CUDEZ_MMA_CACHE_MAX];
    CUcontext        ctx[CUDEZ_MMA_CACHE_MAX];   /* owning context per entry */
    unsigned long long boot_gen[CUDEZ_MMA_CACHE_MAX]; /* owning boot generation */
    cudez_mma_kernel vals[CUDEZ_MMA_CACHE_MAX];
    int used[CUDEZ_MMA_CACHE_MAX];
    int n;
} cudez_mma_cache;

CUDEZ_INLINE void cudez_mma_cache_init(cudez_mma_cache *cache) {
    memset(cache, 0, sizeof *cache);
}

/* Explicit field-by-field config equality (see cache doc: avoids depending on
   enum width / padding, and makes the key self-documenting). Update this if a
   field is ever added to cudez_mma_config. */
CUDEZ_INLINE int cudez_mma_cfg_eq_(const cudez_mma_config *a, const cudez_mma_config *b) {
    return a->dtype_ab == b->dtype_ab &&
           a->tile_m == b->tile_m && a->tile_n == b->tile_n && a->tile_k == b->tile_k &&
           a->k_chunks == b->k_chunks && a->sparse == b->sparse &&
           a->requant_mode == b->requant_mode &&
           a->smem_stage == b->smem_stage && a->store_hint == b->store_hint;
}

/* Looks up cfg in cache; on miss, builds via cudez_try_mma_build and
   inserts (evicting nothing -- once CUDEZ_MMA_CACHE_MAX distinct configs
   have been built, further misses still build and run correctly, they
   just are not cached; raise CUDEZ_MMA_CACHE_MAX before including cudez.h
   if you need more resident configs than that). Returns CUDA_SUCCESS and
   fills *out on either a hit or a successful miss-build. */
CUDEZ_INLINE CUresult cudez_try_mma_build_cached(const cudez *cz, cudez_mma_cache *cache,
                                                 const cudez_mma_config *cfg,
                                                 const char *kernel_name,
                                                 cudez_mma_kernel *out) {
    int i;
    for (i = 0; i < cache->n; i++) {
        if (cache->used[i] && cache->ctx[i] == cz->context &&
            cache->boot_gen[i] == cz->boot_gen &&
            cudez_mma_cfg_eq_(&cache->keys[i], cfg)) {
            *out = cache->vals[i];
            return CUDA_SUCCESS;
        }
    }
    {
        CUresult err = cudez_try_mma_build(cz, cfg, kernel_name, out);
        if (err != CUDA_SUCCESS) return err;
        if (cache->n < CUDEZ_MMA_CACHE_MAX) {
            cache->keys[cache->n] = *cfg;
            cache->ctx[cache->n]  = cz->context;
            cache->boot_gen[cache->n] = cz->boot_gen;
            cache->vals[cache->n] = *out;
            cache->used[cache->n] = 1;
            cache->n++;
        }
        return CUDA_SUCCESS;
    }
}

/* ---- one-call dense GEMM (0.5.0; caching default since 1.1.0) -----------
 * Convenience composition for the common case: capability-check, pick the
 * right tile via cudez_mma_defaults, build, and launch -- D = alpha*A*B +
 * beta*C -- in a single call. For float dtypes only (F16/BF16/TF32); INT8/
 * INT4 (which need requant plumbing) and sparse use the explicit build+launch
 * path. STILL REQUIRES the tile contract (M/N/K multiples; no auto-padding).
 * PIPELINE: this convenience path uses cudez_mma_defaults, i.e. the STREAMING
 * kernel (smem_stage=0) -- portable to any 16-multiple shape, but DRAM-bound and
 * the slowest option. It deliberately does not auto-pick v3-v9, because those
 * carry stricter shape contracts (e.g. v8/v9 need M/N %% 128, K %% 32) that an
 * arbitrary GEMM may not satisfy, and silently rejecting shapes this call
 * currently accepts would be worse. To use the fast pipelines today, build with
 * an explicit cfg.smem_stage (5=v7 small shapes, 6=v8 / 7=v9 large shapes) via
 * cudez_try_mma_build[_cached] + cudez_try_mma_launch. Shape-aware auto-selection
 * (pick_pipeline) is on the roadmap and will land after v9's silicon validation.
 * 1.1.0 (AUDIT-9): this is the friendliest-named entry point in the MMA API,
 * which is exactly why first-time users put it in hot loops -- where the old
 * behavior (a fresh NVRTC compile EVERY call) dominated their frame time. It
 * now builds through a per-translation-unit static cudez_mma_cache, so
 * repeated calls reuse the compiled kernel. NOTE: the static cache is per-TU
 * and NOT thread-safe -- multithreaded builders, or callers wanting explicit
 * cache ownership/eviction, should use cudez_try_mma_build_cached +
 * cudez_try_mma_launch directly; a fresh-compile-every-call path remains via
 * cudez_try_mma_build. Returns a CUresult: CUDA_ERROR_NOT_SUPPORTED if the
 * device or dtype can't run this path. */
CUDEZ_INLINE CUresult cudez_gemm(const cudez *cz, cudez_mma_dtype dtype,
                                 CUdeviceptr A, CUdeviceptr B, CUdeviceptr C, CUdeviceptr D,
                                 int M, int N, int K, float alpha, float beta) {
    static cudez_mma_cache cache_;   /* zero state == cudez_mma_cache_init */
    cudez_mma_config cfg;
    cudez_mma_kernel mm;
    cudez_mma_args a;
    CUresult err;
    if (dtype == CUDEZ_MMA_INT8 || dtype == CUDEZ_MMA_INT4) return CUDA_ERROR_NOT_SUPPORTED;
    if (!cudez_mma_supported(cz, dtype, 0)) return CUDA_ERROR_NOT_SUPPORTED;
    /* 1.0.1 (analysis Option A): the one-call path now routes through the
       dispatcher -- previously it built the STREAMING kernel for every shape,
       so casual users paid 5-8x for kernels the library had already beaten. */
    cfg = cudez_mma_pick(dtype, 0, M, N, K);
    err = cudez_try_mma_build_cached(cz, &cache_, &cfg, "cudez_gemm", &mm);
    if (err != CUDA_SUCCESS) return err;
    memset(&a, 0, sizeof a);
    a.A = A; a.B = B; a.C = C; a.D = D;
    a.M = M; a.N = N; a.K = K; a.alpha = alpha; a.beta = beta;
    a.warps_per_block = (cfg.smem_stage >= 6) ? 16 : 4;   /* ring family = 16 */
    return cudez_try_mma_launch(cz, &mm, &a);
}

/* ---- 2:4 structured-sparsity compression + metadata (0.5.0) -----------
 * Host-side, correctness-oriented (runs once on the CPU to prepare data;
 * not a hot path). Takes a dense M x K row-major float matrix and produces
 * the two inputs the sparse kernel consumes:
 *   - vals: M x (K/2) -- the two largest-magnitude values of each contiguous
 *     4-group, in ascending original-position order (this is the pruning +
 *     compression step; correct and architecture-independent).
 *   - meta: (M/16) * (K/32) * 32 unsigned words -- ONE .b32 per lane per
 *     16x32 tile, packed in the exact layout cudez_mma_sparse_source_ loads
 *     (lane -> g=lane/4, tau=lane%4; the word encodes the 2-bit nonzero
 *     positions for (row g, grp tau), (row g, grp tau+4), (row g+8, grp tau),
 *     (row g+8, grp tau+4), 4 bits each, low word).
 * Requires M %% 16 == 0 and K %% 32 == 0; returns 0 otherwise.
 *
 * HONESTY BOUNDARY (unchanged standard): the VALUES (pruning/compression) are
 * trustworthy. The per-lane METADATA bit-layout is implemented to the PTX ISA
 * sparse-MMA description and is internally consistent with the kernel, but it
 * was corrected in 0.7.1 after the 0.7.0 layout FAILED the on-device diff on an
 * RTX 3060 (sm_86): a 7-candidate probe identified the pair-thread 32-bit
 * layout below as the one the hardware consumes (0/512 mismatches, exact).
 * CONFIRMED on sm_86; other architectures still need their own smoke run.
 * ---------------------------------------------------------------------- */
CUDEZ_INLINE int cudez_mma_2to4_indices_(const float *grp, int *k0, int *k1) {
    int idx[4]; int a, b, tmp;
    idx[0]=0; idx[1]=1; idx[2]=2; idx[3]=3;
    for (a = 1; a < 4; a++) {
        b = a;
        while (b > 0 && fabs((double)grp[idx[b]]) > fabs((double)grp[idx[b-1]])) {
            tmp = idx[b]; idx[b] = idx[b-1]; idx[b-1] = tmp; b--;
        }
    }
    *k0 = idx[0] < idx[1] ? idx[0] : idx[1];
    *k1 = idx[0] < idx[1] ? idx[1] : idx[0];
    return 0;
}
CUDEZ_INLINE int cudez_mma_compress_2to4(const float *dense, int M, int K,
                                         float *vals /* M*(K/2) */,
                                         unsigned *meta /* (M/16)*(K/32)*32 */) {
    int R, J, rt, kt, k_tiles, row_tiles;
    unsigned char *idx_cache; /* one byte per (row, 4-group): k0 in bits[1:0],
        k1 in bits[3:2]. 1.0.3 (deferred item, "3x compress sort"):
        cudez_mma_2to4_indices_ used to be called 3x per group -- once here,
        then twice more re-deriving the SAME sort for metadata lanes tau and
        tau+2 (which the metadata loop's own comment says "carry identical
        words" -- true of the STORED result, not of whether it needs
        re-sorting). Sort each group exactly once into this cache; every
        reader below (vals fill, both metadata lanes) looks it up instead of
        re-sorting. M*(K/4) bytes -- e.g. 4096x4096 is 4 MB, transient and
        freed before this function returns. */
    if (M % 16 != 0 || K % 32 != 0) return 0;

    idx_cache = (unsigned char *)CUDEZ_ALLOC((size_t)M * (K / 4));
    if (!idx_cache) return 0;

    for (R = 0; R < M; R++)
        for (J = 0; J < K / 4; J++) {
            const float *grp = dense + (size_t)R * K + J * 4;
            int k0, k1; cudez_mma_2to4_indices_(grp, &k0, &k1);
            idx_cache[(size_t)R * (K/4) + J] = (unsigned char)((k0 & 3) | ((k1 & 3) << 2));
            vals[(size_t)R * (K/2) + J*2 + 0] = grp[k0];
            vals[(size_t)R * (K/2) + J*2 + 1] = grp[k1];
        }

    k_tiles = K / 32; row_tiles = M / 16;
    for (rt = 0; rt < row_tiles; rt++)
        for (kt = 0; kt < k_tiles; kt++) {
            int g, tau;
            for (g = 0; g < 8; g++)
                for (tau = 0; tau < 2; tau++) {
                    /* HARDWARE-CONFIRMED layout (0.7.1, RTX 3060 / sm_86, via
                       the candidate probe): each lane carries a FULL 32-bit
                       word. base = (lane & 1) * 4 selects the k-group quad
                       (groups 0..3 or 4..7 of the 16x32 tile); the low 16
                       bits hold row g's four nibbles (group order
                       low->high), the high 16 bits row (g+8)'s. Lanes tau
                       and tau+2 carry identical words, so sparsity selector
                       0 (threads tau 0/1) reads a complete set and the
                       encoding stays selector-agnostic. The pre-0.7.1
                       per-lane 16-bit spread was disproven on hardware.
                       1.0.3: lane = g*4+tau and its partner lane+2 = g*4+
                       tau+2 always shared g and base (both derived from
                       lane -- g=lane>>2 groups 4 consecutive lanes, base
                       depends only on parity), so the two lanes always
                       computed the identical word anyway; compute it once
                       here and write it to both instead of re-deriving it
                       per lane. (An earlier draft of this fix tried a
                       simple `lane += 2` stride, which does NOT reproduce
                       this pairing -- lane 2's real partner is lane 0, not
                       lane 4 -- caught by re-deriving the g/base arithmetic
                       with concrete lane values before trusting it.) */
                    int lane = g * 4 + tau, base = tau * 4, i;
                    unsigned word = 0;
                    for (i = 0; i < 4; i++) {
                        unsigned char packed = idx_cache[(size_t)(rt*16 + g) * (K/4) + (kt*8 + base + i)];
                        word |= ((unsigned)packed) << (4 * i);
                        packed = idx_cache[(size_t)(rt*16 + g + 8) * (K/4) + (kt*8 + base + i)];
                        word |= ((unsigned)packed) << (16 + 4 * i);
                    }
                    meta[((size_t)(rt * k_tiles + kt)) * 32 + lane]     = word;
                    meta[((size_t)(rt * k_tiles + kt)) * 32 + lane + 2] = word;
                }
        }
    CUDEZ_FREE(idx_cache);
    return 1;
}

/* ============================================================================
 * ROADMAP NOTES SPECIFIC TO CUDEZ_MMA (honest gaps, not silently deferred)
 *
 *  1. NUMERICAL verification on real tensor cores is the standing gap. The
 *     dense F16/BF16/TF32 and INT8/INT4 kernels, AND the new 2:4 sparse kernel,
 *     compile under real NVRTC 12.9 and assemble under real ptxas; what is NOT
 *     done in-tree is a diff against a reference GEMM on a live GPU. The shipped
 *     harness smoke_mma_gpu.c does exactly that (exact for int, epsilon for
 *     float, plus a 2:4 sparse check) -- run it once per architecture. For the
 *     sparse path specifically the metadata bit-layout is the piece most likely
 *     to need a hardware-confirmed tweak; the harness pinpoints it.
 *  2. NEW in 0.5.0 -- 2:4 sparse is a REAL kernel, not a skeleton. It loads the
 *     compressed A fragment and the dense B fragment per the documented m16n8k32
 *     lane layout, loads per-lane metadata, issues plain mma.sp (sm_80 form),
 *     and scatters D -- and cudez_try_mma_launch now launches it. Prepare inputs
 *     with cudez_mma_compress_2to4 (values are exact; the metadata encoding is
 *     implemented to the PTX ISA spec but hardware-unconfirmed -- item 1). Added
 *     cudez_gemm() (one-call dense GEMM for float dtypes).
 *  3. 0.4.0 control surface + fixes (retained): warps_per_block is launch
 *     geometry not identity (clean cache); cudez_mma_defaults/supported/
 *     try_mma_launch; dense TF32 __float_to_tf32; dense K-loop requires K%WK==0.
 *     INT8/INT4 per-lane load+scatter fixed in 0.3.1 (CUTLASS CuTe layouts;
 *     assemble sm_80..sm_120). Remaining gap for all paths is the numerical diff.
 *  4. sm_90+ SPARSE: cudez emits plain mma.sp, correct for Ampere (sm_80). On
 *     Hopper/Blackwell (sm_90+) the required form is mma.sp::ordered_metadata
 *     (PTX ISA 8.5), whose metadata ordering differs; emitting it (and its
 *     reordered metadata) per target arch is a tracked follow-up. Sparse
 *     INT8/INT4 (m16n8k64) and TF32 1:2 are also not generated yet -- same
 *     mechanics, different metadata grouping; add after F16/BF16 is
 *     hardware-confirmed. cudez_try_mma_launch refuses sparse INT8/INT4 today.
 *  5. THROUGHPUT, updated for 0.9.0. The 0.8.0 bench harness turned this item
 *     from prose into numbers (streaming F16 = 17-40% of cuBLAS on the
 *     reference sm_86; sparse = 13-63% of cuSPARSELt), and the ladder below is
 *     being climbed one bench-judged rung at a time. Status of the original
 *     (a)-(g) list:
 *       (a) block-level shared-memory tiling -- LANDED 0.8.0 (smem_stage=1;
 *           BLOCK_* derive from tile_* as 4x rather than being separate
 *           identity fields, a simpler contract than planned).
 *       (e) register blocking -- LANDED 0.8.0 (the v3 rung: 2x2 WMMA tiles
 *           per warp; v1/v2 losers documented in the 0.8.0 changelog).
 *       (c) cp.async double buffering -- LANDED 0.9.0 (smem_stage=2,
 *           pipeline v4, sm_80+): 2-deep producer/consumer smem queue, step
 *           s+1 staged behind step s's mma_syncs. Chosen as smem_stage
 *           values rather than the planned cfg.pipeline_stages field --
 *           each pipeline is a distinct verified kernel, not a dial.
 *       (b) ldmatrix + raw mma.sync -- IN CODE 1.2.0 (smem_stage=4,
 *           pipeline v6): v5's body with the wmma inner loop replaced by
 *           explicit ldmatrix/mma.sync.m16n8k16 PTX, layouts sourced from
 *           CUTLASS MMA_Traits + the PTX ISA tables and the full index flow
 *           proven bit-exact GPU-free (emu_v6.py). 63 reg vs v5's 69 at the
 *           same smem. Unblocks (d). Hardware gates: the K=192 wrap smoke,
 *           the 768x128x128 partial-band smoke, and the bench verdict.
 *       (d) XOR swizzle -- OPEN, now UNBLOCKED by (b). Padding currently
 *           buys bank-conflict freedom for 8 elements/row of smem; swizzle
 *           would buy it for free and shrink v4's 36.9 KB footprint
 *           (= +1 resident block/SM at default tiles).
 *       (f) split-K / stream-K -- OPEN, now tied to a measured symptom: the
 *           v3 1024^3 wave-quantization dip (0.8.0 guide 4.2).
 *       (g) warp specialization -- still post-1.0. Field note from the
 *           Hopper "outperform cuBLAS" worklogs: dedicated producer/consumer
 *           warpgroups pay off there because wgmma is asynchronous and TMA
 *           is a separate engine; on sm_86, wmma is synchronous per-warp, so
 *           v4 software-pipelines all 128 threads instead. Revisit only on
 *           sm_90+ codegen.
 *     NEW candidate rungs translated from the same worklogs to what sm_86
 *     actually has (each one bench-gated, one change per rung):
 *       (h) epilogue store hints -- IN CODE 1.1.0 (cfg.store_hint=1, on
 *           pipeline v4 or v5 -- orthogonal to rung (i), so the bench can
 *           judge the 2x2: v4, v4h, v5, v5h): output tiles are write-once, never re-read
 *           by the kernel, so evict-first stores (st.global.cs via a
 *           store_matrix_sync round-trip through the dead staging smem)
 *           keep D from thrashing L2 that A/B panels want (the small-GPU
 *           analogue of Hopper's TMA stores bypassing L2 on the way out).
 *           Bench verdict PENDING -- the measured motivation is the v4
 *           2048^3+ clock-sag asymmetry (0.9.0 ledger 4.3: cuBLAS held
 *           ~18.2 TFLOPS through a 2010 MHz->trough sag while v4 fell
 *           15.7->11.4); accepted or rejected per shape by the bench,
 *           like every rung before it.
 *       (i) L2-aware block scheduling -- IN CODE 1.1.0 (smem_stage=3,
 *           pipeline v5): v4's kernel body, unchanged, with a grouped-
 *           rasterization remap of blockIdx.x -> block-tile in place of
 *           v3/v4's plain row-major div/mod, so blocks resident at the
 *           same time share more of the same A-row panel in L2 -- the
 *           poor man's TMA multicast (also interacts with (f)).
 *           Deliberately a NEW smem_stage value rather than an edit to v4
 *           in place, so the bench judges it against v4 head-to-head with
 *           v4 still available as the control -- same discipline
 *           v1-vs-v2-vs-v3-vs-v4 already used. Verified GPU-free at merge:
 *           bijection brute-forced over 1..16 x 1..16 tile grids, source
 *           compiles under real NVRTC 12.9 and assembles under real ptxas
 *           for sm_86. NOT yet numerically verified on hardware: the
 *           768x128x128 smoke gate (partial final GROUP_M band --
 *           bt_per_col=12 spans two groups; a same-shaped 128x128 gate
 *           would never exercise the boundary clamp) and the bench verdict
 *           are the release gates.
 *  5b. INT8/INT4 and the sparse kernel each need this same ladder applied
 *     (sparse now has a quantified target: 13-63% of cuSPARSELt).
 *  6. NON-throughput ergonomics (from peer review; host-verifiable). FIXED in
 *     0.6.0: device arena + batch allocator and pinned host pool (both with
 *     cudez_try_* forms) cut the per-tile allocation cost; reentrant
 *     cudez_strerror_r + single-write cudez_log_ remove the shared-static-buffer
 *     aliasing when two error strings hit one printf. FIXED in 0.5.0:
 *     cudez_reg_grow_ now routes through CUDEZ_ALLOC/FREE with a NULL check (was
 *     raw realloc, OOM-corrupting); added cudez_mma_max_active_blocks (occupancy
 *     reporting). STILL OPEN: CUDEZ_NO_ABORT and the new cudez_try_* forms cover
 *     boot/build/mma_build and the 0.6.0 memory paths, but the OLDER data-path
 *     calls (buffer_new/write, read, launch, finish, graph_*) still abort via
 *     CUDEZ_CHECK and want cudez_try_* counterparts; the cache has no eviction
 *     past CUDEZ_MMA_CACHE_MAX; neither cache nor registry is thread-safe. The
 *     thread-safety fix is the natural home for C11 <stdatomic.h> (a deliberate
 *     later track), not a throughput change.
 *  7. FP8 (e4m3/e5m2, Hopper+) is NOT generated; the enum/ctype/supported/
 *     validator are structured to make it additive (new enum + ctype + cc-floor
 *     + generator branch), as INT8/INT4 were over 0.2.0.
 *  8. cudez_gemm (0.5.0) is the one-call float path but is NOT yet the full
 *     high-level GEMM: it still requires the M%16/N%8/K%WK contract (no auto-
 *     padding) and does not fall back to a CUDA-core kernel when tensor cores
 *     do not apply. Auto-padding + edge-tile predication (masked loads/stores
 *     for ragged M/N/K) are the coupled next step, and belong ON TOP of the
 *     tile-explicit path, never in place of it.
 * ========================================================================== */

#endif /* CUDEZ_H */
