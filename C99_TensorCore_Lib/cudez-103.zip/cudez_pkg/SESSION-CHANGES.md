# cudez 1.0.2 → 1.0.3: session changes

## UPDATE 7: kernel runs to completion, but produces WRONG numbers — real progress, real limit

`smoke` got past all three prior crash points. The whole suite now runs to
completion (including everything after `test_sparse_int8` — `test_pipe18_`
and beyond, all PASS). This confirms the alignment fix (UPDATE 6) and the
register-count fix (UPDATE 5) were both real and correct — the kernel
launches, executes, and returns without faulting.

But the numbers are wrong:
```
SPARSE INT8 mismatch at (0,0): gpu=-5 ref=-1
SPARSE INT8 mismatch at (0,1): gpu=-22 ref=-28
... (8 total, all different magnitudes, no constant offset or scale factor)
INT8 2:4 sparse (64x64x32): FAIL (exact int32)
```

**What this rules out, confirmed by direct calculation, not assumption:**
- `cudez_mma_compress_2to4`'s output (`vals`/`meta`) is provably correct —
  built a full CPU-side model that reconstructs the original dense A rows
  from the compressed values + metadata bit-for-bit, for the test's exact
  2:4 input. This function is shared with F16/BF16 sparse (both PASS), so
  this was never really in doubt, but it's now directly confirmed rather
  than assumed for this specific test's data too.
- The B-register count/addressing (UPDATE 5's fix) is internally
  consistent: re-verified `b_lo`/`b_hi`'s row coverage matches a properly
  re-derived scaling of F16 sparse's own confirmed interleaved pattern
  (not just "some" coverage — the *specific* 4-row-block-then-+16-offset
  structure it uses is the correct generalization of F16's 2-row-then-+8
  pattern to INT8's 4-elements-per-register packing).
- The A-register count (2, not 4) re-derives correctly from a real
  invariant (compressed elements/thread must match F16 sparse's, adjusted
  for INT8's larger elements-per-register) — confirmed again this round.
- The sparsity selector (hardcoded `0x0` in the `asm` call) is not the
  problem — every `mma.sp` call in this file, including F16 sparse's
  confirmed-working one, hardcodes the same value.

**What's still unknown, honestly:** the exact per-lane fragment layout —
which specific bytes `mma.sp.s8.s8` expects to find in which lane's `a0`
vs `a1`, and at which column offset within each. I found one concrete
structural gap while re-deriving this: F16 sparse's A-registers split
across BOTH row-group (`g` vs `g+8`) AND column-offset (`2*tau` vs
`2*tau+8`) — 4 registers total, 2×2. My kernel's 2 registers only split
by row-group, using a single column offset (`lid*4`) that, by a coverage
count, reaches all 16 compressed bytes across the 4 `lid` values — so
coverage is complete, but I cannot confirm the specific byte-to-lane
assignment matches what the fixed-function tensor core hardware expects.
Coverage without the right assignment produces exactly this symptom:
plausible-but-wrong numbers, not garbage and not a crash.

**I tried to resolve this from documentation** — the PTX ISA has the
exact table (Table 99/100, "Sparse MMA .m16n8k32 fragment/metadata
layout for .u8/.s8 type"), but I could not retrieve that specific table's
content through available tools (only the table of contents). A real
practitioner hit the same wall on NVIDIA's own developer forums trying to
extract this exact information, which is part of why F16 sparse needed a
"candidate probe" against real silicon originally rather than being
derived from docs alone.

**Recommendation for closing this out:** the most direct path is the same
one that worked for F16 sparse originally — a small standalone probe
kernel that stages a known pattern into `a0`/`a1`/`b0`/`b1` and dumps
`acc[]` after a single `mma.sp` call, so the real per-lane assignment can
be read off directly from actual output rather than re-derived from
partial documentation. `compute-sanitizer --tool=racecheck` or
`--tool=memcheck` on the current kernel might also reveal something (an
uninitialized read, an actually-still-wrong address) that static analysis
here couldn't surface. I did not build this probe kernel — flagging it
as the recommended next step rather than guessing at more candidate
layouts, since further undirected guessing has a real chance of taking
longer than just measuring it once.

**No changes made in this update** — this was diagnosis only.
`cudez.h`/`cudez_test.c` are unchanged from UPDATE 6's shipped state; the
kernel is exactly as UPDATE 6 left it, still marked UNVERIFIED, now with
a confirmed-wrong verdict instead of an unconfirmed one. That's real
information, even though it's not the fix.

---

## UPDATE 6: third crash, real fix — smem row-stride alignment

Past UPDATE 5's B-register fix, `smoke` got further still (the `mma.sp`
instruction now assembles — `ptxas` accepted it) and hit a new failure,
this time at **runtime**, after the kernel had already launched:
```
cudez: CUDA error at cudez.h:1266: CUDA_ERROR_MISALIGNED_ADDRESS:
misaligned address
```
Line 1266 is `cudez_finish`'s `cuStreamSynchronize` — meaning the kernel
launched and started executing, and the fault only surfaced when the host
synchronized. This confirms the instruction *shape* was right (UPDATE 5's
fix held); the bug was in the kernel's own memory addressing.

**Root cause, found by computing it, not guessing:** `SKA=24` and
`SKB=72` (the padded shared-memory row strides) were chosen to avoid bank
conflicts by padding away from the real row size — but I never checked a
**separate, stricter** requirement: `cp.async`'s 16-byte transfers need a
16-byte-*aligned* destination address for every single row, and 24 and 72
are not multiples of 16. I computed it exactly: `i*24 % 16 != 0` for
every odd `i` (32 of 64 A-rows), `r*72 % 16 != 0` for half of every B-row
— both staging loops were faulting on roughly half their transfers.

The actual mistake, precisely: I copied the numeric values `24`/`72` from
the confirmed-working F16 sparse template without re-deriving them for
INT8's 1-byte elements. In F16's template those are *half-element* counts
(2 bytes each) — `24 half-elements = 48 bytes`, `72 half-elements = 144
bytes`, both cleanly divisible by 16, correctly aligned. Copying the same
*numbers* into a 1-byte-element context silently changed the byte count
without changing the alignment math to match.

**Fixed:** `SKA=16, SKB=64` — no padding at all. Re-derived properly this
time: any multiple of 16 satisfies the alignment requirement, so I
actually computed bank distributions for the real concern (the compute
loop's `unsigned*` reads) instead of assuming padding helps. Turns out
the *unpadded* row size gives perfect bank distribution (32/32, zero
conflicts) — better than the broken padded value (26/32) and far better
than the naive "safer-looking" `SKA=32` (16/32, worst option). Also
checked a second, separate alignment concern this fix surfaced — the
*global*-memory `cp.async` source addresses — and confirmed the kernel's
existing `K%%32==0`/`N%%64==0` launch contract already guarantees those
are aligned too, no new constraint needed.

**Verified:** re-generated the kernel and re-ran every alignment/bounds
check computationally against the actual new values — zero violations
across cp.async destinations (both A and B, all rows), compute-loop
4-byte-aligned reads, and the B-row bounds-safety check from UPDATE 5.
Confirmed F16/BF16 sparse's own `SKA=24`/`SKB=72` are correctly aligned
in their own (2-byte-element) context, so this fix is properly scoped to
just the new kernel, nothing else needed touching. Full gate suite green.

**Three real hardware-found bugs now, three real fixes** — a stale
validator check, a wrong register count, and a wrong byte-alignment
derivation. Each one came from an actual `ptxas`/driver error, not from
me guessing better. I still can't run real `ptxas` or real silicon here,
so this is still the honest state: structurally sound as far as I can
verify without hardware, numerically unconfirmed until `test_sparse_int8`
actually runs.

**Also added:** explicit `[trace] entering <test>` markers (with
`fflush`) before every smoke test from `test_int8` onward. Before finding
this specific bug, I genuinely could not be certain from log positioning
alone that `test_sparse_int8` was still the culprit — `cudez_finish` is
called by every test, so a crash there doesn't by itself say which test's
kernel faulted. It turned out to be right again, but I shouldn't have to
re-derive that confidence from indirect evidence each time. If a fourth
crash happens, whichever `[trace]` line is last in the output tells you
unambiguously which test to look at, no re-diagnosis needed.

---

## UPDATE 5: second crash, real fix — the actual mma.sp register bug

Past UPDATE 4's validator fix, `smoke` got further and hit a new failure:
```
cudez: cuModuleLoadDataEx failed: CUDA_ERROR_INVALID_PTX: a PTX JIT
compilation failed
```

This is `ptxas` (the PTX-to-SASS assembler) rejecting the generated
`mma.sp` instruction as structurally malformed — not a numeric-wrongness
question, an operand-count question. **This is exactly the risk I flagged
in the kernel's own doc comment as unresolved** — and having a real
hardware signal instead of just uncertainty let me actually nail it down
this time, properly, instead of guessing again.

**Root cause:** the `mma.sp.m16n8k32.s8.s8` instruction only had ONE B
register (`b0`) in the inline asm. Re-derived from a real invariant this
time (not analogy-by-proportion, which is what led to the wrong guess
last round): **B is dense/uncompressed in both sparse and dense `mma`
forms — 2:4 sparsity only ever compresses A** — so B's fragment element
count per thread must be *identical* between the dense and sparse forms
of the same instruction shape. Dense INT8's confirmed, silicon-verified
`m16n8k32` B fragment is 2 registers (`b_reg[0]`/`b_reg[1]`, offset by 16
K-rows). Sparse INT8 needs the same 2, not 1. Re-checked A the same way:
2 registers (`a0`/`a1`) turns out to have been correct all along.

**Fixed:** added `b1`, offset 16 rows into the staged B panel (mirroring
dense INT8's `bp + 16*N` pattern, adapted to this kernel's padded shared-
memory layout), and widened the `mma.sp` operand list from 8 to 9
placeholders (`%0`-`%8`) to match. Verified the two B-register reads
(`b_lo`/`b_hi` across all 4 `lid` values) cover the full 32-row K-panel
exactly once each, no gaps or overlaps — a real structural check, not
just "the operand count matches now."

**What I could and couldn't verify without hardware:** confirmed the
generated PTX-adjacent C++ is well-formed (`%0`-`%8` placeholders
contiguous, no gaps/duplicates; operand list counts match on both sides
of the `asm` statement), full gate suite still green. **Could not run
real `ptxas`** — the actual test of whether this now assembles is still
your box. If this specific error recurs, the doc comment now names
exactly what was checked and how, so there's a real trail to extend from
rather than starting over.

---

## UPDATE 4: the core-dump crash — real bug found and fixed, my mistake

A `smoke` run aborted (`SIGABRT`, core dumped) with:
```
cudez_mma: invalid config: sparse INT8/INT4 mma.sp is not generated by
cudez 0.3.0 -- dense INT8/INT4 only (see roadmap note)
./cudez_runall.sh: line 63: Aborted (core dumped) "$BIN" smoke "$DEV"
```

**Root cause, confirmed by reproducing it directly against the exact file
I shipped:** when I built `CUDEZ_SPI8_PIPE_SRC_` (the new INT8 2:4 sparse
kernel) in the previous update, I wired it into the source generator, the
launch-arg push, and the grid-size math — but never touched
`cudez_mma_cfg_valid_`, the config validator that runs **before** any of
that. It had a leftover blanket rejection for every sparse INT8/INT4
config, unchanged since a much older version of this file (hence the
"0.3.0" in the message — that's not a live version check, it's a stale
string literal from years before this session). `test_sparse_int8` calls
the *aborting* `cudez_mma_build`, so this rejection is a guaranteed
`abort()` — **on every device, every time, not an environment-specific
failure.** I verified this by running the exact validation call
`test_sparse_int8` makes against my own shipped `cudez.h` and reproducing
the identical error text before writing the fix.

**Fix:** narrowed the rejection to match what `cudez_mma_launch` already
correctly allows: INT8 sparse at `smem_stage==5` (the kernel that
actually exists, still UNVERIFIED on real hardware — see
`CUDEZ_SPI8_PIPE_SRC_`'s doc comment) is now accepted. INT4 sparse (any
stage) and INT8 sparse at any *other* stage remain correctly rejected,
with updated messages explaining why (INT4's real hardware pattern is
4:8, not implemented; INT8 streaming/ring sparse aren't built).

**Verified:** reproduced the exact failure first (confirmed my own
shipped file really did reject this config), then confirmed the fix
resolves it, then confirmed the fix doesn't over-widen — INT4 sparse and
INT8-sparse-at-wrong-stage both still correctly rejected, F16 sparse
(unaffected, pre-existing) still works. Ran the full `cudez_try_mma_build`
path end to end (validator → generator → NVRTC stub → module load →
kernel lookup) for the exact config `test_sparse_int8` uses — completes
cleanly now. Full gate suite (emulator/emit/retarget) still green.

**This one's on me** — I should have grepped for every place a sparse
INT8/INT4 rejection could live when I built the feature, not just the
launch-time gate. The lesson: when adding a new capability that a
validator is specifically designed to gate, check the validator itself
first, not just the places that consume its output.

---

## UPDATE: real-hardware bug found and fixed (post-3060-run)

A run on a real RTX 3060 Laptop (sm_86) showed `smoke` and `debug`
passing 100% (208 cases total, kernels are correct) but **every single
`bench` row failing** while cuBLAS and cuSPARSELt ran fine. Root cause,
confirmed and fixed:

`phase_abab` boots `cz` (creating and making `cz.context` current via
`cudez_boot`), then calls `cudaSetDevice(dev)` to set up cuBLAS.
`cudaSetDevice()` unconditionally calls `cuCtxSetCurrent()` to switch to
the runtime's **primary context** for the device — silently displacing
`cz.context` from being current. `cz.stream` is bound to `cz.context`
specifically, so every subsequent `cudez_try_mma_launch` call ran with
the wrong context current and failed. `smoke`/`debug` never hit this
because they never call `cudaSetDevice` — pure driver-API throughout, no
competing context to begin with.

This was introduced by this session's own ABAB restructure. My original
reasoning (documented in `phase_abab`'s own comment) was that runtime API
calls simply *adopt* whatever driver context is current — true, but
incomplete: I never checked that `cudaSetDevice` specifically *overwrites*
the current context rather than just reading it.

**Fix:** re-assert `cz.context` as current (`cuCtxSetCurrent`, with its
return value checked and the row skipped rather than silently continuing
on failure) immediately before every `bench_row_cudez_` call, in both the
main interleaved loop and the `cublasCreate`-failure fallback path.
Cheap and idempotent, so it doesn't matter what `cudaSetDevice` or any
cuBLAS call did to the current context in between rows.

**Verification:** syntax-clean, full gate suite still green (unaffected —
none of the emulator/emit/retarget gates exercise `phase_abab`). Since
`gstub`'s `cuCtxSetCurrent` stub always succeeds, I couldn't reproduce the
failure path in-sandbox; instead verified the control-flow logic in
isolation with a stub that can actually fail — confirmed a failing row is
skipped without aborting the rest of the loop, and a fully-succeeding run
still calls every row. **This needs to be re-run on your 3060 to confirm
`bench` actually produces results now** — that's the real test.

---

## UPDATE 2: sparse v9 rebalance CONFIRMED on real hardware — mixed but net positive

Two independent runs on the same RTX 3060 Laptop (bench_512/1024/2048/4096,
smoke 208/208, debug 176/176 both runs) after the context-currency fix
above. The sparse v9 A-staging rebalance (previously flagged UNVERIFIED)
now has real numbers:

**sparse v9 vs dense v9, TFLOPS ratio (higher = sparse ahead):**

| shape | before this session's fix (spreadsheet analysis) | after (this run) |
|---|---|---|
| 1024³ | ~97.5% | **101.1%** |
| 2048³ | ~93.8% | **180.4%** |
| 4096³ | ~70.3% | **95.7%** |

sparse v9 also now beats sparse v7 by 1.12–1.39x at 1024/2048/4096 — it
wasn't reliably ahead of v7 before. The 2048³ jump is large enough that
it's worth confirming again on a third run before treating the magnitude
as final, but the direction is consistent across both runs captured here.

**Not a clean win everywhere:** at 512³, sparse v9 is the WORST of the
three sparse paths (8.86 TFLOPS / 45.3% of cuSPARSELt vs. streaming's
10.53 and v7's 12.37) — its single measured trial time (0.398ms) is
roughly 15-20x the other two paths' times, which is not a subtle
regression, it's a shape mismatch. Almost certainly wave-quantization:
the ring's fixed 128×128 block tile means 512³ (4×4=16 block-tiles total)
badly underfills the SM count compared to v7's 64×64 tile (8×8=64
block-tiles) on the same shape. This is exactly why `cudez_mma_pick`'s
"big" gate (`M>=2048 || N>=2048 || K>=2048`) exists — 512³ was never
supposed to reach the ring kernel via the dispatcher, and doesn't in
`cudez_gemm`. It only shows up here because the bench harness's
`KSPARSEP9`/`F16 sparse v9` row explicitly forces `smem_stage=7` at every
tested size, dispatcher bypassed, specifically to compare pipelines
apples-to-apples across sizes. **If you're calling this kernel directly
(not through `cudez_gemm`), don't use the ring at 512³ or smaller.**

**Also observed:** the run's own clock-drift diagnostic flagged a real
SM clock swing (1425→900 MHz, >15%) within `bench_1024` — laptop/WSL2
DVFS behavior, not a regression, and the sensor-artifact wattage clamp
(BUG-D precedent) correctly reported sane in-run wattage (27-40 W)
despite `env.txt`'s standalone idle snapshot showing the same
752 W artifact the clamp exists for. Absolute TFLOPS in a single run
still carry some clock-regime noise; ratios measured close together
(same-row, ABAB-interleaved) are less affected.

---

## UPDATE 3: BF16 sparse smoke coverage + a new, UNVERIFIED INT8 sparse kernel

### BF16 sparse: closed the "should work, never tested" gap
`test_sparse_bf16` added to `smoke`, modeled directly on `test_sparse_f16`
with `__nv_bfloat16` throughout. BF16 sparse was already wired into
`cudez_mma_sparse_source_` and the launch validator claimed it as
supported, but nothing had ever actually run it against a GPU. This is
now a real numeric check (exact-magnitude comparison against a host
reference, same tolerance as the F16 sparse test) — **run `smoke` and
check this line specifically**, since it's genuinely new information
either way it comes out.

### INT8 2:4 sparse: a full kernel exists now, UNVERIFIED — this is the
### "will you actually test it" part

You asked for this to push sparse capability further. Real hardware
research first: Ampere's sparse tensor cores genuinely support INT8 at
the same 2:4 pattern F16/BF16 already use (`mma.sp.m16n8k32.s8.s8` is
real, confirmed via the PTX ISA's own fragment-layout section list and
independently via a peer-reviewed paper's Ampere sparse-shape table).
**INT4 sparse is a different story** — Ampere's native INT4 sparse
pattern is 4:8, not 2:4, a genuinely different metadata scheme, not just
"unbuilt" — still correctly rejected everywhere in the codebase.

New: `CUDEZ_SPI8_PIPE_SRC_` in `cudez.h` (a 64×64-block, 4-warp, v7-class
cp.async pipeline, modeled directly on the confirmed F16 sparse v7
kernel's structure), wired through `cudez_mma_sparse_source_`,
`cudez_mma_launch` (its own 7-arg signature — `A_vals, A_meta, B, D, M,
N, K`, no C/alpha/beta, matching dense INT8's no-epilogue-scaling
convention), and the grid/tile-size math. `test_sparse_int8` added to
`smoke` (`cc_major>=8` gated), doing an **exact int32 comparison** against
a host reference — no floating-point tolerance needed, unlike the F16/BF16
sparse tests, so this is actually the cleanest possible pass/fail signal
of any sparse test in this codebase.

**Read `CUDEZ_SPI8_PIPE_SRC_`'s doc comment in `cudez.h` before trusting
any output from this kernel.** The short version: staging, tile geometry,
padding, and the epilogue were derived with real confidence (byte-for-byte
worked out by hand, cross-checked against two independently-confirmed
kernels — F16 sparse's structure and dense INT8's confirmed fragment
loads). **The one piece that is genuinely uncertain is the innermost
compute loop's register count** — the kernel uses 2 A-registers (`a0`,
`a1`) and 1 B-register (`b0`), reasoned from dense INT8's proportions, but
a byte-coverage cross-check I ran against my own reasoning turned up an
internal inconsistency I could not resolve without real hardware (my
first-pass derivation said this should need 4 A-registers, matching F16
sparse's count, not 2). I caught this while reviewing my own draft and
documented it honestly in the kernel's own comment rather than picking
one answer and hiding the doubt — **if `test_sparse_int8` fails, this
register-count question is exactly where to look first.**

**Bugs caught and fixed while wiring this in, before ever reaching
hardware** (both would have caused real failures, not just "unverified
numerics"):
- The general sparse launch-arg push (`if (c->sparse) { ...10 args... }`)
  ran unconditionally for every sparse config, including this new INT8
  one — which needed its own 7-arg signature. Without a dedicated INT8
  branch checked first, every INT8-sparse launch would have pushed the
  wrong argument layout (silently reading `D`/`M`/`N`/`K` as if `C`,
  `alpha`, `beta` existed in between them).
- The grid/tile-size math's `bkm` (K-stage-size) selection only checked
  `dtype_ab`, not `sparse` — so INT8 sparse was inheriting dense INT8's
  `BK=64` contract instead of its own real `BK=32` (confirmed via this
  kernel's own `k_stages = K/32`). Would have derived the wrong
  `K%%64==0` requirement against a kernel that only actually needs
  `K%%32==0`.

Both were caught by tracing the actual generated code and cross-checking
byte/register math by hand — not assumed correct because the file
compiled. Neither would have shown up as a compile error; both would
have shown up as either a launch rejection (annoying but safe) or,
worse, a launch that "succeeds" with corrupted arguments (not safe).

---

No GPU access during this work — every item below was verified as far as
possible without hardware (syntax checks against the `gstub` driver-API
stubs, the GPU-free `emu_all.py` gate suite, `emit`/`retarget`, and
standalone host-logic tests against the real functions where the change
was pure host code). **Nothing here should be treated as ledger-grade
until re-run on real silicon.** That's what this file is for: a single
place to check off against your 3060 run, and to know which specific
things need your attention first if `smoke` or `bench` turns up something
unexpected.

Version bumped `1.0.2` → **`1.0.3`** (`CUDEZ_VERSION_PATCH` in `cudez.h`).

Files touched: `cudez.h`, `cudez_test.c`, `gstub/cuda.h` (driver-call stubs
added to keep the sandbox build syncing with `cudez.h`'s new calls).
`CUDEZ.md`, `emu_all.py`, both `.sh` scripts, and the PDF guide are
untouched — byte-identical to what you uploaded.

---

## Priority: run these smoke/bench cases first

If you only have time to spot-check a few things before a full run, these
are the highest-value, most-changed code paths:

-1. **`INT8 2:4 sparse` in `smoke`: confirmed FAIL, not a crash.** See
   UPDATE 7 above. The kernel runs to completion and produces plausible
   but wrong numbers — three real crash-bugs found and fixed this
   session (validator, register count, alignment), but the underlying
   per-lane fragment layout is still wrong and I couldn't isolate it
   further from documentation alone. Re-running `smoke` will reconfirm
   the same FAIL; it won't tell you anything new on its own. If you want
   to help close this out, UPDATE 7 has a specific recommendation (a
   small standalone probe kernel, or `compute-sanitizer`).
   `BF16 2:4 sparse` (a separate, simpler kernel) is still worth checking
   fresh — it hasn't shown a failure yet, but re-confirm since it runs
   right before the INT8 test in the same `smoke` pass.
0. **`bench 0 --only v9 --size 1024`** (or any small bench run) — confirms
   the context-currency fix above actually resolved the "every cudez row
   SKIPPED/FAILED" failure. Check the summary table has real numbers in
   the `cudez ms`/`TFLOPS` columns, not `skipped (capability or launch
   fail)`.
1. **`test_sparse_f16`** (runs on every device) and **`test_pipe18_`**
   (sm_80+, so your 3060 runs it) — exercises the rewritten
   `cudez_mma_compress_2to4` and the experimental sparse v9 rebalance.
2. **`bench 0 --only sparsev9 --size 512,1024,2048`** — the actual
   perf-relevant check for the sparse rebalance (see "Experimental,
   unverified" below). Compare against a `sparsev9` run on the *previous*
   `cudez.h` if you still have it, since that's the only way to know if
   the rebalance actually helped.
3. **Any batched TF32/INT8/INT4 launch through `cudez_gemm`** or
   `cudez_try_mma_build` + `cudez_try_mma_launch` directly with
   `smem_stage` 7 or 8 — exercises the dynamic-smem opt-in hoist (moved
   from launch time to build time; a mistake here would show up as a
   `cuFuncSetAttribute`/`cuLaunchKernel` failure on the *first* launch of
   a v9/v10-class kernel, not a slow-but-working kernel).

---

## Correctness fixes (verified in-sandbox; should be safe, still want confirmation)

### `cudez_teardown`: no synchronize before frees
`cuMemFree`/`cuModuleUnload`/`cuStreamDestroy`/`cuCtxDestroy` fired with
nothing guaranteeing in-flight async work on `cz->stream` or a registered
stream had finished. Added `cuCtxSynchronize()` at the top (making
`cz->context` current first, restoring the caller's context after).
**If you see anything different:** a teardown immediately after a launch,
under `compute-sanitizer`, is the way to confirm this actually closed the
gap — hard to observe otherwise since the race is timing-dependent.

### NULL C batch strides
`sC` (the C-operand batch stride) now forces to 0 whenever `beta==0`,
matching the "C read only if beta != 0" contract the alignment guard
already assumed. Previously a batched `beta=0, C=NULL` call computed
`Cin + blockIdx.z * strideC` on a null base — UB pointer arithmetic, never
dereferenced but still technically undefined. No expected behavior change
for any working code; closes a corner case.

### Zero-size buffer refusal
`cudez_buffer_new(cz, 0)` now returns `{ptr=0, size=0}` cleanly instead of
calling `cuMemAlloc(&p, 0)` (which the driver always refuses) and
`abort()`ing via `CUDEZ_CHECK`. `cudez_read`/`_write_async`/`_read_async`
gained a matching `ptr==0 && bytes>0` refusal, since the empty-buffer fix
made a genuinely-empty buffer look identical to a "size unknown, trust the
caller" one to the existing size check.

### Boot attribute-failure checks
`cuDeviceGetName` failure is now loud but non-fatal (cosmetic only —
feeds a display string and error messages). `cuDeviceGetAttribute`
(compute capability) failure now **fails boot outright** instead of
silently handing back `cc_major=cc_minor=0`. This mattered because
`cc=0` would have disarmed the sm_90+ sparse refusal
(`c->sparse && cc >= 90`) on real Hopper/Blackwell hardware — not
relevant to your 3060 (sm_86), but a real gap on newer silicon.

### Requant-epilogue guard closed at the source layer
`cudez_mma_cfg_valid_` already rejected `requant_mode != NONE` with
`smem_stage=5` for INT8/INT4 (the pipelined kernel has no requant
epilogue — raw s32 only). But `cudez_mma_source()` — a public
introspection entry point, and what the `emit` CLI calls — bypasses that
validator. It now carries the same guard directly. If you only ever call
`cudez_try_mma_build`/`cudez_gemm`, this was already safe; this closes
the gap for direct `cudez_mma_source()` callers and `emit`.

### CUDA-12 graph floor note (documentation only, no behavior change)
`cuGraphInstantiate`'s 3-arg call was already correct for CUDA 12+; added
a comment explaining why it fails to compile on an 11.x toolkit, so that
error is self-explanatory instead of a bare "too few arguments."

### Cache generation counter
`cudez_mma_cache` entries now carry a `boot_gen` (monotonic per-boot
counter) alongside the `CUcontext` pointer; a cache hit requires both to
match. Closes a theoretical gap where a destroyed context's handle value
could be reused by a later `cuCtxCreate`, which pointer-equality alone
couldn't distinguish from a genuine same-context hit.

### NVRTC include-path truncation
`CUDEZ_NVRTC_INCLUDE` (an env var, arbitrary length) was `snprintf`'d into
a fixed 560-byte buffer with the return value discarded — silent
truncation on overflow, then the corrupted path handed to NVRTC. Now
checks `snprintf`'s return value and refuses with a clear message instead
of silently building a broken `--include-path=`.

### Arena absolute alignment
`cudez_arena_alloc` aligned the *relative* bump offset to `ar->align`,
not the *absolute* address — only correct if `ar->base` itself happened
to already be a multiple of `ar->align`. `cudez_try_arena_create` allows
any `align` value with no upper bound, so a caller requesting e.g.
1024-byte alignment could silently get a pointer that wasn't. Fixed to
align the absolute candidate address. **No effect on the default 256-byte
alignment path** (verified byte-identical against the old logic in that
case) — only matters if you call `cudez_try_arena_create` with a custom
`align` above the empirical 256-byte floor.

---

## BUG-C (bench methodology): both halves done

- **Visibility**: the harness now self-samples SM clock/power/temp
  (`nvidia-smi`, same fields `cudez_gpumon.sh` uses) at phase boundaries
  and prints the drift directly in `bench` output.
- **Restructure**: `phase_cudez`/`phase_cublas` replaced by `phase_abab`,
  which boots cudez once, creates the cuBLAS handle/buffers once, and
  interleaves **per row** — cudez's trials immediately followed by
  cuBLAS's trials for the same shape, instead of two full separately-timed
  passes. This is the actual fix for the "phase-A/phase-B ordering under
  chassis heat-soak inflates %cuBLAS" methodology bug.
- The old `phase_cudez`/`phase_cublas` standalone wrappers were deleted
  (they'd become genuinely dead code once `phase_abab` existed, not kept
  around for a "standalone" use case that doesn't actually exist anywhere
  in this codebase).

**What to expect:** re-running `bench` should now show much smaller
row-to-row A→B clock drift than before. If a run's `[clock check]` lines
show a big jump anyway, that's real information — it means interleaving
alone wasn't enough for your particular thermal/power situation.

---

## Optimizations (mechanical, low-risk)

### Dynamic-smem opt-in hoisted from launch time to build time
`cuFuncSetAttribute(MAX_DYNAMIC_SHARED_SIZE_BYTES)` used to fire on
**every** `cudez_mma_launch` call for v9/v10-class kernels. It's a
property of the `CUfunction`, set once — now done once in
`cudez_try_mma_build`, removed from the launch path entirely. Verified
with an instrumented call-count test against the real functions: build
fires it once, five subsequent launches of the same built kernel add
zero additional calls.

**If you hand-construct a `cudez_mma_kernel`** (via `cudez_try_build` +
`cudez_try_kernel_get` directly, bypassing `cudez_try_mma_build`) for a
`smem_stage` 7/8 config, you now need to call the opt-in yourself —
documented at `cudez_try_kernel_get`. Every path in `cudez_test.c` goes
through `cudez_try_mma_build`, so this doesn't affect the harness.

### `cudez_log_` migration
All but one `fprintf(CUDEZ_LOG_FILE, ...)` call site (37 of 38) now route
through `cudez_log_`, which composes the full line in a bounded stack
buffer before one `fputs` — safer under concurrent logging, and now
format-checked by the compiler (`__attribute__((format(printf,...)))`,
GCC/Clang only, added as part of this migration). The one exception
(NVRTC compile-failure log dump) stays as raw `fprintf` on purpose — that
message embeds an arbitrary-length compiler log that must not be
truncated.

### 3× compress-sort eliminated
`cudez_mma_2to4_indices_` (a 4-element insertion sort) was called three
times per `(row, group)` pair in `cudez_mma_compress_2to4` — once
building `vals[]`, then twice more re-deriving the identical sort for
metadata lanes `tau` and `tau+2`. Now sorts once into a scratch cache;
every reader looks it up. **Verified byte-identical output** (both
`vals[]` and `meta[]`) against the pre-fix implementation across 10+
shapes, including against the real `cudez.h` function directly, not just
an extracted copy.

*Caught and fixed mid-implementation:* my first draft of the metadata-loop
rewrite used a naive `lane += 2` stride that doesn't correctly reproduce
the "tau/tau+2 carry identical words" pairing (lane 2's real partner is
lane 0, not lane 4). Caught by re-deriving the `g`/`base` arithmetic with
concrete numbers before trusting the original comment's phrasing, and
fixed before the byte-identical test ever ran clean.

---

## Confirmed on real hardware (was experimental/unverified — see UPDATE 2 above)

### Sparse v9 A-staging thread rebalance
Found and fixed a real structural asymmetry: sparse v9's A-staging loop
bound (256 elements) was exactly half `blockDim.x` (512, 16 warps), so
256 of 512 threads sat completely idle while A staged, then all 512
worked while B staged. Dense v9 has no such gap (its A-stage bound
equals `blockDim.x` exactly). Byte-count math confirms sparse still moves
25% *less* total smem traffic per stage than dense (12,288 vs 16,384 B)
despite this — so the idle-thread gap was a plausible, previously
undocumented contributor to sparse v9 losing to dense v9 on wall clock
despite `mma.sp` halving the compute work.

Rebalanced: A (256 elements) and B (512 elements) merged into one flat
768-element grid-stride loop across all 512 threads. Originally verified
only by construction (bijection proof + the `sp-ring` emulator gate,
which models data placement, not thread scheduling, so couldn't confirm
a wall-clock effect on its own). **Two real runs later (see UPDATE 2):
sparse v9 moved from losing to dense v9 at every large shape to beating
it at 1024/2048³ and nearly matching it at 4096³, and now consistently
beats sparse v7 too.** Confirmed real, not a sandbox-only hypothesis --
but see UPDATE 2 for the 512³ regression this rebalance does NOT fix
(that one is a dispatcher-gating question, not a staging question).

---

## Reviewed, found correct, no change made

Documented here so a future pass doesn't waste time re-checking the same
things — every claim below was actually traced/computed, not assumed:

- **TF32 ring smem padding**: `SKA`/`SKB` byte-strides checked against
  dense v9's — identical padding scheme, correctly avoids the naive
  power-of-2 bank-conflict trap. Checked all 32 threads in a warp's B-read
  pattern by hand — hits all 32 banks, zero conflicts.
- **TF32 `cvt.rna` conversion hoisting**: traced the loop nesting —
  each `A`/`B` element conversion already happens once and is reused
  across the inner loop that consumes it. Not redundant.
- **`cudez_mma_pick`'s shape-contract gates**: traced the *real*
  launch-time contract for both v7 and v9 (via `bmm`/`wm`/`wn`/`bkm`/`wk`)
  and confirmed the dispatcher's `m64`/`m128`/`K%32`/`K%64` gates match
  exactly — not overly conservative, not missing any shape that could
  legally reach a faster pipeline.
- **Sparse v7's staging loops**: unlike v9, both A and B loop bounds
  already equal or exceed `blockDim.x` correctly — no idle-thread issue
  there.
- **Argument-push order vs. generated kernel signatures**: checked
  position-for-position for both the TF32-ring (13-arg batched) and
  sparse (10-arg) signatures against `CUDEZ_PUSH_ARG_` call order. Exact
  match, both pipelines.
- **Per-TU gemm cache**: already implemented (`cudez_gemm`'s
  `static cudez_mma_cache`), dated in-code as pre-1.0.0 (folded into the
  1.0.0 re-baseline before the 1.0.2 audit that filed this as
  "deferred"). Nothing to do here — the deferred-items list appears to
  be stale on this one point.

## Not fixed — needs real hardware to even diagnose

- **TF32 large-shape gap** (67.5–71.4% of cuBLAS): every static angle
  checked came back clean (see above). The remaining gap is most likely
  the mandatory `cvt.rna` conversion cost and the halved ring depth TF32
  pays for its 4-byte element width vs. F16's 2-byte — architectural, not
  a bug. Needs `ncu` to actually characterize.
- **Sparse-vs-cuSPARSELt gap generally** (58–66%, prior to the rebalance
  above): still needs `ncu` (smem throughput, DRAM, mma-pipe utilization)
  to find anything beyond the idle-thread lead already acted on.

## Below-30%-of-cuBLAS sweep: nothing currently qualifies

Traced every "% of cuBLAS" figure in `CUDEZ.md` to its most current
state. Everything that was ever below 30% was either a superseded ladder
rung the dispatcher no longer selects (the changelog states this
explicitly: "the 8-30% band is now EMPTY of live picks," after the
batched-routing fix), or INT4, which has no cuBLAS baseline at all — the
metric doesn't apply. Confirmed none of this session's changes touched
`cudez_mma_pick`'s dispatch logic, so that verdict still holds.

---

## Verification performed (repeated after every change, no GPU)

- `g++ -std=c++14 -fsyntax-only` against `cudez.h` alone (via the
  `gstub` driver-API stubs) and against the full `cudez_test.c` harness.
- `python3 emu_all.py` — the full GPU-free emulator gate suite (bit-exact
  + write-once + ring-hazard asserts across F16/TF32/sparse/INT rungs).
- `./cudez_test emit` and `./cudez_test retarget` — source-generation and
  BF16-retarget contract checks.
- Standalone host-logic tests against the *real* functions (not
  reimplementations) for every change that was pure host code: teardown
  sync ordering, NULL-C stride, zero-size buffer refusal (all 4 copy
  functions), boot attribute failure (both success and simulated-failure
  paths), the requant guard (4 cases), the cache generation counter
  (including calling the real `cudez_try_mma_build_cached`), the NVRTC
  include-path truncation boundary (4 cases), arena alignment (misaligned
  base + normal-case regression), the smem opt-in hoist call count, and
  the compress-sort rewrite (10+ shapes, byte-identical output).

None of this substitutes for a real GPU run. It's the ceiling of what's
checkable without one.
