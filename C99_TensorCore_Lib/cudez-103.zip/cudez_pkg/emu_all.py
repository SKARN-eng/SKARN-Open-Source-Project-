#!/usr/bin/env python3
"""Merged bit-exact CPU emulators for pipelines v8 (smem_stage=6) and v9
(smem_stage=7). One file, one shared copy of the ldmatrix/mma fragment tables
(asserted identical at merge time), two independent gates:

  v8: 128x128 block / 16 warps / BK=32, 2-stage double buffer, STATIC smem
      (37,888 B), two-pass float4 epilogue.
  v9: same kernel with a 3-STAGE cp.async ring in DYNAMIC smem (56,832 B) --
      prologue fills 2, steady keeps 2 in flight (wait_group 2), drain unwinds
      1 -> 0; ring slot = k_tile %% 3. Adds ring-safety invariants: prefetch
      slot != compute slot; slot holds the right tile; prefetch only evicts an
      already-computed tile.

Both prove D == numpy float32 reference BIT-FOR-BIT, every output written once,
every cp.async / float4 access 16 B-aligned. Exit 0 iff BOTH gates pass.
(Merged from emu_v8.py + emu_v9.py; run loops carried over verbatim.)
"""
import numpy as np

WM = WN = WK = 16
BM = BN = 128
BK = 32
SKA = BK + 8            # 40  padded A-panel row stride (halves)
SKB = BN + 8            # 136 padded B-panel row stride (halves)
SG  = BN + 4            # 132 epilogue staging stride (floats)
GROUP_M = 8

# smem blob byte layout (single static allocation, carved into As | Bs, reused as stg)
AS_BYTES = 2 * BM * SKA * 2      # 20,480
BS_BYTES = 2 * BK * SKB * 2      # 17,408
BLOB_BYTES = AS_BYTES + BS_BYTES # 37,888  (< 49,152 = 48 KB static ceiling)

PIPE_DEPTH = 3          # <-- the only structural change from v8 (was 2)

ASLOT = BM * SKA        # 5,120 halves per A ring slot
BSLOT = BK * SKB        # 4,352 halves per B ring slot
RING_HALVES = PIPE_DEPTH * ASLOT + PIPE_DEPTH * BSLOT     # 28,416
RING_BYTES  = RING_HALVES * 2                             # 56,832
STATIC_SMEM_CEIL = 49152     # 48 KB
SM86_SMEM_CAP    = 102400    # 100 KB opt-in max on sm_86


def ldmatrix_x4(smem, addrs, trans):
    """Identical to emu_v8. addrs: 32 shared-mem row pointers (halves)."""
    regs = np.zeros((32, 4, 2), dtype=np.float32)
    for q in range(4):
        rows = [addrs[q * 8 + r] for r in range(8)]
        mat = np.zeros((8, 8), dtype=np.float32)
        for r in range(8):
            mat[r, :] = smem[rows[r]:rows[r] + 8]
        for t in range(32):
            if trans:
                regs[t, q, 0] = mat[2 * (t % 4) + 0, t // 4]
                regs[t, q, 1] = mat[2 * (t % 4) + 1, t // 4]
            else:
                regs[t, q, 0] = mat[t // 4, 2 * (t % 4) + 0]
                regs[t, q, 1] = mat[t // 4, 2 * (t % 4) + 1]
    return regs


def mma_m16n8k16(acc, a_regs, b_regs):
    """Identical to emu_v8."""
    A = np.full((16, 16), np.nan, dtype=np.float32)
    B = np.full((16, 8), np.nan, dtype=np.float32)
    for t in range(32):
        g, r = t // 4, t % 4
        for i in range(4):
            for hh in range(2):
                e = 2 * i + hh
                m = g + 8 * ((e >> 1) & 1)
                k = 2 * r + (e & 1) + 8 * (e >> 2)
                A[m, k] = a_regs[t, i, hh]
        for i in range(2):
            for hh in range(2):
                e = 2 * i + hh
                k = 2 * r + (e & 1) + 8 * (e >> 1)
                n = g
                B[k, n] = b_regs[t, i, hh]
    assert not np.isnan(A).any() and not np.isnan(B).any(), "fragment table gap"
    Dt = (A @ B).astype(np.float32)
    out = acc.copy()
    for t in range(32):
        g, r = t // 4, t % 4
        for e in range(4):
            m = g + 8 * (e >> 1)
            n = 2 * r + (e & 1)
            out[t, e] = acc[t, e] + Dt[m, n]
    return out



def run_v8(M, N, K, seed):
    rng = np.random.default_rng(seed)
    A = rng.integers(-4, 5, (M, K)).astype(np.float32)
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    D = np.zeros((M, N), dtype=np.float32)
    written = np.zeros((M, N), dtype=np.int32)

    assert 64 * SG * 4 <= BLOB_BYTES, "epilogue half-tile exceeds smem blob"
    assert BLOB_BYTES < 49152, "smem blob exceeds 48 KB static ceiling"

    bt_per_row, bt_per_col = N // BN, M // BM
    nblocks = bt_per_row * bt_per_col
    for pid in range(nblocks):
        pig = GROUP_M * bt_per_row
        group_id = pid // pig
        first_m = group_id * GROUP_M
        group_m = min(bt_per_col - first_m, GROUP_M)
        pid_m = first_m + (pid % group_m)
        pid_n = (pid % pig) // group_m
        brow, bcol = pid_m * BM, pid_n * BN

        # 16 warps x 32 lanes; each warp owns a 32x32 region (2x2 tiles of 16x16)
        acc = np.zeros((16, 2, 2, 2, 32, 4), dtype=np.float32)  # [warp][i][j][h][lane][e]
        for ks in range(K // BK):
            k0 = ks * BK
            # stage A panel (BM x BK) and B panel (BK x BN) into padded smem
            As = np.zeros(BM * SKA, dtype=np.float32)
            Bs = np.zeros(BK * SKB, dtype=np.float32)
            for i in range(BM * (BK // 8)):                 # cp.async, 8 halves (16 B) each
                row, col = i // (BK // 8), (i % (BK // 8)) * 8
                assert (row * SKA + col) % 8 == 0, "unaligned cp.async (A)"
                As[row * SKA + col: row * SKA + col + 8] = A[brow + row, k0 + col: k0 + col + 8]
            for i in range(BK * (BN // 8)):
                row, col = i // (BN // 8), (i % (BN // 8)) * 8
                assert (row * SKB + col) % 8 == 0, "unaligned cp.async (B)"
                Bs[row * SKB + col: row * SKB + col + 8] = B[k0 + row, bcol + col: bcol + col + 8]

            for warp in range(16):
                wr, wc = (warp >> 2) * (2 * WM), (warp & 3) * (2 * WN)
                for kk in range(0, BK, WK):              # {0, 16}
                    a_regs = []
                    for i in range(2):
                        addrs = [(wr + i * WM + (t & 15)) * SKA + kk + (t >> 4) * 8
                                 for t in range(32)]
                        a_regs.append(ldmatrix_x4(As, addrs, trans=False))
                    b_regs = []
                    for j in range(2):
                        addrs = [(kk + (t & 15)) * SKB + wc + j * WN + (t >> 4) * 8
                                 for t in range(32)]
                        b_regs.append(ldmatrix_x4(Bs, addrs, trans=True))
                    for i in range(2):
                        for j in range(2):
                            acc[warp, i, j, 0] = mma_m16n8k16(acc[warp, i, j, 0], a_regs[i], b_regs[j][:, 0:2, :])
                            acc[warp, i, j, 1] = mma_m16n8k16(acc[warp, i, j, 1], a_regs[i], b_regs[j][:, 2:4, :])

        # epilogue: TWO passes (upper rows 0-63, lower 64-127); each reuses the
        # dead A/B blob as a 64 x SG float staging tile, then float4 write-out.
        for pas in range(2):
            stg = np.full(64 * SG, np.nan, dtype=np.float32)
            stgw = np.zeros(64 * SG, dtype=np.int32)
            for warp in range(16):
                if (warp >> 3) != pas:                    # warps 0-7 -> pass0, 8-15 -> pass1
                    continue
                wr, wc = (warp >> 2) * (2 * WM), (warp & 3) * (2 * WN)
                for lane in range(32):
                    g, r = lane >> 2, lane & 3
                    for i in range(2):
                        for j in range(2):
                            for h in range(2):
                                for e in range(4):
                                    m = wr + i * WM + g + 8 * (e >> 1)
                                    n = wc + j * WN + h * 8 + 2 * r + (e & 1)
                                    stg[(m - pas * 64) * SG + n] = acc[warp, i, j, h, lane, e]
                                    stgw[(m - pas * 64) * SG + n] += 1
            # cooperative float4 write-out of this 64x128 half-tile (512 threads)
            for idx in range(64 * (BN // 4)):
                row, c4 = idx // (BN // 4), (idx % (BN // 4)) * 4
                assert (row * SG + c4) * 4 % 16 == 0, "unaligned float4 smem read"
                gr = brow + pas * 64 + row
                assert (gr * N + bcol + c4) % 4 == 0, "unaligned float4 global store"
                for k4 in range(4):
                    v = stg[row * SG + c4 + k4]
                    assert not np.isnan(v), "float4 read of unwritten staging"
                    D[gr, bcol + c4 + k4] = v
                    written[gr, bcol + c4 + k4] += 1
            assert (stgw[stgw > 0] == 1).all(), "staging write collision"

    ref = (A @ B).astype(np.float32)
    exact = np.array_equal(D, ref)
    once = (written == 1).all()
    print(f"{M}x{N}x{K}: bit-exact={'PASS' if exact else 'FAIL'} "
          f"write-once={'PASS' if once else 'FAIL'} "
          f"(max|D-ref|={np.abs(D - ref).max()}, written min/max={written.min()}/{written.max()})")
    return exact and once



def run_v9(M, N, K, seed, depth=3):
    rng = np.random.default_rng(seed)
    A = rng.integers(-4, 5, (M, K)).astype(np.float32)
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    D = np.zeros((M, N), dtype=np.float32)
    written = np.zeros((M, N), dtype=np.int32)

    ring_bytes = (depth * ASLOT + depth * BSLOT) * 2
    assert 64 * SG * 4 <= ring_bytes, "epilogue half-tile exceeds ring blob"
    assert ring_bytes > STATIC_SMEM_CEIL, "ring pipelines expected to need dynamic smem"
    assert ring_bytes <= SM86_SMEM_CAP, f"depth-{depth} ring blob {ring_bytes} exceeds sm_86 100 KB cap"

    num_k = K // BK
    bt_per_row, bt_per_col = N // BN, M // BM
    nblocks = bt_per_row * bt_per_col
    for pid in range(nblocks):
        pig = GROUP_M * bt_per_row
        group_id = pid // pig
        first_m = group_id * GROUP_M
        group_m = min(bt_per_col - first_m, GROUP_M)
        pid_m = first_m + (pid % group_m)
        pid_n = (pid % pig) // group_m
        brow, bcol = pid_m * BM, pid_n * BN

        # one flat ring blob (dynamic smem); tag[slot] = which K-tile it holds
        ring = np.zeros(depth * ASLOT + depth * BSLOT, dtype=np.float32)
        tag = [None] * depth
        computed = set()

        def prefetch(t):
            """cp.async K-tile t's A/B panels into ring slot t % depth."""
            slot = t % depth
            # safety (c): only ever evict a tile that has already been computed
            if tag[slot] is not None:
                assert tag[slot] in computed, \
                    f"ring overwrite of live tile {tag[slot]} (slot {slot}) by tile {t}"
            abase = slot * ASLOT
            bbase = depth * ASLOT + slot * BSLOT
            k0 = t * BK
            for i in range(BM * (BK // 8)):                 # 8 halves (16 B) per cp.async
                row, col = i // (BK // 8), (i % (BK // 8)) * 8
                off = abase + row * SKA + col
                assert off % 8 == 0, "unaligned cp.async (A)"
                ring[off:off + 8] = A[brow + row, k0 + col: k0 + col + 8]
            for i in range(BK * (BN // 8)):
                row, col = i // (BN // 8), (i % (BN // 8)) * 8
                off = bbase + row * SKB + col
                assert off % 8 == 0, "unaligned cp.async (B)"
                ring[off:off + 8] = B[k0 + row, bcol + col: bcol + col + 8]
            tag[slot] = t

        acc = np.zeros((16, 2, 2, 2, 32, 4), dtype=np.float32)  # [warp][i][j][h][lane][e]

        # --- prologue: fill the pipe D-1 deep ---
        for t in range(min(depth - 1, num_k)):
            prefetch(t)

        # --- main loop: prefetch (k+D-1), then compute k ---
        for k in range(num_k):
            nxt = k + (depth - 1)
            if nxt < num_k:
                prefetch(nxt)
            cslot = k % depth
            # safety (a) prefetch slot distinct from compute slot; (b) slot holds tile k
            assert nxt >= num_k or (nxt % depth) != cslot, "prefetch aliases compute slot"
            assert tag[cslot] == k, f"slot {cslot} holds tile {tag[cslot]}, expected {k}"
            abase = cslot * ASLOT
            bbase = depth * ASLOT + cslot * BSLOT

            for warp in range(16):
                wr, wc = (warp >> 2) * (2 * WM), (warp & 3) * (2 * WN)
                for kk in range(0, BK, WK):              # {0, 16}
                    a_regs = []
                    for i in range(2):
                        addrs = [abase + (wr + i * WM + (t & 15)) * SKA + kk + (t >> 4) * 8
                                 for t in range(32)]
                        a_regs.append(ldmatrix_x4(ring, addrs, trans=False))
                    b_regs = []
                    for j in range(2):
                        addrs = [bbase + (kk + (t & 15)) * SKB + wc + j * WN + (t >> 4) * 8
                                 for t in range(32)]
                        b_regs.append(ldmatrix_x4(ring, addrs, trans=True))
                    for i in range(2):
                        for j in range(2):
                            acc[warp, i, j, 0] = mma_m16n8k16(acc[warp, i, j, 0], a_regs[i], b_regs[j][:, 0:2, :])
                            acc[warp, i, j, 1] = mma_m16n8k16(acc[warp, i, j, 1], a_regs[i], b_regs[j][:, 2:4, :])
            computed.add(k)

        # --- epilogue: v8's TWO passes (upper 0-63, lower 64-127), reuse dead ring blob ---
        for pas in range(2):
            stg = np.full(64 * SG, np.nan, dtype=np.float32)
            stgw = np.zeros(64 * SG, dtype=np.int32)
            for warp in range(16):
                if (warp >> 3) != pas:
                    continue
                wr, wc = (warp >> 2) * (2 * WM), (warp & 3) * (2 * WN)
                for lane in range(32):
                    g, r = lane >> 2, lane & 3
                    for i in range(2):
                        for j in range(2):
                            for h in range(2):
                                for e in range(4):
                                    m = wr + i * WM + g + 8 * (e >> 1)
                                    n = wc + j * WN + h * 8 + 2 * r + (e & 1)
                                    stg[(m - pas * 64) * SG + n] = acc[warp, i, j, h, lane, e]
                                    stgw[(m - pas * 64) * SG + n] += 1
            for idx in range(64 * (BN // 4)):
                row, c4 = idx // (BN // 4), (idx % (BN // 4)) * 4
                assert (row * SG + c4) * 4 % 16 == 0, "unaligned float4 smem read"
                gr = brow + pas * 64 + row
                assert (gr * N + bcol + c4) % 4 == 0, "unaligned float4 global store"
                for k4 in range(4):
                    v = stg[row * SG + c4 + k4]
                    assert not np.isnan(v), "float4 read of unwritten staging"
                    D[gr, bcol + c4 + k4] = v
                    written[gr, bcol + c4 + k4] += 1
            assert (stgw[stgw > 0] == 1).all(), "staging write collision"

    ref = (A @ B).astype(np.float32)
    exact = np.array_equal(D, ref)
    once = (written == 1).all()
    print(f"{M}x{N}x{K} ({num_k} k-tiles, ring wraps {max(0, num_k - depth) + 1}x): "
          f"bit-exact={'PASS' if exact else 'FAIL'} "
          f"write-once={'PASS' if once else 'FAIL'} "
          f"(max|D-ref|={np.abs(D - ref).max()})")
    return exact and once



# ============================ INT8 (v7-class pipeline) ========================
# mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 fragment tables, sourced from
# the PTX ISA (9.7.13, integer mma) -- NOT hand-derived:
#   lane -> g = lane>>2 (groupID), t = lane&3 (threadID_in_group)
#   A (16x32 s8, ROW):  a0..a3 each pack 4 s8 (byte b = ascending k):
#     a0[b] = A[g   ][t*4+b]      a1[b] = A[g+8][t*4+b]
#     a2[b] = A[g   ][16+t*4+b]   a3[b] = A[g+8][16+t*4+b]
#   B (32x8 s8, COL):   b0[b] = B[t*4+b][g]   b1[b] = B[16+t*4+b][g]
#   D (16x8 s32):       d0,d1 = row g,   cols t*2+{0,1}
#                       d2,d3 = row g+8, cols t*2+{0,1}
# Kernel geometry = the proven v7-class block: 64x64 tile, 4 warps (each 32x32),
# BK=64 (two k32 mma steps per tile), 2-stage cp.async double buffer, STATIC
# smem: 2*(64*SKA8 + 64*SKB8) = 20,480 B (SKA8=SKB8=80, rows 16B-aligned).
I8_BM = I8_BN = 64
I8_BK = 64
SKA8 = I8_BK + 16     # 80 B row stride, s8 A panel (16B pad keeps cp.async aligned)
SKB8 = I8_BN + 16     # 80 B row stride, s8 B panel

def mma_m16n8k32_s8(acc, a_frag, b_frag):
    """acc/[32][4] s32; a_frag [32][4][4] s8 bytes; b_frag [32][2][4] s8."""
    A = np.full((16, 32), np.nan); B = np.full((32, 8), np.nan)
    for lane in range(32):
        g, tg = lane >> 2, lane & 3
        for b in range(4):
            A[g,     tg*4 + b]      = a_frag[lane, 0, b]
            A[g + 8, tg*4 + b]      = a_frag[lane, 1, b]
            A[g,     16 + tg*4 + b] = a_frag[lane, 2, b]
            A[g + 8, 16 + tg*4 + b] = a_frag[lane, 3, b]
            B[tg*4 + b,      g]     = b_frag[lane, 0, b]
            B[16 + tg*4 + b, g]     = b_frag[lane, 1, b]
    assert not np.isnan(A).any() and not np.isnan(B).any(), "s8 fragment table gap"
    Dt = A.astype(np.int64) @ B.astype(np.int64)
    out = acc.copy()
    for lane in range(32):
        g, tg = lane >> 2, lane & 3
        for e in range(4):
            m = g + 8 * (e >> 1)
            n = tg * 2 + (e & 1)
            out[lane, e] = acc[lane, e] + Dt[m, n]
    return out

def run_i8(M, N, K, seed, swz=False, stg_epi=False):
    rng = np.random.default_rng(seed)
    A = rng.integers(-128, 128, (M, K)).astype(np.int64)
    B = rng.integers(-128, 128, (K, N)).astype(np.int64)
    D = np.zeros((M, N), dtype=np.int64)
    written = np.zeros((M, N), dtype=np.int32)
    num_k = K // I8_BK
    for pid_m in range(M // I8_BM):
        for pid_n in range(N // I8_BN):
            brow, bcol = pid_m * I8_BM, pid_n * I8_BN
            As = np.zeros((2, I8_BM * SKA8)); Bs = np.zeros((2, I8_BK * SKB8))
            def stage(t, bf):
                k0 = t * I8_BK
                for i in range(I8_BM * (I8_BK // 16)):          # 16 B per cp.async
                    r, c = i // (I8_BK // 16), (i % (I8_BK // 16)) * 16
                    off = r * SKA8 + c
                    assert off % 16 == 0, "unaligned cp.async (A s8)"
                    As[bf, off:off+16] = A[brow + r, k0 + c: k0 + c + 16]
                for i in range(I8_BK * (I8_BN // 16)):
                    r, c4 = i // (I8_BN // 16), (i % (I8_BN // 16))
                    d4 = (c4 ^ (r & 3)) if swz else c4          # rung-2 chunk swizzle
                    off = r * SKB8 + d4 * 16
                    assert off % 16 == 0, "unaligned cp.async (B s8)"
                    Bs[bf, off:off+16] = B[k0 + r, bcol + c4*16: bcol + c4*16 + 16]
            acc = np.zeros((4, 2, 4, 32, 4), dtype=np.int64)    # [warp][i(m16)][j(n8)][lane][e]
            stage(0, 0)
            for ks in range(num_k):
                if ks + 1 < num_k: stage(ks + 1, (ks + 1) & 1)
                buf = ks & 1
                for warp in range(4):
                    wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                    for kk in range(0, I8_BK, 32):              # {0, 32}
                        for i in range(2):                       # two m16 rows
                            a_frag = np.zeros((32, 4, 4))
                            for lane in range(32):
                                g, tg = lane >> 2, lane & 3
                                base = (wr + i*16 + g) * SKA8 + kk + tg*4
                                # 4B (32-bit) ld.shared each: must be 4B-aligned
                                assert (base % 4) == 0 and ((base + 16) % 4) == 0
                                a_frag[lane, 0] = As[buf, base       : base + 4]
                                a_frag[lane, 1] = As[buf, base + 8*SKA8 : base + 8*SKA8 + 4]
                                a_frag[lane, 2] = As[buf, base + 16     : base + 20]
                                a_frag[lane, 3] = As[buf, base + 8*SKA8 + 16 : base + 8*SKA8 + 20]
                            for j in range(4):                   # four n8 cols
                                b_frag = np.zeros((32, 2, 4))
                                for lane in range(32):
                                    g, tg = lane >> 2, lane & 3
                                    col = wc + j*8 + g
                                    def bldr(row, cc):
                                        d = ((cc >> 4) ^ (row & 3)) if swz else (cc >> 4)
                                        return Bs[buf, row * SKB8 + d*16 + (cc & 15)]
                                    for b in range(4):           # byte gather (s8 col frag)
                                        b_frag[lane, 0, b] = bldr(kk + tg*4 + b, col)
                                        b_frag[lane, 1, b] = bldr(kk + 16 + tg*4 + b, col)
                                acc[warp, i, j] = mma_m16n8k32_s8(acc[warp, i, j], a_frag, b_frag)
            if not stg_epi:
                for warp in range(4):                            # rung-1 direct s32 stores
                    wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                    for i in range(2):
                        for j in range(4):
                            for lane in range(32):
                                g, tg = lane >> 2, lane & 3
                                for e in range(4):
                                    m = brow + wr + i*16 + g + 8*(e >> 1)
                                    n = bcol + wc + j*8 + tg*2 + (e & 1)
                                    D[m, n] = acc[warp, i, j, lane, e]
                                    written[m, n] += 1
            else:
                SGE = I8_BN + 4                                  # 68-int staging stride
                for pas in range(2):                             # warp-row halves
                    stg = np.full(32 * SGE, np.nan)
                    stw = np.zeros(32 * SGE, dtype=np.int32)
                    for warp in range(4):
                        if (warp >> 1) != pas: continue
                        wc = (warp & 1) * 32
                        for i in range(2):
                            for j in range(4):
                                for lane in range(32):
                                    g, tg = lane >> 2, lane & 3
                                    for e in range(4):
                                        mr = i*16 + g + 8*(e >> 1)
                                        nc = wc + j*8 + tg*2 + (e & 1)
                                        stg[mr * SGE + nc] = acc[warp, i, j, lane, e]
                                        stw[mr * SGE + nc] += 1
                    assert (stw[stw > 0] == 1).all(), "i8 staging collision"
                    for idx in range(32 * (I8_BN // 4)):
                        row, c4 = idx // (I8_BN // 4), (idx % (I8_BN // 4)) * 4
                        assert (row * SGE + c4) * 4 % 16 == 0, "unaligned int4 smem read"
                        m = brow + pas*32 + row
                        assert (m * N + bcol + c4) % 4 == 0, "unaligned int4 global store"
                        for q in range(4):
                            v = stg[row * SGE + c4 + q]
                            assert not np.isnan(v), "int4 read of unwritten staging"
                            D[m, bcol + c4 + q] = v
                            written[m, bcol + c4 + q] += 1
    ref = A @ B
    exact = np.array_equal(D, ref); once = (written == 1).all()
    print(f"i8{'r2' if (swz or stg_epi) else '  '} {M}x{N}x{K}: bit-exact={'PASS' if exact else 'FAIL'} "
          f"write-once={'PASS' if once else 'FAIL'} (max|D-ref|={np.abs(D-ref).max()})")
    return exact and once

# ============================ TF32 (v7-class pipeline) ========================
# mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32, PTX ISA layout:
#   a0=A[g][tau] a1=A[g+8][tau] a2=A[g][tau+4] a3=A[g+8][tau+4]
#   b0=B[tau][g] b1=B[tau+4][g]; C/D standard 16x8. Elements are 4 B floats
#   (tf32 = f32 quantized to 10-bit mantissa; integer test data makes the
#   quantization the identity, so the gate is bit-exact like the f16 gates).
TF_BM = TF_BN = 64
TF_BK = 32            # four k8 mma steps per tile
SKAT = TF_BK + 4      # 36-float A row stride (rows 16B-aligned: 36*4=144)
SKBT = TF_BN + 4      # 68-float B row stride

def run_tf32(M, N, K, seed):
    rng = np.random.default_rng(seed)
    A = rng.integers(-4, 5, (M, K)).astype(np.float32)
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    D = np.zeros((M, N), dtype=np.float32); written = np.zeros((M, N), np.int32)
    num_k = K // TF_BK
    for pm in range(M // TF_BM):
        for pn in range(N // TF_BN):
            brow, bcol = pm * TF_BM, pn * TF_BN
            As = np.zeros((2, TF_BM * SKAT), np.float32); Bs = np.zeros((2, TF_BK * SKBT), np.float32)
            def stage(tk, bf):
                k0 = tk * TF_BK
                for i in range(TF_BM * (TF_BK // 4)):        # 16 B = 4 floats per cp.async
                    r, c = i // (TF_BK // 4), (i % (TF_BK // 4)) * 4
                    off = r * SKAT + c
                    assert (off * 4) % 16 == 0, "unaligned cp.async (A tf32)"
                    As[bf, off:off+4] = A[brow + r, k0 + c: k0 + c + 4]
                for i in range(TF_BK * (TF_BN // 4)):
                    r, c = i // (TF_BN // 4), (i % (TF_BN // 4)) * 4
                    off = r * SKBT + c
                    assert (off * 4) % 16 == 0, "unaligned cp.async (B tf32)"
                    Bs[bf, off:off+4] = B[k0 + r, bcol + c: bcol + c + 4]
            acc = np.zeros((4, 2, 4, 32, 4), np.float32)     # [warp][i m16][j n8][lane][e]
            stage(0, 0)
            for ks in range(num_k):
                if ks + 1 < num_k: stage(ks + 1, (ks + 1) & 1)
                buf = ks & 1
                for warp in range(4):
                    wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                    for kk in range(0, TF_BK, 8):
                        for i in range(2):
                            for j in range(4):
                                Dt = np.zeros((16, 8), np.float64)
                                Atile = np.zeros((16, 8)); Btile = np.zeros((8, 8))
                                for lane in range(32):
                                    g, tau = lane >> 2, lane & 3
                                    ab = (wr + i*16 + g) * SKAT + kk
                                    Atile[g,     tau]     = As[buf, ab + tau]
                                    Atile[g + 8, tau]     = As[buf, ab + 8*SKAT + tau]
                                    Atile[g,     tau + 4] = As[buf, ab + tau + 4]
                                    Atile[g + 8, tau + 4] = As[buf, ab + 8*SKAT + tau + 4]
                                    col = wc + j*8 + g
                                    Btile[tau,     g] = Bs[buf, (kk + tau)     * SKBT + col]
                                    Btile[tau + 4, g] = Bs[buf, (kk + tau + 4) * SKBT + col]
                                Dt = Atile @ Btile
                                for lane in range(32):
                                    g, tau = lane >> 2, lane & 3
                                    for e in range(4):
                                        acc[warp, i, j, lane, e] += Dt[g + 8*(e >> 1), tau*2 + (e & 1)]
                for _ in (0,):
                    pass
            for warp in range(4):                            # direct f32 stores (rung 1)
                wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                for i in range(2):
                    for j in range(4):
                        for lane in range(32):
                            g, tau = lane >> 2, lane & 3
                            for e in range(4):
                                m = brow + wr + i*16 + g + 8*(e >> 1)
                                n = bcol + wc + j*8 + tau*2 + (e & 1)
                                D[m, n] = acc[warp, i, j, lane, e]
                                written[m, n] += 1
    ref = (A @ B).astype(np.float32)
    ok = np.array_equal(D, ref) and (written == 1).all()
    print(f"tf32 {M}x{N}x{K}: bit-exact={'PASS' if np.array_equal(D,ref) else 'FAIL'} "
          f"write-once={'PASS' if (written==1).all() else 'FAIL'} (max|D-ref|={np.abs(D-ref).max()})")
    return ok

# ============================ INT4 (v7-class pipeline) ========================
# mma.sync.aligned.m16n8k64.row.col.s32.s4.s4.s32 -- fragment layout mirrored
# from the silicon-proven streaming i4 kernel (gen_i4.cu): a-regs are 32-bit
# loads (8 s4, cols tg*8..+7; a2/a3 at +32 cols); b-regs pack 8 nibbles from
# rows tg*8+{0..7} and +32, col g (low nibble = even column).
I4_BM = I4_BN = 64
I4_BK = 128           # two k64 mma steps; A row = 64 B packed
SKA4 = 64 + 16        # 80 B packed-A row stride
SKB4 = 32 + 16        # 48 B packed-B row stride (64 cols / 2)

def run_i4(M, N, K, seed):
    rng = np.random.default_rng(seed)
    A = rng.integers(-8, 8, (M, K)).astype(np.int64)
    B = rng.integers(-8, 8, (K, N)).astype(np.int64)
    packA = np.zeros((M, K // 2), np.uint8); packB = np.zeros((K, N // 2), np.uint8)
    for r in range(M):
        for c in range(0, K, 2):
            packA[r, c >> 1] = (A[r, c] & 0xF) | ((A[r, c+1] & 0xF) << 4)
    for r in range(K):
        for c in range(0, N, 2):
            packB[r, c >> 1] = (B[r, c] & 0xF) | ((B[r, c+1] & 0xF) << 4)
    def s4(v):
        v = int(v) & 0xF
        return v - 16 if v >= 8 else v
    D = np.zeros((M, N), np.int64); written = np.zeros((M, N), np.int32)
    num_k = K // I4_BK
    for pm in range(M // I4_BM):
        for pn in range(N // I4_BN):
            brow, bcol = pm * I4_BM, pn * I4_BN
            As = np.zeros((2, I4_BM * SKA4), np.uint8); Bs = np.zeros((2, I4_BK * SKB4), np.uint8)
            def stage(tk, bf):
                kb = tk * (I4_BK // 2)                       # byte column base
                for i in range(I4_BM * 4):                   # 64 B row = 4 x 16 B
                    r, c = i // 4, (i % 4) * 16
                    off = r * SKA4 + c
                    assert off % 16 == 0
                    As[bf, off:off+16] = packA[brow + r, kb + c: kb + c + 16]
                for i in range(I4_BK * 2):                   # 32 B row = 2 x 16 B
                    r, c = i // 2, (i % 2) * 16
                    off = r * SKB4 + c
                    assert off % 16 == 0
                    Bs[bf, off:off+16] = packB[tk * I4_BK + r, (bcol >> 1) + c: (bcol >> 1) + c + 16]
            acc = np.zeros((4, 2, 4, 32, 4), np.int64)
            stage(0, 0)
            for ks in range(num_k):
                if ks + 1 < num_k: stage(ks + 1, (ks + 1) & 1)
                buf = ks & 1
                for warp in range(4):
                    wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                    for kk in (0, 64):                       # two k64 steps (nibble cols)
                        for i in range(2):
                            Atile = np.zeros((16, 64))
                            for lane in range(32):
                                g, tg = lane >> 2, lane & 3
                                ab = (wr + i*16 + g) * SKA4 + (kk >> 1) + tg*4
                                ah = ab + 8 * SKA4
                                for v in range(8):           # a0/a2 rows g; a1/a3 rows g+8
                                    byt = As[buf, ab + (v >> 1)];      Atile[g,   tg*8 + v]      = s4(byt >> (4*(v & 1)))
                                    byt = As[buf, ab + 16 + (v >> 1)]; Atile[g,   32 + tg*8 + v] = s4(byt >> (4*(v & 1)))
                                    byt = As[buf, ah + (v >> 1)];      Atile[g+8, tg*8 + v]      = s4(byt >> (4*(v & 1)))
                                    byt = As[buf, ah + 16 + (v >> 1)]; Atile[g+8, 32 + tg*8 + v] = s4(byt >> (4*(v & 1)))
                            for j in range(4):
                                Btile = np.zeros((64, 8))
                                for lane in range(32):
                                    g, tg = lane >> 2, lane & 3
                                    col = wc + j*8 + g
                                    for v in range(8):
                                        r0 = kk + tg*8 + v
                                        byt = Bs[buf, r0 * SKB4 + (col >> 1)];        Btile[tg*8 + v,      g] = s4(byt >> (4*(col & 1)))
                                        byt = Bs[buf, (r0 + 32) * SKB4 + (col >> 1)]; Btile[32 + tg*8 + v, g] = s4(byt >> (4*(col & 1)))
                                Dt = Atile @ Btile
                                for lane in range(32):
                                    g, tg = lane >> 2, lane & 3
                                    for e in range(4):
                                        acc[warp, i, j, lane, e] += Dt[g + 8*(e >> 1), tg*2 + (e & 1)]
            for warp in range(4):
                wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                for i in range(2):
                    for j in range(4):
                        for lane in range(32):
                            g, tg = lane >> 2, lane & 3
                            for e in range(4):
                                m = brow + wr + i*16 + g + 8*(e >> 1)
                                n = bcol + wc + j*8 + tg*2 + (e & 1)
                                D[m, n] = acc[warp, i, j, lane, e]
                                written[m, n] += 1
    ref = A @ B
    ok = np.array_equal(D, ref) and (written == 1).all()
    print(f"i4 {M}x{N}x{K}: bit-exact={'PASS' if np.array_equal(D,ref) else 'FAIL'} "
          f"write-once={'PASS' if (written==1).all() else 'FAIL'} (max|D-ref|={np.abs(D-ref).max()})")
    return ok

# ============================ 2:4 SPARSE (v7-class pipeline) ==================
# The silicon-proven streaming mma.sp kernel's fragment + HARDWARE-CONFIRMED
# metadata layout (cudez_mma_compress_2to4, 0.7.1), with A_vals + B staged via
# the cp.async double buffer. Metadata stays in global (128 B per 16x32 tile,
# L2-resident, reused across pid_n). WK=32 -> BK=32, one mma.sp step per stage.
SP_BM = SP_BN = 64
SP_BK = 32
SKAS = 16 + 8         # compressed-A halves row stride (24)
SKBS = SP_BN + 8      # dense-B halves row stride (72)

def _2to4_indices(grp):
    idx = sorted(range(4), key=lambda i: -abs(grp[i]))
    k0, k1 = sorted(idx[:2])
    return k0, k1

def sp_compress(dense, M, K):
    vals = np.zeros((M, K // 2), np.float32)
    meta = np.zeros(((M // 16) * (K // 32), 32), np.uint32)
    for R in range(M):
        for J in range(K // 4):
            grp = dense[R, J*4:J*4+4]
            k0, k1 = _2to4_indices(grp)
            vals[R, J*2 + 0] = grp[k0]; vals[R, J*2 + 1] = grp[k1]
    k_tiles = K // 32
    for rt in range(M // 16):
        for kt in range(k_tiles):
            for lane in range(32):
                g, base = lane >> 2, (lane & 1) * 4
                word = 0
                for i in range(4):
                    grp = dense[rt*16 + g, (kt*8 + base + i)*4:(kt*8 + base + i)*4 + 4]
                    k0, k1 = _2to4_indices(grp)
                    word |= ((k0 & 3) | ((k1 & 3) << 2)) << (4 * i)
                    grp = dense[rt*16 + g + 8, (kt*8 + base + i)*4:(kt*8 + base + i)*4 + 4]
                    k0, k1 = _2to4_indices(grp)
                    word |= ((k0 & 3) | ((k1 & 3) << 2)) << (16 + 4 * i)
                meta[rt * k_tiles + kt, lane] = word
    return vals, meta

def run_sp(M, N, K, seed):
    rng = np.random.default_rng(seed)
    A = np.zeros((M, K), np.float32)
    for R in range(M):                                       # exactly 2:4 structured
        for J in range(K // 4):
            pos = sorted(rng.choice(4, size=2, replace=False))
            v = rng.integers(-4, 5, 2)
            A[R, J*4 + pos[0]] = v[0]; A[R, J*4 + pos[1]] = v[1]
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    vals, meta = sp_compress(A, M, K)
    D = np.zeros((M, N), np.float32); written = np.zeros((M, N), np.int32)
    num_k = K // SP_BK; k_tiles = num_k
    for pm in range(M // SP_BM):
        for pn in range(N // SP_BN):
            brow, bcol = pm * SP_BM, pn * SP_BN
            As = np.zeros((2, SP_BM * SKAS), np.float32); Bs = np.zeros((2, SP_BK * SKBS), np.float32)
            def stage(tk, bf):
                for i in range(SP_BM * 2):                   # 16-half row = 2 x 8-half chunks
                    r, c = i // 2, (i % 2) * 8
                    off = r * SKAS + c
                    assert off % 8 == 0, "unaligned cp.async (A_vals)"
                    As[bf, off:off+8] = vals[brow + r, tk*16 + c: tk*16 + c + 8]
                for i in range(SP_BK * (SP_BN // 8)):
                    r, c = i // (SP_BN // 8), (i % (SP_BN // 8)) * 8
                    off = r * SKBS + c
                    assert off % 8 == 0, "unaligned cp.async (B sp)"
                    Bs[bf, off:off+8] = B[tk*SP_BK + r, bcol + c: bcol + c + 8]
            acc = np.zeros((4, 2, 4, 32, 4), np.float32)
            stage(0, 0)
            for ks in range(num_k):
                if ks + 1 < num_k: stage(ks + 1, (ks + 1) & 1)
                buf = ks & 1
                for warp in range(4):
                    wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                    for i in range(2):
                        # reconstruct the dense 16x32 A tile from staged vals + global meta
                        Atile = np.zeros((16, 32))
                        band = (brow + wr + i*16) // 16
                        for lane in range(32):
                            g, base = lane >> 2, (lane & 1) * 4
                            word = int(meta[band * k_tiles + ks, lane])
                            for q in range(4):
                                nib = (word >> (4*q)) & 0xF
                                k0, k1 = nib & 3, (nib >> 2) & 3
                                grpc = base + q                     # compressed pair index
                                ab = (wr + i*16 + g) * SKAS + grpc*2
                                Atile[g, (base+q)*4 + k0] = As[buf, ab]
                                Atile[g, (base+q)*4 + k1] = As[buf, ab + 1]
                                nib = (word >> (16 + 4*q)) & 0xF
                                k0, k1 = nib & 3, (nib >> 2) & 3
                                ab = (wr + i*16 + g + 8) * SKAS + grpc*2
                                Atile[g + 8, (base+q)*4 + k0] = As[buf, ab]
                                Atile[g + 8, (base+q)*4 + k1] = As[buf, ab + 1]
                        for j in range(4):
                            Btile = np.zeros((32, 8))
                            for lane in range(32):
                                g, tau = lane >> 2, lane & 3
                                col = wc + j*8 + g
                                for pr in range(4):                 # paired rows 2tau+{0,1}+8*pr
                                    Btile[2*tau + 8*pr,     g] = Bs[buf, (2*tau + 8*pr)     * SKBS + col]
                                    Btile[2*tau + 8*pr + 1, g] = Bs[buf, (2*tau + 8*pr + 1) * SKBS + col]
                            Dt = Atile @ Btile
                            for lane in range(32):
                                g, tau = lane >> 2, lane & 3
                                for e in range(4):
                                    acc[warp, i, j, lane, e] += Dt[g + 8*(e >> 1), 2*tau + (e & 1)]
            for warp in range(4):
                wr, wc = (warp >> 1) * 32, (warp & 1) * 32
                for i in range(2):
                    for j in range(4):
                        for lane in range(32):
                            g, tau = lane >> 2, lane & 3
                            for e in range(4):
                                m = brow + wr + i*16 + g + 8*(e >> 1)
                                n = bcol + wc + j*8 + 2*tau + (e & 1)
                                D[m, n] = acc[warp, i, j, lane, e]
                                written[m, n] += 1
    ref = (A @ B).astype(np.float32)
    ok = np.array_equal(D, ref) and (written == 1).all()
    print(f"sp {M}x{N}x{K}: bit-exact={'PASS' if np.array_equal(D,ref) else 'FAIL'} "
          f"write-once={'PASS' if (written==1).all() else 'FAIL'} (max|D-ref|={np.abs(D-ref).max()})")
    return ok


# ==================== 2:4 SPARSE v9-CLASS RING (128-tile) =====================
# The sparse v7 kernel's fragments + metadata, scaled to the dense-v9 recipe:
# 128x128 block, 16 warps (4x4 of 32x32 regions), BK=32 (one mma.sp step per
# tile), 3-stage cp.async ring. Compressed A halves the panel, so 3 slots =
# 3*(128*24 + 32*136)*2 = 44,544 B -- fits STATIC smem (<= 48 KB), unlike
# dense v9. Ring schedule identical to v9 (prologue 2, wait_group 2, drain).
SPR_BM = SPR_BN = 128
SPR_BK = 32
SKAS9 = 16 + 8          # 24-half compressed-A row stride
SKBS9 = SPR_BN + 8      # 136-half B row stride
SPR_ASLOT = SPR_BM * SKAS9
SPR_BSLOT = SPR_BK * SKBS9

def run_sp_ring(M, N, K, seed, depth=3):
    rng = np.random.default_rng(seed)
    A = np.zeros((M, K), np.float32)
    for R in range(M):
        for J in range(K // 4):
            pos = sorted(rng.choice(4, size=2, replace=False))
            v = rng.integers(-4, 5, 2)
            A[R, J*4 + pos[0]] = v[0]; A[R, J*4 + pos[1]] = v[1]
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    vals, meta = sp_compress(A, M, K)
    D = np.zeros((M, N), np.float32); written = np.zeros((M, N), np.int32)
    num_k = K // SPR_BK; k_tiles = num_k
    ring_bytes = depth * (SPR_ASLOT + SPR_BSLOT) * 2
    assert ring_bytes <= 48 * 1024, f"sparse ring {ring_bytes} exceeds static smem"
    for pm in range(M // SPR_BM):
        for pn in range(N // SPR_BN):
            brow, bcol = pm * SPR_BM, pn * SPR_BN
            ring = np.full(depth * (SPR_ASLOT + SPR_BSLOT), np.nan, np.float32)
            tag = [None] * depth
            def stage(tk, slot):
                a0 = slot * SPR_ASLOT
                b0 = depth * SPR_ASLOT + slot * SPR_BSLOT
                for i in range(SPR_BM * 2):
                    r, c = i // 2, (i % 2) * 8
                    off = a0 + r * SKAS9 + c
                    assert (off * 2) % 16 == 0, "unaligned cp.async (A_vals ring)"
                    ring[off:off+8] = vals[brow + r, tk*16 + c: tk*16 + c + 8]
                for i in range(SPR_BK * (SPR_BN // 8)):
                    r, c = i // (SPR_BN // 8), (i % (SPR_BN // 8)) * 8
                    off = b0 + r * SKBS9 + c
                    assert (off * 2) % 16 == 0, "unaligned cp.async (B ring)"
                    ring[off:off+8] = B[tk*SPR_BK + r, bcol + c: bcol + c + 8]
                tag[slot] = tk
            acc = np.zeros((16, 2, 4, 32, 4), np.float32)
            def compute(tk, slot):
                assert tag[slot] == tk, f"ring hazard: slot {slot} holds {tag[slot]}, wanted {tk}"
                a0 = slot * SPR_ASLOT
                b0 = depth * SPR_ASLOT + slot * SPR_BSLOT
                for warp in range(16):
                    wr, wc = (warp >> 2) * 32, (warp & 3) * 32
                    for i in range(2):
                        Atile = np.zeros((16, 32))
                        band = (brow + wr + i*16) // 16
                        for lane in range(32):
                            g, base = lane >> 2, (lane & 1) * 4
                            word = int(meta[band * k_tiles + tk, lane])
                            for q in range(4):
                                nib = (word >> (4*q)) & 0xF
                                k0, k1 = nib & 3, (nib >> 2) & 3
                                ab = a0 + (wr + i*16 + g) * SKAS9 + (base+q)*2
                                v0, v1 = ring[ab], ring[ab + 1]
                                assert not (np.isnan(v0) or np.isnan(v1)), "read of unstaged A"
                                Atile[g, (base+q)*4 + k0] = v0
                                Atile[g, (base+q)*4 + k1] = v1
                                nib = (word >> (16 + 4*q)) & 0xF
                                k0, k1 = nib & 3, (nib >> 2) & 3
                                ab = a0 + (wr + i*16 + g + 8) * SKAS9 + (base+q)*2
                                Atile[g + 8, (base+q)*4 + k0] = ring[ab]
                                Atile[g + 8, (base+q)*4 + k1] = ring[ab + 1]
                        for j in range(4):
                            Btile = np.zeros((32, 8))
                            for lane in range(32):
                                g, tau = lane >> 2, lane & 3
                                col = wc + j*8 + g
                                for pr in range(4):
                                    Btile[2*tau + 8*pr,     g] = ring[b0 + (2*tau + 8*pr)     * SKBS9 + col]
                                    Btile[2*tau + 8*pr + 1, g] = ring[b0 + (2*tau + 8*pr + 1) * SKBS9 + col]
                            Dt = Atile @ Btile
                            for lane in range(32):
                                g, tau = lane >> 2, lane & 3
                                for e in range(4):
                                    acc[warp, i, j, lane, e] += Dt[g + 8*(e >> 1), 2*tau + (e & 1)]
            # v9 schedule
            stage(0, 0)
            if num_k > 1: stage(1, 1)
            for ks in range(num_k):
                if ks + 2 < num_k: stage(ks + 2, (ks + 2) % depth)
                compute(ks, ks % depth)
            for warp in range(16):
                wr, wc = (warp >> 2) * 32, (warp & 3) * 32
                for i in range(2):
                    for j in range(4):
                        for lane in range(32):
                            g, tau = lane >> 2, lane & 3
                            for e in range(4):
                                m = brow + wr + i*16 + g + 8*(e >> 1)
                                n = bcol + wc + j*8 + 2*tau + (e & 1)
                                D[m, n] = acc[warp, i, j, lane, e]
                                written[m, n] += 1
    ref = (A @ B).astype(np.float32)
    ok = np.array_equal(D, ref) and (written == 1).all()
    print(f"sp-ring {M}x{N}x{K}: bit-exact={'PASS' if np.array_equal(D,ref) else 'FAIL'} "
          f"write-once={'PASS' if (written==1).all() else 'FAIL'} (max|D-ref|={np.abs(D-ref).max()})")
    return ok


# ==================== TF32 v9-CLASS RING (128-tile, BK=16) ====================
# TF32's 4 B elements double the panels: BK=32 x 3 slots = 107,520 B busts the
# 100 KB sm_86 cap, so the ring runs BK=16 (two k8 steps/tile): 3*(128*20 +
# 16*136)*4 = 56,832 B -- numerically the SAME blob dense v9 allocates.
TR_BM = TR_BN = 128
TR_BK = 16
SKAT9 = TR_BK + 4      # 20-float A row stride
SKBT9 = TR_BN + 8      # 136-float B row stride
TR_ASLOT = TR_BM * SKAT9
TR_BSLOT = TR_BK * SKBT9

def run_tf32_ring(M, N, K, seed, depth=3):
    rng = np.random.default_rng(seed)
    A = rng.integers(-4, 5, (M, K)).astype(np.float32)
    B = rng.integers(-4, 5, (K, N)).astype(np.float32)
    D = np.zeros((M, N), np.float32); written = np.zeros((M, N), np.int32)
    num_k = K // TR_BK
    assert depth * (TR_ASLOT + TR_BSLOT) * 4 <= 100 * 1024
    for pm in range(M // TR_BM):
        for pn in range(N // TR_BN):
            brow, bcol = pm * TR_BM, pn * TR_BN
            ring = np.full(depth * (TR_ASLOT + TR_BSLOT), np.nan, np.float32)
            tag = [None] * depth
            def stage(tk, slot):
                a0 = slot * TR_ASLOT; b0 = depth * TR_ASLOT + slot * TR_BSLOT
                for i in range(TR_BM * (TR_BK // 4)):
                    r, c = i // (TR_BK // 4), (i % (TR_BK // 4)) * 4
                    off = a0 + r * SKAT9 + c
                    assert (off * 4) % 16 == 0
                    ring[off:off+4] = A[brow + r, tk*TR_BK + c: tk*TR_BK + c + 4]
                for i in range(TR_BK * (TR_BN // 4)):
                    r, c = i // (TR_BN // 4), (i % (TR_BN // 4)) * 4
                    off = b0 + r * SKBT9 + c
                    assert (off * 4) % 16 == 0
                    ring[off:off+4] = B[tk*TR_BK + r, bcol + c: bcol + c + 4]
                tag[slot] = tk
            acc = np.zeros((16, 2, 4, 32, 4), np.float32)
            def compute(tk, slot):
                assert tag[slot] == tk, f"ring hazard slot {slot}: {tag[slot]} != {tk}"
                a0 = slot * TR_ASLOT; b0 = depth * TR_ASLOT + slot * TR_BSLOT
                for warp in range(16):
                    wr, wc = (warp >> 2) * 32, (warp & 3) * 32
                    for kk in range(0, TR_BK, 8):
                        for i in range(2):
                            for j in range(4):
                                At = np.zeros((16, 8)); Bt = np.zeros((8, 8))
                                for lane in range(32):
                                    g, tau = lane >> 2, lane & 3
                                    ab = a0 + (wr + i*16 + g) * SKAT9 + kk
                                    v = ring[ab + tau];               assert not np.isnan(v); At[g, tau] = v
                                    At[g + 8, tau]     = ring[ab + 8*SKAT9 + tau]
                                    At[g,     tau + 4] = ring[ab + tau + 4]
                                    At[g + 8, tau + 4] = ring[ab + 8*SKAT9 + tau + 4]
                                    col = wc + j*8 + g
                                    Bt[tau,     g] = ring[b0 + (kk + tau)     * SKBT9 + col]
                                    Bt[tau + 4, g] = ring[b0 + (kk + tau + 4) * SKBT9 + col]
                                Dt = At @ Bt
                                for lane in range(32):
                                    g, tau = lane >> 2, lane & 3
                                    for e in range(4):
                                        acc[warp, i, j, lane, e] += Dt[g + 8*(e >> 1), tau*2 + (e & 1)]
            stage(0, 0)
            if num_k > 1: stage(1, 1)
            for ks in range(num_k):
                if ks + 2 < num_k: stage(ks + 2, (ks + 2) % depth)
                compute(ks, ks % depth)
            for warp in range(16):
                wr, wc = (warp >> 2) * 32, (warp & 3) * 32
                for i in range(2):
                    for j in range(4):
                        for lane in range(32):
                            g, tau = lane >> 2, lane & 3
                            for e in range(4):
                                m = brow + wr + i*16 + g + 8*(e >> 1)
                                n = bcol + wc + j*8 + tau*2 + (e & 1)
                                D[m, n] = acc[warp, i, j, lane, e]
                                written[m, n] += 1
    ref = (A @ B).astype(np.float32)
    ok = np.array_equal(D, ref) and (written == 1).all()
    print(f"tf32-ring {M}x{N}x{K}: bit-exact={'PASS' if np.array_equal(D,ref) else 'FAIL'} "
          f"write-once={'PASS' if (written==1).all() else 'FAIL'}")
    return ok

# ================================ gates =======================================
print("=== v8 gate ==="); ok8 = run_v8(128,128,192,101) and run_v8(768,128,128,102) and run_v8(256,256,64,103) and run_v8(128,256,96,104)
print("=== v9 gate ==="); ok9 = all(run_v9(*s, depth=3) for s in ((128,128,192,101),(768,128,128,102),(256,256,64,103),(128,256,96,104),(128,128,256,105),(128,128,32,106),(256,128,384,107)))
print("=== v10 gate ==="); okA = all(run_v9(*s, depth=4) for s in ((128,128,192,201),(768,128,128,202),(256,256,96,203),(128,128,64,204),(128,128,32,205),(128,128,512,206),(256,128,384,207)))
print("=== i8 rung-1 gate ==="); okI = all(run_i8(*s) for s in ((64,64,128,301),(128,192,64,302),(192,64,192,303),(64,128,320,304)))
print("=== i8 rung-2 gate (swizzle + staged epilogue) ===")
okI2 = all(run_i8(*s, swz=True, stg_epi=True) for s in ((64,64,128,311),(128,192,64,312),(192,64,192,313),(64,128,320,314)))
print("=== tf32 gate ==="); okT = all(run_tf32(*s) for s in ((64,64,64,401),(128,192,32,402),(192,64,96,403),(64,128,160,404)))
print("=== i4 gate ==="); ok4 = all(run_i4(*s) for s in ((64,64,256,501),(128,192,128,502),(192,64,384,503)))
print("=== 2:4 sparse gate ==="); okS = all(run_sp(*s) for s in ((64,64,64,601),(128,192,32,602),(192,64,96,603),(64,128,160,604)))
print("=== 2:4 sparse RING gate (128-tile, v9-class) ===")
okSR = all(run_sp_ring(*s) for s in ((128,128,96,701),(256,128,64,702),(128,256,160,703),(128,128,32,704)))
print("=== TF32 RING gate (128-tile, BK=16) ===")
okTR = all(run_tf32_ring(*s) for s in ((128,128,96,801),(256,128,32,802),(128,256,160,803),(128,128,16,804)))
allok = ok8 and ok9 and okA and okI and okI2 and okT and ok4 and okS and okSR and okTR
print("\nEMULATOR SUITE:", "ALL PASS" if allok else "*** FAIL ***")
raise SystemExit(0 if allok else 1)
