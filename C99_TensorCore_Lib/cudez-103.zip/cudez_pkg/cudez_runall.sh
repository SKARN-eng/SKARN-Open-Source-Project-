#!/usr/bin/env bash
# cudez_runall.sh -- one command: gate, then benchmark every pipeline at every
# shape, with GPU clock/power logging per shape and a final cudez-vs-baseline
# summary table.
#
# Usage:
#   ./cudez_runall.sh                      # device 0, shapes 512..4096, 5 trials
#   DEV=0 TRIALS=9 ./cudez_runall.sh       # more trials (odd recommended)
#   SIZES="2048 4096" ONLY=v9 ./cudez_runall.sh   # narrow run
#   COOLDOWN=30 ./cudez_runall.sh          # longer thermal cooldown between shapes
#
# Produces: cudez_run_<epoch>/  containing per-shape bench CSVs, per-shape GPU
# monitor CSVs, smoke/debug logs, environment snapshot, and summary.txt.
# Send the whole directory back.
#
# BATTERY NOTE: on battery the driver power-caps the GPU hard (often 30-40 W vs
# the 55-80 W AC cap on RTX 3060 Laptop parts), so ABSOLUTE TFLOPS will sag --
# for cudez AND the baseline equally. The %-of-baseline ratios stay meaningful.
# This script records power.limit and per-shape clock/power samples so the run
# is interpretable either way; the summary flags clock droop (throttling).

set -u
set -o pipefail   # gates pipe through tee; without this the || tests tee, not the harness
DEV="${DEV:-0}"
TRIALS="${TRIALS:-5}"
SIZES="${SIZES:-512 1024 2048 4096}"
ONLY="${ONLY:-}"
COOLDOWN="${COOLDOWN:-20}"
BIN="${BIN:-./cudez_test}"

[ -x "$BIN" ] || { echo "ERROR: $BIN not found/executable. Build first, e.g.:
  g++ -O2 -std=c++14 cudez_test.c -o cudez_test -lcuda -lnvrtc -lcublas -lcublasLt -lcudart" >&2; exit 2; }

SMI="$(command -v nvidia-smi || echo /usr/lib/wsl/lib/nvidia-smi)"
EPOCH=$(date +%s); OUT="cudez_run_${EPOCH}"; mkdir -p "$OUT"
say() { echo; echo "==== $* ===="; }

# ---- 0. environment snapshot (this is what makes battery runs interpretable) ----
say "environment -> $OUT/env.txt"
{
  date; uname -a
  [ -x "$SMI" ] && "$SMI" --query-gpu=name,driver_version,power.limit,power.max_limit,clocks.max.sm,memory.total --format=csv
  [ -x "$SMI" ] && "$SMI" --query-gpu=power.draw,clocks.sm,temperature.gpu --format=csv,noheader | sed 's/^/idle: /'
} > "$OUT/env.txt" 2>&1
cat "$OUT/env.txt"
PLIM=$("$SMI" --query-gpu=power.limit --format=csv,noheader,nounits 2>/dev/null | head -1 | cut -d. -f1)
case "${PLIM:-}" in (''|*[!0-9]*) : ;; (*) [ "$PLIM" -lt 45 ] && \
  echo "NOTE: power.limit=${PLIM}W -- looks like a battery cap; absolute TFLOPS will be low, ratios still valid." ;; esac

mon_start() {  # mon_start <logfile>
  ( while :; do
      "$SMI" --query-gpu=timestamp,utilization.gpu,clocks.sm,clocks.mem,power.draw,temperature.gpu \
             --format=csv,noheader >> "$1" 2>/dev/null; sleep 0.25
    done ) & MON_PID=$!
}
mon_stop() { kill "${MON_PID:-0}" 2>/dev/null; wait "${MON_PID:-0}" 2>/dev/null; MON_PID=; }

# ---- 1. gates: retarget (host) -> smoke (GPU numerics). Bench means nothing if red. ----
say "gate 1/2: retarget contract (host-only)"
"$BIN" retarget | tee "$OUT/retarget.txt" || { echo "STOP: retarget failed"; exit 1; }

say "gate 2/2: smoke (numerical correctness on device $DEV)"
"$BIN" smoke "$DEV" | tee "$OUT/smoke.txt" || { echo "STOP: smoke not green -- no bench numbers mean anything"; exit 1; }

# ---- 2. debug cross-pipeline sweep (correctness across shape grid) ----
say "debug sweep -> $OUT/debug.csv"
"$BIN" debug "$DEV" --csv "$OUT/debug.csv" | tail -3 | tee -a "$OUT/debug.txt" || echo "WARN: debug sweep reported failures -- see $OUT/debug.csv"

# ---- 3. bench per shape, monitored, with cooldowns ----
ONLYARG=(); [ -n "$ONLY" ] && ONLYARG=(--only "$ONLY")
for S in $SIZES; do
  say "bench @ ${S}^3 (trials=$TRIALS${ONLY:+, only=$ONLY}) -- monitoring clocks/power"
  mon_start "$OUT/gpumon_${S}.csv"
  "$BIN" bench "$DEV" "${ONLYARG[@]}" --size "$S" --trials "$TRIALS" --csv "$OUT/bench_${S}.csv" \
      | tee "$OUT/bench_${S}.txt"
  mon_stop
  # per-shape clock verdict
  awk -F',' '{gsub(/ MHz| W| %|\r/,""); c=$3+0; if(c>0){if(mx<c)mx=c; if(mn==0||c<mn)mn=c; n++}}
       END{ if(n) printf "  SM clock %d-%d MHz over %d samples%s\n", mn, mx, n,
            (mx-mn>150 ? "  <-- droop >150 MHz: throttling during this shape" : "") }' \
      "$OUT/gpumon_${S}.csv"
  [ "$S" != "${SIZES##* }" ] && { echo "  cooldown ${COOLDOWN}s ..."; sleep "$COOLDOWN"; }
done

# ---- 4. summary: median rows only, cudez vs baseline, % of baseline ----
say "summary -> $OUT/summary.txt"
{
  printf "%-6s %-18s %10s %10s %8s\n" "shape" "kernel" "cudez_TF" "base_TF" "%base"
  for S in $SIZES; do
    [ -f "$OUT/bench_${S}.csv" ] || continue
    awk -F',' -v S="$S" '
      /^#/ || $8!="median" {next}
      $6=="cudez"    { cz[$1]=$11 }
      $6=="baseline" { bl[$1]=$11; lib[$1]=$7 }
      END {
        for (k in cz) {
          if (k in bl && bl[k]>0)
            printf "%-6s %-18s %10.2f %10.2f %7.1f%%\n", S, k, cz[k], bl[k], 100*cz[k]/bl[k];
          else
            printf "%-6s %-18s %10.2f %10s %8s\n", S, k, cz[k], "-", "-";
        }
      }' "$OUT/bench_${S}.csv" | sort -k2,2 -k1,1n
  done
} | tee "$OUT/summary.txt"

echo
echo "DONE. Everything is in $OUT/ -- send the whole directory back."
echo "(env.txt shows the power cap; gpumon_*.csv shows clocks during each shape;"
echo " summary.txt is the cudez-vs-baseline table at each shape.)"
