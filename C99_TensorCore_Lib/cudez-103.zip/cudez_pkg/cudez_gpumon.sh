#!/usr/bin/env bash
# cudez_gpumon.sh -- prove the GPU is doing the work, and catch throttle skew.
#
# Wraps ANY command with a background nvidia-smi sampler (~5 Hz), then prints a
# summary: peak/median GPU utilization, SM clock range, power range, temperature.
# The log is timestamped so rows line up with the harness's "bench start ...
# trial offsets [+Ns]" banner.
#
# Usage:
#   ./cudez_gpumon.sh ./cudez_test bench 0 --only v9 --size 4096 --trials 9 --csv v9_4096.csv
#   ./cudez_gpumon.sh ./cudez_test all
#
# Output: gpumon_<epoch>.csv (raw samples) + a summary block on stdout.
#
# WSL2 notes:
#  - nvidia-smi works in WSL2 (via /usr/lib/wsl/lib). `dmon` often does NOT;
#    this script uses --query-gpu polling, which does.
#  - Some fields can read "[N/A]" on laptop parts / WSL; the summary skips them.
#  - utilization.gpu is COARSE: "% of the sample period in which any kernel was
#    resident". It proves the GPU is busy; it does NOT prove tensor cores are.
#    For tensor-core-level proof use Nsight Compute (see notes at bottom).

set -u
[ $# -ge 1 ] || { echo "usage: $0 <command...>" >&2; exit 2; }

SMI="$(command -v nvidia-smi || echo /usr/lib/wsl/lib/nvidia-smi)"
[ -x "$SMI" ] || { echo "nvidia-smi not found -- cannot monitor" >&2; exit 2; }

EPOCH=$(date +%s)
LOG="gpumon_${EPOCH}.csv"
FIELDS="timestamp,utilization.gpu,utilization.memory,clocks.sm,clocks.mem,power.draw,temperature.gpu"

echo "# gpumon start $(date '+%Y-%m-%d %H:%M:%S %Z') (epoch ${EPOCH})" > "$LOG"
echo "# fields: ${FIELDS}" >> "$LOG"

# sampler: ~5 Hz. --format=csv,noheader keeps rows machine-readable.
(
  while :; do
    "$SMI" --query-gpu=${FIELDS} --format=csv,noheader 2>/dev/null \
      | awk -F', *' -v OFS=', ' '{ w=$6+0; if (w > 200) $6 = "NA" } 1' >> "$LOG"
      # BUG-D (1.0.1): WSL2 sensor artifact reports impossible watts (752 W
      # on an 85 W part); clamp so power analysis is not poisoned.
    sleep 0.2
  done
) &
MON=$!
trap 'kill $MON 2>/dev/null' EXIT

echo "gpumon: sampling to ${LOG}; running: $*"
T0=$(date +%s.%N)
"$@"
RC=$?
T1=$(date +%s.%N)
kill $MON 2>/dev/null; wait $MON 2>/dev/null
trap - EXIT

# ---- summary (tolerates [N/A] fields) ----
awk -F',' -v t0="$T0" -v t1="$T1" -v rc="$RC" '
  /^#/ { next }
  {
    gsub(/ %| MHz| W|\r/ , "");            # strip units
    u=$2+0;  if ($2 !~ /N\/A/) { if (u>pu) pu=u; su+=u; nu++ }
    c=$4+0;  if ($4 !~ /N\/A/) { if (c>pc) pc=c; if (mc==0||c<mc) mc=c; nc++ }
    p=$6+0;  if ($6 !~ /N\/A/) { if (p>pp) pp=p; sp+=p; np++ }
    t=$7+0;  if ($7 !~ /N\/A/) { if (t>pt) pt=t }
    n++
  }
  END {
    printf "\n==== gpumon summary ====\n";
    printf "samples: %d over %.1f s (exit code %d)\n", n, t1-t0, rc;
    if (nu) printf "GPU util:   peak %d%%, mean %.0f%%   <-- >0 sustained = GPU is executing\n", pu, su/nu;
    if (nc) printf "SM clock:   %d - %d MHz            <-- big droop mid-run = thermal/power throttle\n", mc, pc;
    if (np) printf "power:      peak %.1f W, mean %.1f W (RTX 3060 Laptop cap ~55-80 W by OEM)\n", pp, sp/np;
    if (pt) printf "temp peak:  %d C\n", pt;
    if (nu && pu < 10) printf "WARNING: utilization never rose above 10%% -- the command may not have touched this GPU\n";
  }' "$LOG"
echo "raw samples: ${LOG} (timestamps align with the harness bench-start banner)"
exit $RC
