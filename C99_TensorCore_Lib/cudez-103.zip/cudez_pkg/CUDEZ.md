# cudez 1.5.0 -- consolidated documentation

*(Merged 2026-07-15 from GUIDE / RUNBOOK / V9_DEV / CHANGELOG /
NEXTSTEPS / REVIEW_RESPONSE into one file. File layout is now: `cudez.h` (the
library), `cudez_test.c` (unified harness: verify | debug | smoke | bench | all |
emit | retarget), `emu_all.py` (v8 + v9 emulator gates), `gstub/` (GPU-free
compile stubs), plus the run scripts `cudez_runall.sh` and `cudez_gpumon.sh`.)*

## Contents
1. [Guide -- what cudez is, pipeline picks, measured numbers](#guide-what-cudez-is-pipeline-picks-measured-numbers)
2. [Runbook -- exact on-box commands and what to send back](#runbook-exact-on-box-commands-and-what-to-send-back)
3. [v9 -- design, GPU-free proofs, FROZEN acceptance criteria](#v9-design-gpu-free-proofs-frozen-acceptance-criteria)
4. [Changelog 1.5.0](#changelog-1-5-0)
5. [Next steps / roadmap](#next-steps-roadmap)
6. [External code review -- findings and dispositions](#external-code-review-findings-and-dispositions)

---

## Guide -- what cudez is, pipeline picks, measured numbers

## cudez 1.5.0 — User Guide

> **Silicon-validated (sm_86).** All pipelines pass the on-hardware numerical
> smoke test (F16 v3-v8, BF16, TF32, INT8, INT4, and 2:4 sparse). Throughput
> figures are 9-trial medians on an RTX 3060 Laptop; best-effort rather than
> under a confirmed clock lock (WSL2 restricts it), so absolute %cuBLAS is
> approximate. See CHANGELOG_1_5_0.md for the full validation record.

### 1. What cudez is

`cudez.h` is a single-header C99 library (no build system, no dependencies beyond
the CUDA Driver API + NVRTC) that generates, compiles, caches, and launches
hand-written tensor-core GEMM kernels at runtime. You describe a problem with a
small config struct; cudez emits the matching kernel source, compiles it with
NVRTC, and hands you a launchable kernel. Supported math: F16, BF16, TF32, INT8,
INT4 — dense and 2:4 structured-sparse — across a ladder of shared-memory
pipeline variants.

It is a *header*: `#include "cudez.h"` in one translation unit. Compiles as C99
(gcc) or C++ (g++); the test harness is C++.

### 2. Quick start

```c
#include "cudez.h"

cudez cz = cudez_boot(0, 0);                 /* device 0, default flags */

cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
cfg.smem_stage = 6;                          /* v8: 128x128 block (see s5) */

char err[256];
cudez_mma_kernel k = cudez_mma_build(&cz, &cfg, err, sizeof err);
/* ... allocate/copy A,B,C,D; fill cudez_mma_args a ... */
cudez_mma_launch(&cz, &k, &a);
```

Always start from `cudez_mma_defaults()` (or `memset`) so every field — including
ones you don't set — is defined; the config is used as a cache key.

### 3. Dtype support matrix

| dtype | dense | 2:4 sparse | pipeline ladder | notes |
|---|---|---|---|---|
| F16  | yes | yes (sm_80–89) | v3–v8 (stages 1–6) | fully exercised |
| BF16 | yes | — | **v6/v7/v8 (stages 4–6), new in 1.5.0** | streaming on stages 0–3 |
| TF32 | yes | — | streaming | staging pending |
| INT8 | yes | — | streaming | pipeline pending (emu_int) |
| INT4 | yes | — | streaming | no cuBLAS baseline; oracle vs CUTLASS |
| F64  | — | — | — | scaffolded, no codegen (sm_86 DMMA throttled) |

`cudez_mma_supported(&cz, dtype)` reports what the current device+build can do.

### 4. The pipeline ladder (`smem_stage`)

Each stage is a distinct generated kernel, added as a new value (never an in-place
edit) so the bench judges it head-to-head against the previous rung.

| stage | name | what it adds | launch contract |
|---|---|---|---|
| 0 | streaming | baseline, no block smem staging | warps=4 |
| 1 | v3 | block smem tiling + 2×2 register blocking | warps=4, M/N/K % (4·tile) |
| 2 | v4 | cp.async double buffering (2-deep) | warps=4 |
| 3 | v5 | + L2-aware grouped rasterization | warps=4 |
| 4 | v6 | raw `ldmatrix.m8n8.x4` + `mma.sync.m16n8k16` (drops wmma) | warps=4 |
| 5 | v7 | + smem-staged float4-coalesced epilogue | warps=4 |
| 6 | v8 | tiled to 128×128 block, 16 warps, `BK=32` | **warps=16, M%128, N%128, K%32** |

Stages 1–5 share the warps=4 / `M,N,K % (4·tile_*)` contract. Stage 6 (v8) is the
odd one out: 16 warps and the 128×128×32 multiples above. `store_hint` is a
v4/v5-era epilogue tweak and is refused on stage 6.

All of stages 2–6 are **2-stage** software pipelines (one step of cp.async
lookahead). Deeper pipelining (v9) is designed but gated — see NEXTSTEPS.

### 5. Choosing a pipeline per shape

Measured on the sm_86 reference GPU (RTX 3060 Laptop, 9-trial medians; best-effort,
not under a confirmed hardware clock lock — WSL2 restricts `-lgc` — so absolute
%cuBLAS is approximate, but the relative pipeline ordering is unambiguous). F16:

- **≥ 2048³: use v8 (stage 6).** It wins the pipeline ladder at both sizes measured:
  ~15.1 TFLOPS at 2048³ (≈80% of cuBLAS) and ~14.7 at 4096³ (≈69% of cuBLAS,
  edging v6 at 68% and v7 at 64%). The wide 128×128 tile earns its keep once there
  are enough blocks to fill the device.
- **≤ 1024³: use v7 (stage 5)** — or v5, they're within noise (~15.7 TFLOPS,
  ~145% of cuBLAS; cuBLAS is far from peak on tiny GEMMs so beating it here is
  expected, not a sign of anything). v8 falls to ~11.3 TFLOPS at 1024³ — the
  128×128 tile leaves too few blocks to fill the GPU.

Crossover: v7 below 2048, v8 at 2048 and up. BF16 tracks F16 almost exactly on the
same pipelines (measured within ~2% of the F16 numbers above), confirming the
identical-layout retarget carries the performance across, not just the correctness.

Not yet pipelined (streaming-only, so DRAM-bound and slow — the roadmap targets):
TF32 ~16–50% of cuBLAS, INT8 ~11–15%, INT4 ~2.6 TOPS. These are the next wins.

### 6. BF16 (new in 1.5.0)

BF16 now uses the same fast pipelines as F16. Set `dtype_ab = CUDEZ_MMA_BF16` and
`smem_stage` 4, 5, or 6. Accumulation is F32. Because BF16 and F16 share the exact
`ldmatrix`/`mma.sync` register layout, cudez emits the proven F16 kernel body and
retargets the type tokens — so the numerical index flow is identical to F16's
(bit-exact-verified via `emu_all.py (v8 gate)`). Measured: BF16 jumps from streaming-tier (~15% of cuBLAS)
to F16-tier -- ~14.3 TFLOPS at 4096³ (68% cuBLAS) and ~15.0 at 2048³ (80%),
within ~2% of the F16 pipeline numbers. The retarget carries performance, not
just correctness.

### 7. 2:4 structured sparse

F16/BF16 dense-B × 2:4-sparse-A via `mma.sp`. Requires sm_80+. **cudez emits the
Ampere-form `mma.sp`; it refuses sparse on sm_90+ (Hopper/Blackwell)**, which
require `mma.sp::ordered_metadata` that cudez does not generate yet — refusing
rather than risk silently-wrong results. Sparse works on sm_80–89 (including the
sm_86 reference GPU).

### 8. Config + launch reference

`cudez_mma_config` (all fields 4-byte; zero-init via defaults): `dtype_ab`,
`tile_m/tile_n/tile_k`, `k_chunks` (K-loop unroll ≥1), `sparse`, `requant_mode`
(INT8/INT4 only), `smem_stage`, `store_hint`. The whole struct is the cache key.

`cudez_mma_args`: device pointers A/B/C/D, dims M/N/K, leading dims, `alpha`/
`beta`, `warps_per_block` (must match the stage contract), stream.

### 9. The build cache

`cudez_try_mma_build_cached` keys on the config struct (exact field compare — the
struct has no padding). Identical configs reuse the compiled module; different
configs rebuild. Not thread-safe and no eviction past `CUDEZ_MMA_CACHE_MAX`
(single-threaded setup/teardown assumed).

### 10. Verification discipline

cudez ships GPU-free proofs (CPU emitter + bit-exact index emulators like
`emu_all.py (v8 gate)`) and an on-box harness (`cudez_test.c`) that does the real work:
`smoke` diffs each kernel against a CPU reference on silicon, `debug --csv` sweeps
pipelines for cross-correctness, and the bench times them. A kernel that compiles
is not a kernel that's correct — run the smoke on each new architecture. cudez
does not force this at the library level; it's a process gate (see the changelog's
release gate).

### 11. Known limitations

- No edge-tile predication: `M,N,K` must be exact tile multiples (per stage).
- Cache and internal registry are not thread-safe.
- INT8/INT4 are streaming-only (pipeline pending `emu_int.py`).
- No FP64 codegen (scaffolded only; GA106 DMMA is throttled, low priority).
- v9 (deeper pipeline) designed but gated on the v8 register count.

### 12. Hardware notes

Reference GPU: RTX 3060 Laptop (GA106, sm_86, 55 W, WSL2). Consumer Ampere throttles
FP64 tensor throughput hard, which is why FP64 is deprioritized. A dual-V100
(sm_70) engine is a separate future target. Clock behavior matters for
benchmarking: lock the boost clock (lower `-lgc` until the 9-trial CV collapses)
before trusting any TFLOPS number — the pipeline-choice guidance in §5 depends on
it.

---

## Runbook -- exact on-box commands and what to send back

## cudez 1.5.0 — Silicon Test Runbook

Run the steps **in order, top to bottom**. Don't skip. Don't reorder.

Each step has the same shape:

- **RUN** — copy the whole grey box, paste it, press Enter. Each box is
  self-contained; you never need to paste "part" of a box.
- **EXPECT** — what a good result looks like. If you don't see it, don't move on.
- **SEND BACK** — the file to hand me (only on some steps).
- **IF IT FAILS** — what to do.

Notes before you start:

- Every command runs from the `~/cudez-test` folder.
- `sudo` will ask for your password — that's normal.
- A `# ...` line inside a box is a comment; it's fine to paste it.

---

### Step 0 — Get into the folder and de-fang permissions

Unzipping strips the "executable" bit off scripts and the Python files, which
causes `Permission denied` if you try `./something`. Two ways around it, and this
step does both so it can't bite you later:

1. we always call helpers through their interpreter (`python3 x.py`, `bash x.sh`), and
2. we add the bit back on the compiled binary and any scripts, just in case.

**RUN**

```bash
cd ~/cudez-test
```

**RUN**

```bash
chmod +x cudez_test 2>/dev/null; chmod +x *.sh 2>/dev/null; echo "permissions set"
```

**EXPECT**

```
permissions set
```

(If `cudez_test` doesn't exist yet, that's fine — you build it in Step 1.)

---

### Step 0.5 — One-time only: make cuSPARSELt permanent

Do this **once, ever.** It stops the `cusparseLt.h: No such file or directory`
error for good by pointing your shell at one complete copy of cuSPARSELt (you
have several installed). If you've already run it, skip to Step 1.

**RUN** — this one line finds a complete copy and writes three lines into
`~/.bashrc`. It's long but it's a *single line*, so it pastes as one piece.
Nothing to download:

```bash
L=$(dirname "$(find / -name "libcusparseLt.so*" -not -path "/mnt/*" 2>/dev/null | head -1)"); I="$(dirname "$L")/include"; if [ -f "$I/cusparseLt.h" ]; then grep -v "# cslt-fix" ~/.bashrc > ~/.bashrc.t 2>/dev/null; mv ~/.bashrc.t ~/.bashrc; printf 'export CPATH="%s:$CPATH" # cslt-fix\nexport LIBRARY_PATH="%s:$LIBRARY_PATH" # cslt-fix\nexport LD_LIBRARY_PATH="%s:$LD_LIBRARY_PATH" # cslt-fix\n' "$I" "$L" "$L" >> ~/.bashrc; echo "OK: using header $I + lib $L; written to ~/.bashrc"; else echo "No complete copy found - run: find / -name cusparseLt.h -not -path '/mnt/*' 2>/dev/null"; fi
```

**RUN** — load it into the current shell (new terminals pick it up automatically):

```bash
source ~/.bashrc
```

**EXPECT** — the first line prints `OK: using header ... + lib ...`, naming the
copy it chose. From now on, every shell can build with `-lcusparseLt` and no
`-I/-L/-rpath` flags.

**IF IT FAILS** — if it prints `No complete copy found`, run the `find` command it
suggests and set the paths by hand (or send me the output):

```bash
find / -name cusparseLt.h -not -path '/mnt/*' 2>/dev/null
```

---

### Step 1 — Build the harness

Preferred build (works after Step 0.5; includes the sparse-vs-cuSPARSELt column):

**RUN**

```bash
g++ -O2 cudez_test.c -o cudez_test -lcuda -lnvrtc -lcudart -lcublas -lcusparse -lcusparseLt
```

**EXPECT** — no output at all. That means it linked. Confirm cuSPARSELt resolved:

**RUN**

```bash
ldd cudez_test | grep cusparseLt
```

**EXPECT** — one line pointing at your `libcusparseLt.so`. Then confirm the binary:

**RUN**

```bash
ls -l cudez_test
```

**EXPECT** — one line showing the file, with an `x` in the permissions
(e.g. `-rwxr-xr-x`).

**FALLBACK** — if you skipped Step 0.5 or don't have cuSPARSELt, build without it
(you lose only the sparse speed-comparison column, nothing else):

```bash
g++ -O2 -DCUDEZ_TEST_NO_CUSPARSELT cudez_test.c -o cudez_test -lcuda -lnvrtc -lcudart -lcublas
```

**IF IT FAILS** — if NVRTC later complains it can't find CUDA headers, set this
once and rebuild:

```bash
export CUDEZ_NVRTC_INCLUDE=/usr/local/cuda/include
```

---

### Step 2 — `verify` (compile every kernel, no GPU math yet)

**RUN**

```bash
./cudez_test verify /usr/local/cuda/include > verify.txt 2>&1
```

**EXPECT** — the command finishes with no error. Check the log:

**RUN**

```bash
grep -c "NVRTC compile OK" verify.txt
```

**EXPECT** — a number **7 or higher** (one per pipeline). If you'd rather eyeball it:

**RUN**

```bash
cat verify.txt
```

**EXPECT** — every line says `NVRTC compile OK`. No `error:` lines.

**SEND BACK** — `verify.txt`

**IF IT FAILS** — stop here and send `verify.txt`. A failure here is a codegen
bug; there's no point going to hardware until it's fixed.

---

### Step 3 — ptxas register counts (this unblocks v9)

Step 2 wrote the PTX files. First confirm they're there:

**RUN**

```bash
ls gen_v7.ptx gen_v8.ptx
```

**EXPECT** — both filenames print (no "No such file").

Now assemble each one **separately**. Run these **one at a time** — two boxes,
two pastes:

**RUN**

```bash
ptxas -arch=sm_86 -v gen_v8.ptx -o /dev/null 2>&1 | tee ptxas.txt
```

**RUN**

```bash
ptxas -arch=sm_86 -v gen_v7.ptx -o /dev/null 2>&1 | tee -a ptxas.txt
```

**EXPECT** — for each, a couple of `ptxas info :` lines. The one that matters is:

```
ptxas info    : Used NN registers, ...
```

**SEND BACK** — `ptxas.txt` (or just paste the two `Used NN registers` lines).
The `gen_v8` register number is what I need to design v9.

**IF IT FAILS** — if you see `Input file 'gen_.ptx' could not be opened`, you
pasted a version with a `$k` in it. Use the two boxes exactly as written above —
they have the real filenames, no variables.

---

### Step 4 — `smoke` (THE correctness gate — must be green)

This is the important one. It runs each kernel on the real tensor cores and
checks the result against a known-correct answer.

**RUN**

```bash
./cudez_test smoke 0 > smoke.txt 2>&1
```

**EXPECT** — check for any failures:

**RUN**

```bash
grep -i "fail\|mismatch\|error" smoke.txt
```

**EXPECT** — **no output** (nothing printed = nothing failed). Then skim it:

**RUN**

```bash
cat smoke.txt
```

**SEND BACK** — `smoke.txt`

**IF IT FAILS (anything under Step 4's grep prints):**

> **STOP. Do not run Steps 5 or 6.** Send me `smoke.txt`. The most likely
> offenders are the 2:4 sparse metadata layout and the INT8/INT4 lane layout —
> those only show up on silicon. I'll fix the kernel, you rebuild (Step 1) and
> rerun this step. Benchmarks are meaningless until smoke is clean.

---

### Step 5 — `debug` (correctness across many shapes)

Only if Step 4 was clean.

**RUN**

```bash
./cudez_test debug 0 --csv debug.csv
```

**EXPECT** — it finishes and writes the file. Confirm:

**RUN**

```bash
ls -l debug.csv
```

**SEND BACK** — `debug.csv`

---

### Step 6 — `bench` (performance, under a locked clock)

Only if Step 4 was clean. Last time the clock wasn't locked, so most numbers
were noise. Lock it first.

#### 6.1 — Lock the GPU clock

**RUN**

```bash
sudo nvidia-smi -lgc 1500
```

**EXPECT** — a line like `Set GPU clocks ... to 1500 MHz` / `All done`.

**IF IT FAILS** — if WSL2 refuses (`not supported` / permission), skip locking and
use the clock-logging variant in 6.5 instead, then tell me it wasn't locked.

#### 6.2 — 4096³ (re-confirm v7 vs v8)

**RUN**

```bash
./cudez_test bench 0 --size 4096 --trials 9 --csv bench_4096.csv
```

#### 6.3 — 2048³ and 1024³ (the ones that were inconclusive)

Run these two **one at a time**:

**RUN**

```bash
./cudez_test bench 0 --size 2048 --trials 9 --csv bench_2048.csv
```

**RUN**

```bash
./cudez_test bench 0 --size 1024 --trials 9 --csv bench_1024.csv
```

#### 6.4 — BF16 on the fast pipelines (new in 1.5.0)

Run these two **one at a time**:

**RUN**

```bash
./cudez_test bench 0 --only bf16v7 --size 4096 --trials 9 --csv bench_bf16v7.csv
```

**RUN**

```bash
./cudez_test bench 0 --only bf16v8 --size 4096 --trials 9 --csv bench_bf16v8.csv
```

#### 6.5 — (Optional) clock-logged run, if 6.1 wouldn't lock

**RUN**

```bash
bash run_bench_with_clocklog.sh 0 --size 2048 --trials 9 --csv bench_2048.csv
```

> Note: `bash run_bench_with_clocklog.sh` (not `./`) so a missing executable bit
> can't stop it.

#### 6.6 — Unlock the clock when you're done

**RUN**

```bash
sudo nvidia-smi -rgc
```

**EXPECT** — `Reset GPU clocks ... All done`.

**SEND BACK** — every `bench_*.csv` file.

> If any CSV's per-trial spread looks large (a cold first trial, values jumping
> around), the clock was still moving. Re-lock lower in 6.1 (`-lgc 1350`, then
> `1200`) and rerun just that shape until the numbers settle.

---

### Final checklist — what to send me

```
verify.txt
ptxas.txt              (or just the two "Used NN registers" lines)
smoke.txt              <-- the gate
debug.csv
bench_4096.csv
bench_2048.csv
bench_1024.csv
bench_bf16v7.csv
bench_bf16v8.csv
```

### What I do with it

1. Fix anything `smoke`/`debug` turned up (sparse metadata / INT layout are the
   usual suspects) — you rebuild and rerun Steps 4–5.
2. Lock in the v7-vs-v8 pick per shape from the clock-locked medians.
3. Use the `gen_v8` register count to finalize and build v9.
4. If it's all green: bump the version to 1.5.0 and finish the guide.

---

## v9 -- design, GPU-free proofs, FROZEN acceptance criteria

## cudez v9 (smem_stage=7) — dev, GPU-free-verified, awaiting silicon

v9 is an **opt-in, experimental** pipeline layered on the promoted, silicon-validated
1.5.0. It does not change v3–v8 behaviour; selecting it requires `smem_stage = 7`.
This note freezes what v9 is and — **before any hardware numbers exist** — the exact
criteria under which the box run will accept or reject it.

### What v9 is

v8's 128×128 / 16-warp / BK=32 raw-`mma` kernel, **byte-for-byte** (same
`ldmatrix.m8n8.x4` + `mma.sync.m16n8k16` inner loop, same 2-pass float4 epilogue),
with v8's **2-stage** cp.async double buffer replaced by a **3-stage ring buffer**.

Why a 3rd stage, and why now: the sm_86 `ptxas -v` line from the 1.5.0 run showed
**v8 = 70 registers → register-bound to 1 block/SM**. A third smem stage is therefore
**occupancy-free** (occupancy is already floored at 1), and it buys **two** K-tiles of
cp.async lookahead instead of one — more latency hiding at exactly the low occupancy a
128×128 tile is stuck with. That low-occupancy DRAM stall is the leading suspect for
v8 topping out at **~69% of cuBLAS at 4096³**.

The 3-deep A/B ring is **56,832 B**, above the 48 KB static-smem ceiling, so v9 uses
**dynamic shared memory**: the launch path opts in once via
`cuFuncSetAttribute(fn, CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES, 56832)`.
56,832 B < the 100 KB sm_86 cap, so it is still **1 block/SM** — occupancy is
unchanged by design; only the pipeline got deeper.

Schedule (proven below): prologue fills 2 stages; the steady loop keeps 2 in flight
(`cp.async.wait_group 2`) and computes the oldest; the drain unwinds `wait_group 1`
then `0`. Ring slot = `k_tile % 3`.

### GPU-free proof status (what is already established)

- **`emu_all.py (v9 gate)` — bit-exact ring proof, ALL PASS** on 7 shapes: `max|D−ref| = 0.0`,
  every output written once, and three ring-safety invariants a 2-stage pipeline
  cannot violate but a 3-stage one can: (a) the slot being prefetched is always
  distinct from the slot being computed, (b) the slot read for tile *k* actually holds
  tile *k*, (c) a prefetch only ever evicts an already-computed tile. Shapes include
  `num_k < depth` (K=64), the degenerate single-tile pipe (K=32), and 12-tile deep
  wraps — the edge cases the schedule is most likely to get wrong.
- **Codegen verified structurally**: `diff gen_v8.cu gen_v9.cu` shows differences in
  **only** the smem declaration (static→dynamic, 2→3 slots) and the schedule. The
  cp.async stage body, the ldmatrix/mma inner loop, and the entire epilogue are
  **identical** — the fragment math cannot have drifted.
- BF16 v9 retarget emits correctly (`__half`→`__nv_bfloat16`, 3-slot offset preserved).
- Generator + launch path compile clean (`g++ -fsyntax-only`).

What is **not** yet established: real tensor-core timing, and the `ptxas -v` register
count for v9. Those need the box. **v9 is unproven on silicon until the run below.**

### Box test commands

```bash
## 0) build as usual (device 0 shown)
##    smoke first: numerical correctness of v9 on real tensor cores
./cudez_test smoke 0
##    -> expect a new line: "F16  smem v9 (128x128x192 x2 + 768x128x128): PASS"
##       (and v8's line must still PASS — a v8 regression fails the whole smoke)

## 1) cross-pipeline correctness sweep (v9 now in the ladder)
./cudez_test debug 0 --csv debug_v9.csv
##    -> the v9 rows must read verdict=PASS at every shape

## 2) v9 vs cuBLAS at the three decision shapes, F16 then BF16
./cudez_test bench 0 --only v9    --size 1024 --trials 9 --csv v9_1024.csv
./cudez_test bench 0 --only v9    --size 2048 --trials 9 --csv v9_2048.csv
./cudez_test bench 0 --only v9    --size 4096 --trials 9 --csv v9_4096.csv
./cudez_test bench 0 --only bf16v9 --size 4096 --trials 9 --csv v9_bf16_4096.csv

## 3) capture v9's register/smem line (compare to v8 = 70 regs / 1 block/SM)
##    (same NVRTC/ptxas path the 1.5.0 ptxas.txt used, with smem_stage=7)
```

If `cuFuncSetAttribute` fails on this GPU (dynamic-smem cap below 56 KB), v9 refuses at
launch with a clear message pointing back to v8 — that is expected behaviour, not a bug.

### FROZEN acceptance criteria (decided before the numbers)

v9 is **accepted for large shapes (≥2048³)** iff **all** hold on the box:

1. **Correctness:** `smoke` shows v9 PASS **and** v8 still PASS; `debug` v9 rows all PASS.
2. **No small-shape regression:** at **≤1024³**, v9 does **not** beat v7, and v9 is **not**
   promoted there — v7 stays the small-shape incumbent (it was 144% cuBLAS at 1024).
   This criterion only checks v9 didn't somehow *replace* the small path; v9 is a
   large-shape bet.
3. **Large-shape win at sustainable clock:** at 2048³ and 4096³, **v9 ≥ v8 within
   trial-to-trial noise** (medians; treat a gap inside the run's own trial spread as a
   tie, not a win). A tie is **not** acceptance — the 3rd stage costs a slot of smem and
   a `wait_group`, so v9 must **clear v8, not merely match it**, to justify replacing it.
4. **Occupancy unregressed:** v9's `ptxas -v` still fits **1 block/SM** on sm_86
   (≤ the 100 KB dynamic cap; register count in the ~70–80 band is fine — occupancy is
   already floored at 1, so a few extra regs cost nothing).

If (3) is a tie or v9 loses, **v9 is rejected** and v8 remains the ≥2048³ pipeline; the
3-stage idea is recorded as tried-and-neutral in the ledger. No silent retention.

Regardless of the outcome, the dispatcher `pick_pipeline(M,N,K,batch,dtype)` and the
shape sweep that maps the v7↔(v8|v9) crossover knee come **after** this run, using
whichever of v8/v9 wins the large-shape slot.

---

## Changelog 1.5.0

## cudez 1.5.0 — Changelog

Status: **PROMOTED.** `CUDEZ_VERSION_*` = 1.5.0. All generated kernels pass the
on-hardware numerical smoke test on the sm_86 reference GPU (RTX 3060 Laptop,
WSL2) — see "Silicon validation" below. Performance is characterized (9-trial
medians, best-effort rather than under a confirmed clock lock, which WSL2
restricts); the per-shape pipeline picks are data-backed.

### Silicon validation (sm_86) — PASSED

The on-hardware `smoke` gate is green: **every** generated kernel matches a CPU
fp32 reference on the actual tensor cores — F16 (streaming, v3, v4, v4h, v5, v5h,
v6, v7, v8), BF16, TF32, INT8, INT4, 2:4 sparse, batched, and the one-call
`cudez_gemm` path. Notably the **2:4 sparse metadata bit-layout is correct on this
GPU** (the single thing most likely to need a hardware re-derivation), and **v8 and
BF16 — the 1.5.0 headline features — are numerically correct**.

Performance (9-trial medians vs cuBLAS/cuSPARSELt):
- **v8 wins ≥2048³:** ~15.1 TFLOPS @2048³ (≈80% cuBLAS), ~14.7 @4096³ (≈69%,
  edging v6/v7). This resolves the previously-inconclusive 2048³ shape — v8 > v7.
- **v7 wins ≤1024³:** ~15.7 TFLOPS (v8 drops to ~11.3 — the 128×128 tile starves
  the device at small sizes). cudez beats cuBLAS at 1024³ because cuBLAS isn't
  tuned for tiny GEMMs, not an anomaly.
- **BF16 fix delivered:** from streaming-tier (~15% cuBLAS) to F16-tier — ~14.3
  TFLOPS @4096³ (68%), ~15.0 @2048³ (80%), within ~2% of F16. The retarget carries
  performance, not just correctness.
- **Still streaming (the next wins):** TF32 ~16–50%, INT8 ~11–15%, INT4 ~2.6 TOPS
  of cuBLAS — DRAM-bound, confirming the INT/TF32 pipeline work is the top roadmap
  item.

**ptxas (sm_86):** v8 uses **70 registers**, 37,888 B smem; v7 uses 72 registers,
36,864 B. 70 regs × 512 threads = 35,840 → **v8 is register-bound to 1 block/SM**
(exactly the predicted binder). This unblocks v9: a 3rd cp.async stage at BK=32 is
occupancy-free (already 1 block/SM), so v9 = BK=32 3-stage dynamic-smem is the
design, and the extra stage buys deeper latency-hiding without costing a block.

Note: the standalone `verify` mode reported `cannot open mma.h / cuda_fp16.h` —
that's an NVRTC include-path artifact of how `verify` was invoked (the arg is an
include dir, not a device ordinal), NOT a codegen problem: `smoke` compiled and ran
all the same kernels correctly via the library's runtime NVRTC path.

---

---

### Headline

**BF16 now runs on the fast raw-MMA pipelines (v6/v7/v8), not just the streaming
path.** Before 1.5.0 only F16 had the shared-memory/cp.async pipeline ladder;
BF16/TF32/INT8/INT4 were streaming-only, which is DRAM-bound and starves the
tensor cores (measured at ~16% of cuBLAS for BF16 at 4096³). BF16 shares F16's
exact `ldmatrix`/`mma.sync` register layout, so 1.5.0 emits the proven F16 kernel
body and retargets two token classes (`__half`→`__nv_bfloat16`,
`.f16.f16`→`.bf16.bf16`). This is expected to move BF16 from streaming-tier to
F16-tier throughput; the bench now measures it directly.

### New in 1.5.0

#### Pipelines / codegen
- **BF16 on `smem_stage` 4, 5, 6 (v6/v7/v8).** Retarget of the bit-exact F16 body
  via new helpers `cudez_strreplace_all_` (bounds-checked in-place) and
  `cudez_bf16_retarget_`, invoked before the `return 1` in each of the v6/v7/v8
  generators when `dtype_ab == CUDEZ_MMA_BF16`. F32 accumulate throughout.
  Verified: F16 output byte-identical after the edits; BF16 emits balanced,
  correct source for all three stages; the v8 index emulator (`emu_all.py (v8 gate)`)
  transfers unchanged (identical layout); helpers are g++-clean.
- **v8 (`smem_stage=6`) carried forward from 1.4.0-dev:** 128×128 block, 16 warps
  (512 threads), `BK=32` (halved from v7 to land A/B panels at 37,888 B < the
  48 KB static-smem ceiling, keeping 2 blocks/SM and doubling arithmetic
  intensity to 32 FLOP/byte). Two-pass float4 epilogue. Reuses v6/v7's exact
  inner loop. Launch contract: `warps_per_block==16`, `M%128==0`, `N%128==0`,
  `K%32==0`.

#### Correctness guards (from the deep-technical-review 2nd pass)
- **Sparse sm_90+ ceiling (review finding #1 — the one genuine silent-risk).**
  `cudez_mma_cfg_valid_` had a floor (`cc<80` refused) but no ceiling. cudez
  emits Ampere-form `mma.sp`; sm_90+ (Hopper/Blackwell) require
  `mma.sp::ordered_metadata` (PTX ISA 8.5+), which cudez does not generate yet.
  Added a ceiling that refuses sparse on `cc>=90` rather than risk incorrect
  results. **Honesty note baked into the message:** whether plain `mma.sp`
  mis-assembles or miscomputes on sm_90+ is unverified (no sm_90 hardware in
  reach); either way cudez cannot produce *correct* 2:4 sparse output there, so
  refusing is correct. sm_80..sm_89 (incl. the sm_86 reference GPU) are
  unaffected. Remove when the ordered-metadata variant lands (roadmap item 4).
- **`smem_stage` field doc drift (review finding #6).** The struct doc-comment
  described only stages 0–2 and still claimed "F16 dense ONLY." Extended to
  cover v5–v8 and the new BF16-on-4–6 support, plus the stage-6 launch contract.

#### Tooling / verification
- **`gstub/` — g++-compatible CUDA/cuBLAS/cuSPARSELt stubs.** Function-like macros
  (work in C++, unlike empty-paren prototypes) for the full driver/runtime/
  cublas/cusparseLt surface the harness touches, plus `cuda_fp16.h`/`cuda_bf16.h`
  types. The box-verified harness compiles clean under
  `g++ -std=c++14 -fsyntax-only -I gstub -I .` (exit 0), so harness edits are now
  g++-verifiable in-sandbox. This closes the gap that let a prior `int`→enum
  parameter mismatch (`verify_emit_int`) reach the box uncaught.
- **BF16 harness bench wiring.** New kinds `KBF16S7` (bf16 v7) and `KBF16S8`
  (bf16 v8, 16 warps); kinds-table rows; `--only bf16v7|bf16v8` tokens; sm_80
  gate; dtype/element-size/source mapping to the bf16 host buffer. The bench
  build+launch is the de-facto bf16 smoke (fails loudly if the kernel doesn't
  compile or run on silicon). g++-verified clean.

### Deep-review triage outcomes (verified against the code)
- **#1 sparse sm_90+:** REAL → fixed (above).
- **#6 doc drift:** REAL → fixed (above).
- **#3 every pipeline is 2-stage:** REAL, corroborates the v9 plan (see NEXTSTEPS).
  The review frames the binder as shared memory; at 128×128 the real binder is
  *registers* (32 accumulators/thread floors ~1 block/SM), which is why v9 is
  gated on the v8 ptxas `-v` line, not on smem math.
- **#2 no in-tree hardware verification:** OVERSTATED (header-only scope). The
  harness smoke tests already diff every pipeline vs a CPU reference on silicon,
  and `debug` mode sweeps them. What's absent is a *library-level guard forcing
  it* — declined the heavyweight `ACKNOWLEDGE_UNVERIFIED` macro as by-design.
- **#4 cache `memcmp` padding:** verified no live bug on gcc/x86-64 (`sizeof`==36,
  nine 4-byte members: 7 `int` + 2 enum, **no floats** — an earlier draft of this
  note miscounted). Ultimately switched to explicit field-by-field compare anyway,
  bundled with the A-1 context-keying below (a second reviewer flagged the
  implementation-defined-enum-width caveat, and A-1 required touching the same
  comparison — so closing both at once was free).
- **#5 `srcbuf_sz=16384` too small for v8:** EMPIRICALLY FALSE. Measured v8 =
  7,770 B, bf16-v8 = 7,867 B; the 2× headroom is intact.
- **#9 FP64 codegen missing:** REAL but LOW priority for sm_86 (GA106 DMMA
  throughput is throttled to near-vestigial). Plan is sound; gated behind a
  smoke-vs-CUDA-cores go/no-go. Deferred.

### Second deep-review pass (full-tree handoff) — fixes applied
A second review ran the in-sandbox tools and verified against the code (not the
audit comments). It confirmed the green foundation (emu_v8 bit-exact, g++ gate,
emitter sizes, emu↔`gen_v8.cu` index equivalence) and found a set of latent
hazards the first pass missed — all fixed here, all still GPU-free-verified:
- **A-1 (most serious) — `cudez_gemm`'s hidden static cache wasn't context-keyed.**
  The per-TU `static cudez_mma_cache` keyed on config only, so
  boot(A)→gemm→teardown(A)→boot(B)→gemm with the same config could hit a cached
  `CUfunction` on a freed module (silent, and the static is unreachable). Fixed:
  the cache now stores the owning `CUcontext` per entry and hits only on a context
  match. Bundled with the field-by-field key (below).
- **B-3 — cache `memcmp` → explicit field compare.** `cudez_mma_cfg_eq_` compares
  the nine named fields, removing the dependence on enum width / padding. (Update
  it if a field is ever added — noted in-code.)
- **A-3 — BF16 retarget could silently truncate.** `cudez_strreplace_all_` was
  `void` and bailed silently on overflow; `cudez_bf16_retarget_` couldn't report
  it. Both now return `int`, and the three generator call sites fail the build on
  truncation — same "refuse rather than risk wrong results" contract as the sm_90
  sparse ceiling. Proven by a new pure-host test ``cudez_test retarget`` (7/7 pass,
  including the too-small-buffer→0 cases).
- **A-2 — float4 C/D epilogue alignment (stages 5/6 only).** v7/v8 vectorize the
  global C/D access as `float4`, which faults on a non-16B-aligned base (arena
  sub-view / element-offset submatrix). The launch path now rejects a misaligned
  base for `smem_stage∈{5,6}` — precisely: D always, C only when `beta!=0` (the C
  read is beta-gated, so a misaligned-but-unread C at beta=0 is allowed, unlike
  the reviewer's `C|D` sketch). The row offset is already 4-aligned via the
  existing N-tile contract, so only the base needed guarding.
- **C-1 — contradictory sparse-status docs.** A stale 0.3.1-era block called the
  2:4 sparse path a "compilable skeleton, not a working sparse GEMM," contradicting
  three other in-file notes and the actual code (which emits real 4+4 loads and a
  real scatter). Replaced with an accurate caution: sparse IS a real kernel; what's
  unverified is the metadata bit-layout (re-derived once after an on-device probe)
  and the sm_90 `ordered_metadata` gap (already refused).
- **B-1 — `cudez_launch1d` div-by-zero.** `block_size==0` now returns a named error
  instead of SIGFPE.
- **B-2 — sparse launch args bypassed the overflow-checked macro.** The sparse
  branch now marshals through `CUDEZ_PUSH_ARG_` like dense/int, so a future
  sparse-signature change gets the same protection (was a fixed `sargs[10]`).

Deferred from that pass (correctly, per its own ordering): the standing #1 risk —
**on-hardware numerical diff of every generated kernel** — remains the release
gate (see below), and the §1.D coverage backfill (cross-context and float4-misalign
harness cases) lands with the silicon run that can execute them; the A-3 host test
is done now.

### Not in 1.5.0 (queued)
- INT8/INT4 shared-memory pipeline (the largest remaining perf win) — blocked on
  `emu_int.py` (bit-exact `m16n8k32.s8` / `m16n8k64.s4` fragment emulator). This
  is NOT a retarget; different MMA shapes and fragment layouts.
- **v9** (`smem_stage=7`, N-stage cp.async ring-buffer pipeline) — gated on the
  v8 ptxas `-v` register count (decides BK=32-dynamic-smem vs BK=16-static).
- FP64 (`CUDEZ_MMA_F64`) codegen — deferred (see #9 above).

### Release gate (what promotes 1.5.0)
On the sm_86 box, in order: `g++ -fsyntax-only` (green in-sandbox) → NVRTC compile
→ ptxas assemble → `smoke` (diff vs reference) for F16 v8 and BF16 v6/v7/v8 →
`debug --csv` cross-pipeline correctness → clock-locked bench. On green: bump the
version macros to 1.5.0 and finalize GUIDE_1_5_0.md with the measured numbers.

---

## Next steps / roadmap

## cudez — NEXTSTEPS (living queue)

### >>> 1.5.0 SILICON VALIDATED + PROMOTED (sm_86) <<<
- smoke green: every kernel correct on hardware (incl. v8, bf16, 2:4 sparse metadata)
- perf characterized: v8 wins >=2048 (80%/69% cuBLAS), v7 wins <=1024; bf16 fixed (15% -> 68-80%)
- ptxas received: v8 = 70 regs (register-bound to 1 block/SM) -> v9 design decided
- version macros bumped 1.1.0 -> 1.5.0


### Done since 1.4.0-dev (all GPU-free verified)
- [x] v8 pipeline (smem_stage=6): codegen + launch + validator + emu_v8 (bit-exact, 4 gates)
- [x] BF16 on v6/v7/v8: token-retarget of the proven F16 body; validator relaxed for bf16 on stages 4-6
- [x] BF16 harness bench wiring: KBF16S7/KBF16S8 kinds, table rows, `--only bf16v7|bf16v8`, sm_80 gate, dt/es/src map
- [x] Sparse sm_90+ ceiling (review #1): refuse cc>=90 rather than silent-wrong; sm_80..89 unaffected
- [x] smem_stage doc drift (review #6): struct comment now covers v5-v8 + bf16-on-4-6
- [x] gstub/: g++-compatible macro stubs -> harness now compiles under `g++ -fsyntax-only` in-sandbox (exit 0)
- [x] Deep-review 2nd pass triage (see CHANGELOG_1_5_0.md for per-finding verdicts)
- [x] Full-tree deep-review handoff fixes: A-1 (context-key gemm cache) + B-3 (field-eq),
      A-3 (bf16 retarget fails loud; proven by `cudez_test retarget` 7/7), A-2 (float4 C/D
      alignment guard for stages 5/6), C-1 (stale sparse-skeleton doc corrected),
      B-1 (launch1d div-by-zero guard), B-2 (sparse args through checked macro)

### Next (in order)
1. **emu_int.py** — bit-exact CPU emulator of the INT8/INT4 fragment flow
   (`mma.m16n8k32.s8`, `mma.m16n8k64.s4`). Prerequisite for the INT pipeline, which
   is the largest remaining perf win. NOT a retarget — different MMA shapes and
   fragment layouts than F16. Pure Python; fully verifiable in-sandbox.
2. **INT8/INT4 shared-memory pipeline codegen** — after emu_int passes. Apply the
   v6/v7/v8 staging ladder to the integer path (currently streaming-only ->
   DRAM-bound -> ~13% cuBLAS at 4096³).
3. **v9 (`smem_stage=7`, 3-stage cp.async ring buffer)** — **BUILT + GPU-free-verified,
   awaiting silicon.** Full codegen (reuses v8's fragment math byte-for-byte + fresh
   ring scaffolding), validator, launch path (dynamic-smem opt-in via
   `cuFuncSetAttribute`, 56,832 B), BF16 retarget, and harness wiring
   (`--only v9`/`bf16v9`, smoke, debug sweep, bench rows) all landed. `emu_all.py (v9 gate)`
   passes bit-exact on 7 shapes incl. ring-safety invariants and deep wraps; structural
   `diff gen_v8.cu gen_v9.cu` confirms only smem-decl + schedule changed. **Next: the
   box run in `V9_DEV.md`** (smoke -> debug -> bench --only v9/bf16v9 at 1024/2048/4096
   + a v9 ptxas line), judged against the acceptance criteria frozen there. Then the
   shape-sweep + `pick_pipeline` dispatcher, using whichever of v8/v9 wins ≥2048³.
4. **BF16 numerical gate (small)** — generalize the smoke/debug sweep to bf16
   (int inputs are exact in bf16, same tolerance). Currently inherited from the
   F16 emulator proof + identical-layout retarget; bench build+launch is the
   de-facto gate.
5. **Coverage backfill (§1.D of the handoff)** — harness cases that need silicon to
   run: cross-context (boot->gemm->teardown->boot->gemm) asserting the A-1 fix, and a
   v7/v8 launch on a +4B-offset arena sub-view asserting the A-2 rejection. (The A-3
   host test is already in-tree and passing.)
6. **Finalize GUIDE_1_5_0.md** — draft skeleton is in-tree; fill the measured
   numbers and mark features validated once silicon passes.
7. **Promote:** bump CUDEZ_VERSION_* macros 1.1.0 -> 1.5.0 on green box run.

### Blocked on the user (silicon-side)
- [DONE] v8 ptxas line received: 70 regs.
- **Clock-locked 2048³/1024³ rerun** — the prior `all` run wasn't clock-locked
  (CV 14-40% from boost transitions); only 4096³ was trustworthy there. Lower
  `-lgc` until the 9-trial CV collapses; no temperature-correction column.
- [DONE] Silicon results received: all smoke PASS; no correctness bugs surfaced.
  Only wart: standalone `verify` needs a CUDA include-dir arg (runtime path is fine).

### In-sandbox verification available (no CUDA/GPU)
- `python3 emu_all.py`                                  (index flow, bit-exact)
- `./cudez_test emit`         (CPU emit, all samples)
- `g++ -std=c++14 -fsyntax-only -Wno-unused-value -I gstub -I . cudez_test.c` (harness, exit 0)
- `gcc -std=c99 -I gstub -I . `cudez_test retarget` && ./a.out` (A-3 truncation contract, 7/7)
- Cannot compile CUDA (no NVRTC/ptxas/cuBLAS on box).

---

## External code review -- findings and dispositions

## Response to `cudez-v9-review.md`

Every finding was reproduced against the shipped code and dispositioned below.
All GPU-free gates still pass after the changes (`emu_v9`, `emu_v8`, `emit`,
`test_retarget`, harness `g++ -fsyntax-only`, and a direct unit test of the
rewritten `cudez_strreplace_all_` across grow/shrink/overflow).

| # | Severity | Disposition |
|---|---|---|
| **F1** | 🔴 CRITICAL | **FIXED.** `test_f16_smem_stage` now treats `stage == 7` as a 16-warp / BK=32 block for both `wpb_ok` (16, not 4) and `badK` (48, which `%32 != 0`, so genuinely rejected). Stage 7 also gets its own build name `smoke_f16_smem_v9`. This was a real harness bug I introduced; without it `smoke` printed a double false FAIL on the first GPU. |
| **F2** | 🟠 HIGH | **FIXED.** `cudez_mma_max_active_blocks` now passes the real dynamic-smem size for stage 7 (via the new `CUDEZ_V9_DYN_SMEM` macro — one source of truth shared with the launch site) instead of `0`; doc comment corrected. It no longer over-reports v9 occupancy. |
| **F3** | 🟠 HIGH | **FIXED.** The six registry-array frees in `cudez_teardown` now use `CUDEZ_FREE` instead of raw `free`, so a custom `CUDEZ_ALLOC`/`CUDEZ_FREE` user no longer gets `free()` on non-`malloc` memory. |
| **F4** | 🟡 MED | **FIXED.** The `cudez_mma_config` comment now describes the field-by-field cache compare (`cudez_mma_cfg_eq_`) and warns that a new field must be added there to participate; the obsolete byte-compare/memset advice is gone. |
| **F5** | 🟡 MED | **DOCUMENTED (design).** `cudez_gemm`'s comment now states it uses the streaming pipeline, explains why it does not auto-pick v3–v9 (their shape contracts would reject GEMMs streaming accepts), and points to the explicit `smem_stage` path plus the roadmapped `pick_pipeline` dispatcher. The default is left unchanged deliberately — a fixed non-zero default would make the flagship call fail on shapes it currently handles. Auto-selection lands with the dispatcher after v9's silicon run. |
| **F6** | 🟡 MED | **FIXED.** The v9 generator's head comment now says `smem_stage=7 (pipeline v9)` and describes the 3-stage ring/dynamic smem. The BF16 retarget also rewrites the CUTLASS op name in the comment (`F32F16F16F32_TN` → `F32BF16BF16F32_TN`) so the BF16 kernel's provenance comment is honest. |
| **F7** | 🟡 MED | **FIXED.** `cudez_read`, `cudez_write_async`, `cudez_read_async` now reject a copy whose `bytes > b.size` (guarded by `b.size != 0` so size-unknown buffers keep prior behavior), turning a silent OOB device copy into a logged refusal. |
| **F8** | 🟡 MED | **FIXED.** `cudez_launch1d` computes the grid in 64-bit and errors loudly past the `gridDim.x` limit (2,147,483,647) instead of truncating `size_t`→`unsigned` and silently dropping the tail — same ceiling the mma launcher enforces. |
| **F9** | 🟡 MED | **DOCUMENTED (invariant).** The BF16 retarget is still a substring rewrite; it is safe for the current generators (bare `__half`/`__half2` only, both map correctly). The function now carries the explicit invariant future AB-typed kernels must satisfy, and notes the `typedef cz_ab_t` refactor as the eventual removal of the constraint. That refactor touches every generator and belongs in its own change, not bundled with v9 bring-up. |
| **F10** | 🟡 MED | **FIXED.** The validator now emits a non-fatal note when `smem_stage == 7 && k_chunks > 1`, warning that unrolling v9's steady loop (stage+compute+wait_group per copy) can cost the occupancy v9 is register-bound to preserve. Benign default (`k_chunks == 1`) is silent. |
| nit: `strreplace` O(n²) | ⚪ | **FIXED.** `cudez_strreplace_all_` hoists a running length instead of `strlen`-ing the whole buffer each iteration; now O(n). Unit-tested for grow/shrink/equal/overflow correctness. |
| nit: occupancy doc | ⚪ | Folded into F2. |
| nit: `cudez_buffer_free` no-op log | ⚪ | Left as-is (defensible; low value vs. noise). |
| nit: const-cast to mutate registry | ⚪ | Left as-is (only UB if the `cudez` is truly `const`, which it never is); noted as a "technically" item, not a live bug. |

**Not changed and why (F5, F9):** both have a "correct" fix that is materially larger
than the finding (a shape-aware dispatcher; a whole-codebase type-alias refactor). Both
are real and both are captured — F5 in the roadmap, F9 as an enforced code invariant —
so neither is silently dropped, but neither is rushed into the v9 bring-up patch where a
regression would be expensive.

The reviewer's headline stands: the v9 **kernel** needed no change. Every fix above is in
the harness, the launch/host helpers, docs, or comments. The frozen `V9_DEV.md`
acceptance run is now safe to execute from step 1.

---

## Addendum: run 1784078804 (2026-07-14, AC power) -- analysis and v9 ruling

**Correctness: fully green.** debug swept 160/160 PASS (every pipeline including
v9, all shapes); smoke's sole "failure" was the stale `smem_stage=7` must-reject
probe -- the box fix that the consolidated zip had accidentally reverted, now
permanently applied (probe moved to 8, `rows[]` grown to 128).

**Performance: measurement invalidated by DVFS.** gpumon caught the GPU seesawing
210-1425 MHz at 15-44 W through phase A (cudez rows, idle gaps between NVRTC
builds) then committing to 907-1695 MHz at 75-81 W for phase B (cuBLAS,
back-to-back rows). Max temp 73 C -- not thermal; the governor simply never
committed during bursty load. The confound cut both ways: at 4096 cuBLAS looked
2.3x better than its phase-A-equivalent self; at 2048 cuBLAS's own rows caught a
clock dip (0.86 -> 4.34 ms trial-to-trial) and cudez looked 171% of it. Neither
ratio is real. Consequence: bench harness is now **v2.3** -- a per-row clock
prime (300 ms sustained untimed load, `CUDEZ_PRIME_MS` overrides, 0 = v2.2) on
BOTH phases; the timed methodology is unchanged so numbers stay comparable.
Baselines for v8/v9/BF16-pipeline rows were also missing entirely (two stale
kind-switches in phase B); fixed, so the flagship kernels get their %cuBLAS.

**v9 frozen-criteria ruling: DEFERRED, not accepted.** Within-run v8-vs-v9 (same
phase, adjacent rows) at 2048: F16 v9 +4.8% but trial ranges overlap (v8 spread
123% -- clock chaos) = tie; BF16 v9 +13.8% with NON-overlapping ranges -- a real
signal. At 4096: F16 -3.7%, BF16 -5.7%, ranges overlap = tie-or-slight-loss.
The bar (clear v8 at BOTH >=2048 shapes) was not met, but the run also failed
the criteria's "at sustainable clock" precondition, so v9 is not recorded as
tried-and-neutral either. One primed re-run decides it:
`TRIALS=9 SIZES="2048 4096" ./cudez_runall.sh`.

---

## Addendum: run 1784082434 (2026-07-14, AC, bench v2.3 primed) -- v9 ACCEPTED, 1.6.0

Clock discipline held: memory clock pinned at 7000 MHz, power at the 80 W cap
(median 78-80 W), temp <=79 C -- power-limited steady state, i.e. this laptop's
sustainable operating point. Gates: smoke ALL PASS, debug 160/160.

**Frozen-criteria verdict: v9 ACCEPTED for >=2048^3.** v9 beat v8 at BOTH decision
shapes in BOTH dtypes with fully NON-overlapping trial ranges (v9's slowest trial
faster than v8's fastest): F16 +3.0% @2048 / +7.2% @4096; BF16 +2.6% / +6.8%.
The margin grows with size -- the 3-stage ring's extra K-tile of lookahead is
doing exactly what it was built for. Occupancy criterion satisfied by
construction (56,832 B dynamic smem = 1 block/SM on sm_86).

**New project records @4096^3:** F16 17.95 TF (79.2% cuBLAS), BF16 17.68 TF
(78.7%) -- up from v8's 72.6%/73.7% in the same run and the old 69% record.

**Pipeline picks are now:** v7 (smem_stage=5) for <=1024; **v9 (smem_stage=7) for
>=2048**; v8 stays in the tree as the ladder rung and the automatic fallback for
GPUs that cannot grant 56 KB of dynamic smem. Version bumped to **1.6.0**.

**Roadmap after this result:** (1) the depth ladder continues -- 2->3 stages
bought +7% at 4096, and depth-4 (75,776 B) and even depth-5 (94,720 B) still fit
under the sm_86 100 KB cap at 1 block/SM; a `pipe_depth` config knob is the
natural v10 rung, judged by the same frozen shape/criteria pattern. (2) the
`pick_pipeline` dispatcher: the v7<->v9 crossover sits between 1024 and 2048;
map the knee at 1280/1536/1792 first. (3) INT8 remains the largest dtype gap
(11-17% of cuBLAS) -- the pipeline ladder has not been ported there yet.
(4) batched-small (28%) after that.

---

## Addendum: 1.7.0-dev rungs -- v10 (4-stage ring) and INT8 pipeline. GPU-free-verified, criteria FROZEN before silicon

Two rungs land together, each one change, both proven GPU-free before any
hardware number exists. The library version stays 1.6.0 until acceptance.

### v10 (smem_stage=8): the ring deepened to 4 stages
v9's kernel with one more ring slot: 75,776 B dynamic smem (under the 100 KB
sm_86 cap, still 1 block/SM), prologue fills 3, steady keeps 3 K-tiles of
cp.async lookahead in flight (wait_group 3), drain unwinds 2 -> 1 -> 0.
Fragments and epilogue remain byte-for-byte v8/v9 (structural diff verified).
Proof: emu_all.py v10 gate -- bit-exact + write-once + ring-safety on 7 shapes
including num_k<depth and 16-tile wraps. MOTIVE: 2 -> 3 stages bought +7.2% at
4096^3 with the margin growing in size; this buys the next increment of the
same latency hiding.

**FROZEN v10 acceptance (decided now):** accept for >=2048^3 iff (1) smoke v10
PASS with v8/v9 still PASS and debug v10 rows all PASS; (2) at 2048^3 AND
4096^3, v10 median beats V9 (the incumbent now, not v8) with non-overlapping
trial ranges at committed clocks (bench v2.3 priming); (3) no <=1024^3 pick
changes (v7 stays); (4) 1 block/SM by construction (75,776 B). A tie or
overlap = v10 rejected, recorded tried-and-neutral, v9 keeps the slot; the
depth ladder stops there. Diminishing returns are the expected outcome; the
rung exists to measure exactly where they set in.

### INT8 on the v7-class pipeline (smem_stage=5 + CUDEZ_MMA_INT8)
The streaming s8 kernel's silicon-proven m16n8k32.s8 fragment layouts, moved
from per-fragment GLOBAL gathers (its bottleneck: ~2 TOPS, 11-17% of cuBLAS)
onto the proven v7-class machinery: 64x64 block, 4 warps, BK=64 (two k32 mma
steps), 2-stage cp.async double buffer using v8's exact silicon-proven
prefetch/wait/sync idiom, 20,480 B static smem. A fragments = 4 B ld.shared;
B fragments = 4-byte column gathers (swizzle is a LATER rung if bench demands);
epilogue = direct s32 stores (same policy). Same launch contract semantics,
enforced: warps_per_block=4, M/N/K % 64 == 0. Proof: emu_all.py i8 gate --
bit-exact int32 on 4 shapes; fragment tables additionally cross-checked
byte-for-byte against the streaming kernel that already passed silicon smoke.

**FROZEN INT8-pipeline acceptance (decided now):** accept iff (1) smoke
"INT8 smem v7" PASS (exact int32) with the streaming INT8 row still PASS;
(2) bench "INT8 smem v7" clears the STREAMING int8 kernel by >=2x at 1024^3
and >=2048^3 (the bar is the incumbent, not cuBLAS parity -- closing to
cuBLAS is the ladder's job over multiple rungs, exactly as F16 took v3..v9);
(3) no other row regresses. If it clears, it becomes the INT8 default pick
and the next INT8 rungs (B-gather swizzle, staged epilogue, ring) get queued
by what the numbers say; INT4 and TF32 then get the same recipe.

### Box commands (deciding run for both rungs)
```bash
./cudez_test smoke 0          # v10 + "INT8 smem v7" rows must PASS, all others still PASS
./cudez_test debug 0 --csv debug_v10.csv
TRIALS=9 SIZES="1024 2048 4096" ./cudez_runall.sh     # full primed table
# focused, if preferred:
#   TRIALS=9 ONLY=v10    SIZES="2048 4096" ./cudez_runall.sh
#   TRIALS=9 ONLY=int8v7 SIZES="1024 2048" ./cudez_runall.sh
```

---

## Addendum: run 1784165818 (2026-07-15, primed) -- 1.7.0 PROMOTED. INT8 pipeline ACCEPTED; v10 rejected (tried-and-neutral)

Gates: retarget, verify (NVRTC compile of every generated kernel), and smoke ALL
PASS -- including v10's first actual silicon execution (the prior FAIL was the
harness warp-count bug, since generalized to `stage >= 6`) and the INT8
pipeline's exact-int32 check.

**INT8 pipeline: ACCEPTED, decisively.** Frozen bar was >=2x over the streaming
incumbent at 1024^3 and 2048^3. Measured: 7.7x and 7.0x (5.6x at 512, 7.5x at
4096). In one rung INT8 went from the worst dtype in the table (11-17%% of
cuBLAS) to 83-86%% at large shapes -- and at 512-1024^3 it BEATS cuBLAS outright
(248%%, 131%%). `smem_stage=5` is now the INT8 default pick at every 64-multiple
shape. The rung-1 simplifications (unswizzled B gathers, direct s32 stores)
left that much on the table and still cleared the bar 3.5x over.

**v10: REJECTED -- tried-and-neutral; the depth ladder stops at 3.** Frozen bar
was clearing v9 with disjoint trials at BOTH >=2048 shapes. Measured: F16 ties
at both (+0.6%%, +1.2%%, ranges overlap); BF16 splits (-1.0%% at 2048, +1.4%%
disjoint at 4096). Run used 3 trials rather than 9, but at ~1%% deltas more
trials cannot manufacture a clear. FINDING: the 3rd stage bought +7%%, the 4th
bought noise -- two K-tiles of lookahead already hide what cp.async latency
there is to hide at these shapes. The remaining ~21%% gap to cuBLAS at 4096^3
is therefore NOT more pipeline depth; the next candidates are DRAM-efficiency
work (epilogue traffic, L2/tile swizzle) or algorithmic (split-K). v10 stays in
the tree as a correct, smoke-covered opt-in; v9 keeps the >=2048 pick.

**Pipeline picks (1.7.0):** F16/BF16 -- v7 (stage 5) <=1024, v9 (stage 7)
>=2048. INT8 -- stage 5 pipeline everywhere admissible. v8 = dynamic-smem
fallback; v10 = opt-in.

**Roadmap, reordered by the table:** (1) TF32 is now the worst dtype (18.6%% at
4096) -- give it the recipe (m16n8k8.tf32 fragments + the v7-class machinery).
(2) INT4 (m16n8k64.s4) -- same recipe, no in-process baseline (CUTLASS profiler
note). (3) 2:4 sparse pipeline (17-27%%). (4) batched-small (27%%). (5) the
v7<->v9 knee sweep (1280/1536/1792) + `pick_pipeline` dispatcher -- now also
routing INT8 to stage 5. (6) INT8 rung 2 (B-gather swizzle, staged epilogue)
if the 83-86%% large-shape number wants pushing toward its 131%% small-shape self.

---

## Addendum: 1.8.0-dev -- the recipe applied everywhere. Four rungs, GPU-free-verified, criteria FROZEN

The v7-class cp.async machinery (proven twice: F16 v7, INT8 rung 1) is applied
to every remaining slow surface, one kernel per rung, all emulator-gated before
silicon (emu_all.py now runs EIGHT gates, all bit-exact):

1. **TF32 pipeline** (`smem_stage=5` + TF32): m16n8k8.tf32 fragments,
   cvt.rna.tf32.f32 on every operand (cuBLAS-matching rounding), 64x64 block,
   BK=32, alpha/beta + batched-stride contract preserved. FROZEN bar: smoke
   PASS and >=2x the streaming TF32 kernel at >=1024^3.
2. **INT4 pipeline** (`smem_stage=5` + INT4): the streaming s4 kernel's
   silicon-proven m16n8k64 fragments (packed 2/byte) staged; BK=128,
   K %% 128 == 0. FROZEN bar: smoke PASS (exact int32) and >=2x streaming INT4
   at >=1024^3 (no external baseline; CUTLASS-profiler note stands).
3. **2:4 sparse pipeline** (`sparse=1` + `smem_stage=5`): the streaming mma.sp
   kernel's fragments + the HARDWARE-CONFIRMED 0.7.1 metadata layout, with
   A_vals + B cp.async-staged; metadata stays global (L2-resident). FROZEN
   bar: smoke PASS, >=2x streaming sparse, AND -- the bar that matters --
   beats cudez's OWN dense v9 dense-equivalent at >=2048^3; if 2:4 cannot beat
   dense, pruning buys nothing and the row says so.
4. **INT8 rung 2** (`smem_stage=5` + INT8 + `store_hint=1`): rung 1 + a 16 B
   chunk XOR swizzle on the B panel + a staged s32 epilogue with int4 stores.
   FROZEN bar: clears RUNG 1 (the incumbent) with disjoint trials at >=2048^3;
   a tie retires the idea and rung 1 keeps the slot (v10's precedent).

Emulator status: v8 / v9 / v10 / i8r1 / i8r2 / tf32 / i4 / sparse gates ALL
PASS bit-exact, including ring-safety, staging-collision, and swizzle
round-trip asserts. Smoke gains four rows (TF32 smem v7, INT4 smem v7,
INT8 smem v7r2, F16 sparse v7), all exact comparisons. Bench gains four rows
with baselines (TF32->cuBLAS, sparse->cuSPARSELt, i8r2->cuBLAS, INT4->none).

Deciding run: `TRIALS=9 SIZES="1024 2048 4096" ./cudez_runall.sh` -- one run
judges all four frozen bars. Version stays 1.7.0 until judged.

---

## Addendum: 1.8.0-dev r2 -- silicon abort root-caused; validator gate added

Run on the box: TF32 smem v7 **PASS** and INT4 smem v7 **PASS** on silicon
(two of four 1.8.0-dev bars half-met), then the INT8 rung-2 smoke ABORTED:
the validator still rejected `store_hint=1` at stage 5. Root cause: the
pass that was meant to relax that rule used an UNASSERTED text replace whose
pattern didn't match the file -- it silently no-op'd, and nothing in the
sandbox could notice because `emit` calls `cudez_mma_source()` directly,
BYPASSING the validator. Two fixes: (1) the store_hint and sparse-stage
rules are now actually relaxed (INT8@5+hint, sparse@5), with exact-match
edits; (2) `emit` now runs a **validator gate first** -- every pipeline
config checked against a synthetic sm_86 before anything else -- which
immediately caught the SECOND lurking disagreement (sparse@5 also rejected,
would have been the next abort). Tooling rule recorded: no unasserted
replaces, ever; the assert that "failed" during this fix is the mechanism
working. Remaining silicon debt: INT8 r2 + sparse v7 smoke rows, then the
four frozen bars.

---

## Addendum: run testall7_16_26 -- 1.8.0 PROMOTED. TF32 + INT4 ACCEPTED; INT8-r2 retired; sparse rung 1 supersedes streaming but the pruning bar is unmet

Smoke: EVERY row PASS -- all 20 kernels silicon-correct, including the mma.sp
pipeline (staged vals + hardware-confirmed metadata) and INT8 rung 2.

**TF32 pipeline: ACCEPTED** (2.02x/2.26x/3.21x streaming at 1024/2048/4096;
90.0% of cuBLAS at 1024, 58.7-62.3% at large -- against a ceiling that is
structurally half of F16). TF32's worst-dtype era is over: 18.2% -> 58.7%+.

**INT4 pipeline: ACCEPTED** (4.5x/5.2x/5.9x streaming; 20.75 TOPS peak at
2048 -- faster than INT8's 16.6, the 2x s4 rate showing through).

**INT8 rung 2: RETIRED (tried-and-negative).** Frozen bar was clearing rung 1
at >=2048 with disjoint trials; measured: r2 SLOWER by 2.1%/4.2% with r2's
entire trial range above r1's best. The swizzle + staged epilogue cost more
than the bank conflicts they removed at large shapes (r2 did win +3-5% at
<=1024 -- noted for a possible small-shape-only variant, not pursued now).
Rung 1 keeps the INT8 slot; store_hint=1 remains a correct opt-in.

**Sparse rung 1: split verdict.** It DOMINATES the streaming sparse kernel at
every shape (1.6-1.8x) and therefore becomes the sparse-lane pick -- but it
missed BOTH frozen bars: under 2x streaming, and it LOSES to dense v9
(13.78 vs 17.71 @2048; 13.22 vs 18.22 @4096). The pruning value proposition
("2:4 beats dense") is NOT yet earned by cudez; cuSPARSELt's 27-46 TF shows
where it lives: big-tile, deep-pipeline sparse kernels. Next sparse rung is
therefore the known recipe at the next scale: a v9-class 128-tile ring for
mma.sp. Until then the honest guidance stands: for raw speed run dense v9;
run sparse v7 only when the model is already 2:4-pruned.

**Picks (1.8.0):** F16/BF16 v7 <=1024, v9 >=2048; TF32/INT8/INT4 stage-5
pipeline everywhere admissible; sparse stage-5 within the sparse lane.
**Roadmap:** sparse v9-class ring (largest known-mechanism gap), then the
pick_pipeline dispatcher (now near-trivial), then batched-small.

---

## Addendum: 1.9.0-dev -- sparse v9-class ring + pick_pipeline dispatcher. Criteria FROZEN

**Sparse ring** (`sparse=1` + `smem_stage=7`): sparse rung 1's fragments and
hardware-confirmed metadata, scaled to the dense-v9 recipe -- 128x128 block,
16 warps, BK=32, 3-stage cp.async ring. Compressed A halves the panel, so the
whole ring is 44,544 B and fits STATIC smem (no dynamic-smem opt-in; the
launch path explicitly does NOT request v9's blob for sparse). Ring schedule
byte-identical to v9. Proven: emu_all.py sp-ring gate, bit-exact + write-once
+ ring-hazard asserts, 4 shapes incl. num_k < depth. Epilogue unchanged from
rung 1 -- the ring is this rung's one change.

**FROZEN sparse-ring bar:** accept iff (1) smoke "F16 sparse v9" PASS with
"F16 sparse v7" still PASS; (2) beats sparse v7 (in-lane incumbent) at 2048^3
AND 4096^3 with disjoint trials; (3) THE PRUNING BAR: beats dense v9's
dense-equivalent TFLOPS at >=2048^3. (2) without (3) -> it takes the sparse
lane, pruning claim stays unearned, and the next step is profiling, not
another blind rung. Neither -> tried-and-negative, rung 1 keeps the lane.

**Dispatcher** `cudez_mma_pick(dt, sparse, M, N, K)`: returns defaults with
the JUDGED pipeline for the shape (ledger 1.6.0-1.8.0): F16/BF16 v7<=small /
v9>=2048-class (KNEE PROVISIONAL at 2048 -- refine with a 1280/1536/1792
sweep, requested below); TF32/INT8/INT4 stage 5 where the contract admits;
sparse stage 5 (stage 7 pending verdict); graceful streaming fallback for
non-conforming shapes. A GPU-free pick-table gate now runs inside `emit`
alongside the validator gate. The dispatcher only ever hands out judged
winners: sparse ring and any future rung must earn their slot before
cudez_mma_pick will name them.

**Batched-small: deferred with reasons.** The 28%-of-cuBLAS batched gap is
NOT a pipeline problem: at 32x16-class shapes a single GEMM cannot fill the
GPU, and cuBLAS wins via specialized batched kernels that pack multiple
matrices per CTA. That is a new kernel FAMILY (multi-matrix tiling), not a
rung on this ladder -- it deserves its own design pass with its own emulator,
not a squeeze-in. Recorded as the top item after the sparse verdict.

### Box commands (deciding run)
```bash
./cudez_test smoke 0        # "F16 sparse v9" is the new row; all others stay green
TRIALS=9 SIZES="1024 2048 4096" ./cudez_runall.sh
# knee sweep for the dispatcher (any time, cheap):
TRIALS=9 ONLY=v7 SIZES="1280 1536 1792" ./cudez_runall.sh
TRIALS=9 ONLY=v9 SIZES="1280 1536 1792" ./cudez_runall.sh
```

---

## Addendum: run testall2 -- sparse-v9 in-lane verdict; a CLOCK ANOMALY caught; the batched discovery. 1.9.0-dev r2

**Run integrity first.** This run's F16-dense-family rows are corrupted by a
clock anomaly and were NOT used for judgment. Evidence: F16 smem v9 posted
10.68 TF at 4096 while BF16 smem v9 -- a byte-identical kernel but for the
retarget -- posted 18.29 in the SAME run, and F16 v9's own two prior primed
runs said 17.7-18.2. The anomaly window covers the F16 phase (rows run first)
and bleeds into TF32 (its 2048 row reads 5.29 vs 6.84 prior). INT8 / INT4 /
sparse / BF16 phases look clean. Interpretation: sustained-clock ramp or a
competing process early in the run. Consequence: any verdict comparing
against THIS run's F16 dense rows would be judging against a crippled
incumbent -- refused.

**Sparse v9 ring: in-lane ACCEPTED.** Same-run, same-conditions: 17.92 vs
sparse v7's 14.74 at 2048 (+21.6%) and 18.26 vs 13.90 at 4096 (+31.4%).
Sparse v9 takes the sparse lane; 57.6% / 65.6% of cuSPARSELt (up from
43.6% / 49.2%). **The PRUNING bar is NOT YET JUDGED:** against historical
committed-clock dense v9 (17.71 / 18.22), sparse v9 (17.92 / 18.26) is a
statistical tie, and this run's dense rows are inadmissible. Deciding A/B,
back-to-back so clocks are shared:
`TRIALS=9 ONLY=v9 SIZES="2048 4096" ./cudez_runall.sh && TRIALS=9 ONLY=sparsev9 SIZES="2048 4096" ./cudez_runall.sh`

**The batched discovery.** The "F16 batched x8" row (28.5-29.8% of cuBLAS,
the ONLY live pick in the 8-30% band) has been benching the STREAMING kernel
-- while v7 and v9 have carried strides + blockIdx.z batching natively since
they were written (verified in gen_v7.cu / gen_v9.cu). The "needs a new
kernel family" assessment was wrong for 512/1024-class batches; it remains
true only for genuinely tiny matrices. Two new rows measure the pipelines on
the same batch: "F16 batchd v7 x8" and "F16 batchd v9 x8". FROZEN bar
(matching the stated goal): the better of the two must reach >=50% of
cuBLAS strided-batched at 512^3 x8 AND 1024^3 x8; expectation is well above.

**League table (live picks, trustworthy numbers, large shapes):** INT8 93-96%
| F16/BF16 ~80-84% | sparse-vs-cuSPARSELt 58-66% | TF32 60-75% (2048 row
anomaly-tainted, re-judge) | batched 28.5% pending the new rows | INT4 no
baseline. Everything else in the 8-30% band is a superseded ladder rung the
dispatcher never selects.

---

## Addendum: run testall3 -- 1.9.0 PROMOTED. Batched ACCEPTED at 83-85%; sparse pruning bar judged NOT MET (tie, -2%)

Clean run (F16 v9 back at 17.86/18.39 -- last run's anomaly confirmed
transient, the identical-kernel BF16 cross-check was the right tell).

**Batched: ACCEPTED, pick = v7.** Frozen bar was >=50% at both shapes;
measured 85.3% (512^3 x8) and 82.7% (1024^3 x8), vs the streaming row's
29.3%/28.2% in the same run. v9-batched also clears (77-82%) but does not
beat v7. One wiring change took the last live 8-30% item to 83-85%: the
8-30% band is now EMPTY of live picks. Dispatcher unchanged (shape-based
pick already routes these to v7).

**Sparse pruning bar: JUDGED, NOT MET.** Same-run, clean clocks: sparse v9
17.49 vs dense v9 17.86 @2048 (-2.1%); 17.91 vs 18.39 @4096 (-2.6%);
loses slightly at every shape. Sparse v9 keeps the sparse lane (57-66% of
cuSPARSELt at 2048/4096) and the dispatcher now hands out stage 7 in-lane,
but "prune and win" remains unearned -- honestly recorded. The clean margin
(-2-3%, down from rung 1's -22%) plus the fact that mma.sp halves the mma
work says the kernel is NOT mma-bound: the prime suspect is the B side,
which sparsity does not compress (B smem traffic and bandwidth are
byte-identical to dense). Per the frozen text: the next step is PROFILING
(ncu: smem throughput + dram + mma pipe utilization, sparse v9 vs dense v9
side by side), not another blind rung. cuSPARSELt's 27-36 TF proves the
ceiling exists; the mechanism to reach it must be measured, not guessed.

**1.9.0 league table (live picks, large shapes):** INT8 87-90% (+252%/+132%
small) | F16 80-86% (v9; 104% @1024) | BF16 79-84% | batched 83-85% (v7) |
TF32 59-64% large, 82-90% small (ring port = next build) | sparse-lane
58-66% of cuSPARSELt | INT4 16-21 TOPS no baseline. Remaining under-80%:
TF32 large (known next rung) and the sparse-vs-cuSPARSELt gap (profiling
first). The 80-90%-of-cuBLAS flag now flies over INT8, F16@small/mid,
batched, and BF16 -- the CUDA Fortran campaign threshold is within sight.

---

## Addendum: 1.10.0-dev -- TF32 on the v9-class ring. Criteria FROZEN

`smem_stage=7` + TF32: the tf32 v7 pipeline scaled to the 128-tile 3-stage
ring. TF32's 4 B elements force BK=16 (two k8 steps per tile), making the
ring blob 56,832 B of dynamic smem -- numerically identical to dense v9's,
so the launch path grants it with no new size. v9 schedule byte-identical;
cvt.rna on all operands preserved; batched strides + blockIdx.z preserved.
Proven: emu_all.py tf32-ring gate (bit-exact + write-once + ring-hazard,
4 shapes incl. num_k < depth); validator gate + pick-table green.

**FROZEN bar:** accept iff (1) smoke "TF32 smem v9" PASS with "TF32 smem v7"
still PASS; (2) beats TF32 v7 at 2048^3 AND 4096^3 with disjoint trials.
Target band: 80-90% of cuBLAS TF32 at large shapes (v7 sits at 59-64%; the
v7->v9 jump bought F16 exactly this band). If accepted, the dispatcher's
TF32 branch gains the v9 pick for %128 shapes with K %% 16 == 0. A tie
means TF32's large-shape ceiling is not cp.async depth either -- and joins
the sparse ncu question as a profiling matter.

Deciding run: `TRIALS=9 SIZES="1024 2048 4096" ./cudez_runall.sh`
(plus the sparse ncu profile whenever convenient:
`ncu --set full -k regex:bench ./cudez_test bench 0 --only sparsev9 ...` vs
`--only v9` at 2048^3).

---

## Addendum: run 1784253394 -- 1.10.0 PROMOTED. TF32 ring ACCEPTED

Clean committed-clock run, 9 trials, all smoke green incl. the full K-ladder.
**TF32 ring vs v7, both frozen shapes, fully disjoint ranges:** 2048^3:
2.144 ms (2.142-2.146) vs 2.484 (2.483-2.485), +15.9%%; 4096^3: 17.769
(17.69-19.43) vs 21.431 (20.99-24.30), +20.6%%. ACCEPTED. Band: 71.4%% /
67.5%% of cuBLAS TF32 at 2048/4096 (from 63/56); v7 keeps <=1024 (89.7%%).
The throttled-run ratio extrapolation over-promised parity -- cross-regime
ratios do not transfer; recorded as a lesson. Dispatcher: TF32 gains the
ring for big %%128 shapes with K %% 16 == 0 -- the TF32 lane now mirrors
F16's v7/v9 split exactly. Remaining TF32 gap (to 80%%+) joins sparse in
the PROFILING queue: both stage-7 rings trail their ceilings by mechanisms
depth cannot buy; ncu decides the next rung for each. Ledger note: the
dispatch-order bug class now has a permanent mechanical gate (kernel
identity by opcode) after costing two silicon aborts.

---

## RE-VERSION: public release cudez 1.0.0 (2026-07-17)

The development ladder 0.x -> 1.10.0 is hereby re-baselined as **cudez
1.0.0**: every planned shape is silicon-proven -- all six dtype lanes (F16,
BF16, TF32, INT8, INT4, 2:4 sparse) on pipelined tensor cores, batching,
the pick_pipeline dispatcher, and the full GPU-free gate suite (10
emulators, validator, pick-table, kernel-identity). Internal ladder names
(v3..v10, rung letters) remain in comments and docs as the historical
record; the verdict ledger above IS the changelog of 0.x. From 1.0.0
forward, semver applies conventionally: PATCH = bug fixes, MINOR =
improvements/new kernels (sparse+TF32 profiling rungs, batched-tiny
family), MAJOR = breaking API. Named forward tracks: new-GPU compatibility
(sm_89/sm_90: validate fragment tables + smem caps per arch), native
Windows (MSVC C99 + driver-API paths; WSL2 is the proven baseline), and
the Fortran 2008 shim (in progress, user-led).

---

## 1.0.1 -- external analysis implemented (four bugs, one routing win)

An independent source-level analysis of 1.0.0 found four issues; all
verified against the tree and fixed:

**BUG-B (crash class, first per recommended order):** the float4/int4
vector-store alignment guard excluded INT8 rung 2, whose staged epilogue
does int4 stores -- a 4-B-aligned D passed validation and would fault.
Guard now covers (INT8 && store_hint==1).

**BUG-A (silent corruption at >=2^31 element offsets):** the streaming
dense/INT8/INT4/sparse kernels indexed A/B/C/D in 32-bit int; a 50k x 50k
GEMM on a large-memory GPU corrupts silently. Structurally uncatchable on
the 6 GB reference card. All streaming operand bases, stores, and warp_id
widened to 64-bit, mirroring the pipeline kernels. Regression-pinned in
the emit gate ("(long long)" casts asserted per file) -- which required
adding the streaming dense + streaming sparse kernels to the emit list at
all (a coverage hole), and the new missing-file check immediately caught
an expectation ordered before its emit. Gates catching gate bugs: working
as designed.

**Option A (largest user-facing win):** cudez_gemm built the STREAMING
kernel for every shape -- casual users paid 5-8x for kernels the library
had already beaten. The one-call path now routes through cudez_mma_pick
with the correct warp count per stage.

**BUG-C (bench methodology, acknowledged not yet fixed in code):** phase-A/
phase-B ordering under chassis heat-soak inflates %%cuBLAS on long runs and
the >100%% small-shape figures are UNCONFIRMED until re-measured
interleaved. The ABAB per-row restructure is queued as the next harness
MINOR; until then published figures carry this caveat, and the per-trial
clock join the analysis suggests is possible from existing CSVs.

**BUG-D:** gpumon now clamps sensor-artifact power samples (>200 W on an
85 W part; WSL2 driver artifact).

---

## 1.0.2 -- second external audit implemented (harness-driven, 946-shape sweep)

All findings verified; fixed in the audit's own priority order:

**BUG-2 (silent wrong data, P1):** requant_mode x smem_stage=5 validated but
the pipelined INT8/INT4 kernels have no requant epilogue -- callers
following the docs read s32 bits as float. Validator now rejects the combo
with a named message; a pipeline requant epilogue is a roadmap MINOR.

**BUG-1 (cudez_gemm regression, P2):** the dispatcher's stage-4 branch was
gated K%32 but v6's launch contract is K%64 (same as v7) -- so it fired
ONLY for shapes v6 rejects, and after 1.0.1's Option A routing, legal
shapes (64x64x96...) errored in the friendliest entry point. An audit of
my own audit implementation: Option A shipped without sweeping the pick
table against launch contracts; this auditor's 946-shape harness did
exactly that sweep. Branch deleted (falls to streaming, as the
dispatcher's doc always promised) + pick-table regression pin added.

**Landmine-1 (P3):** every cudez_try_boot failure path now memsets *out to
zero -- the doc's promise, and the end of the NO_ABORT double-destroy.

**BUG-3 (P4):** launch and occupancy disagreed on sparse-v9 dynamic smem
(0 vs 56,832 B). One shared helper cudez_mma_dyn_smem_() now feeds both
sites -- the single source of truth the macro comment always claimed.

**Hygiene (P5):** the file-top banner now cites the version macros as the
single truth (stale "0.7.0" line removed; historical banners kept as
provenance). Overlength template literals (7 templates > C99's 4,095-char
minimum) are ACKNOWLEDGED and deferred to the MSVC/pedantic compatibility
track -- splitting static templates is invasive and belongs with that
work, not a patch release.

**Deferred with thanks (roadmap):** const-cast registry mutation, teardown
stream-sync, CUDA-12 graph floor note, cache generation counter, NULL-C
batch strides, NVRTC include truncation check, arena absolute alignment,
zero-size buffer refusal, boot attribute-failure checks; optimizations
(build-time smem opt-in hoist, 3x compress sort, per-TU gemm cache,
cudez_log_ migration). The audit also confirmed non-findings worth
keeping: 16 KB build buffer ample (max source 8,356 B), zero format-string
defects across all 82 configs, and the TF32-ring smem/V9_DYN_SMEM
coincidence correct-not-collision.

---

## 1.0.3 -- deferred-item sweep + BUG-C harness restructure + one experimental rung

No GPU access this pass -- everything below is verified in-sandbox (syntax
checks against the gstub driver-API stubs, the GPU-free emu_all.py
gates, `emit`/`retarget`, and standalone host-logic tests where the
change was pure host code). Real-hardware confirmation is still owed on
every item; nothing here should be taken as ledger-grade until re-run on
a box.

**Correctness (deferred items closed):**
- **Teardown stream-sync:** cudez_teardown now cuCtxSynchronize()s (making
  cz->context current first, restoring the caller's previous context
  after) before freeing/unloading/destroying anything -- closes the gap
  where in-flight async work on cz->stream or a registered stream could
  be freed out from under it.
- **NULL C batch strides:** sC now forces to 0 whenever beta==0, matching
  the "C read only if beta != 0" contract cudez_mma_launch's own alignment
  guard already assumed -- closes UB pointer arithmetic (Cin + stride) on
  a null C base in batched beta=0 calls.
- **Zero-size buffer refusal:** cudez_buffer_new(cz, 0) now returns an
  empty buffer ({0,0}) instead of calling cuMemAlloc(&p, 0), which the
  driver always refuses -- closes an abort() with no context on what's
  usually an upstream size-calc landing on 0. cudez_read/_write_async/
  _read_async gained a matching ptr==0-with-bytes>0 refusal, since the
  fix made an empty buffer indistinguishable from a "size unknown, trust
  the caller" one to the existing size check.
- **Boot attribute-failure checks:** cuDeviceGetName failure is now loud
  but non-fatal (cosmetic only). cuDeviceGetAttribute (compute capability)
  failure now FAILS boot outright -- a silent failure previously left
  cc=0, under which the sm_90+ sparse refusal (cc>=90) can never fire on
  real Hopper/Blackwell hardware.
- **Requant-epilogue guard closed at the source layer:** cudez_mma_cfg_valid_
  already rejected requant_mode!=NONE + smem_stage=5 for INT8/INT4, but
  cudez_mma_source() is a public introspection entry (and what `emit`
  calls) that bypasses that validator. It now carries the same guard
  directly, so a caller can no longer get back well-formed C source for a
  pipelined INT8/INT4 kernel that silently ignores requant_mode (that
  kernel's signature has no scale/zero_point at all).
- **CUDA-12 graph floor note (doc-only):** cuGraphInstantiate's 3-arg call
  was already the correct CUDA 12+ form; added the version-floor comment
  explaining why building against 11.x fails that line, so a future edit
  doesn't "fix" it back to the 5-arg _v2 form and break every 12+ caller.
- **Cache generation counter:** cudez_mma_cache entries now carry a
  boot_gen alongside CUcontext; a hit requires both to match. Closes the
  gap where the driver API does not guarantee a destroyed context's
  handle value is never reused by a later cuCtxCreate -- pointer equality
  alone couldn't tell "same context" from "different context, same
  recycled pointer."
- **Const-cast registry mutation:** reviewed, left as-is. The 1.0.2
  disposition holds: only UB if the cudez is truly const, which nothing
  in this codebase ever does; a real fix means changing several public
  signatures (const cudez* -> cudez*), API-breaking and out of scope here.

**BUG-C (bench methodology) -- both halves done:**
- Smaller step first: the harness now self-samples SM clock/power/temp
  (same nvidia-smi fields cudez_gpumon.sh already used) at phase
  boundaries and reports drift directly in bench output, no external
  cross-referencing required.
- Full restructure: phase_cudez/phase_cublas's per-row bodies factored
  into bench_row_cudez_/bench_row_cublas_ (logic unchanged, byte-for-byte)
  and driven by a new phase_abab that boots cudez once, creates the
  cuBLAS handle/buffers once, and interleaves per ROW -- cudez's trials
  immediately followed by cuBLAS's trials for the SAME shape, instead of
  two full separately-scoped passes. Confirmed safe to keep both backends'
  contexts live simultaneously (CUDA's own docs: runtime API calls on a
  thread operate on whatever non-primary CUcontext is current there, and
  cudez_boot's cuCtxCreate makes cz's context current and never pops it).
  The old phase_cudez/phase_cublas wrappers were deleted rather than kept
  as unreachable "for standalone use" dead code, since nothing actually
  called them once phase_abab existed.

**Experimental (UNVERIFIED, dev branch only):** sparse v9's A-staging loop
bound (256) was HALF of blockDim.x (512, 16 warps), so 256 of 512 threads
sat idle the whole time A staged, then all 512 worked during B's stage;
dense v9 has no such gap (its A-stage bound equals blockDim.x exactly).
Byte-count math confirms the doc's "uncompressed B, byte-identical to
dense" claim (8192 B either kernel) but also shows sparse's TOTAL per-stage
traffic is 25% LESS than dense's (12,288 vs 16,384 B) -- so raw B-side
bytes alone can't be the whole story, and the idle-warp gap is a second,
previously undocumented candidate. Rebalanced: A (256 el) and B (512 el)
merged into one flat 768-element grid-stride loop across all 512 threads,
verified by construction to produce the exact same 256+512 destinations as
the original two loops (checked computationally, not just by inspection).
Passes the sp-ring emulator gate, but that gate models data placement, not
thread scheduling, and structurally cannot confirm this helps wall-clock
time. Marked UNVERIFIED in the kernel's own doc comment; needs ncu or even
just an A/B wall-clock run before promotion past this dev branch -- do not
treat this as validating the "prune and win" bar sparse v9 has not yet
earned.

