#ifndef CUBLAS_V2_STUB
#define CUBLAS_V2_STUB
#ifndef CUDA_R_16F
#define CUDA_R_16F 0
#define CUDA_R_32F 1
#define CUDA_R_16BF 2
#define CUDA_R_8I 3
#define CUDA_R_32I 4
#endif
typedef void* cublasHandle_t;
typedef int cublasStatus_t;
#define CUBLAS_STATUS_SUCCESS 0
#define CUBLAS_STATUS_NOT_SUPPORTED 15
#define CUBLAS_OP_N 0
#define CUBLAS_GEMM_DEFAULT_TENSOR_OP 0
#define CUBLAS_COMPUTE_32F 0
#define CUBLAS_COMPUTE_32I 1
#define cublasCreate(...) ((cublasStatus_t)0)
#define cublasDestroy(...) ((cublasStatus_t)0)
#define cublasGemmEx(...) ((cublasStatus_t)0)
#define cublasGemmStridedBatchedEx(...) ((cublasStatus_t)0)
#endif
