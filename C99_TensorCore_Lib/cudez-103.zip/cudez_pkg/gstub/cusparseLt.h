#ifndef CUSPARSELT_STUB
#define CUSPARSELT_STUB
#ifndef CUDA_R_16F
#define CUDA_R_16F 0
#define CUDA_R_32F 1
#define CUDA_R_16BF 2
#define CUDA_R_8I 3
#define CUDA_R_32I 4
#endif
#include <stddef.h>
typedef int cusparseStatus_t;
typedef void* cusparseLtHandle_t;   /* handle used via pointer */
typedef struct { long _[32]; } cusparseLtMatDescriptor_t;
typedef struct { long _[32]; } cusparseLtMatmulDescriptor_t;
typedef struct { long _[32]; } cusparseLtMatmulAlgSelection_t;
typedef struct { long _[32]; } cusparseLtMatmulPlan_t;
typedef int cusparseLtComputetype_t;
#define CUSPARSE_STATUS_SUCCESS 0
#define CUSPARSE_ORDER_ROW 0
#define CUSPARSE_OPERATION_NON_TRANSPOSE 0
#define CUSPARSE_COMPUTE_32F 0
#define CUSPARSELT_SPARSITY_50_PERCENT 0
#define CUSPARSELT_MATMUL_ALG_DEFAULT 0
#define CUSPARSELT_MATMUL_ALG_CONFIG_ID 0
#define CUSPARSELT_MATMUL_SPLIT_K 1
#define CUSPARSELT_MATMUL_SPLIT_K_MODE 2
#define CUSPARSELT_PRUNE_SPMMA_TILE 0
#define cusparseLtInit(...) ((cusparseStatus_t)0)
#define cusparseLtDestroy(...) ((cusparseStatus_t)0)
#define cusparseLtStructuredDescriptorInit(...) ((cusparseStatus_t)0)
#define cusparseLtDenseDescriptorInit(...) ((cusparseStatus_t)0)
#define cusparseLtMatDescriptorDestroy(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulDescriptorInit(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulAlgSelectionInit(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulAlgGetAttribute(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulPlanInit(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulPlanDestroy(...) ((cusparseStatus_t)0)
#define cusparseLtMatmulGetWorkspace(...) ((cusparseStatus_t)0)
#define cusparseLtSpMMAPrune(...) ((cusparseStatus_t)0)
#define cusparseLtSpMMAPruneCheck(...) ((cusparseStatus_t)0)
#define cusparseLtSpMMACompressedSize(...) ((cusparseStatus_t)0)
#define cusparseLtSpMMACompress(...) ((cusparseStatus_t)0)
#define cusparseLtMatmul(...) ((cusparseStatus_t)0)
#endif
