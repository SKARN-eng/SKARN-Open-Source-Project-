#ifndef CUDA_FP16_STUB
#define CUDA_FP16_STUB
typedef unsigned short __half;
#define __float2half(x) ((__half)(x))
#define __half2float(x) ((float)(x))
#endif
