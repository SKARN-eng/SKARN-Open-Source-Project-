#ifndef CUDA_BF16_STUB
#define CUDA_BF16_STUB
typedef unsigned short __nv_bfloat16;
#define __float2bfloat16(x) ((__nv_bfloat16)(x))
#define __bfloat162float(x) ((float)(x))
#endif
