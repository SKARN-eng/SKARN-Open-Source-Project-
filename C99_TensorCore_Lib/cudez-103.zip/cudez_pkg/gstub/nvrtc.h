#ifndef NVRTC_H_STUB
#define NVRTC_H_STUB
typedef enum { NVRTC_SUCCESS=0, NVRTC_ERROR=1 } nvrtcResult;
typedef void* nvrtcProgram;
#define nvrtcCreateProgram(...) ((nvrtcResult)0)
#define nvrtcDestroyProgram(...) ((nvrtcResult)0)
#define nvrtcCompileProgram(...) ((nvrtcResult)0)
#define nvrtcGetPTX(...) ((nvrtcResult)0)
static inline nvrtcResult cudez_stub_ptxsize_(void *prog, size_t *out) {
    (void)prog; *out = 1; return (nvrtcResult)0;
}
#define nvrtcGetPTXSize(prog, pout) cudez_stub_ptxsize_(prog, pout)
#define nvrtcGetProgramLog(...) ((nvrtcResult)0)
#define nvrtcGetProgramLogSize(...) ((nvrtcResult)0)
#define nvrtcGetLoweredName(...) ((nvrtcResult)0)
#define nvrtcGetErrorString(...) ("stub")
#endif
