#ifndef CUDA_RUNTIME_STUB
#define CUDA_RUNTIME_STUB
#ifndef CUDA_R_16F
#define CUDA_R_16F 0
#define CUDA_R_32F 1
#define CUDA_R_16BF 2
#define CUDA_R_8I 3
#define CUDA_R_32I 4
#endif
#include <stddef.h>
typedef int cudaError_t;
typedef void* cudaStream_t;
typedef void* cudaEvent_t;
#define cudaSuccess 0
#define cudaMemcpyHostToDevice 1
#define cudaMemcpyDeviceToHost 2
#define cudaSetDevice(...) ((cudaError_t)0)
#define cudaDeviceSynchronize(...) ((cudaError_t)0)
#define cudaMalloc(...) ((cudaError_t)0)
#define cudaFree(...) ((cudaError_t)0)
#define cudaMemcpy(...) ((cudaError_t)0)
#define cudaEventCreate(...) ((cudaError_t)0)
#define cudaEventRecord(...) ((cudaError_t)0)
#define cudaEventSynchronize(...) ((cudaError_t)0)
#define cudaEventElapsedTime(...) ((cudaError_t)0)
#define cudaEventDestroy(...) ((cudaError_t)0)
#define cudaGetErrorString(...) ("stub")
#endif
