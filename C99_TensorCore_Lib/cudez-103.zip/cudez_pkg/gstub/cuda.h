#ifndef CUDA_H_STUB
#define CUDA_H_STUB
#include <stddef.h>
typedef unsigned long long CUdeviceptr;
typedef int CUdevice;
typedef void* CUcontext; typedef void* CUmodule; typedef void* CUfunction;
typedef void* CUstream; typedef void* CUevent; typedef void* CUgraph; typedef void* CUgraphExec;
typedef enum { CUDA_SUCCESS=0, CUDA_ERROR_INVALID_VALUE=1, CUDA_ERROR_OUT_OF_MEMORY=2,
  CUDA_ERROR_NO_DEVICE=100, CUDA_ERROR_NOT_SUPPORTED=801, CUDA_ERROR_UNKNOWN=999 } CUresult;
#define CU_CTX_SCHED_AUTO 0
#define CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR 76
#define CU_MEMHOSTALLOC_PORTABLE 1
#define CU_STREAM_CAPTURE_MODE_GLOBAL 0
#define CU_STREAM_DEFAULT 0
#define cuInit(...) ((CUresult)0)
#define cuDeviceGet(...) ((CUresult)0)
#define cuDeviceGetCount(...) ((CUresult)0)
#define cuDeviceGetName(...) ((CUresult)0)
#define cuDeviceGetAttribute(...) ((CUresult)0)
#define cuCtxCreate(...) ((CUresult)0)
#define cuCtxDestroy(...) ((CUresult)0)
#define cuCtxGetCurrent(...) ((CUresult)0)
#define cuCtxSetCurrent(...) ((CUresult)0)
#define cuCtxSynchronize(...) ((CUresult)0)
#define cuModuleLoadDataEx(...) ((CUresult)0)
#define cuModuleGetFunction(...) ((CUresult)0)
#define cuModuleUnload(...) ((CUresult)0)
#define cuLaunchKernel(...) ((CUresult)0)
#define cuMemAlloc(...) ((CUresult)0)
#define cuMemFree(...) ((CUresult)0)
#define cuMemHostAlloc(...) ((CUresult)0)
#define cuMemFreeHost(...) ((CUresult)0)
#define cuMemcpyHtoD(...) ((CUresult)0)
#define cuMemcpyDtoH(...) ((CUresult)0)
#define cuMemcpyHtoDAsync(...) ((CUresult)0)
#define cuMemcpyDtoHAsync(...) ((CUresult)0)
#define cuStreamCreate(...) ((CUresult)0)
#define cuStreamDestroy(...) ((CUresult)0)
#define cuStreamSynchronize(...) ((CUresult)0)
#define cuStreamBeginCapture(...) ((CUresult)0)
#define cuStreamEndCapture(...) ((CUresult)0)
#define cuEventDestroy(...) ((CUresult)0)
#define cuGraphInstantiate(...) ((CUresult)0)
#define cuGraphLaunch(...) ((CUresult)0)
#define cuGraphDestroy(...) ((CUresult)0)
#define cuGraphExecDestroy(...) ((CUresult)0)
#define cuOccupancyMaxActiveBlocksPerMultiprocessor(...) ((CUresult)0)
#define cuGetErrorName(...) ((CUresult)0)
#define cuGetErrorString(...) ((CUresult)0)
#define CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES 8
#define cuFuncSetAttribute(...) ((CUresult)0)
#define CU_EVENT_DEFAULT 0
#define cuEventCreate(...) ((CUresult)0)
#define cuEventRecord(...) ((CUresult)0)
#define cuEventSynchronize(...) ((CUresult)0)
#define cuEventElapsedTime(...) ((CUresult)0)
#endif
