/* cudez_test.c -- cudez 1.1.0 unified verification + benchmark harness.
 *
 * ONE translation unit, ONE binary, three subcommands -- the 0.9.0 cycle's
 * three separate tools (verify_pipeline_asm.c, smoke_mma_gpu.c,
 * bench_mma_gpu.c) merged so a release drop is one source file to version
 * and one compile line to get right. It also retires the 0.9.0 field
 * incident where reused -o targets produced a bench binary that was
 * secretly the verifier -- there is now exactly one binary.
 *
 *   ./cudez_test verify [incdir]        GPU-free NVRTC compile gate over the
 *                                       generated v3/v4/v4h/v5/v5h kernels via
 *                                       the public cudez_mma_source() path
 *                                       (writes gen_*.cu + gen_*.ptx; run
 *                                       ptxas -arch=sm_86 -v on the .ptx
 *                                       yourself for the assemble half).
 *                                       incdir defaults to /usr/include;
 *                                       set CRT_INC too if crt/mma.h lives
 *                                       elsewhere.
 *   ./cudez_test smoke  [device]        REAL-HARDWARE numerical gates: every
 *                                       kernel diffed against a CPU
 *                                       reference. Green here is the
 *                                       precondition for any bench number.
 *   ./cudez_test bench  [device] [...]  performance record (harness v2.2):
 *                                       --only f16|smem|v4|v4h|v5|v5h|v6|v7|v8|
 *                                              bf16|bf16v7|bf16v8|bf16v9|bf16v10|tf32|int8|int8v7|int4|sparse|batched
 *                                       --size 512|1024|2048|4096
 *                                       --trials T   --csv FILE
 *   ./cudez_test all    [device] [...]  verify (default incdir), then smoke,
 *                                       then bench with the remaining args;
 *                                       stops at the first failing stage,
 *                                       same as `verify && smoke && bench`.
 *
 * Subcommand data isolation: the shared LCG is re-seeded at the top of each
 * subcommand, so `cudez_test smoke` inside an `all` run sees byte-identical
 * operands to a standalone `cudez_test smoke` -- numbers stay comparable
 * with the 0.8.0/0.9.0 records made by the standalone tools.
 *
 * Build (C++ compiler; NVIDIA's fp16/bf16 host intrinsics are C++-only,
 * cudez.h itself stays C99):
 *   g++ -O2 cudez_test.c -o cudez_test \
 *       -I"$CUSPARSELT_DIR/include" -L"$CUSPARSELT_DIR/lib" \
 *       -lcuda -lnvrtc -lcudart -lcublas -lcusparse -lcusparseLt \
 *       -Wl,-rpath,"$CUSPARSELT_DIR/lib"
 *
 * No cuSPARSELt tarball on the machine? Build without the sparse baseline
 * (every other row and baseline still runs; the sparse rows lose only
 * their cuSPARSELt column):
 *   g++ -O2 -DCUDEZ_TEST_NO_CUSPARSELT cudez_test.c -o cudez_test \
 *       -lcuda -lnvrtc -lcudart -lcublas
 * Run with CUDEZ_NVRTC_INCLUDE exported if your NVRTC needs it (Debian:
 * /usr/include). See cudez.h 0.7.1 notes.
 */
#include "cudez.h"
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>
#ifndef CUDEZ_TEST_NO_CUSPARSELT
#include <cusparseLt.h>
#endif
#include <time.h>
#include <cstdlib>

/* deterministic small-integer operands (exactly representable in fp16 and in
   the int4 range), so references are exact and mismatches mean real bugs.
   Re-seeded per subcommand (see header comment). */
static unsigned g_lcg = 2463534242u;
static int rnd_range(int lo, int hi) {
    g_lcg ^= g_lcg << 13; g_lcg ^= g_lcg >> 17; g_lcg ^= g_lcg << 5;
    return lo + (int)(g_lcg % (unsigned)(hi - lo + 1));
}
static void lcg_reset(void) { g_lcg = 2463534242u; }

/* ==========================================================================
 * Subcommand: verify -- GPU-free NVRTC compile gate (was verify_pipeline_asm.c)
 * ==========================================================================
 * Generates the pipeline v3 (smem_stage=1), v4 (smem_stage=2), v4h
 * (smem_stage=2 + store_hint=1, rung (h)), v5 (smem_stage=3, rung (i)),
 * v5h (both rungs composed) and v6 (smem_stage=4, rung (b): raw
 * ldmatrix + mma.sync inner loop) sources through
 * the PUBLIC cudez_mma_source() introspection entry (no driver/context
 * needed), compiles each under real NVRTC for compute_86, and writes the
 * PTX for real ptxas (run separately). This is the same "compiles under
 * real NVRTC and assembles under real ptxas" rung the 0.8.0/0.9.0 ledgers
 * used before hardware smoke -- it is NOT a numerical PASS. */
static int verify_emit_and_compile(int stage, int hint, const char *name,
                                   const char *cufile, const char *ptxfile,
                                   const char *incdir) {
    static char src[32768];
    cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
    cfg.smem_stage = stage;
    cfg.store_hint = hint;
    if (!cudez_mma_source(&cfg, name, src, sizeof src)) {
        printf("[stage=%d hint=%d] source generation FAILED (buffer?)\n", stage, hint);
        return 1;
    }
    printf("[stage=%d hint=%d] generated %zu bytes of CUDA source -> %s\n",
           stage, hint, strlen(src), cufile);
    { FILE *f = fopen(cufile, "w"); fputs(src, f); fclose(f); }

    nvrtcProgram prog;
    if (nvrtcCreateProgram(&prog, src, "cudez_mma.cu", 0, NULL, NULL) != NVRTC_SUCCESS) {
        printf("[stage=%d hint=%d] nvrtcCreateProgram failed\n", stage, hint); return 1;
    }
    char inc[600], inc2[600];
    snprintf(inc, sizeof inc, "--include-path=%s", incdir);
    snprintf(inc2, sizeof inc2, "--include-path=%s", getenv("CRT_INC") ? getenv("CRT_INC") : incdir);
    const char *opts[3] = { "--gpu-architecture=compute_86", inc, inc2 };
    nvrtcResult cr = nvrtcCompileProgram(prog, 3, opts);
    size_t logsz = 0; nvrtcGetProgramLogSize(prog, &logsz);
    if (logsz > 1) {
        char *log = (char *)malloc(logsz);
        nvrtcGetProgramLog(prog, log);
        printf("[stage=%d hint=%d] NVRTC log:\n%s\n", stage, hint, log);
        free(log);
    }
    if (cr != NVRTC_SUCCESS) {
        printf("[stage=%d hint=%d] NVRTC compile FAILED\n", stage, hint);
        nvrtcDestroyProgram(&prog); return 1;
    }
    size_t ptxsz = 0; nvrtcGetPTXSize(prog, &ptxsz);
    char *ptx = (char *)malloc(ptxsz);
    nvrtcGetPTX(prog, ptx);
    { FILE *f = fopen(ptxfile, "w"); fwrite(ptx, 1, ptxsz - 1, f); fclose(f); }
    printf("[stage=%d hint=%d] NVRTC compile OK (%zu bytes PTX) -> %s\n", stage, hint, ptxsz, ptxfile);
    free(ptx);
    nvrtcDestroyProgram(&prog);
    return 0;
}

/* GPU-free NVRTC gate for the integer (INT8/INT4) dense path -- same compile
   pipeline as verify_emit_and_compile, config driven by dtype instead of stage. */
static int verify_emit_int(cudez_mma_dtype dtype, const char *name, const char *cufile,
                           const char *ptxfile, const char *incdir) {
    static char src[32768];
    cudez_mma_config cfg = cudez_mma_defaults(dtype);
    if (!cudez_mma_source(&cfg, name, src, sizeof src)) {
        printf("[dtype=%d] source generation FAILED (buffer?)\n", dtype); return 1;
    }
    printf("[dtype=%d] generated %zu bytes of CUDA source -> %s\n", dtype, strlen(src), cufile);
    { FILE *f = fopen(cufile, "w"); fputs(src, f); fclose(f); }
    nvrtcProgram prog;
    if (nvrtcCreateProgram(&prog, src, "cudez_mma.cu", 0, NULL, NULL) != NVRTC_SUCCESS) {
        printf("[dtype=%d] nvrtcCreateProgram failed\n", dtype); return 1;
    }
    char inc[600], inc2[600];
    snprintf(inc, sizeof inc, "--include-path=%s", incdir);
    snprintf(inc2, sizeof inc2, "--include-path=%s", getenv("CRT_INC") ? getenv("CRT_INC") : incdir);
    const char *opts[3] = { "--gpu-architecture=compute_86", inc, inc2 };
    nvrtcResult cr = nvrtcCompileProgram(prog, 3, opts);
    size_t logsz = 0; nvrtcGetProgramLogSize(prog, &logsz);
    if (logsz > 1) { char *log = (char *)malloc(logsz); nvrtcGetProgramLog(prog, log);
                     printf("[dtype=%d] NVRTC log:\n%s\n", dtype, log); free(log); }
    if (cr != NVRTC_SUCCESS) { printf("[dtype=%d] NVRTC compile FAILED\n", dtype);
                               nvrtcDestroyProgram(&prog); return 1; }
    size_t ptxsz = 0; nvrtcGetPTXSize(prog, &ptxsz);
    char *ptx = (char *)malloc(ptxsz); nvrtcGetPTX(prog, ptx);
    { FILE *f = fopen(ptxfile, "w"); fwrite(ptx, 1, ptxsz - 1, f); fclose(f); }
    printf("[dtype=%d] NVRTC compile OK (%zu bytes PTX) -> %s\n", dtype, ptxsz, ptxfile);
    free(ptx); nvrtcDestroyProgram(&prog);
    return 0;
}

static int verify_main(int argc, char **argv) {
    const char *incdir = argc > 1 ? argv[1] : "/usr/include";
    int rc = 0;
    rc |= verify_emit_and_compile(1, 0, "gemm_v3",  "gen_v3.cu",  "gen_v3.ptx",  incdir);
    rc |= verify_emit_and_compile(2, 0, "gemm_v4",  "gen_v4.cu",  "gen_v4.ptx",  incdir);
    rc |= verify_emit_and_compile(2, 1, "gemm_v4h", "gen_v4h.cu", "gen_v4h.ptx", incdir);
    rc |= verify_emit_and_compile(3, 0, "gemm_v5",  "gen_v5.cu",  "gen_v5.ptx",  incdir);
    rc |= verify_emit_and_compile(3, 1, "gemm_v5h", "gen_v5h.cu", "gen_v5h.ptx", incdir);
    rc |= verify_emit_and_compile(4, 0, "gemm_v6",  "gen_v6.cu",  "gen_v6.ptx",  incdir);
    rc |= verify_emit_and_compile(5, 0, "gemm_v7",  "gen_v7.cu",  "gen_v7.ptx",  incdir);
    rc |= verify_emit_and_compile(6, 0, "gemm_v8",  "gen_v8.cu",  "gen_v8.ptx",  incdir);
    rc |= verify_emit_int(CUDEZ_MMA_INT8, "gemm_i8", "gen_i8.cu", "gen_i8.ptx", incdir);
    rc |= verify_emit_int(CUDEZ_MMA_INT4, "gemm_i4", "gen_i4.cu", "gen_i4.ptx", incdir);
    return rc;
}

/* ==========================================================================
 * Subcommand: smoke -- real-hardware numerical gates (was smoke_mma_gpu.c)
 * ========================================================================== */
/* ---------------------------------------------------------------- F16 dense */
static int test_f16(cudez *cz) {
    const int M = 32, N = 32, K = 64;   /* M%16==0, N%16==0, K%16==0 */
    int m, n, k, bad = 0;
    float *Af = (float*)malloc(sizeof(float) * M * K);
    float *Bf = (float*)malloc(sizeof(float) * K * N);
    __half *Ah = (__half*)malloc(sizeof(__half) * M * K);
    __half *Bh = (__half*)malloc(sizeof(__half) * K * N);
    float *Dg = (float*)malloc(sizeof(float) * M * N);
    float *Zero = (float*)calloc((size_t)M * N, sizeof(float));

    for (k = 0; k < M * K; k++) { Af[k] = (float)rnd_range(-4, 4); Ah[k] = __float2half(Af[k]); }
    for (k = 0; k < K * N; k++) { Bf[k] = (float)rnd_range(-4, 4); Bh[k] = __float2half(Bf[k]); }
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_f16");
        cudez_buffer dA = cudez_buffer_write(cz, Ah,  sizeof(__half) * M * K);
        cudez_buffer dB = cudez_buffer_write(cz, Bh,  sizeof(__half) * K * N);
        cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float) * M * N);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(float) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  F16 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __half2float(Ah[m*K+k]) * __half2float(Bh[k*N+n]);
                if (fabsf(Dg[m*N+n] - acc) > 0.5f) {
                    printf("  F16 mismatch at (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); bad++;
                }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ah); free(Bh); free(Dg); free(Zero);
    printf("F16  dense       (%dx%dx%d): %s\n", M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* ------------------------------------------- F16 smem pipelines (0.8.0-0.10.0)
 * Numerical gate shared by cfg.smem_stage=1 (pipeline v3), =2 (pipeline
 * v4, cp.async double buffering) and =2 + store_hint=1 (v4h, the 0.10.0
 * evict-first epilogue): 128x128xK forces a 2x2 grid of 64x64
 * block-tiles (multi-block correctness), each block being 2x2 warps x 2x2
 * register-blocked WMMA tiles. K per stage: v3 runs K=128 (two BK=64
 * stages, the 0.8.0 gate unchanged); v4/v4h run K=192 (THREE stages)
 * deliberately -- with only two stages the double buffer never wraps, so
 * a ping-pong/restage bug would pass a K=128 gate and silently corrupt
 * every longer K. beta is a parameter because v4h's epilogue is NEW code
 * with two branches: beta!=0 exercises the read-C-add path across all
 * four per-warp tiles, beta==0 the pure-store path -- the v4h gate runs
 * BOTH (v3/v4 keep their historical beta=1 gate byte-for-byte). Also
 * asserts the three launch rejections (warps!=4; M not %64; K not %64). */
static int test_f16_smem_stage(cudez *cz, int stage, int store_hint, int M, int K,
                               float beta, const char *tag) {
    const int N = 128;
    int m, n, k, bad = 0;
    float *Af = (float*)malloc(sizeof(float) * M * K);
    float *Bf = (float*)malloc(sizeof(float) * K * N);
    __half *Ah = (__half*)malloc(sizeof(__half) * M * K);
    __half *Bh = (__half*)malloc(sizeof(__half) * K * N);
    float *Cf = (float*)malloc(sizeof(float) * M * N);
    float *Dg = (float*)malloc(sizeof(float) * M * N);

    for (k = 0; k < M * K; k++) { Af[k] = (float)rnd_range(-4, 4); Ah[k] = __float2half(Af[k]); }
    for (k = 0; k < K * N; k++) { Bf[k] = (float)rnd_range(-4, 4); Bh[k] = __float2half(Bf[k]); }
    for (k = 0; k < M * N; k++) Cf[k] = (float)rnd_range(-4, 4);
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm;
        cfg.smem_stage = stage;
        cfg.store_hint = store_hint;
        mm = cudez_mma_build(cz, &cfg,
                             stage == 8 ? "smoke_f16_smem_v10" :
                             stage == 7 ? "smoke_f16_smem_v9" :
                             stage == 6 ? "smoke_f16_smem_v8" :
                             stage == 5 ? "smoke_f16_smem_v7" :
                             stage == 4 ? "smoke_f16_smem_v6" :
                             stage == 3 ? (store_hint ? "smoke_f16_smem_v5h" : "smoke_f16_smem_v5") :
                             store_hint ? "smoke_f16_smem_v4h" :
                             stage == 2 ? "smoke_f16_smem_v4" : "smoke_f16_smem");
        {
        cudez_buffer dA = cudez_buffer_write(cz, Ah, sizeof(__half) * M * K);
        cudez_buffer dB = cudez_buffer_write(cz, Bh, sizeof(__half) * K * N);
        cudez_buffer dC = cudez_buffer_write(cz, Cf, sizeof(float) * M * N);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(float) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        /* GENERALIZED (was an enumerated list -- which silently excluded each
           new rung: bit v9 as review finding F1, then bit v10 the same way).
           Every stage >= 6 is the 128x128 / 16-warp / BK=32 family, including
           any future ring rung; do NOT turn this back into a list. */
        int wpb_ok = (stage >= 6) ? 16 : 4;
        int badK   = (stage >= 6) ? 48 : 96;  /* %WK(16) but not %BK (32 vs 64) */
        a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.alpha = 2.0f; a.beta = beta; a.warps_per_block = wpb_ok;

        /* geometry rejections must fire BEFORE launch, loudly */
        a.warps_per_block = 2;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 %s: warps_per_block=2 was not rejected\n", tag); bad++;
        }
        a.warps_per_block = wpb_ok; a.M = 96;   /* 96 % block-M != 0 (64 or 128) */
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 %s: M=96 (not %%block) was not rejected\n", tag); bad++;
        }
        a.M = M; a.K = badK;                 /* badK % BK != 0 */
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 %s: K=%d (not %%BK) was not rejected\n", tag, badK); bad++;
        }
        a.K = K;

        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  F16 %s launch failed\n", tag); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __half2float(Ah[m*K+k]) * __half2float(Bh[k*N+n]);
                acc = 2.0f * acc + beta * Cf[m*N+n];   /* alpha/beta epilogue */
                if (fabsf(Dg[m*N+n] - acc) > 0.5f) {
                    printf("  F16 %s mismatch at (%d,%d): gpu=%.1f ref=%.1f\n", tag, m, n, Dg[m*N+n], acc); bad++;
                }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
        }
    }
    free(Af); free(Bf); free(Ah); free(Bh); free(Cf); free(Dg);
    return bad ? 1 : 0;
}

static int test_f16_smem(cudez *cz) {   /* pipeline v3: the 0.8.0 gate, unchanged */
    int bad = test_f16_smem_stage(cz, 1, 0, 128, 128, 1.0f, "smem");
    printf("F16  smem stage  (128x128x128): %s   <== 0.8.0 pipeline v3, alpha/beta + reject checks\n",
           bad ? "FAIL" : "PASS");
    return bad;
}

static int test_f16_smem_v4(cudez *cz) { /* pipeline v4: the 0.9.0 gate */
    int bad;
    /* config rejections specific to v4 (build-time, before any launch) */
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_BF16);
        cudez_mma_kernel mm;
        cfg.smem_stage = 2;
        if (cudez_try_mma_build(cz, &cfg, "must_reject", &mm) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 smem v4: BF16 + smem_stage=2 was not rejected\n");
            return 1;
        }
        /* smem_stage=3 (pipeline v5) became a VALID value once rung (i)
           landed -- the "one past the max" boundary check moves to 4. If
           this ever fires, it means smem_stage=3 stopped being accepted
           somewhere and v5 silently broke; do not just bump this number
           without checking why. */
        cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        /* smem_stage=8 (pipeline v10) became a VALID value when the 4-stage
           ring landed in 1.7.0-dev -- the rejection boundary moves to 9,
           exactly as it moved 3->4 (rung i), 4->5 (rung b), 5->6 (rung e),
           6->7 (v9), 7->8 (v10). If this ever fires, smem_stage=8 stopped
           being accepted and v10 silently broke; do not just bump this number
           without checking why. */
        cfg.smem_stage = 9;
        if (cudez_try_mma_build(cz, &cfg, "must_reject", &mm) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 smem v4: smem_stage=9 was not rejected\n");
            return 1;
        }
    }
    bad = test_f16_smem_stage(cz, 2, 0, 128, 192, 1.0f, "smem v4");
    printf("F16  smem v4     (128x128x192): %s   <== 0.9.0 pipeline v4 (cp.async x3 stages), alpha/beta + reject checks\n",
           bad ? "FAIL" : "PASS");
    return bad;
}

static int test_f16_smem_v4h(cudez *cz) { /* rung (h): the 0.10.0 gate */
    int bad;
    /* config rejections specific to store_hint (build-time, before launch):
       the hinted epilogue is a pipeline v4 rung, valid ONLY on smem_stage=2 */
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm;
        cfg.smem_stage = 2; cfg.store_hint = 2;
        if (cudez_try_mma_build(cz, &cfg, "must_reject", &mm) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 smem v4h: store_hint=2 was not rejected\n");
            return 1;
        }
        cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cfg.smem_stage = 1; cfg.store_hint = 1;
        if (cudez_try_mma_build(cz, &cfg, "must_reject", &mm) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 smem v4h: store_hint=1 + smem_stage=1 (v3) was not rejected\n");
            return 1;
        }
        cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cfg.smem_stage = 0; cfg.store_hint = 1;
        if (cudez_try_mma_build(cz, &cfg, "must_reject", &mm) != CUDA_ERROR_INVALID_VALUE) {
            printf("  F16 smem v4h: store_hint=1 + smem_stage=0 (streaming) was not rejected\n");
            return 1;
        }
    }
    /* BOTH epilogue branches: the hinted epilogue is new code, so unlike
       the historical v3/v4 gates it is diffed with beta=1 (read-C-add
       path) AND beta=0 (pure evict-first store path). Same K=192
       three-stage discipline as v4 -- the K-loop is untouched, but a
       restage bug would corrupt what the new epilogue reads. */
    bad  = test_f16_smem_stage(cz, 2, 1, 128, 192, 1.0f, "smem v4h b1");
    bad += test_f16_smem_stage(cz, 2, 1, 128, 192, 0.0f, "smem v4h b0");
    printf("F16  smem v4h    (128x128x192): %s   <== 0.10.0 rung (h) evict-first epilogue (beta=1 AND beta=0), reject checks\n",
           bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

static int test_f16_smem_v5(cudez *cz) { /* pipeline v5: rung (i), 1.1.0 gate */
    int bad;
    /* 768x128x128: bt_per_col = M/BM = 768/64 = 12 block-tile rows, against
       GROUP_M=8 -- this deliberately spans TWO rasterization groups, the
       second one PARTIAL (rows 8-11, only 4 of 8). 128x128x128 like v3/v4's
       gate would give bt_per_col=2, never leaving the first (short) group
       and never exercising the boundary math (first_m/group_m clamp) at
       all -- a bug there could pass a same-shaped gate and still corrupt
       real M values. The bijection is brute-force verified GPU-free over
       1..16 x 1..16 grids; THIS gate is the hardware check. */
    bad = test_f16_smem_stage(cz, 3, 0, 768, 128, 1.0f, "smem v5");
    printf("F16  smem v5     (768x128x128): %s   <== 1.1.0 rung (i) L2-aware block rasterization, partial-group boundary\n",
           bad ? "FAIL" : "PASS");
    return bad;
}

static int test_f16_smem_v5h(cudez *cz) { /* v5 + rung (h): the composition gate */
    int bad;
    /* The 2x2 cross-term: the hinted epilogue computes output addresses
       from brow/bcol, which is exactly what the v5 swizzle changes -- the
       two rungs are independently gated above, so THIS gate exists to
       catch a composition bug (epilogue reading a stale/plain mapping).
       Same partial-group shape as the v5 gate; beta=1 exercises the
       read-C-add path against swizzled coordinates too. */
    bad = test_f16_smem_stage(cz, 3, 1, 768, 128, 1.0f, "smem v5h");
    printf("F16  smem v5h    (768x128x128): %s   <== 1.1.0 rungs (i)+(h) composed (swizzle x evict-first epilogue)\n",
           bad ? "FAIL" : "PASS");
    return bad;
}

static int test_f16_smem_v6(cudez *cz) { /* pipeline v6: rung (b), 1.2.0 gates */
    int bad;
    /* v6 inherits BOTH prior gate shapes (CYCLE_HANDOFF SS6.1): 128x128x192
       is the K=192 wrap discipline (three BK=64 stages -- a double-buffer
       ping-pong bug passes any two-stage K and corrupts every longer one),
       and 768x128x128 is the partial GROUP_M band (bt_per_col=12 spans two
       rasterization groups, the second one 4 of 8). The index flow --
       ldmatrix addressing, fragment tables, register-direct epilogue --
       is proven bit-exact GPU-free by emu_v6.py at BOTH shapes; THESE
       gates validate the PTX ISA semantics that proof conditions on,
       on real silicon. beta=1 exercises the read-C-add epilogue path. */
    {   /* store_hint on v6 is NOT a shipped rung: the validator must
           refuse the composition until it is gated, same as it refused
           hint-on-v3/streaming before 1.1.0. */
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm;
        cfg.smem_stage = 4; cfg.store_hint = 1;
        if (cudez_try_mma_build(cz, &cfg, "smoke_v6h_reject", &mm) == CUDA_SUCCESS) {
            printf("  F16 smem v6: store_hint=1 + smem_stage=4 was not rejected\n");
            return 1;
        }
    }
    bad  = test_f16_smem_stage(cz, 4, 0, 128, 192, 1.0f, "smem v6 kwrap");
    bad += test_f16_smem_stage(cz, 4, 0, 768, 128, 1.0f, "smem v6 band");
    printf("F16  smem v6     (128x128x192 + 768x128x128): %s   <== 1.2.0 rung (b) ldmatrix + raw mma.sync\n",
           bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

static int test_f16_smem_v7(cudez *cz) { /* pipeline v7: rung (e) gates */
    int bad;
    /* v7 inherits both gate shapes. beta=1 exercises the float4
       read-modify-write path; a second beta=0 run at the K-wrap shape
       covers the alpha-only vector path. */
    {   cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm;
        cfg.smem_stage = 5; cfg.store_hint = 1;
        if (cudez_try_mma_build(cz, &cfg, "smoke_v7h_reject", &mm) == CUDA_SUCCESS) {
            printf("  F16 smem v7: store_hint=1 + smem_stage=5 was not rejected\n");
            return 1;
        }
    }
    bad  = test_f16_smem_stage(cz, 5, 0, 128, 192, 1.0f, "smem v7 kwrap");
    bad += test_f16_smem_stage(cz, 5, 0, 128, 192, 0.0f, "smem v7 beta0");
    bad += test_f16_smem_stage(cz, 5, 0, 768, 128, 1.0f, "smem v7 band");
    printf("F16  smem v7     (128x128x192 x2 + 768x128x128): %s   <== rung (e) staged float4 epilogue\n",
           bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

static int test_f16_smem_v8(cudez *cz) { /* pipeline v8: rung (f) gates */
    int bad;
    /* v8 (128x128 block, 16 warps) reuses both gate shapes: 128x128x192 is one
       block with a 6-step K wrap; 768x128x128 is a 6-block-row partial GROUP_M
       band. store_hint=1 must be refused (v8 bakes its own float4 epilogue). */
    {   cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm;
        cfg.smem_stage = 6; cfg.store_hint = 1;
        if (cudez_try_mma_build(cz, &cfg, "smoke_v8h_reject", &mm) == CUDA_SUCCESS) {
            printf("  F16 smem v8: store_hint=1 + smem_stage=6 was not rejected\n");
            return 1;
        }
    }
    bad  = test_f16_smem_stage(cz, 6, 0, 128, 192, 1.0f, "smem v8 kwrap");
    bad += test_f16_smem_stage(cz, 6, 0, 128, 192, 0.0f, "smem v8 beta0");
    bad += test_f16_smem_stage(cz, 6, 0, 768, 128, 1.0f, "smem v8 band");
    printf("F16  smem v8     (128x128x192 x2 + 768x128x128): %s   <== rung (f) 128x128 block\n",
           bad ? "FAIL" : "PASS");
    {
        int rc8 = bad ? 1 : 0;   /* preserve v8's verdict across the v9 block */
        bad  = test_f16_smem_stage(cz, 7, 0, 128, 192, 1.0f, "smem v9 kwrap");
        bad += test_f16_smem_stage(cz, 7, 0, 128, 192, 0.0f, "smem v9 beta0");
        bad += test_f16_smem_stage(cz, 7, 0, 768, 128, 1.0f, "smem v9 band");
        printf("F16  smem v9     (128x128x192 x2 + 768x128x128): %s   <== v9 3-stage cp.async ring (dynamic smem)\n",
               bad ? "FAIL" : "PASS");
        {
            int rc9 = bad ? 1 : 0;
            bad  = test_f16_smem_stage(cz, 8, 0, 128, 192, 1.0f, "smem v10 kwrap");
            bad += test_f16_smem_stage(cz, 8, 0, 128,  64, 1.0f, "smem v10 short");  /* 2 tiles < depth 4 */
            bad += test_f16_smem_stage(cz, 8, 0, 768, 128, 1.0f, "smem v10 band");
            printf("F16  smem v10    (128x128x{192,64} + 768x128x128): %s   <== v10 4-stage ring\n",
                   bad ? "FAIL" : "PASS");
            return (rc8 || rc9 || bad) ? 1 : 0;
        }
    }
}


static int test_int8(cudez *cz) {
    const int M = 32, N = 16, K = 64;   /* M%16==0, N%8==0, K%32==0 */
    int m, n, k, bad = 0;
    signed char *A = (signed char*)malloc((size_t)M * K);
    signed char *B = (signed char*)malloc((size_t)K * N);
    int *Dg = (int*)malloc(sizeof(int) * M * N);
    for (k = 0; k < M * K; k++) A[k] = (signed char)rnd_range(-4, 4);
    for (k = 0; k < K * N; k++) B[k] = (signed char)rnd_range(-4, 4);
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT8);   /* NONE: D is int32 */
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_int8");
        cudez_buffer dA = cudez_buffer_write(cz, A, (size_t)M * K);
        cudez_buffer dB = cudez_buffer_write(cz, B, (size_t)K * N);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(int) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr; a.M = M; a.N = N; a.K = K; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  INT8 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(int) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                int acc = 0;
                for (k = 0; k < K; k++) acc += (int)A[m*K+k] * (int)B[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  INT8 mismatch at (%d,%d): gpu=%d ref=%d\n", m, n, Dg[m*N+n], acc); bad++; }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
    }
    free(A); free(B); free(Dg);
    printf("INT8 dense       (%dx%dx%d): %s (exact int32)\n", M, N, K, bad ? "FAIL" : "PASS");
    {   /* 1.7.0-dev: same exact-int32 check on the pipelined s8 kernel at a
           pipeline-legal shape (64-multiples; K=192 wraps the double buffer). */
        const int PM = 128, PN = 128, PK = 192;
        int rc0 = bad ? 1 : 0, pbad = 0;
        signed char *pA = (signed char*)malloc((size_t)PM * PK);
        signed char *pB = (signed char*)malloc((size_t)PK * PN);
        int *pD = (int*)malloc(sizeof(int) * (size_t)PM * PN);
        for (k = 0; k < PM * PK; k++) pA[k] = (signed char)rnd_range(-4, 4);
        for (k = 0; k < PK * PN; k++) pB[k] = (signed char)rnd_range(-4, 4);
        {
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT8);
            cudez_mma_kernel mm;
            cfg.smem_stage = 5;
            mm = cudez_mma_build(cz, &cfg, "smoke_int8_v7");
            {
                cudez_buffer dA = cudez_buffer_write(cz, pA, (size_t)PM * PK);
                cudez_buffer dB = cudez_buffer_write(cz, pB, (size_t)PK * PN);
                cudez_buffer dD = cudez_buffer_new(cz, sizeof(int) * (size_t)PM * PN);
                cudez_mma_args a; memset(&a, 0, sizeof a);
                a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr;
                a.M = PM; a.N = PN; a.K = PK; a.warps_per_block = 4;
                if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  INT8 v7 launch failed\n"); pbad = 1; }
                cudez_finish(cz);
                cudez_read(cz, dD, pD, sizeof(int) * (size_t)PM * PN);
                for (m = 0; m < PM && pbad < 8; m++)
                    for (n = 0; n < PN && pbad < 8; n++) {
                        int acc = 0;
                        for (k = 0; k < PK; k++) acc += (int)pA[m*PK+k] * (int)pB[k*PN+n];
                        if (pD[m*PN+n] != acc) { printf("  INT8 v7 mismatch at (%d,%d): gpu=%d ref=%d\n", m, n, pD[m*PN+n], acc); pbad++; }
                    }
                cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
            }
        }
        free(pA); free(pB); free(pD);
        printf("INT8 smem v7     (%dx%dx%d): %s (exact int32)   <== 1.7.0-dev cp.async pipeline\n",
               PM, PN, PK, pbad ? "FAIL" : "PASS");
        return (rc0 || pbad) ? 1 : 0;
    }
}

/* ---------------------------------------------------------------- INT4 dense */
static void pack_nibble(signed char *bytes, int elem_index, int val) {
    int byte = elem_index >> 1, shift = (elem_index & 1) * 4;
    unsigned char cur = (unsigned char)bytes[byte];
    cur = (unsigned char)((cur & ~(0xF << shift)) | (((unsigned)val & 0xF) << shift));
    bytes[byte] = (signed char)cur;
}
static int test_int4(cudez *cz) {
    const int M = 32, N = 16, K = 128;  /* M%16==0, N%8==0, K%64==0 */
    int m, n, k, bad = 0;
    int  *Aval = (int*)malloc(sizeof(int) * M * K);
    int  *Bval = (int*)malloc(sizeof(int) * K * N);
    signed char *Ab = (signed char*)calloc((size_t)M * (K/2), 1);
    signed char *Bb = (signed char*)calloc((size_t)K * (N/2), 1);
    int *Dg = (int*)malloc(sizeof(int) * M * N);
    for (m = 0; m < M; m++)
        for (k = 0; k < K; k++) { int v = rnd_range(-8, 7); Aval[m*K+k] = v; pack_nibble(Ab + m*(K/2), k, v); }
    for (k = 0; k < K; k++)
        for (n = 0; n < N; n++) { int v = rnd_range(-8, 7); Bval[k*N+n] = v; pack_nibble(Bb + k*(N/2), n, v); }
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT4);
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_int4");
        cudez_buffer dA = cudez_buffer_write(cz, Ab, (size_t)M * (K/2));
        cudez_buffer dB = cudez_buffer_write(cz, Bb, (size_t)K * (N/2));
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(int) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr; a.M = M; a.N = N; a.K = K; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  INT4 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(int) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                int acc = 0;
                for (k = 0; k < K; k++) acc += Aval[m*K+k] * Bval[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  INT4 mismatch at (%d,%d): gpu=%d ref=%d\n", m, n, Dg[m*N+n], acc); bad++; }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
    }
    free(Aval); free(Bval); free(Ab); free(Bb); free(Dg);
    printf("INT4 dense       (%dx%dx%d): %s (exact int32)\n", M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* ------------------------------------------------------------- F16 2:4 sparse */
/* Build A with an EXACT 2:4 pattern (exactly 2 nonzeros per contiguous 4 along
   K). Because the other two are already zero, the reference product equals the
   full dense A*B -- and the sparse kernel must reconstruct that SAME product
   from the compressed values + metadata. If the metadata positions are wrong,
   the kernel pairs the wrong B rows and this test fails while dense F16 passes:
   a clean, localized signal that the metadata encoding needs a hardware tweak. */
static int test_sparse_f16(cudez *cz) {
    const int M = 32, N = 16, K = 64;   /* M%16==0, N%8==0, K%32==0 */
    int m, n, k, g, bad = 0;
    size_t meta_n = (size_t)(M/16) * (K/32) * 32;
    float  *Af   = (float*)calloc((size_t)M * K, sizeof(float));
    float  *Bf   = (float*)malloc(sizeof(float) * K * N);
    __half *Ah   = (__half*)malloc(sizeof(__half) * M * K);
    __half *Bh   = (__half*)malloc(sizeof(__half) * K * N);
    float  *vals = (float*)malloc(sizeof(float) * M * (K/2));
    __half *valsh= (__half*)malloc(sizeof(__half) * M * (K/2));
    unsigned *meta = (unsigned*)malloc(sizeof(unsigned) * meta_n);
    float  *Dg   = (float*)malloc(sizeof(float) * M * N);
    float  *Zero = (float*)calloc((size_t)M * N, sizeof(float));

    for (m = 0; m < M; m++)
        for (g = 0; g < K/4; g++) {
            int p0 = rnd_range(0,3), p1 = rnd_range(0,3);
            while (p1 == p0) p1 = rnd_range(0,3);
            Af[m*K + g*4 + p0] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
            Af[m*K + g*4 + p1] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
        }
    for (k = 0; k < M * K; k++) Ah[k] = __float2half(Af[k]);
    for (k = 0; k < K * N; k++) { Bf[k] = (float)rnd_range(-4, 4); Bh[k] = __float2half(Bf[k]); }

    if (!cudez_mma_compress_2to4(Af, M, K, vals, meta)) { printf("  sparse compress contract fail\n"); bad = 1; }
    for (k = 0; k < M * (K/2); k++) valsh[k] = __float2half(vals[k]);
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16); cfg.sparse = 1;
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_sp_f16");
        cudez_buffer dA   = cudez_buffer_write(cz, valsh, sizeof(__half) * M * (K/2));
        cudez_buffer dMeta= cudez_buffer_write(cz, meta,  sizeof(unsigned) * meta_n);
        cudez_buffer dB   = cudez_buffer_write(cz, Bh,    sizeof(__half) * K * N);
        cudez_buffer dC   = cudez_buffer_write(cz, Zero,  sizeof(float) * M * N);
        cudez_buffer dD   = cudez_buffer_new(cz, sizeof(float) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.meta = dMeta.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  SPARSE launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __half2float(Ah[m*K+k]) * __half2float(Bh[k*N+n]);
                if (fabsf(Dg[m*N+n] - acc) > 0.5f) {
                    printf("  SPARSE mismatch at (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); bad++;
                }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dMeta); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ah); free(Bh); free(vals); free(valsh); free(meta); free(Dg); free(Zero);
    printf("F16  2:4 sparse  (%dx%dx%d): %s   <== confirms metadata layout on THIS GPU\n", M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* 1.0.3 (deferred item: BF16 sparse smoke coverage gap). BF16 sparse is
   wired into cudez_mma_sparse_source_ (the is_bf16 branch) and the launch
   validator's own error text claims "only F16/BF16 sparse" is supported,
   but nothing anywhere in this harness had ever actually run it -- the
   only sparse smoke coverage was F16-specific. 2:4 metadata is a
   hardware-level encoding of WHICH of 4 positions survived pruning,
   independent of the sparse operand's element type in principle, so this
   is expected to pass cleanly -- but "should work" and "confirmed on
   silicon" are different claims, and that gap is exactly what this test
   closes. Modeled directly on test_sparse_f16: same shape, same
   structure, __nv_bfloat16 throughout instead of __half. */
static int test_sparse_bf16(cudez *cz) {
    const int M = 32, N = 16, K = 64;   /* M%16==0, N%8==0, K%32==0 */
    int m, n, k, g, bad = 0;
    size_t meta_n = (size_t)(M/16) * (K/32) * 32;
    float  *Af   = (float*)calloc((size_t)M * K, sizeof(float));
    float  *Bf   = (float*)malloc(sizeof(float) * K * N);
    __nv_bfloat16 *Ab   = (__nv_bfloat16*)malloc(sizeof(__nv_bfloat16) * M * K);
    __nv_bfloat16 *Bb   = (__nv_bfloat16*)malloc(sizeof(__nv_bfloat16) * K * N);
    float  *vals = (float*)malloc(sizeof(float) * M * (K/2));
    __nv_bfloat16 *valsb= (__nv_bfloat16*)malloc(sizeof(__nv_bfloat16) * M * (K/2));
    unsigned *meta = (unsigned*)malloc(sizeof(unsigned) * meta_n);
    float  *Dg   = (float*)malloc(sizeof(float) * M * N);
    float  *Zero = (float*)calloc((size_t)M * N, sizeof(float));

    for (m = 0; m < M; m++)
        for (g = 0; g < K/4; g++) {
            int p0 = rnd_range(0,3), p1 = rnd_range(0,3);
            while (p1 == p0) p1 = rnd_range(0,3);
            Af[m*K + g*4 + p0] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
            Af[m*K + g*4 + p1] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
        }
    for (k = 0; k < M * K; k++) Ab[k] = __float2bfloat16(Af[k]);
    for (k = 0; k < K * N; k++) { Bf[k] = (float)rnd_range(-4, 4); Bb[k] = __float2bfloat16(Bf[k]); }

    if (!cudez_mma_compress_2to4(Af, M, K, vals, meta)) { printf("  sparse compress contract fail\n"); bad = 1; }
    for (k = 0; k < M * (K/2); k++) valsb[k] = __float2bfloat16(vals[k]);
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_BF16); cfg.sparse = 1;
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_sp_bf16");
        cudez_buffer dA   = cudez_buffer_write(cz, valsb, sizeof(__nv_bfloat16) * M * (K/2));
        cudez_buffer dMeta= cudez_buffer_write(cz, meta,  sizeof(unsigned) * meta_n);
        cudez_buffer dB   = cudez_buffer_write(cz, Bb,    sizeof(__nv_bfloat16) * K * N);
        cudez_buffer dC   = cudez_buffer_write(cz, Zero,  sizeof(float) * M * N);
        cudez_buffer dD   = cudez_buffer_new(cz, sizeof(float) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.meta = dMeta.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  SPARSE BF16 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __bfloat162float(Ab[m*K+k]) * __bfloat162float(Bb[k*N+n]);
                if (fabsf(Dg[m*N+n] - acc) > 0.5f) {
                    printf("  SPARSE BF16 mismatch at (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); bad++;
                }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dMeta); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ab); free(Bb); free(vals); free(valsb); free(meta); free(Dg); free(Zero);
    printf("BF16 2:4 sparse  (%dx%dx%d): %s   <== confirms metadata layout is dtype-independent on THIS GPU\n", M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* 1.0.3-dev: real smoke coverage for CUDEZ_SPI8_PIPE_SRC_ (INT8 2:4 sparse,
   UNVERIFIED -- see that template's doc comment in cudez.h for the full
   derivation and specific risk areas). This is the actual test that answers
   "is INT8 sparse broken" -- an exact int32 comparison against a host
   reference, same discipline as test_int8. Shape is the smallest legal one
   for THIS kernel's real contract (M%64==0, N%64==0, K%32==0 -- a fixed
   64x64-block v7-class pipeline, stricter than F16/BF16 sparse's smaller
   M%16/N%8/K%32 streaming-shape tests above). If this fails, the doc
   comment on CUDEZ_SPI8_PIPE_SRC_ names exactly where to look first (the
   a0/a1 register-count question). */
static int test_sparse_int8(cudez *cz) {
    const int M = 64, N = 64, K = 32;   /* M%64==0, N%64==0, K%32==0 */
    int m, n, k, g, bad = 0;
    size_t meta_n = (size_t)(M/16) * (K/32) * 32;
    float *Af = (float*)calloc((size_t)M * K, sizeof(float));
    signed char *A = (signed char*)malloc((size_t)M * K);
    signed char *B = (signed char*)malloc((size_t)K * N);
    float *vals = (float*)malloc(sizeof(float) * M * (K/2));
    signed char *valsi = (signed char*)malloc((size_t)M * (K/2));
    unsigned *meta = (unsigned*)malloc(sizeof(unsigned) * meta_n);
    int *Dg = (int*)malloc(sizeof(int) * M * N);

    /* Same 2:4 construction as the F16/BF16 sparse tests: exactly 2 nonzero
       (here, small nonzero int) positions per 4-element group, so the
       compressed representation round-trips exactly through int8's integer
       domain (no rounding, unlike F16/BF16's float roundtrip -- int8 sparse
       should be EASIER to validate exactly than the float dtypes). */
    for (m = 0; m < M; m++)
        for (g = 0; g < K/4; g++) {
            int p0 = rnd_range(0,3), p1 = rnd_range(0,3);
            while (p1 == p0) p1 = rnd_range(0,3);
            Af[m*K + g*4 + p0] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
            Af[m*K + g*4 + p1] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
        }
    for (k = 0; k < M * K; k++) A[k] = (signed char)Af[k];
    for (k = 0; k < K * N; k++) B[k] = (signed char)rnd_range(-4, 4);

    if (!cudez_mma_compress_2to4(Af, M, K, vals, meta)) { printf("  sparse compress contract fail\n"); bad = 1; }
    for (k = 0; k < M * (K/2); k++) valsi[k] = (signed char)vals[k];
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT8); cfg.sparse = 1; cfg.smem_stage = 5;
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_sp_int8");
        cudez_buffer dA   = cudez_buffer_write(cz, valsi, (size_t)M * (K/2));
        cudez_buffer dMeta= cudez_buffer_write(cz, meta,  sizeof(unsigned) * meta_n);
        cudez_buffer dB   = cudez_buffer_write(cz, B,     (size_t)K * N);
        cudez_buffer dD   = cudez_buffer_new(cz, sizeof(int) * M * N);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.meta = dMeta.ptr; a.B = dB.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.warps_per_block = 4;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  SPARSE INT8 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(int) * M * N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                int acc = 0;
                for (k = 0; k < K; k++) acc += (int)A[m*K+k] * (int)B[k*N+n];
                if (Dg[m*N+n] != acc) {
                    printf("  SPARSE INT8 mismatch at (%d,%d): gpu=%d ref=%d\n", m, n, Dg[m*N+n], acc); bad++;
                }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dMeta); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dD);
    }
    free(Af); free(A); free(B); free(vals); free(valsi); free(meta); free(Dg);
    printf("INT8 2:4 sparse  (%dx%dx%d): %s (exact int32)   <== UNVERIFIED kernel, see\n"
           "                                     CUDEZ_SPI8_PIPE_SRC_'s doc comment if this FAILs\n",
           M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* ------------------------------------------------------------- cudez_gemm path */
static int test_gemm(cudez *cz) {
    const int M = 16, N = 16, K = 32; int m, n, k, bad = 0;
    float *Af = (float*)malloc(sizeof(float)*M*K), *Bf = (float*)malloc(sizeof(float)*K*N);
    __half *Ah = (__half*)malloc(sizeof(__half)*M*K), *Bh = (__half*)malloc(sizeof(__half)*K*N);
    float *Dg = (float*)malloc(sizeof(float)*M*N), *Zero = (float*)calloc((size_t)M*N,sizeof(float));
    for (k = 0; k < M*K; k++) { Af[k] = (float)rnd_range(-4,4); Ah[k] = __float2half(Af[k]); }
    for (k = 0; k < K*N; k++) { Bf[k] = (float)rnd_range(-4,4); Bh[k] = __float2half(Bf[k]); }
    {
        cudez_buffer dA = cudez_buffer_write(cz, Ah, sizeof(__half)*M*K);
        cudez_buffer dB = cudez_buffer_write(cz, Bh, sizeof(__half)*K*N);
        cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float)*M*N);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(float)*M*N);
        CUresult e = cudez_gemm(cz, CUDEZ_MMA_F16, dA.ptr, dB.ptr, dC.ptr, dD.ptr, M, N, K, 1.0f, 0.0f);
        if (e != CUDA_SUCCESS) { printf("  cudez_gemm returned %s\n", cudez_strerror(e)); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float)*M*N);
        for (m = 0; m < M && bad < 8; m++)
            for (n = 0; n < N && bad < 8; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __half2float(Ah[m*K+k]) * __half2float(Bh[k*N+n]);
                if (fabsf(Dg[m*N+n] - acc) > 0.5f) { printf("  GEMM mismatch at (%d,%d)\n", m, n); bad++; }
            }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ah); free(Bh); free(Dg); free(Zero);
    printf("cudez_gemm F16   (%dx%dx%d): %s (one-call path)\n", M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

static int test_batched_f16(cudez *cz) {
    const int BC = 3, M = 32, N = 16, K = 32;   /* M%16==0, N%16==0, K%16==0 */
    int b, m, n, k, bad = 0;
    size_t eA = (size_t)M * K, eB = (size_t)K * N, eD = (size_t)M * N;
    float  *Af = (float *)malloc(sizeof(float) * BC * eA);
    float  *Bf = (float *)malloc(sizeof(float) * BC * eB);
    __half *Ah = (__half *)malloc(sizeof(__half) * BC * eA);
    __half *Bh = (__half *)malloc(sizeof(__half) * BC * eB);
    float  *Dg = (float *)malloc(sizeof(float) * BC * eD);
    float  *Zero = (float *)calloc((size_t)BC * eD, sizeof(float));

    for (k = 0; k < (int)(BC * eA); k++) { Af[k] = (float)rnd_range(-4, 4); Ah[k] = __float2half(Af[k]); }
    for (k = 0; k < (int)(BC * eB); k++) { Bf[k] = (float)rnd_range(-4, 4); Bh[k] = __float2half(Bf[k]); }
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_batched_f16");
        cudez_buffer dA = cudez_buffer_write(cz, Ah,   sizeof(__half) * BC * eA);
        cudez_buffer dB = cudez_buffer_write(cz, Bh,   sizeof(__half) * BC * eB);
        cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float)  * BC * eD);
        cudez_buffer dD = cudez_buffer_new(cz,         sizeof(float)  * BC * eD);
        cudez_mma_args a; memset(&a, 0, sizeof a);
        a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
        a.batch_count = BC;   /* strides left 0 -> packed defaults (M*K,K*N,M*N,M*N) */
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  BATCHED launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * BC * eD);
        for (b = 0; b < BC && bad < 8; b++) {
            const __half *A = Ah + (size_t)b * eA;
            const __half *B = Bh + (size_t)b * eB;
            for (m = 0; m < M && bad < 8; m++)
                for (n = 0; n < N && bad < 8; n++) {
                    float acc = 0.0f;
                    for (k = 0; k < K; k++) acc += __half2float(A[m*K+k]) * __half2float(B[k*N+n]);
                    if (fabsf(Dg[(size_t)b*eD + m*N+n] - acc) > 0.5f) {
                        printf("  BATCHED mismatch b=%d (%d,%d): gpu=%.1f ref=%.1f\n",
                               b, m, n, Dg[(size_t)b*eD + m*N+n], acc); bad++;
                    }
                }
        }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ah); free(Bh); free(Dg); free(Zero);
    printf("F16  batched x%d (%dx%dx%d): %s (blockIdx.z)\n", BC, M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* Batched BF16 (0.7.0, BUG-4): same blockIdx.z path as F16, distinct data per
   batch element. BF16 needs sm_80+ regardless of batching. */
static int test_batched_bf16(cudez *cz) {
    const int BC = 3, M = 32, N = 16, K = 32;   /* M%16==0, N%16==0, K%16==0 */
    int b, m, n, k, bad = 0;
    size_t eA = (size_t)M * K, eB = (size_t)K * N, eD = (size_t)M * N;
    float          *Af = (float *)malloc(sizeof(float) * BC * eA);
    float          *Bf = (float *)malloc(sizeof(float) * BC * eB);
    __nv_bfloat16  *Ab = (__nv_bfloat16 *)malloc(sizeof(__nv_bfloat16) * BC * eA);
    __nv_bfloat16  *Bb = (__nv_bfloat16 *)malloc(sizeof(__nv_bfloat16) * BC * eB);
    float          *Dg = (float *)malloc(sizeof(float) * BC * eD);
    float          *Zero = (float *)calloc((size_t)BC * eD, sizeof(float));

    for (k = 0; k < (int)(BC * eA); k++) { Af[k] = (float)rnd_range(-4, 4); Ab[k] = __float2bfloat16(Af[k]); }
    for (k = 0; k < (int)(BC * eB); k++) { Bf[k] = (float)rnd_range(-4, 4); Bb[k] = __float2bfloat16(Bf[k]); }
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_BF16);
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_batched_bf16");
        cudez_buffer dA = cudez_buffer_write(cz, Ab,   sizeof(__nv_bfloat16) * BC * eA);
        cudez_buffer dB = cudez_buffer_write(cz, Bb,   sizeof(__nv_bfloat16) * BC * eB);
        cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float)         * BC * eD);
        cudez_buffer dD = cudez_buffer_new(cz,         sizeof(float)         * BC * eD);
        cudez_mma_args a = cudez_mma_args_batched(M, N, K, BC, 1.0f, 0.0f);
        a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;  /* strides 0 -> packed */
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  BATCHED BF16 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * BC * eD);
        for (b = 0; b < BC && bad < 8; b++) {
            const __nv_bfloat16 *A = Ab + (size_t)b * eA;
            const __nv_bfloat16 *B = Bb + (size_t)b * eB;
            for (m = 0; m < M && bad < 8; m++)
                for (n = 0; n < N && bad < 8; n++) {
                    float acc = 0.0f;
                    for (k = 0; k < K; k++) acc += __bfloat162float(A[m*K+k]) * __bfloat162float(B[k*N+n]);
                    if (fabsf(Dg[(size_t)b*eD + m*N+n] - acc) > 0.5f) {
                        printf("  BATCHED BF16 mismatch b=%d (%d,%d): gpu=%.1f ref=%.1f\n",
                               b, m, n, Dg[(size_t)b*eD + m*N+n], acc); bad++;
                    }
                }
        }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Ab); free(Bb); free(Dg); free(Zero);
    printf("BF16 batched x%d (%dx%dx%d): %s (blockIdx.z)\n", BC, M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* Batched TF32 (0.7.0, BUG-4): TF32 kernels take float inputs (rounded to TF32 on
   load), so the device operands are plain float. Needs sm_80+. */
static int test_batched_tf32(cudez *cz) {
    const int BC = 3, M = 32, N = 16, K = 32;   /* TF32 tile is 16x16x8; K%8==0 */
    int b, m, n, k, bad = 0;
    size_t eA = (size_t)M * K, eB = (size_t)K * N, eD = (size_t)M * N;
    float *Af = (float *)malloc(sizeof(float) * BC * eA);
    float *Bf = (float *)malloc(sizeof(float) * BC * eB);
    float *Dg = (float *)malloc(sizeof(float) * BC * eD);
    float *Zero = (float *)calloc((size_t)BC * eD, sizeof(float));

    for (k = 0; k < (int)(BC * eA); k++) Af[k] = (float)rnd_range(-4, 4);
    for (k = 0; k < (int)(BC * eB); k++) Bf[k] = (float)rnd_range(-4, 4);
    {
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_TF32);
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "smoke_batched_tf32");
        cudez_buffer dA = cudez_buffer_write(cz, Af,   sizeof(float) * BC * eA);
        cudez_buffer dB = cudez_buffer_write(cz, Bf,   sizeof(float) * BC * eB);
        cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float) * BC * eD);
        cudez_buffer dD = cudez_buffer_new(cz,         sizeof(float) * BC * eD);
        cudez_mma_args a = cudez_mma_args_batched(M, N, K, BC, 1.0f, 0.0f);
        a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
        if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  BATCHED TF32 launch failed\n"); bad = 1; }
        cudez_finish(cz);
        cudez_read(cz, dD, Dg, sizeof(float) * BC * eD);
        for (b = 0; b < BC && bad < 8; b++) {
            const float *A = Af + (size_t)b * eA;
            const float *B = Bf + (size_t)b * eB;
            for (m = 0; m < M && bad < 8; m++)
                for (n = 0; n < N && bad < 8; n++) {
                    float acc = 0.0f;
                    for (k = 0; k < K; k++) acc += A[m*K+k] * B[k*N+n];
                    if (fabsf(Dg[(size_t)b*eD + m*N+n] - acc) > 0.5f) {
                        printf("  BATCHED TF32 mismatch b=%d (%d,%d): gpu=%.1f ref=%.1f\n",
                               b, m, n, Dg[(size_t)b*eD + m*N+n], acc); bad++;
                    }
                }
        }
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB);
        cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
    }
    free(Af); free(Bf); free(Dg); free(Zero);
    printf("TF32 batched x%d (%dx%dx%d): %s (blockIdx.z)\n", BC, M, N, K, bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}

/* Cache identity (0.7.0, OPT-3): batch_count lives in cudez_mma_args, never in
   cudez_mma_config, so it cannot perturb the byte-compared cache key. Building
   the same config twice must be a HIT (same handle, cache size unchanged). No
   GPU launch -- only NVRTC build, which the harness already does. */
static int test_cache_identity(cudez *cz) {
    cudez_mma_cache cache; cudez_mma_cache_init(&cache);
    cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
    cudez_mma_kernel k1, k2;
    int bad = 0, n1, n2;
    if (cudez_try_mma_build_cached(cz, &cache, &cfg, "cache_probe", &k1) != CUDA_SUCCESS) {
        printf("  cache build 1 failed\n"); return 1; }
    n1 = cache.n;
    if (cudez_try_mma_build_cached(cz, &cache, &cfg, "cache_probe", &k2) != CUDA_SUCCESS) {
        printf("  cache build 2 failed\n"); return 1; }
    n2 = cache.n;
    if (n1 != 1 || n2 != 1) { printf("  cache grew (%d -> %d); expected a hit\n", n1, n2); bad = 1; }
    if (k1.kernel.fn != k2.kernel.fn) { printf("  cache returned a different handle on hit\n"); bad = 1; }
    printf("cache identity   (bc is launch-arg): %s (n=%d, hit)\n", bad ? "FAIL" : "PASS", n2);
    return bad ? 1 : 0;
}

/* Input validation (0.7.0): the reject-before-launch paths. Each returns
   CUDA_ERROR_INVALID_VALUE before any cuLaunchKernel, so no device buffers are
   needed. The library's rejection messages print to stderr -- that is expected
   here, not a failure. */
static int test_input_validation(cudez *cz) {
    cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
    cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "validate_probe");
    cudez_mma_args base  = cudez_mma_args_batched(64, 64, 64, 2, 1.0f, 0.0f); /* bc=2 -> general path */
    int bad = 0;
    { cudez_mma_args a = base; a.strideA = -1;                       /* BUG-2 */
      if (cudez_try_mma_launch(cz,&mm,&a) != CUDA_ERROR_INVALID_VALUE) { printf("  negative stride not rejected\n"); bad=1; } }
    { cudez_mma_args a = base; a.broadcast_mask = 8u;                /* UX-3 (D/stray bit) */
      if (cudez_try_mma_launch(cz,&mm,&a) != CUDA_ERROR_INVALID_VALUE) { printf("  stray broadcast bit not rejected\n"); bad=1; } }
    { cudez_mma_args a = base; a.broadcast_mask = CUDEZ_BROADCAST_A; a.strideA = 4096; /* UX-2 */
      if (cudez_try_mma_launch(cz,&mm,&a) != CUDA_ERROR_INVALID_VALUE) { printf("  broadcast/stride conflict not rejected\n"); bad=1; } }
    { cudez_mma_args a = base; a.batch_count = 70000;               /* gridDim.z cap */
      if (cudez_try_mma_launch(cz,&mm,&a) != CUDA_ERROR_INVALID_VALUE) { printf("  batch_count>65535 not rejected\n"); bad=1; } }
    { cudez_mma_args a = cudez_mma_args_batched(2000000, 2000000, 16, 1, 1.0f, 0.0f); /* BUG-3 grid-x */
      if (cudez_try_mma_launch(cz,&mm,&a) != CUDA_ERROR_INVALID_VALUE) { printf("  grid-x overflow not guarded\n"); bad=1; } }
    { /* BUGREPORT 1.3.0 SS1: NULL pool must fail loudly, not segfault.
         Covers cudez_host_pool_alloc directly and both async wrappers. */
      float probe = 1.0f;
      cudez_buffer nb; memset(&nb, 0, sizeof nb);  /* never dereferenced: the
                                    NULL-pool guard fails first, by design */
      if (cudez_host_pool_alloc(NULL, 64) != NULL) { printf("  NULL-pool alloc did not return NULL\n"); bad=1; }
      if (cudez_pool_write_async(cz, NULL, nb, &probe, sizeof probe) != NULL) { printf("  NULL-pool write_async did not return NULL\n"); bad=1; }
      if (cudez_pool_read_async(cz, NULL, nb, sizeof(float)) != NULL) { printf("  NULL-pool read_async did not return NULL\n"); bad=1; } }
    printf("input validation (reject-before-launch): %s\n", bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}


/* 1.8.0-dev pipeline gates: TF32 / INT4 / 2:4-sparse / INT8-rung2, each on the
   v7-class cp.async machinery at pipeline-legal shapes (64-multiples). Integer
   test data keeps TF32's mantissa quantization the identity, so every check is
   EXACT, same standard as the rest of smoke. */
static int test_pipe18_(cudez *cz) {
    int m, n, k, bad = 0, total = 0;
    /* ---- TF32 pipeline: 128x128x96 vs fp32 reference, exact ---- */
    {
        const int M = 128, N = 128, K = 96;
        float *A = (float*)malloc(sizeof(float)*M*K), *B = (float*)malloc(sizeof(float)*K*N);
        float *Dg = (float*)malloc(sizeof(float)*M*N);
        int lb = 0;
        for (k = 0; k < M*K; k++) A[k] = (float)rnd_range(-4, 4);
        for (k = 0; k < K*N; k++) B[k] = (float)rnd_range(-4, 4);
        {
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_TF32);
            cudez_mma_kernel mm; cfg.smem_stage = 5;
            mm = cudez_mma_build(cz, &cfg, "smoke_tf32_v7");
            cudez_buffer dA = cudez_buffer_write(cz, A, sizeof(float)*M*K);
            cudez_buffer dB = cudez_buffer_write(cz, B, sizeof(float)*K*N);
            cudez_buffer dD = cudez_buffer_new(cz, sizeof(float)*M*N);
            cudez_mma_args a; memset(&a, 0, sizeof a);
            a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr; a.C = dD.ptr;
            a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
            if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  TF32 v7 launch failed\n"); lb = 1; }
            cudez_finish(cz);
            cudez_read(cz, dD, Dg, sizeof(float)*M*N);
            for (m = 0; m < M && lb < 8; m++) for (n = 0; n < N && lb < 8; n++) {
                float acc = 0.f; for (k = 0; k < K; k++) acc += A[m*K+k]*B[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  TF32 v7 mismatch (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); lb++; }
            }
            cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
        }
        printf("TF32 smem v7     (%dx%dx%d): %s (exact, int data)   <== 1.8.0\n", M, N, K, lb ? "FAIL" : "PASS");
        {   /* 1.10.0-dev diagnostic (r2): the first silicon run FAILED with
               NON-INTEGER outputs from integer inputs = the kernel read smem
               it never staged. Isolate the layer with a K-ladder:
               K=16 -> single tile, NO steady loop, NO ring wrap (prologue+
                       drain only): fails => fragment/staging addressing.
               K=32 -> two tiles, drain-only pipeline: fails only here or
                       beyond => slot handoff.
               K=96 -> full steady loop + wrap: fails only here => ring
                       schedule/eviction.
               Each shape reports separately; K=96 keeps the FAIL gate. */
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_TF32);
            cudez_mma_kernel mm; int rb = 0, kv;
            static const int KL[3] = { 16, 32, 96 };
            cfg.smem_stage = 7; cfg.k_chunks = 1;   /* unroll(1) = pragma neutralized; 0 is INVALID per the validator (r2 set 0 and aborted -- own goal) */
            mm = cudez_mma_build(cz, &cfg, "smoke_tf32_v9");
            for (kv = 0; kv < 3; kv++) {
                int Kd = KL[kv], db = 0;
                cudez_buffer dA = cudez_buffer_write(cz, A, sizeof(float)*M*Kd);
                cudez_buffer dB = cudez_buffer_write(cz, B, sizeof(float)*Kd*N);
                cudez_buffer dD = cudez_buffer_new(cz, sizeof(float)*M*N);
                cudez_mma_args a2; memset(&a2, 0, sizeof a2);
                a2.A = dA.ptr; a2.B = dB.ptr; a2.D = dD.ptr; a2.C = dD.ptr;
                a2.M = M; a2.N = N; a2.K = Kd; a2.alpha = 1.0f; a2.beta = 0.0f; a2.warps_per_block = 16;
                if (cudez_try_mma_launch(cz, &mm, &a2) != CUDA_SUCCESS) { printf("  TF32 v9 K=%d launch failed\n", Kd); db = 1; }
                cudez_finish(cz);
                cudez_read(cz, dD, Dg, sizeof(float)*M*N);
                for (m = 0; m < M && db < 6; m++) for (n = 0; n < N && db < 6; n++) {
                    float acc = 0.f; for (k = 0; k < Kd; k++) acc += A[m*Kd+k]*B[k*N+n];
                    if (Dg[m*N+n] != acc) { printf("  TF32 v9 K=%d mismatch (%d,%d): gpu=%.1f ref=%.1f\n", Kd, m, n, Dg[m*N+n], acc); db++; }
                }
                printf("  TF32 v9 ladder K=%-3d (%s): %s\n", Kd,
                       kv == 0 ? "1 tile, no steady, no wrap" : kv == 1 ? "2 tiles, drain-only" : "steady + wrap",
                       db ? "FAIL" : "PASS");
                if (kv == 2) rb = db;   /* the full case keeps the gate */
                else rb += db ? 1 : 0;
                cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
            }
            printf("TF32 smem v9     (%dx%dx{16,32,96}): %s (isolation ladder)   <== 1.10.0-dev r2\n", M, N, rb ? "FAIL" : "PASS");
            bad += !!rb; total++;
        }
        bad += !!lb; total++;
        free(A); free(B); free(Dg);
    }
    /* ---- INT4 pipeline: 128x128x256, exact int32 ---- */
    {
        const int M = 128, N = 128, K = 256;
        signed char *A = (signed char*)malloc((size_t)M*K/2), *B = (signed char*)malloc((size_t)K*N/2);
        int *Dg = (int*)malloc(sizeof(int)*M*N), *ref = (int*)calloc((size_t)M*N, sizeof(int));
        signed char *Au = (signed char*)malloc((size_t)M*K), *Bu = (signed char*)malloc((size_t)K*N);
        int lb = 0;
        for (k = 0; k < M*K; k++) Au[k] = (signed char)rnd_range(-8, 7);
        for (k = 0; k < K*N; k++) Bu[k] = (signed char)rnd_range(-8, 7);
        for (m = 0; m < M; m++) for (k = 0; k < K; k += 2)
            A[((size_t)m*K + k) >> 1] = (signed char)((Au[m*K+k] & 0xF) | ((Au[m*K+k+1] & 0xF) << 4));
        for (k = 0; k < K; k++) for (n = 0; n < N; n += 2)
            B[((size_t)k*N + n) >> 1] = (signed char)((Bu[k*N+n] & 0xF) | ((Bu[k*N+n+1] & 0xF) << 4));
        {
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT4);
            cudez_mma_kernel mm; cfg.smem_stage = 5;
            mm = cudez_mma_build(cz, &cfg, "smoke_i4_v7");
            cudez_buffer dA = cudez_buffer_write(cz, A, (size_t)M*K/2);
            cudez_buffer dB = cudez_buffer_write(cz, B, (size_t)K*N/2);
            cudez_buffer dD = cudez_buffer_new(cz, sizeof(int)*M*N);
            cudez_mma_args a; memset(&a, 0, sizeof a);
            a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr;
            a.M = M; a.N = N; a.K = K; a.warps_per_block = 4;
            if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  INT4 v7 launch failed\n"); lb = 1; }
            cudez_finish(cz);
            cudez_read(cz, dD, Dg, sizeof(int)*M*N);
            for (m = 0; m < M && lb < 8; m++) for (n = 0; n < N && lb < 8; n++) {
                int acc = 0; for (k = 0; k < K; k++) acc += (int)Au[m*K+k]*(int)Bu[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  INT4 v7 mismatch (%d,%d): gpu=%d ref=%d\n", m, n, Dg[m*N+n], acc); lb++; }
            }
            cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
        }
        printf("INT4 smem v7     (%dx%dx%d): %s (exact int32)   <== 1.8.0-dev\n", M, N, K, lb ? "FAIL" : "PASS");
        bad += !!lb; total++;
        free(A); free(B); free(Au); free(Bu); free(Dg); free(ref);
    }
    /* ---- INT8 rung 2 (store_hint=1): 128x128x192, exact int32 ---- */
    {
        const int M = 128, N = 128, K = 192;
        signed char *A = (signed char*)malloc((size_t)M*K), *B = (signed char*)malloc((size_t)K*N);
        int *Dg = (int*)malloc(sizeof(int)*M*N);
        int lb = 0;
        for (k = 0; k < M*K; k++) A[k] = (signed char)rnd_range(-4, 4);
        for (k = 0; k < K*N; k++) B[k] = (signed char)rnd_range(-4, 4);
        {
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_INT8);
            cudez_mma_kernel mm; cfg.smem_stage = 5; cfg.store_hint = 1;
            mm = cudez_mma_build(cz, &cfg, "smoke_i8_v7r2");
            cudez_buffer dA = cudez_buffer_write(cz, A, (size_t)M*K);
            cudez_buffer dB = cudez_buffer_write(cz, B, (size_t)K*N);
            cudez_buffer dD = cudez_buffer_new(cz, sizeof(int)*M*N);
            cudez_mma_args a; memset(&a, 0, sizeof a);
            a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr;
            a.M = M; a.N = N; a.K = K; a.warps_per_block = 4;
            if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  INT8 v7r2 launch failed\n"); lb = 1; }
            cudez_finish(cz);
            cudez_read(cz, dD, Dg, sizeof(int)*M*N);
            for (m = 0; m < M && lb < 8; m++) for (n = 0; n < N && lb < 8; n++) {
                int acc = 0; for (k = 0; k < K; k++) acc += (int)A[m*K+k]*(int)B[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  INT8 v7r2 mismatch (%d,%d): gpu=%d ref=%d\n", m, n, Dg[m*N+n], acc); lb++; }
            }
            cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
        }
        printf("INT8 smem v7r2   (%dx%dx%d): %s (exact int32)   <== 1.8.0-dev swizzle + staged epi\n", M, N, K, lb ? "FAIL" : "PASS");
        bad += !!lb; total++;
        free(A); free(B); free(Dg);
    }
    /* ---- 2:4 sparse pipeline: 128x128x96, vs dense f16 host reference ---- */
    {
        const int M = 128, N = 128, K = 96;
        size_t meta_n = (size_t)(M/16) * (K/32) * 32;
        float *Af = (float*)calloc((size_t)M*K, sizeof(float));
        __half *Bh = (__half*)malloc(sizeof(__half)*K*N);
        float *Bf = (float*)malloc(sizeof(float)*K*N);
        float *vals = (float*)malloc(sizeof(float)*M*(K/2));
        __half *valsh = (__half*)malloc(sizeof(__half)*M*(K/2));
        unsigned *meta = (unsigned*)malloc(sizeof(unsigned)*meta_n);
        float *Dg = (float*)malloc(sizeof(float)*M*N);
        float *Zero = (float*)calloc((size_t)M*N, sizeof(float));
        int g2, lb = 0;
        for (m = 0; m < M; m++) for (g2 = 0; g2 < K/4; g2++) {
            int p0 = rnd_range(0,3), p1 = rnd_range(0,3);
            while (p1 == p0) p1 = rnd_range(0,3);
            Af[m*K + g2*4 + p0] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
            Af[m*K + g2*4 + p1] = (float)(rnd_range(0,1) ? rnd_range(1,4) : -rnd_range(1,4));
        }
        for (k = 0; k < K*N; k++) { Bf[k] = (float)rnd_range(-4, 4); Bh[k] = __float2half(Bf[k]); }
        cudez_mma_compress_2to4(Af, M, K, vals, meta);
        for (k = 0; k < M*(K/2); k++) valsh[k] = __float2half(vals[k]);
        {
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
            cudez_mma_kernel mm; cfg.sparse = 1; cfg.smem_stage = 5;
            mm = cudez_mma_build(cz, &cfg, "smoke_sp_v7");
            cudez_buffer dA = cudez_buffer_write(cz, valsh, sizeof(__half)*M*(K/2));
            cudez_buffer dM = cudez_buffer_write(cz, meta, sizeof(unsigned)*meta_n);
            cudez_buffer dB = cudez_buffer_write(cz, Bh, sizeof(__half)*K*N);
            cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float)*M*N);
            cudez_buffer dD = cudez_buffer_new(cz, sizeof(float)*M*N);
            cudez_mma_args a; memset(&a, 0, sizeof a);
            a.A = dA.ptr; a.meta = dM.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
            a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 4;
            if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  SPARSE v7 launch failed\n"); lb = 1; }
            cudez_finish(cz);
            cudez_read(cz, dD, Dg, sizeof(float)*M*N);
            for (m = 0; m < M && lb < 8; m++) for (n = 0; n < N && lb < 8; n++) {
                float acc = 0.f; for (k = 0; k < K; k++) acc += Af[m*K+k]*Bf[k*N+n];
                if (Dg[m*N+n] != acc) { printf("  SPARSE v7 mismatch (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); lb++; }
            }
            cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dM); cudez_buffer_free(cz, dB);
            cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
        }
        printf("F16  sparse v7   (%dx%dx%d): %s (exact, int data)   <== 1.8.0 mma.sp pipeline\n", M, N, K, lb ? "FAIL" : "PASS");
        bad += !!lb; total++;
        {   /* 1.9.0-dev: same data through the 128-tile 3-stage sparse RING */
            cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
            cudez_mma_kernel mm; int rb = 0;
            cfg.sparse = 1; cfg.smem_stage = 7;
            mm = cudez_mma_build(cz, &cfg, "smoke_sp_v9");
            {
                cudez_buffer dA = cudez_buffer_write(cz, valsh, sizeof(__half)*M*(K/2));
                cudez_buffer dM = cudez_buffer_write(cz, meta, sizeof(unsigned)*meta_n);
                cudez_buffer dB = cudez_buffer_write(cz, Bh, sizeof(__half)*K*N);
                cudez_buffer dC = cudez_buffer_write(cz, Zero, sizeof(float)*M*N);
                cudez_buffer dD = cudez_buffer_new(cz, sizeof(float)*M*N);
                cudez_mma_args a; memset(&a, 0, sizeof a);
                a.A = dA.ptr; a.meta = dM.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
                a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f; a.warps_per_block = 16;
                if (cudez_try_mma_launch(cz, &mm, &a) != CUDA_SUCCESS) { printf("  SPARSE v9 launch failed\n"); rb = 1; }
                cudez_finish(cz);
                cudez_read(cz, dD, Dg, sizeof(float)*M*N);
                for (m = 0; m < M && rb < 8; m++) for (n = 0; n < N && rb < 8; n++) {
                    float acc = 0.f; for (k = 0; k < K; k++) acc += Af[m*K+k]*Bf[k*N+n];
                    if (Dg[m*N+n] != acc) { printf("  SPARSE v9 mismatch (%d,%d): gpu=%.1f ref=%.1f\n", m, n, Dg[m*N+n], acc); rb++; }
                }
                cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dM); cudez_buffer_free(cz, dB);
                cudez_buffer_free(cz, dC); cudez_buffer_free(cz, dD);
            }
            printf("F16  sparse v9   (%dx%dx%d): %s (exact, int data)   <== 1.9.0-dev 128-tile ring\n", M, N, K, rb ? "FAIL" : "PASS");
            bad += !!rb; total++;
        }
        free(Af); free(Bf); free(Bh); free(vals); free(valsh); free(meta); free(Dg); free(Zero);
    }
    (void)total;
    return bad;
}

static int smoke_main(int argc, char **argv) {
    int dev = (argc > 1) ? atoi(argv[1]) : 0;
    int fails = 0;
    cudez cz = cudez_boot(dev, 0);
    lcg_reset();   /* standalone-identical operands, even inside `all` */
    cudez_print_device(&cz);
    printf("cudez v%d.%d.%d numerical smoke test\n\n",
           CUDEZ_VERSION_MAJOR, CUDEZ_VERSION_MINOR, CUDEZ_VERSION_PATCH);

    fails += test_f16(&cz);   /* sm_70+ */
    fails += test_f16_smem(&cz); /* sm_70+; 0.8.0 smem pipeline gate */
    if (cz.cc_major >= 8) fails += test_f16_smem_v4(&cz); /* 0.9.0 cp.async pipeline gate */
    else printf("F16  smem v4: SKIPPED (device is sm_%d%d; cp.async needs sm_80+)\n",
                cz.cc_major, cz.cc_minor);
    if (cz.cc_major >= 8) fails += test_f16_smem_v4h(&cz); /* 0.10.0 rung (h) gate */
    else printf("F16  smem v4h: SKIPPED (device is sm_%d%d; pipeline v4 needs sm_80+)\n",
                cz.cc_major, cz.cc_minor);
    if (cz.cc_major >= 8) fails += test_f16_smem_v5(&cz); /* 1.1.0 rung (i) gate */
    else printf("F16  smem v5: SKIPPED (device is sm_%d%d; cp.async needs sm_80+)\n",
                cz.cc_major, cz.cc_minor);
    if (cz.cc_major >= 8) fails += test_f16_smem_v5h(&cz); /* 1.1.0 composition gate */
    if (cz.cc_major >= 8) fails += test_f16_smem_v6(&cz); /* 1.2.0 rung (b) gate */
    if (cz.cc_major >= 8) fails += test_f16_smem_v7(&cz); /* rung (e) gate */
    if (cz.cc_major >= 8) fails += test_f16_smem_v8(&cz); /* 1.4.0-dev rung (f) gate */
    else printf("F16  smem v5h: SKIPPED (device is sm_%d%d; cp.async needs sm_80+)\n",
                cz.cc_major, cz.cc_minor);
    fails += test_gemm(&cz);  /* sm_70+, one-call */
    fails += test_batched_f16(&cz); /* sm_70+, blockIdx.z batched */
    fails += test_cache_identity(&cz);    /* any device: build-only, OPT-3 */
    fails += test_input_validation(&cz);  /* any device: reject-before-launch */

    /* 1.0.3-dev r4: explicit trace markers from here on, added specifically
       to resolve a real diagnostic ambiguity -- a CUDA_ERROR_MISALIGNED_ADDRESS
       at cudez_finish (which every test below calls) doesn't by itself say
       WHICH test's kernel actually faulted; the crash could be in any test
       between here and the end of smoke_main, not necessarily the newest
       code. These markers make the next crash unambiguous: whichever
       "entering ..." line is LAST in the output is the one that faulted. */
    printf("[trace] entering test_int8\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_INT8, 0)) fails += test_int8(&cz);
    else printf("INT8 dense: SKIPPED (device is sm_%d%d; needs sm_80+)\n", cz.cc_major, cz.cc_minor);

    printf("[trace] entering test_int4\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_INT4, 0)) fails += test_int4(&cz);
    else printf("INT4 dense: SKIPPED (device is sm_%d%d; needs sm_80+)\n", cz.cc_major, cz.cc_minor);

    /* Batched BF16/TF32 (0.7.0, BUG-4): the batched dense path for these dtypes,
       numerically diffed for the first time -- both require sm_80+. */
    printf("[trace] entering test_batched_bf16\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_BF16, 0)) fails += test_batched_bf16(&cz);
    else printf("BF16 batched: SKIPPED (device is sm_%d%d; needs sm_80+)\n", cz.cc_major, cz.cc_minor);

    printf("[trace] entering test_batched_tf32\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_TF32, 0)) fails += test_batched_tf32(&cz);
    else printf("TF32 batched: SKIPPED (device is sm_%d%d; needs sm_80+)\n", cz.cc_major, cz.cc_minor);

    printf("[trace] entering test_sparse_f16\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_F16, 1)) fails += test_sparse_f16(&cz);
    printf("[trace] entering test_sparse_bf16\n"); fflush(stdout);
    if (cudez_mma_supported(&cz, CUDEZ_MMA_BF16, 1)) fails += test_sparse_bf16(&cz);
    printf("[trace] entering test_sparse_int8\n"); fflush(stdout);
    if (cz.cc_major >= 8) fails += test_sparse_int8(&cz);  /* 1.0.3-dev: UNVERIFIED kernel,
        see CUDEZ_SPI8_PIPE_SRC_'s doc comment. Gated directly on sm_80+ (cp.async,
        matching this kernel's own contract) rather than cudez_mma_supported, which
        deliberately still returns 0 for (INT8, sparse=1) -- that predicate's contract
        is "works at ANY smem_stage" and this kernel only exists at smem_stage=5. */
    printf("[trace] entering test_pipe18_\n"); fflush(stdout);
    if (cz.cc_major >= 8) fails += test_pipe18_(&cz);  /* 1.8.0-dev: tf32/i4/i8r2/sparse pipelines */
    else printf("F16 2:4 sparse: SKIPPED (device is sm_%d%d; needs sm_80+)\n", cz.cc_major, cz.cc_minor);
    printf("[trace] all tests completed\n"); fflush(stdout);

    printf("\n%s\n", fails ? "*** SOME TESTS FAILED ***" : "All executed tests PASSED.");
    cudez_teardown(&cz);
    return fails ? 1 : 0;
}

/* ==========================================================================
 * Subcommand: bench -- the performance record, harness v2.2
 * (was bench_mma_gpu.c; v2.2 = v2 timing methodology UNCHANGED, plus the
 * v4h/v5/v5h rows for rungs (h)/(i) and the single-binary packaging)
 * ========================================================================== */
/* ---- benchmark plan ---------------------------------------------------- */
#define WARMUP 3
#define ITERS  10
#define MAXTRIALS 15

static int         g_trials    = 3;    /* --trials: timed trials per row/side */
static int         g_only_kind = -1;   /* --only:   -1 = all kinds            */
static int         g_size      = 0;    /* --size:    0 = all sizes            */
static const char *g_csv       = NULL; /* --csv:    per-trial output file     */
static double      g_wall0     = 0.0;  /* monotonic bench-start reference     */
static time_t      g_epoch0    = 0;    /* wall-clock bench start (for logs)   */

static double now_s(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

/* ---- phase clock-drift diagnostic (1.0.3, BUG-C smaller step) ----------
 * BUG-C (CUDEZ.md changelog): phase-A/phase-B ordering under chassis
 * heat-soak can inflate %cuBLAS on long runs, and the fix (an ABAB
 * per-row restructure) is a bigger change than a bug-fix pass should make
 * blind. This is the visibility half first: sample the SM clock/power/temp
 * at the START and END of each phase and print the delta, so a run that IS
 * affected by drift says so directly in the bench output instead of
 * requiring a human to launch cudez_gpumon.sh separately and manually
 * align its timestamps against the "bench start" banner.
 *
 * Reuses the exact nvidia-smi query fields and WSL2 nvidia-smi path
 * fallback cudez_gpumon.sh already uses, so a harness-reported sample and
 * a gpumon.sh sample taken at the same instant should agree. Best-effort:
 * nvidia-smi absence, a WSL2 [N/A] field, or a popen failure all degrade to
 * "no sample" rather than aborting the run -- this is a diagnostic, not a
 * gate. */
typedef struct { int ok; int sm_mhz; double power_w; int temp_c; } cudez_gpu_sample_;

static cudez_gpu_sample_ cudez_sample_gpu_clock_(void) {
    cudez_gpu_sample_ s; FILE *p; char line[256];
    s.ok = 0; s.sm_mhz = 0; s.power_w = 0.0; s.temp_c = 0;
    /* Same field order as cudez_gpumon.sh's FIELDS, minus the columns this
       one-shot sample doesn't need (timestamp, utilization); same WSL2
       fallback path if a bare `nvidia-smi` isn't on PATH. */
    p = popen("nvidia-smi --query-gpu=clocks.sm,power.draw,temperature.gpu "
              "--format=csv,noheader,nounits 2>/dev/null || "
              "/usr/lib/wsl/lib/nvidia-smi --query-gpu=clocks.sm,power.draw,"
              "temperature.gpu --format=csv,noheader,nounits 2>/dev/null", "r");
    if (!p) return s;
    if (fgets(line, sizeof line, p)) {
        int mhz = 0, tempc = 0; double watts = 0.0;
        if (sscanf(line, "%d, %lf, %d", &mhz, &watts, &tempc) == 3) {
            /* BUG-D precedent (1.0.1): WSL2 sensor artifacts can report
               impossible wattage on a small laptop part -- same clamp
               cudez_gpumon.sh applies, so this sample can't be poisoned
               the same way that CSV column already was. */
            s.sm_mhz = mhz;
            s.power_w = (watts > 200.0) ? -1.0 : watts;
            s.temp_c = tempc;
            s.ok = 1;
        }
    }
    pclose(p);
    return s;
}

/* Prints a start/end sample pair for one phase and returns the end sample
   (so bench_main can diff phase A's end against phase B's start -- the
   actual gap BUG-C is about, not either phase's own internal drift, which
   the per-row clock prime already addresses). */
static cudez_gpu_sample_ cudez_report_phase_clock_(const char *phase_label,
                                                    cudez_gpu_sample_ start) {
    cudez_gpu_sample_ end = cudez_sample_gpu_clock_();
    if (start.ok && end.ok) {
        printf("  [clock check] %s: SM %d -> %d MHz", phase_label, start.sm_mhz, end.sm_mhz);
        if (start.power_w >= 0.0 && end.power_w >= 0.0)
            printf(", %.1f -> %.1f W", start.power_w, end.power_w);
        printf(", %d -> %d C\n", start.temp_c, end.temp_c);
        if (start.sm_mhz > 0 && abs(end.sm_mhz - start.sm_mhz) * 100 / start.sm_mhz >= 15)
            printf("  [clock check] WARNING: SM clock moved >=15%% within %s -- "
                   "this phase's own numbers may span more than one clock regime\n",
                   phase_label);
    } else if (!start.ok && !end.ok) {
        printf("  [clock check] %s: nvidia-smi unavailable -- no sample "
               "(run cudez_gpumon.sh alongside this command for a full trace)\n",
               phase_label);
    }
    return end;
}

static int cmp_dbl(const void *a, const void *b) {
    double d = *(const double *)a - *(const double *)b;
    return (d > 0.0) - (d < 0.0);
}

/* Print all trials with their start offsets (for correlation against a
 * live nvidia-smi clock/power log -- see run_bench_with_clocklog.sh) and
 * return the median. This is the 0.8.0 sparse-row diagnostic, promoted to
 * the house rule for every row and every baseline: a single divergent
 * trial stays visible as an outlier instead of silently becoming "the"
 * number, and the committed number is resistant to it. For even trial
 * counts the upper median is used -- prefer odd counts. */
static double commit_trials(const char *side, const double *tr,
                            const double *ts, int n) {
    double s[MAXTRIALS]; int t;
    memcpy(s, tr, sizeof(double) * (size_t)n);
    qsort(s, (size_t)n, sizeof(double), cmp_dbl);
    if (n > 1) {
        printf("    [%s trials:", side);
        for (t = 0; t < n; t++) printf("  +%.1fs %.3f", ts[t], tr[t]);
        printf(" ms -> median %.3f]\n", s[n / 2]);
        fflush(stdout);
    }
    return s[n / 2];
}

typedef enum { KF16, KF16S, KF16S4, KF16S4H, KF16S5, KF16S5H, KF16S6, KF16S7, KF16S8, KF16S9, KF16S10, KBF16, KBF16S7, KBF16S8, KBF16S9, KBF16S10, KTF32, KTF32P, KTF32P9, KI8, KI8P, KI8P2, KI4, KI4P, KSPARSE, KSPARSEP, KSPARSEP9, KF16B8, KF16B8P, KF16B8P9 } bkind;

typedef struct {
    bkind kind; const char *label;
    int M, N, K, batch;          /* batch 1 = single GEMM */
    double cz_ms, cz_tf;         /* cudez result (median of trials) */
    double bl_ms, bl_tf;         /* baseline result (median of trials) */
    double cz_tr[MAXTRIALS], cz_ts[MAXTRIALS]; int cz_ntr; /* per-trial ms + start offsets */
    double bl_tr[MAXTRIALS], bl_ts[MAXTRIALS]; int bl_ntr;
    int cz_ok, bl_ok;            /* row valid flags */
    const char *bl_note;
    const char *bl_lib;          /* which baseline library filled bl_ms/bl_tf */
} brow;

static brow rows[128];   /* 1.5.0: 19 kinds x 4 sizes + batched > 64 -- grown per
                            the box fix; per-shape runs fit either way */
static int  nrows = 0;

static void plan(void) {
    static const int sz[] = { 512, 1024, 2048, 4096 };
    static const struct { bkind k; const char *l; } kinds[] = {
        { KF16,    "F16 dense       " },
        { KF16S,   "F16 smem stage  " },
        { KF16S4,  "F16 smem v4     " },   /* 0.9.0 cp.async pipeline */
        { KF16S4H, "F16 smem v4h    " },   /* 0.10.0 rung (h): v4 + evict-first stores */
        { KF16S5,  "F16 smem v5     " },   /* 1.1.0 rung (i): v4 + L2-aware rasterization */
        { KF16S5H, "F16 smem v5h    " },   /* 1.1.0 rungs (i)+(h) composed */
        { KF16S6,  "F16 smem v6     " },   /* 1.2.0 rung (b): raw ldmatrix + mma.sync */
        { KF16S7,  "F16 smem v7     " },   /* rung (e): v6 + staged float4 epilogue */
        { KF16S8,  "F16 smem v8     " },   /* 1.4.0-dev rung (f): 128x128 block, 16 warps */
        { KF16S9,  "F16 smem v9     " },   /* 1.6.0: v8 + 3-stage cp.async ring (ACCEPTED >=2048) */
        { KF16S10, "F16 smem v10    " },   /* 1.7.0-dev: ring deepened to 4 stages */
        { KBF16,   "BF16 dense      " },
        { KBF16S7, "BF16 smem v7    " },   /* 1.5.0: bf16 on the v7 raw-mma pipeline */
        { KBF16S8, "BF16 smem v8    " },   /* 1.5.0: bf16 on the v8 128x128 pipeline */
        { KBF16S9, "BF16 smem v9    " },   /* 1.6.0: bf16 on the v9 ring pipeline */
        { KBF16S10,"BF16 smem v10   " },   /* 1.7.0-dev: bf16 on the 4-stage ring */
        { KTF32,   "TF32 dense      " },
        { KTF32P,  "TF32 smem v7    " },   /* 1.8.0: tf32 mma on the cp.async pipeline */
        { KTF32P9, "TF32 smem v9    " },   /* 1.10.0-dev: tf32 on the v9-class ring (BK=16) */
        { KI8,     "INT8 dense      " },
        { KI8P,    "INT8 smem v7    " },   /* 1.7.0: s8 mma on the v7-class cp.async pipeline */
        { KI8P2,   "INT8 smem v7r2  " },   /* 1.8.0-dev: + B chunk-swizzle + staged epilogue */
        { KI4,     "INT4 dense      " },
        { KI4P,    "INT4 smem v7    " },   /* 1.8.0-dev: s4 mma on the cp.async pipeline */
        { KSPARSE, "F16 2:4 sparse  " },
        { KSPARSEP,"F16 sparse v7   " },   /* 1.8.0: mma.sp on the cp.async pipeline */
        { KSPARSEP9,"F16 sparse v9  " },   /* 1.9.0-dev: mma.sp on the 128-tile 3-stage ring */
    };
    size_t i, j;
    for (i = 0; i < sizeof kinds / sizeof kinds[0]; i++)
        for (j = 0; j < sizeof sz / sizeof sz[0]; j++) {
            brow *r;
            if (g_only_kind >= 0 && (int)kinds[i].k != g_only_kind) continue;
            if (g_size && sz[j] != g_size) continue;
            if (nrows >= (int)(sizeof rows / sizeof rows[0])) {
                /* AUDIT-5: hard stop BEFORE the write, always on -- an assert
                   would vanish under -DNDEBUG (see AUDIT-3 in cudez.h) */
                fprintf(stderr, "plan(): rows[] full (%d) -- grow the array\n", nrows);
                exit(2);
            }
            r = &rows[nrows++];
            memset(r, 0, sizeof *r);
            r->kind = kinds[i].k; r->label = kinds[i].l;
            r->M = sz[j]; r->N = sz[j]; r->K = sz[j]; r->batch = 1;
        }
    /* strided-batched F16: the 0.6.0 amortization claim, measured */
    for (j = 0; j < 2; j++) {
        brow *r;
        if (g_only_kind >= 0 && g_only_kind != (int)KF16B8) continue;
        if (g_size && sz[j] != g_size) continue;
        if (nrows >= (int)(sizeof rows / sizeof rows[0])) {
            fprintf(stderr, "plan(): rows[] full (%d) -- grow the array\n", nrows);
            exit(2);
        }
        r = &rows[nrows++];
        memset(r, 0, sizeof *r);
        r->kind = KF16B8; r->label = "F16 batched x8  ";
        r->M = sz[j]; r->N = sz[j]; r->K = sz[j]; r->batch = 8;
    }
    /* 1.9.0-dev: the batched row above runs the STREAMING kernel -- but v7/v9
       already carry strides + blockIdx.z natively. These rows measure the
       pipelines doing the exact same batch. */
    for (j = 0; j < 2; j++) {
        if (g_size && sz[j] != g_size) continue;
        if (nrows >= (int)(sizeof rows / sizeof rows[0])) break;
        brow *rb = &rows[nrows++]; memset(rb, 0, sizeof *rb);
        rb->kind = KF16B8P; rb->label = "F16 batchd v7 x8";
        rb->M = sz[j]; rb->N = sz[j]; rb->K = sz[j]; rb->batch = 8;
    }
    for (j = 0; j < 2; j++) {
        if (g_size && sz[j] != g_size) continue;
        if (nrows >= (int)(sizeof rows / sizeof rows[0])) break;
        brow *rb = &rows[nrows++]; memset(rb, 0, sizeof *rb);
        rb->kind = KF16B8P9; rb->label = "F16 batchd v9 x8";
        rb->M = sz[j]; rb->N = sz[j]; rb->K = sz[j]; rb->batch = 8;
    }
}

static int kind_from_token(const char *s) {
    if (!strcmp(s, "f16"))                          return (int)KF16;
    if (!strcmp(s, "smem") || !strcmp(s, "f16s"))   return (int)KF16S;
    if (!strcmp(s, "v4")   || !strcmp(s, "smem2"))  return (int)KF16S4;
    if (!strcmp(s, "v4h")  || !strcmp(s, "hint"))   return (int)KF16S4H;
    if (!strcmp(s, "v5")   || !strcmp(s, "smem3"))  return (int)KF16S5;
    if (!strcmp(s, "v5h"))                          return (int)KF16S5H;
    if (!strcmp(s, "v6")   || !strcmp(s, "smem4"))  return (int)KF16S6;
    if (!strcmp(s, "v7")   || !strcmp(s, "smem5"))  return (int)KF16S7;
    if (!strcmp(s, "v8")   || !strcmp(s, "smem6"))  return (int)KF16S8;
    if (!strcmp(s, "v9")   || !strcmp(s, "smem7"))  return (int)KF16S9;
    if (!strcmp(s, "v10")  || !strcmp(s, "smem8"))  return (int)KF16S10;
    if (!strcmp(s, "bf16"))                         return (int)KBF16;
    if (!strcmp(s, "bf16v7"))                       return (int)KBF16S7;
    if (!strcmp(s, "bf16v8"))                        return (int)KBF16S8;
    if (!strcmp(s, "bf16v9"))                        return (int)KBF16S9;
    if (!strcmp(s, "bf16v10"))                       return (int)KBF16S10;
    if (!strcmp(s, "tf32"))                         return (int)KTF32;
    if (!strcmp(s, "int8"))                         return (int)KI8;
    if (!strcmp(s, "int8v7") || !strcmp(s, "i8p"))  return (int)KI8P;
    if (!strcmp(s, "int8v7r2") || !strcmp(s, "i8p2")) return (int)KI8P2;
    if (!strcmp(s, "tf32v7"))                       return (int)KTF32P;
    if (!strcmp(s, "tf32v9"))                       return (int)KTF32P9;
    if (!strcmp(s, "int4v7"))                       return (int)KI4P;
    if (!strcmp(s, "sparsev7"))                     return (int)KSPARSEP;
    if (!strcmp(s, "sparsev9"))                     return (int)KSPARSEP9;
    if (!strcmp(s, "int4"))                         return (int)KI4;
    if (!strcmp(s, "sparse"))                       return (int)KSPARSE;
    if (!strcmp(s, "batched"))                      return (int)KF16B8;
    if (!strcmp(s, "batchedv7"))                    return (int)KF16B8P;
    if (!strcmp(s, "batchedv9"))                    return (int)KF16B8P9;
    return -2;
}

static double row_flops(const brow *r) {           /* dense-equivalent */
    return 2.0 * r->M * r->N * r->K * r->batch;
}

/* ---- shared host operands (filled once at max shape) ------------------- */
#define MAXE (4096u * 4096u)          /* max elements of one operand */
/* (rnd_range/g_lcg: shared, top of file -- re-seeded per subcommand) */

static float         *hF;      /* floats (TF32 inputs, sparse compress src) */
static __half        *hH;      /* halves */
static __nv_bfloat16 *hB;      /* bfloat16 */
static signed char   *hI;      /* int8 / packed int4 bytes */

static void fill_hosts(void) {
    size_t i;
    hF = (float *)malloc(sizeof(float) * MAXE);
    hH = (__half *)malloc(sizeof(__half) * MAXE);
    hB = (__nv_bfloat16 *)malloc(sizeof(__nv_bfloat16) * MAXE);
    hI = (signed char *)malloc(MAXE);
    for (i = 0; i < MAXE; i++) {
        float v = (float)rnd_range(-4, 4);
        hF[i] = v; hH[i] = __float2half(v); hB[i] = __float2bfloat16(v);
        hI[i] = (signed char)rnd_range(-8, 7);
    }
}

/* ================= Phase A: cudez (driver API) ========================== */
static double time_cudez(cudez *cz, cudez_mma_kernel *mm, cudez_mma_args *a) {
    CUevent e0, e1; float ms = 0.0f; int it;
    cuEventCreate(&e0, CU_EVENT_DEFAULT); cuEventCreate(&e1, CU_EVENT_DEFAULT);
    for (it = 0; it < WARMUP; it++)
        if (cudez_try_mma_launch(cz, mm, a) != CUDA_SUCCESS) return -1.0;
    cuEventRecord(e0, cz->stream);
    for (it = 0; it < ITERS; it++)
        if (cudez_try_mma_launch(cz, mm, a) != CUDA_SUCCESS) return -1.0;
    cuEventRecord(e1, cz->stream);
    cuEventSynchronize(e1);
    cuEventElapsedTime(&ms, e0, e1);
    cuEventDestroy(e0); cuEventDestroy(e1);
    return (double)ms / ITERS;
}

/* g_trials independent trials of (WARMUP + ITERS), median committed.
   bench v2.3: before the trial loop, PRIME THE CLOCK -- run the kernel untimed
   in sync'd batches until g_prime_ms of sustained load has elapsed. Evidence
   (run 1784078804, gpumon): on laptop/WSL2 the DVFS governor seesawed 210-1425
   MHz through phase A (idle gaps from per-row NVRTC builds) while phase B's
   back-to-back cuBLAS rows ran committed at 1695 MHz / 80 W -- a 2.3x confound
   in a single run, both directions. Priming gives every row a committed clock.
   The TIMED methodology (3 warmup + 10 iters, median of trials) is UNCHANGED
   from v2.2, so primed numbers remain directly comparable. CUDEZ_PRIME_MS
   overrides (0 disables = exact v2.2 behavior). */
static double g_prime_ms = 300.0;
static void prime_clock_cz_(cudez *cz, cudez_mma_kernel *mm, cudez_mma_args *a) {
    double t0 = now_s(); int it = 0;
    if (g_prime_ms <= 0.0) return;
    while ((now_s() - t0) * 1000.0 < g_prime_ms && it < 5000) {
        int b;
        for (b = 0; b < WARMUP; b++, it++)
            if (cudez_try_mma_launch(cz, mm, a) != CUDA_SUCCESS) return;
        cuStreamSynchronize(cz->stream);
    }
}
static double cz_trials(cudez *cz, cudez_mma_kernel *mm, cudez_mma_args *a,
                        brow *r) {
    int t;
    prime_clock_cz_(cz, mm, a);
    for (t = 0; t < g_trials; t++) {
        r->cz_ts[t] = now_s() - g_wall0;
        r->cz_tr[t] = time_cudez(cz, mm, a);
        if (r->cz_tr[t] < 0.0) { r->cz_ntr = 0; return -1.0; }
    }
    r->cz_ntr = g_trials;
    return commit_trials("cudez", r->cz_tr, r->cz_ts, g_trials);
}

/* Runs cudez's own kernel(s) for exactly one row, byte-for-byte the same
   logic phase_cudez's loop body used to contain (1.0.3 ABAB restructure:
   factored out so a combined per-row loop can call this immediately
   followed by bench_row_cublas_ for the SAME row, instead of every cudez
   row running to completion before any cuBLAS row starts). */
static void bench_row_cudez_(cudez *cz, brow *r) {
    int M = r->M, N = r->N, K = r->K, sm80 = (cz->cc_major >= 8);
    cudez_mma_args a; memset(&a, 0, sizeof a);
    a.M = M; a.N = N; a.K = K; a.alpha = 1.0f; a.beta = 0.0f;
    a.warps_per_block = 4;

    if (r->kind != KF16 && r->kind != KF16S && r->kind != KF16B8 && !sm80) { r->cz_ok = 0; return; }
    if ((r->kind == KF16S4 || r->kind == KF16S4H ||
         r->kind == KF16S5 || r->kind == KF16S5H ||
         r->kind == KF16S6 || r->kind == KF16S7 ||
         r->kind == KF16S8 || r->kind == KF16S9 || r->kind == KF16S10 ||
         r->kind == KBF16S7 || r->kind == KBF16S8 || r->kind == KBF16S9 ||
         r->kind == KBF16S10 || r->kind == KI8P || r->kind == KI8P2 ||
         r->kind == KTF32P || r->kind == KI4P || r->kind == KSPARSEP ||
         r->kind == KSPARSEP9 || r->kind == KF16B8P || r->kind == KF16B8P9 ||
         r->kind == KTF32P9) && !sm80) { r->cz_ok = 0; return; }  /* cp.async is sm_80+ */

    if (r->kind == KF16 || r->kind == KF16S || r->kind == KF16S4 ||
        r->kind == KF16S4H || r->kind == KF16S5 || r->kind == KF16S5H ||
        r->kind == KF16S6 || r->kind == KF16S7 || r->kind == KF16S8 ||
        r->kind == KF16S9 || r->kind == KF16S10 || r->kind == KBF16S7 ||
        r->kind == KBF16S8 || r->kind == KBF16S9 || r->kind == KBF16S10 ||
        r->kind == KBF16 || r->kind == KTF32 || r->kind == KTF32P || r->kind == KTF32P9 || r->kind == KF16B8 ||
        r->kind == KF16B8P || r->kind == KF16B8P9) {
        cudez_mma_dtype dt = (r->kind == KBF16 || r->kind == KBF16S7 || r->kind == KBF16S8 || r->kind == KBF16S9 || r->kind == KBF16S10) ? CUDEZ_MMA_BF16
                           : (r->kind == KTF32 || r->kind == KTF32P || r->kind == KTF32P9) ? CUDEZ_MMA_TF32 : CUDEZ_MMA_F16;
        size_t es = (r->kind == KTF32 || r->kind == KTF32P || r->kind == KTF32P9) ? sizeof(float) : 2;
        const void *src = (r->kind == KTF32 || r->kind == KTF32P || r->kind == KTF32P9) ? (void *)hF
                        : (r->kind == KBF16 || r->kind == KBF16S7 || r->kind == KBF16S8 || r->kind == KBF16S9 || r->kind == KBF16S10) ? (void *)hB : (void *)hH;
        size_t eA = (size_t)M * K * r->batch, eB = (size_t)K * N * r->batch;
        /* batch>1 reuses the same operand block per element via packed
           strides over a buffer sized batch*single (contents irrelevant
           for timing; addresses are what matter) */
        void *bigA = malloc(es * eA), *bigB = malloc(es * eB);
        int b;
        for (b = 0; b < r->batch; b++) {
            memcpy((char *)bigA + es * (size_t)M * K * b, src, es * (size_t)M * K);
            memcpy((char *)bigB + es * (size_t)K * N * b, src, es * (size_t)K * N);
        }
        cudez_mma_config cfg = cudez_mma_defaults(dt);
        if (r->kind == KF16S)  cfg.smem_stage = 1;  /* 0.8.0 pipeline v3 */
        if (r->kind == KF16S4) cfg.smem_stage = 2;  /* 0.9.0 pipeline v4 */
        if (r->kind == KF16S4H) { cfg.smem_stage = 2; cfg.store_hint = 1; }  /* 0.10.0 rung (h) */
        if (r->kind == KF16S5)  cfg.smem_stage = 3;  /* 1.1.0 rung (i) pipeline v5 */
        if (r->kind == KF16S5H) { cfg.smem_stage = 3; cfg.store_hint = 1; }  /* rungs (i)+(h) */
        if (r->kind == KF16S6)  cfg.smem_stage = 4;  /* 1.2.0 rung (b) pipeline v6 */
        if (r->kind == KF16S7)  cfg.smem_stage = 5;  /* rung (e) pipeline v7 */
        if (r->kind == KF16S8) { cfg.smem_stage = 6; a.warps_per_block = 16; }  /* 1.4.0-dev rung (f) pipeline v8: 128x128 block */
        if (r->kind == KF16S9) { cfg.smem_stage = 7; a.warps_per_block = 16; }  /* 1.5.0-dev pipeline v9: v8 + 3-stage ring (dyn smem) */
        if (r->kind == KBF16S7)  cfg.smem_stage = 5;  /* 1.5.0 bf16 on v7 */
        if (r->kind == KBF16S8) { cfg.smem_stage = 6; a.warps_per_block = 16; }  /* 1.5.0 bf16 on v8 */
        if (r->kind == KBF16S9) { cfg.smem_stage = 7; a.warps_per_block = 16; }  /* 1.6.0 bf16 on v9 */
        if (r->kind == KF16S10)  { cfg.smem_stage = 8; a.warps_per_block = 16; }  /* 1.7.0-dev v10: 4-stage ring */
        if (r->kind == KBF16S10) { cfg.smem_stage = 8; a.warps_per_block = 16; }  /* bf16 on v10 (opt-in) */
        if (r->kind == KTF32P)     cfg.smem_stage = 5;  /* 1.8.0 tf32 pipeline */
        if (r->kind == KTF32P9)  { cfg.smem_stage = 7; a.warps_per_block = 16; }  /* 1.10.0-dev ring */
        if (r->kind == KF16B8P)    cfg.smem_stage = 5;  /* 1.9.0-dev batched on v7 */
        if (r->kind == KF16B8P9) { cfg.smem_stage = 7; a.warps_per_block = 16; }  /* batched on v9 */
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "bench");
        cudez_buffer dA = cudez_buffer_write(cz, bigA, es * eA);
        cudez_buffer dB = cudez_buffer_write(cz, bigB, es * eB);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(float) * (size_t)M * N * r->batch);
        a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr;
        if (r->batch > 1) a.batch_count = r->batch;
        r->cz_ms = cz_trials(cz, &mm, &a, r);
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
        free(bigA); free(bigB);
    } else if (r->kind == KI8 || r->kind == KI8P || r->kind == KI8P2 ||
               r->kind == KI4 || r->kind == KI4P) {
        cudez_mma_config cfg = cudez_mma_defaults(
            (r->kind == KI4 || r->kind == KI4P) ? CUDEZ_MMA_INT4 : CUDEZ_MMA_INT8);
        if (r->kind == KI8P || r->kind == KI8P2 || r->kind == KI4P) cfg.smem_stage = 5;
        if (r->kind == KI8P2) cfg.store_hint = 1;  /* rung 2: swizzle + staged epi */
        cudez_mma_kernel mm = cudez_mma_build(cz, &cfg, "bench");
        size_t bA = (r->kind != KI4 && r->kind != KI4P) ? (size_t)M * K : (size_t)M * K / 2;
        size_t bB = (r->kind != KI4 && r->kind != KI4P) ? (size_t)K * N : (size_t)K * N / 2;
        cudez_buffer dA = cudez_buffer_write(cz, hI, bA);
        cudez_buffer dB = cudez_buffer_write(cz, hI, bB);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(int) * (size_t)M * N);
        a.A = dA.ptr; a.B = dB.ptr; a.D = dD.ptr;
        r->cz_ms = cz_trials(cz, &mm, &a, r);
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
    } else { /* KSPARSE */
        float    *vals = (float *)malloc(sizeof(float) * (size_t)M * (K / 2));
        __half   *vh   = (__half *)malloc(sizeof(__half) * (size_t)M * (K / 2));
        size_t    mn   = (size_t)(M / 16) * (K / 32) * 32;
        unsigned *meta = (unsigned *)malloc(sizeof(unsigned) * mn);
        size_t j;
        /* hF is not 2:4; prune-compress handles that (keeps top-2 per
           group) -- timing needs valid structure, not pretty data */
        cudez_mma_compress_2to4(hF, M, K, vals, meta);
        for (j = 0; j < (size_t)M * (K / 2); j++) vh[j] = __float2half(vals[j]);
        cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16); cfg.sparse = 1;
        if (r->kind == KSPARSEP)  cfg.smem_stage = 5;   /* 1.8.0 pipelined mma.sp */
        if (r->kind == KSPARSEP9) cfg.smem_stage = 7;   /* 1.9.0-dev 128-tile ring */
        cudez_mma_kernel mm  = cudez_mma_build(cz, &cfg, "bench");
        cudez_buffer dA = cudez_buffer_write(cz, vh, sizeof(__half) * (size_t)M * (K / 2));
        cudez_buffer dM = cudez_buffer_write(cz, meta, sizeof(unsigned) * mn);
        cudez_buffer dB = cudez_buffer_write(cz, hH, sizeof(__half) * (size_t)K * N);
        cudez_buffer dD = cudez_buffer_new(cz, sizeof(float) * (size_t)M * N);
        a.A = dA.ptr; a.meta = dM.ptr; a.B = dB.ptr; a.D = dD.ptr;
        a.warps_per_block = (r->kind == KSPARSEP9) ? 16 : 4;   /* ring is 16-warp */
        /* KSPARSE at 1024^3 showed an unexplained dip in an earlier run
           (cudez.h's grid math rules out the known smem_stage-style
           wave-quantization cause for THIS kernel: 1024^2/16^2/4 = 1024
           blocks here, plenty deep). The 3-trial diagnostic that lived
           here caught single divergent third-trials at 1024^3/4096^3 --
           opposite directions, same run -- pointing at boost-clock/
           power-state transitions on the 55 W part, not the shapes. In
           harness v2 that diagnostic (multi-trial + median + printed
           start offsets) is the default for EVERY row via cz_trials();
           correlate outliers with run_bench_with_clocklog.sh. */
        r->cz_ms = cz_trials(cz, &mm, &a, r);
        cudez_buffer_free(cz, dA); cudez_buffer_free(cz, dM);
        cudez_buffer_free(cz, dB); cudez_buffer_free(cz, dD);
        free(vals); free(vh); free(meta);
    }
    r->cz_ok = (r->cz_ms > 0.0);
    if (r->cz_ok) r->cz_tf = row_flops(r) / (r->cz_ms * 1e-3) / 1e12;
    printf("  %s %4dx%4dx%4d%s : %s\n", r->label, r->M, r->N, r->K,
           r->batch > 1 ? " x8" : "   ",
           r->cz_ok ? "timed" : "SKIPPED/FAILED");
    fflush(stdout);
}


/* ================= Phase B: cuBLAS baseline (runtime API) =============== */
#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { \
    printf("cuda rt error: %s\n", cudaGetErrorString(e_)); exit(1); } } while (0)

static double time_cublas(int iters_ok, void (*fn)(void *), void *ctx) {
    cudaEvent_t e0, e1; float ms = 0.0f; int it;
    if (!iters_ok) return -1.0;
    CK(cudaEventCreate(&e0)); CK(cudaEventCreate(&e1));
    for (it = 0; it < WARMUP; it++) fn(ctx);
    CK(cudaEventRecord(e0, 0));
    for (it = 0; it < ITERS; it++) fn(ctx);
    CK(cudaEventRecord(e1, 0));
    CK(cudaEventSynchronize(e1));
    CK(cudaEventElapsedTime(&ms, e0, e1));
    cudaEventDestroy(e0); cudaEventDestroy(e1);
    return (double)ms / ITERS;
}

typedef struct {
    cublasHandle_t h; brow *r;
    void *A, *B, *C; cublasStatus_t st;
} blctx;

static void bl_gemm(void *p) {
    blctx *c = (blctx *)p; brow *r = c->r;
    float onef = 1.0f, zerof = 0.0f; int onei = 1, zeroi = 0;
    /* row-major C = A*B via column-major (B^T A^T): swap operands, n first */
    switch (r->kind) {
    case KF16: case KF16S: case KF16S4: case KF16S4H: case KF16S5: case KF16S5H: case KF16S6: case KF16S7: case KF16S8: case KF16S9: case KF16S10:
        c->st = cublasGemmEx(c->h, CUBLAS_OP_N, CUBLAS_OP_N, r->N, r->M, r->K,
            &onef, c->B, CUDA_R_16F, r->N, c->A, CUDA_R_16F, r->K,
            &zerof, c->C, CUDA_R_32F, r->N, CUBLAS_COMPUTE_32F,
            CUBLAS_GEMM_DEFAULT); break;
    case KBF16: case KBF16S7: case KBF16S8: case KBF16S9: case KBF16S10:
        c->st = cublasGemmEx(c->h, CUBLAS_OP_N, CUBLAS_OP_N, r->N, r->M, r->K,
            &onef, c->B, CUDA_R_16BF, r->N, c->A, CUDA_R_16BF, r->K,
            &zerof, c->C, CUDA_R_32F, r->N, CUBLAS_COMPUTE_32F,
            CUBLAS_GEMM_DEFAULT); break;
    case KTF32: case KTF32P: case KTF32P9:
        c->st = cublasGemmEx(c->h, CUBLAS_OP_N, CUBLAS_OP_N, r->N, r->M, r->K,
            &onef, c->B, CUDA_R_32F, r->N, c->A, CUDA_R_32F, r->K,
            &zerof, c->C, CUDA_R_32F, r->N, CUBLAS_COMPUTE_32F_FAST_TF32,
            CUBLAS_GEMM_DEFAULT); break;
    case KI8: case KI8P: case KI8P2:
        c->st = cublasGemmEx(c->h, CUBLAS_OP_N, CUBLAS_OP_N, r->N, r->M, r->K,
            &onei, c->B, CUDA_R_8I, r->N, c->A, CUDA_R_8I, r->K,
            &zeroi, c->C, CUDA_R_32I, r->N, CUBLAS_COMPUTE_32I,
            CUBLAS_GEMM_DEFAULT); break;
    case KF16B8: case KF16B8P: case KF16B8P9:
        c->st = cublasGemmStridedBatchedEx(c->h, CUBLAS_OP_N, CUBLAS_OP_N,
            r->N, r->M, r->K,
            &onef, c->B, CUDA_R_16F, r->N, (long long)r->K * r->N,
                   c->A, CUDA_R_16F, r->K, (long long)r->M * r->K,
            &zerof, c->C, CUDA_R_32F, r->N, (long long)r->M * r->N,
            r->batch, CUBLAS_COMPUTE_32F, CUBLAS_GEMM_DEFAULT); break;
    default: c->st = CUBLAS_STATUS_NOT_SUPPORTED; break;
    }
}

/* Runs cuBLAS's baseline for exactly one row, byte-for-byte the same logic
   phase_cublas's loop body used to contain (1.0.3 ABAB restructure). h and
   the d* operand buffers are the shared, once-per-run setup phase_cublas
   used to own directly; now passed in so a combined loop can call this
   immediately after bench_row_cudez_ for the SAME row. */
static void bench_row_cublas_(cublasHandle_t h, void *dH, void *dB16,
                              void *dF, void *dI, void *dC, brow *r) {
    blctx c; c.h = h; c.r = r; c.st = CUBLAS_STATUS_SUCCESS;
    switch (r->kind) {
    case KF16: case KF16S: case KF16S4: case KF16S4H: case KF16S5: case KF16S5H: case KF16S6: case KF16S7: case KF16S8: case KF16S9: case KF16S10: case KF16B8: case KF16B8P: case KF16B8P9:
                            c.A = dH;   c.B = dH;   c.C = dC; break;
    case KBF16: case KBF16S7: case KBF16S8: case KBF16S9: case KBF16S10:
                            c.A = dB16; c.B = dB16; c.C = dC; break;
    case KTF32: case KTF32P: case KTF32P9:             c.A = dF;   c.B = dF;   c.C = dC; break;
    case KI8: case KI8P: case KI8P2: c.A = dI; c.B = dI; c.C = dC; break;
    case KI4: case KI4P: r->bl_note = "no cuBLAS/cuSPARSELt equiv -- see CUTLASS profiler note"; return;
#ifndef CUDEZ_TEST_NO_CUSPARSELT
    case KSPARSE: case KSPARSEP: case KSPARSEP9: r->bl_note = "pending: filled by Phase C (cuSPARSELt)"; return;
#else
    case KSPARSE: r->bl_note = "no baseline in this build (-DCUDEZ_TEST_NO_CUSPARSELT)"; return;
#endif
    default: r->bl_note = "no cuBLAS equivalent"; return;
    }
    bl_gemm(&c);                    /* probe call: supported combo? */
    CK(cudaDeviceSynchronize());
    if (c.st != CUBLAS_STATUS_SUCCESS) {
        r->bl_note = "cuBLAS combo unsupported"; return;
    }
    {
        int t, bad = 0;
        /* bench v2.3: same per-row clock prime as phase A, so both sides
           of every ratio are measured at a committed clock. */
        if (g_prime_ms > 0.0) {
            double t0 = now_s(); int it = 0;
            while ((now_s() - t0) * 1000.0 < g_prime_ms && it < 5000) {
                int b;
                for (b = 0; b < WARMUP; b++, it++) bl_gemm(&c);
                CK(cudaDeviceSynchronize());
            }
        }
        for (t = 0; t < g_trials; t++) {
            r->bl_ts[t] = now_s() - g_wall0;
            r->bl_tr[t] = time_cublas(1, bl_gemm, &c);
            if (r->bl_tr[t] < 0.0) { bad = 1; break; }
        }
        if (!bad) {
            r->bl_ntr = g_trials;
            r->bl_ms = commit_trials("cuBLAS", r->bl_tr, r->bl_ts, g_trials);
        } else r->bl_ms = -1.0;
    }
    r->bl_ok = (r->bl_ms > 0.0);
    if (r->bl_ok) { r->bl_tf = row_flops(r) / (r->bl_ms * 1e-3) / 1e12; r->bl_lib = "cuBLAS"; }
}


#ifndef CUDEZ_TEST_NO_CUSPARSELT
/* ================= Phase C: cuSPARSELt baseline (sparse rows only) ====== *
 * Independent of cudez's own 2:4 kernel: builds a fresh dense F16 operand,
 * lets cuSPARSELt prune + compress it with ITS OWN format, and times ITS
 * OWN cusparseLtMatmul. Nothing here reuses cudez's compressed A/metadata
 * buffers -- that would just be timing cudez against itself.
 *
 * API calls and workflow order below follow the current cuSPARSELt Getting
 * Started guide (docs.nvidia.com/cuda/cusparselt/getting_started.html) as
 * of this writing. cuSPARSELt's compute-type enum name for the FP16-in/
 * FP32-accumulate combination has shifted across library releases -- if
 * CUSPARSE_COMPUTE_32F does not match your installed cusparseLt.h, grep it
 * for the enumerator next to "FP16 ... FP32" in cusparseLtComputetype_t (or
 * equivalent) and swap it in; that is a version skew, not a design error.
 *
 * Confirmed against cuSPARSELt 0.7.0.0: cusparseLtSpMMACompressedSize() and
 * cusparseLtSpMMACompress() both take an extra user-managed scratch buffer
 * (compressBufferSize / d_compressed_buffer) that older (<=0.3.x) docs and
 * blog samples don't show -- 0.4.0 added it "to avoid internal memory
 * allocations." If you're on an older or newer cuSPARSELt and the compiler
 * complains about these two calls again, that's what changed; drop or add
 * the buffer arg to match your installed cusparseLt.h rather than reverting
 * to the old two/four-arg form. */
#define CSK(x) do { cusparseStatus_t s_ = (x); if (s_ != CUSPARSE_STATUS_SUCCESS) { \
    printf("cusparseLt error %d at %s:%d -- skipping this row\n", (int)s_, __FILE__, __LINE__); \
    goto row_done; } } while (0)

static void phase_cusparselt(int dev) {
    cusparseLtHandle_t handle;
    int i, have_handle;
    CK(cudaSetDevice(dev));
    if (cusparseLtInit(&handle) != CUSPARSE_STATUS_SUCCESS) {
        printf("\nphase C: cusparseLtInit failed -- sparse baseline column stays empty\n");
        printf("  (missing/incompatible cuSPARSELt install, or GPU below SM 8.0)\n");
        return;
    }
    have_handle = 1;
    printf("\nphase C: cuSPARSELt baseline (%d warmup + %d timed iters, sparse rows only)\n\n",
           WARMUP, ITERS);

    for (i = 0; i < nrows; i++) {
        brow *r = &rows[i];
        if (r->kind != KSPARSE && r->kind != KSPARSEP && r->kind != KSPARSEP9) continue;
        {
        int M = r->M, N = r->N, K = r->K;
        __half *dA = NULL, *dB = NULL, *dC = NULL, *dA_compressed = NULL;
        void *d_workspace = NULL, *d_compress_buffer = NULL;
        size_t compressed_size = 0, compress_buffer_size = 0, workspace_size = 0;
        cusparseLtMatDescriptor_t matA, matB, matC;
        cusparseLtMatmulDescriptor_t matmul;
        cusparseLtMatmulAlgSelection_t alg_sel;
        cusparseLtMatmulPlan_t plan;
        int plan_ok = 0, dvalid = 0, *d_valid = NULL;
        float alpha = 1.0f, beta = 0.0f;
        cudaEvent_t e0, e1; float ms_total = 0.0f; int it;

        CK(cudaMalloc((void **)&dA, sizeof(__half) * (size_t)M * K));
        CK(cudaMalloc((void **)&dB, sizeof(__half) * (size_t)K * N));
        CK(cudaMalloc((void **)&dC, sizeof(__half) * (size_t)M * N));
        /* reuse the same pseudo-random host fill used everywhere else --
           cuSPARSELt prunes it to 2:4 itself, exactly like a real caller
           handing it an arbitrary dense weight matrix */
        CK(cudaMemcpy(dA, hH, sizeof(__half) * (size_t)M * K, cudaMemcpyHostToDevice));
        CK(cudaMemcpy(dB, hH, sizeof(__half) * (size_t)K * N, cudaMemcpyHostToDevice));

        CSK(cusparseLtStructuredDescriptorInit(&handle, &matA, M, K, K, 16,
                CUDA_R_16F, CUSPARSE_ORDER_ROW, CUSPARSELT_SPARSITY_50_PERCENT));
        CSK(cusparseLtDenseDescriptorInit(&handle, &matB, K, N, N, 16,
                CUDA_R_16F, CUSPARSE_ORDER_ROW));
        CSK(cusparseLtDenseDescriptorInit(&handle, &matC, M, N, N, 16,
                CUDA_R_16F, CUSPARSE_ORDER_ROW));
        CSK(cusparseLtMatmulDescriptorInit(&handle, &matmul,
                CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                &matA, &matB, &matC, &matC, CUSPARSE_COMPUTE_32F));
        CSK(cusparseLtMatmulAlgSelectionInit(&handle, &alg_sel, &matmul,
                CUSPARSELT_MATMUL_ALG_DEFAULT));
        CSK(cusparseLtMatmulPlanInit(&handle, &plan, &matmul, &alg_sel));
        plan_ok = 1;

        /* Diagnostic, not required for correctness: read back whatever
           algorithm/split-K state is on alg_sel after plan init, so a
           shape-to-shape swing in timing (e.g. one size looking unusually
           fast or slow relative to its neighbors) can be checked against a
           real mechanism -- split-K parallelizing K differently per shape
           -- instead of shrugged off as clock/thermal noise. If these
           numbers are IDENTICAL across all four shapes, split-K is not the
           explanation for any such swing and the cause is elsewhere
           (measurement noise, GPU power state, etc). */
        {
            int32_t alg_id = -1, split_k = -1, split_k_mode = -1;
            cusparseLtMatmulAlgGetAttribute(&handle, &alg_sel,
                CUSPARSELT_MATMUL_ALG_CONFIG_ID, &alg_id, sizeof(alg_id));
            cusparseLtMatmulAlgGetAttribute(&handle, &alg_sel,
                CUSPARSELT_MATMUL_SPLIT_K, &split_k, sizeof(split_k));
            cusparseLtMatmulAlgGetAttribute(&handle, &alg_sel,
                CUSPARSELT_MATMUL_SPLIT_K_MODE, &split_k_mode, sizeof(split_k_mode));
            printf("    [alg_id=%d split_k=%d split_k_mode=%d]\n",
                   alg_id, split_k, split_k_mode);
        }

        CSK(cusparseLtSpMMAPrune(&handle, &matmul, dA, dA, CUSPARSELT_PRUNE_SPMMA_TILE, 0));
        CK(cudaMalloc((void **)&d_valid, sizeof(int)));
        CSK(cusparseLtSpMMAPruneCheck(&handle, &matmul, dA, d_valid, 0));
        CK(cudaMemcpy(&dvalid, d_valid, sizeof(int), cudaMemcpyDeviceToHost));
        if (dvalid != 0) {
            printf("  F16 2:4 sparse   %4dx%4dx%4d    : cuSPARSELt prune-check failed "
                   "(library/driver mismatch?) -- skipped\n", M, N, K);
            goto row_done;
        }

        CSK(cusparseLtSpMMACompressedSize(&handle, &plan, &compressed_size, &compress_buffer_size));
        CK(cudaMalloc((void **)&dA_compressed, compressed_size));
        if (compress_buffer_size) CK(cudaMalloc(&d_compress_buffer, compress_buffer_size));
        CSK(cusparseLtSpMMACompress(&handle, &plan, dA, dA_compressed, d_compress_buffer, 0));

        CSK(cusparseLtMatmulGetWorkspace(&handle, &plan, &workspace_size));
        if (workspace_size) CK(cudaMalloc(&d_workspace, workspace_size));

        /* probe once before timing, same discipline as the cuBLAS phase */
        CSK(cusparseLtMatmul(&handle, &plan, &alpha, dA_compressed, dB, &beta,
                dC, dC, d_workspace, NULL, 0));
        CK(cudaDeviceSynchronize());

        /* Trial parity with cudez's sparse row (0.8.0 handoff open item 1):
           g_trials independent trials, each WARMUP untimed + ITERS timed,
           median committed. The 1024^3 spike (36.99 TF) had reproduced
           within 1.6% across two full runs but on ONE timed sample each --
           now it gets the same outlier-visible treatment as everything
           else. */
        {
            int t;
            for (t = 0; t < g_trials; t++) {
                r->bl_ts[t] = now_s() - g_wall0;
                CK(cudaEventCreate(&e0)); CK(cudaEventCreate(&e1));
                for (it = 0; it < WARMUP; it++)
                    cusparseLtMatmul(&handle, &plan, &alpha, dA_compressed, dB, &beta,
                                      dC, dC, d_workspace, NULL, 0);
                CK(cudaEventRecord(e0, 0));
                for (it = 0; it < ITERS; it++)
                    cusparseLtMatmul(&handle, &plan, &alpha, dA_compressed, dB, &beta,
                                      dC, dC, d_workspace, NULL, 0);
                CK(cudaEventRecord(e1, 0));
                CK(cudaEventSynchronize(e1));
                CK(cudaEventElapsedTime(&ms_total, e0, e1));
                cudaEventDestroy(e0); cudaEventDestroy(e1);
                r->bl_tr[t] = (double)ms_total / ITERS;
            }
            r->bl_ntr = g_trials;
            r->bl_ms = commit_trials("cuSPARSELt", r->bl_tr, r->bl_ts, g_trials);
        }
        r->bl_ok = (r->bl_ms > 0.0);
        if (r->bl_ok) {
            r->bl_tf = row_flops(r) / (r->bl_ms * 1e-3) / 1e12;   /* dense-equivalent, same convention as cudez's own sparse row */
            r->bl_lib = "cuSPARSELt";
            r->bl_note = NULL;
        }
        printf("  F16 2:4 sparse   %4dx%4dx%4d    : cuSPARSELt timed\n", M, N, K);

row_done:
        if (plan_ok) {
            cusparseLtMatDescriptorDestroy(&matA);
            cusparseLtMatDescriptorDestroy(&matB);
            cusparseLtMatDescriptorDestroy(&matC);
            cusparseLtMatmulPlanDestroy(&plan);
        }
        if (dA) cudaFree(dA);
        if (dB) cudaFree(dB);
        if (dC) cudaFree(dC);
        if (dA_compressed) cudaFree(dA_compressed);
        if (d_compress_buffer) cudaFree(d_compress_buffer);
        if (d_workspace) cudaFree(d_workspace);
        if (d_valid) cudaFree(d_valid);
        }
    }
    if (have_handle) cusparseLtDestroy(&handle);
}
#else  /* CUDEZ_TEST_NO_CUSPARSELT */
/* Built without cuSPARSELt: the sparse rows still run and report cudez's
 * own numbers; only their baseline column stays empty. This trades the
 * one dependency that is not in the distro toolkit (the NVIDIA tarball +
 * CUSPARSELT_DIR export) for a one-line build -- the full build remains
 * the ledger-grade configuration. */
static void phase_cusparselt(int dev) {
    (void)dev;
    printf("\nphase C: SKIPPED -- built with -DCUDEZ_TEST_NO_CUSPARSELT; sparse rows\n"
           "have no baseline column in this binary (rebuild with cuSPARSELt for the\n"
           "ledger-grade configuration)\n");
}
#endif /* CUDEZ_TEST_NO_CUSPARSELT */

/* ================= Combined ABAB phase (1.0.3, BUG-C restructure) ======= *
 * The actual fix: the harness used to run two full, separately scoped
 * passes over every row (all of cudez's rows, THEN all of cuBLAS's),
 * so any GPU clock/thermal drift over the course of a long run landed on
 * whichever phase happened to run later -- inflating or deflating %cuBLAS
 * on long runs (chassis heat-soak) independent of anything the kernels
 * themselves did. This phase interleaves per ROW instead: for each shape,
 * run cudez's trials immediately followed by cuBLAS's trials for that SAME
 * shape, before moving to the next row. Consecutive A/B measurements for
 * one row are now close together in wall-clock time, so drift affects both
 * sides of that row's ratio almost equally.
 *
 * Both backends' setup lives for the whole run (not per-phase): cudez's
 * driver-API context is booted once and never torn down until every row is
 * done, and the cuBLAS handle + operand buffers are likewise created once.
 * This is safe to mix: per CUDA's own docs, "If a non-primary CUcontext
 * created by the CUDA Driver API is current to a thread then the CUDA
 * Runtime API calls to that thread will operate on that CUcontext" --
 * cudez_boot's cuCtxCreate makes cz's context current and cudez never pops
 * it, so cublasCreate/cudaMalloc/etc. below transparently operate on cz's
 * context rather than lazily initializing their own primary context. */
static void phase_abab(int dev) {
    cudez cz = cudez_boot(dev, 0);
    cudez_gpu_sample_ clk_start = cudez_sample_gpu_clock_();
    cublasHandle_t h;
    void *dH, *dB16, *dF, *dI, *dC;
    size_t maxb = sizeof(float) * MAXE;
    int i;

    cudez_print_device(&cz);
    printf("phase AB (interleaved): cudez %d.%d.%d vs cuBLAS, per-row "
           "(%d warmup + %d timed iters)\n\n",
           CUDEZ_VERSION_MAJOR, CUDEZ_VERSION_MINOR, CUDEZ_VERSION_PATCH,
           WARMUP, ITERS);

    CK(cudaSetDevice(dev));
    if (cublasCreate(&h) != CUBLAS_STATUS_SUCCESS) {
        printf("phase AB: cublasCreate failed -- cudez rows will still run, "
               "no baseline column\n");
        for (i = 0; i < nrows; i++) {
            if (cuCtxSetCurrent(cz.context) != CUDA_SUCCESS) {
                printf("  %s: cuCtxSetCurrent failed -- skipping row (cudez "
                       "context lost)\n", rows[i].label);
                continue;
            }
            bench_row_cudez_(&cz, &rows[i]);
        }
        cudez_report_phase_clock_("phase AB (cudez-only)", clk_start);
        cudez_teardown(&cz);
        return;
    }
    CK(cudaMalloc(&dH,  sizeof(__half) * MAXE));
    CK(cudaMalloc(&dB16,sizeof(__nv_bfloat16) * MAXE));
    CK(cudaMalloc(&dF,  maxb));
    CK(cudaMalloc(&dI,  MAXE));
    CK(cudaMalloc(&dC,  sizeof(float) * MAXE));
    CK(cudaMemcpy(dH,   hH, sizeof(__half) * MAXE, cudaMemcpyHostToDevice));
    CK(cudaMemcpy(dB16, hB, sizeof(__nv_bfloat16) * MAXE, cudaMemcpyHostToDevice));
    CK(cudaMemcpy(dF,   hF, maxb, cudaMemcpyHostToDevice));
    CK(cudaMemcpy(dI,   hI, MAXE, cudaMemcpyHostToDevice));

    for (i = 0; i < nrows; i++) {
        brow *r = &rows[i];
        /* BUG (1.0.3 ABAB restructure, found via a real 3060 run where every
           cudez row failed while cuBLAS/cuSPARSELt ran fine): cudaSetDevice()
           above unconditionally calls cuCtxSetCurrent() to switch to the
           runtime's PRIMARY context for the device -- silently displacing
           cz.context (created and made current by cudez_boot) from being
           current. cz.stream is bound to cz.context specifically, so every
           cudez_try_mma_launch call after that point operated with the wrong
           context current. Re-assert cz.context as current right before each
           cudez call; cheap (a pointer swap) and idempotent, so it doesn't
           matter what cudaSetDevice or any cuBLAS/runtime call did to the
           current context since the last row. */
        if (cuCtxSetCurrent(cz.context) != CUDA_SUCCESS) {
            printf("  %s: cuCtxSetCurrent failed -- skipping row (cudez context "
                   "lost)\n", r->label);
            continue;
        }
        bench_row_cudez_(&cz, r);
        bench_row_cublas_(h, dH, dB16, dF, dI, dC, r);
    }

    cudez_report_phase_clock_("phase AB (interleaved, whole run)", clk_start);
    cublasDestroy(h);
    cudaFree(dH); cudaFree(dB16); cudaFree(dF); cudaFree(dI); cudaFree(dC);
    cudez_teardown(&cz);
}


static void bench_usage(const char *argv0) {
    printf("usage: %s bench [device] [--only f16|smem|v4|v4h|v5|v5h|v6|v7|v8|v9|v10|"
           "bf16|...|tf32|tf32v7|int8|int8v7|int8v7r2|int4|int4v7|sparse|sparsev7|batched]\n"
           "       [--size 512|1024|2048|4096] [--trials T (1..%d, odd recommended)]\n"
           "       [--csv FILE]\n"
           "dedicated single-row rerun example:\n"
           "  %s bench 0 --only v4h --size 2048 --trials 9 --csv v4h2048.csv\n"
           "clock-correlated run: ./run_bench_with_clocklog.sh [same bench args]\n",
           argv0, MAXTRIALS, argv0);
}

static int bench_main(int argc, char **argv) {
    int dev = 0, i;
    char tbuf[64];
    lcg_reset();   /* standalone-identical operands, even inside `all` */
    g_trials = 3; g_only_kind = -1; g_size = 0; g_csv = NULL; nrows = 0;
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--only") && i + 1 < argc) {
            g_only_kind = kind_from_token(argv[++i]);
            if (g_only_kind == -2) { printf("unknown kind '%s'\n", argv[i]); bench_usage(argv[0]); return 1; }
        } else if (!strcmp(argv[i], "--size") && i + 1 < argc) {
            g_size = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--trials") && i + 1 < argc) {
            g_trials = atoi(argv[++i]);
            if (g_trials < 1) g_trials = 1;
            if (g_trials > MAXTRIALS) g_trials = MAXTRIALS;
        } else if (!strcmp(argv[i], "--csv") && i + 1 < argc) {
            g_csv = argv[++i];
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            bench_usage(argv[0]); return 0;
        } else if (argv[i][0] >= '0' && argv[i][0] <= '9') {
            dev = atoi(argv[i]);
        } else {
            printf("unknown argument '%s'\n", argv[i]); bench_usage(argv[0]); return 1;
        }
    }
    g_wall0  = now_s();
    g_epoch0 = time(NULL);
    { const char *e = getenv("CUDEZ_PRIME_MS"); if (e) g_prime_ms = atof(e); }
    strftime(tbuf, sizeof tbuf, "%Y-%m-%d %H:%M:%S %Z", localtime(&g_epoch0));
    printf("cudez benchmark harness v2.3 (1.5.0) -- run `cudez_test smoke` to green FIRST\n"
           "(v2.3 = v2.2 timed methodology unchanged + per-row clock prime for laptop/WSL2\n"
           " DVFS; CUDEZ_PRIME_MS overrides, 0 = exact v2.2)\n");
    printf("bench start: %s (epoch %ld) -- trial offsets [+Ns] are from this instant;\n"
           "match them against a live clock log (cudez_gpumon.sh / cudez_runall.sh)\n",
           tbuf, (long)g_epoch0);
    printf("trials/row: %d (median committed)%s", g_trials,
           (g_trials % 2 == 0) ? " -- even count: upper median used, prefer odd\n" : "\n");
    printf("clock prime: %.0f ms sustained load per row before timing%s\n", g_prime_ms,
           g_prime_ms <= 0.0 ? " (DISABLED -- v2.2 raw behavior, DVFS confound possible)" : "");
    if (g_only_kind >= 0 || g_size)
        printf("plan filter: only=%s size=%s -- PARTIAL RUN, not a publishable full ledger\n",
               g_only_kind >= 0 ? "set" : "all", g_size ? "set" : "all");
    printf("\n");
    plan();
    if (nrows == 0) { printf("plan is empty after filters -- nothing to do\n"); return 1; }
    fill_hosts();
    phase_abab(dev);
    phase_cusparselt(dev);

    printf("\n%-17s %-16s | %9s %8s | %9s %8s %-11s | %7s\n",
           "path", "shape", "cudez ms", "TFLOPS", "base ms", "TFLOPS", "baseline", "% of BL");
    printf("------------------------------------------------------------"
           "----------------------------\n");
    for (i = 0; i < nrows; i++) {
        brow *r = &rows[i];
        char shp[24];
        snprintf(shp, sizeof shp, "%dx%dx%d%s", r->M, r->N, r->K,
                 r->batch > 1 ? " x8" : "");
        if (!r->cz_ok) {
            printf("%-17s %-16s | %s\n", r->label, shp, "skipped (capability or launch fail)");
            continue;
        }
        if (r->bl_ok)
            printf("%-17s %-16s | %9.3f %8.2f | %9.3f %8.2f %-11s | %6.1f%%\n",
                   r->label, shp, r->cz_ms, r->cz_tf, r->bl_ms, r->bl_tf,
                   r->bl_lib ? r->bl_lib : "?", 100.0 * r->bl_ms / r->cz_ms);
        else
            printf("%-17s %-16s | %9.3f %8.2f | %9s %8s %-11s | %s\n",
                   r->label, shp, r->cz_ms, r->cz_tf, "-", "-", "-",
                   r->bl_note ? r->bl_note : "-");
    }
    if (g_csv) {
        FILE *f = fopen(g_csv, "w");
        if (!f) { printf("could not open %s for CSV output\n", g_csv); }
        else {
            int t;
            fprintf(f, "# cudez bench v2; start_offset_s is relative to bench start epoch %ld\n",
                    (long)g_epoch0);
            fprintf(f, "path,M,N,K,batch,side,lib,trial,start_offset_s,ms,tflops\n");
            for (i = 0; i < nrows; i++) {
                brow *r = &rows[i];
                char lbl[24]; size_t L;
                snprintf(lbl, sizeof lbl, "%s", r->label);
                for (L = strlen(lbl); L > 0 && lbl[L - 1] == ' '; L--) lbl[L - 1] = '\0';
                for (t = 0; t < r->cz_ntr; t++)
                    fprintf(f, "%s,%d,%d,%d,%d,cudez,cudez,%d,%.3f,%.6f,%.4f\n",
                            lbl, r->M, r->N, r->K, r->batch, t,
                            r->cz_ts[t], r->cz_tr[t],
                            row_flops(r) / (r->cz_tr[t] * 1e-3) / 1e12);
                /* AUDIT-1 (1.1.0 second pass): the median/baseline rows used
                   the PADDED r->label while per-trial rows used the trimmed
                   lbl -- two distinct keys for one kernel under any
                   groupby("path"). All four writes now use lbl. */
                if (r->cz_ok)
                    fprintf(f, "%s,%d,%d,%d,%d,cudez,cudez,median,,%.6f,%.4f\n",
                            lbl, r->M, r->N, r->K, r->batch, r->cz_ms, r->cz_tf);
                for (t = 0; t < r->bl_ntr; t++)
                    fprintf(f, "%s,%d,%d,%d,%d,baseline,%s,%d,%.3f,%.6f,%.4f\n",
                            lbl, r->M, r->N, r->K, r->batch,
                            r->bl_lib ? r->bl_lib : "?", t,
                            r->bl_ts[t], r->bl_tr[t],
                            row_flops(r) / (r->bl_tr[t] * 1e-3) / 1e12);
                if (r->bl_ok)
                    fprintf(f, "%s,%d,%d,%d,%d,baseline,%s,median,,%.6f,%.4f\n",
                            lbl, r->M, r->N, r->K, r->batch,
                            r->bl_lib ? r->bl_lib : "?", r->bl_ms, r->bl_tf);
            }
            fclose(f);
            printf("\nper-trial CSV written to %s\n", g_csv);
        }
    }

    printf("\nnotes: every ms/TFLOPS cell above is the MEDIAN of %d independent trials\n"
           "(each %d warmup + %d timed iters); individual trials and their start offsets\n"
           "were printed inline and go to --csv for correlation against a clock log.\n",
           g_trials, WARMUP, ITERS);
    printf("notes: TFLOPS = 2*M*N*K*batch / time (sparse is DENSE-EQUIVALENT: compare\n"
           "the sparse row against the dense F16 row of the same shape, against EITHER\n"
           "baseline). INT8 is TOPS, baselined against cuBLAS. INT4 is TOPS with no\n"
           "in-process baseline (see the CUTLASS profiler note at the bottom of this\n"
           "file) -- fold that number in by hand once you have it. %% of BL = baseline\n"
           "time / cudez time (100%% = parity), regardless of which library filled the\n"
           "baseline column. cudez's dense kernels have no shared-memory tiling except\n"
           "the opt-in smem_stage pipeline -- these numbers ARE the surface the tiling\n"
           "work must beat. Save this output with `nvidia-smi` info.\n");
    free(hF); free(hH); free(hB); free(hI);
    return 0;
}

/* ==========================================================================
 * INT4 baseline via CUTLASS profiler (out-of-process, not linked here)
 * ==========================================================================
 * Why this isn't a Phase D in this binary: cuBLAS and cuSPARSELt are both
 * plain C ABI shared libraries -- link a symbol, call it, time it, exactly
 * like Phase B/C above. CUTLASS is a header-only C++ TEMPLATE library: a
 * kernel is a compile-time instantiation (tile shape, warp shape, pipeline
 * stages, swizzle...) chosen and built per-shape/per-dtype by its own
 * CMake-driven generator. There is no single cutlass_int4_gemm() symbol to
 * link against; forcing one instantiation into this g++ translation unit
 * would mean vendoring the CUTLASS template headers and picking, by hand,
 * one specific tile config that becomes >the< "CUTLASS baseline" -- a much
 * heavier and much more arbitrary choice than the ones this file makes for
 * cuBLAS/cuSPARSELt, which never require picking an algorithm.
 *
 * CUTLASS instead ships cutlass_profiler, a prebuilt tool whose entire job
 * is "give me TFLOPS for shape X, dtype Y, on this GPU" and auto-tune over
 * its own kernel catalog for you -- exactly the oracle role cuBLAS/
 * cuSPARSELt play here, just invoked as a separate process instead of a
 * linked call. Recommended procedure:
 *
 *   git clone --depth 1 https://github.com/NVIDIA/cutlass.git
 *   cd cutlass && mkdir build && cd build
 *   cmake .. -DCUTLASS_NVCC_ARCHS=86 -DCUTLASS_LIBRARY_KERNELS=s4*gemm*
 *   make cutlass_profiler -j
 *
 *   ./tools/profiler/cutlass_profiler --operation=Gemm \
 *       --A=s4:row --B=s4:row --C=s32:row --accumulator-type=s32 \
 *       --m=512  --n=512  --k=512  --warmup-iterations=3 --profiling-iterations=10
 *   # repeat for m=n=k in {1024,2048,4096} -- the same four shapes as the
 *   # INT4 dense row above
 *
 * cutlass_profiler prints GFLOPs/TFLOPs (report as TOPS for int4, same
 * convention as cudez's own INT4 row) plus a CSV if --output= is given.
 * Fold those four numbers into the ledger as "cudez INT4 vs CUTLASS s4
 * GEMM (best of catalog)" -- and say so explicitly, since "CUTLASS" here
 * means "best tile config CUTLASS's own search found," not one fixed
 * kernel, which is a slightly different honesty statement than the fixed-
 * algorithm cuBLAS/cuSPARSELt columns above.
 */

/* ==========================================================================
 * Dispatcher
 * ========================================================================== */
static void top_usage(const char *argv0) {
    printf("cudez_test -- cudez %d.%d.%d unified harness\n"
           "usage: %s <verify|debug|smoke|bench|all|emit|retarget> [args]\n"
           "  verify [incdir]         GPU-free NVRTC gate over generated v3..v9\n"
           "                          (incdir default /usr/include; CRT_INC honored;\n"
           "                           on WSL2/CUDA boxes pass /usr/local/cuda/include)\n"
           "  debug  [device] [--csv F]  cross-pipeline correctness sweep -> CSV\n"
           "                          (streaming,v3..v9 x shape grid; catches anomalies)\n"
           "  smoke  [device]         real-hardware numerical gates (green FIRST)\n"
           "  bench  [device] [...]   performance record; see `%s bench --help`\n"
           "  all    [device] [...]   retarget, verify, smoke, then bench(remaining\n"
           "                          args); stops at the first failing stage\n"
           "  emit                    GPU-free: dump every generated kernel to gen_*.cu\n"
           "                          (was emit.c; uses the public introspection path)\n"
           "  retarget                host-only unit test of the bf16 retarget contract\n"
           "                          (was test_retarget.c; no GPU needed)\n",
           CUDEZ_VERSION_MAJOR, CUDEZ_VERSION_MINOR, CUDEZ_VERSION_PATCH,
           argv0, argv0);
}

/* ------------------------------------------------------------ debug sweep --
 * `./cudez_test debug [device] [--csv FILE]`
 * Runs every F16 pipeline (streaming, v3..v8) across a shape grid and two
 * alpha/beta cases, compares each launch to a CPU fp32 reference, and writes a
 * per-case CSV (pipeline, shape, launch_ok, max_abs_err, mismatches, verdict).
 * Inputs are exact small integers so a correct kernel yields max_abs_err 0 --
 * any nonzero error or unexpected launch rejection is an anomaly to inspect.
 * This is the "catch anomalies" companion to bench: bench measures speed on
 * green kernels, debug proves correctness across the whole matrix at once. */
static void debug_row(FILE *f, const char *name, int stage, int hint,
                      int M, int N, int K, float al, float be,
                      int launch_ok, double maxe, long mism, const char *verd) {
    fprintf(f, "%s,%d,%d,%d,%d,%d,%.1f,%.1f,%d,%.6g,%ld,%s\n",
            name, stage, hint, M, N, K, al, be, launch_ok, maxe, mism, verd);
    fflush(f);
}

static int debug_main(int argc, char **argv) {
    int dev = 0, i, si, pi, abi;
    const char *csv = "debug_report.csv";
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--csv") && i + 1 < argc) csv = argv[++i];
        else dev = atoi(argv[i]);
    }
    { cudez cz = cudez_boot(dev, 0);
    int sm80 = (cz.cc_major >= 8);
    FILE *f = fopen(csv, "w");
    if (!f) { printf("debug: cannot open %s\n", csv); cudez_teardown(&cz); return 1; }
    cudez_print_device(&cz);
    fprintf(f, "# cudez %d.%d.%d debug sweep -- cross-pipeline correctness vs CPU fp32 reference\n",
            CUDEZ_VERSION_MAJOR, CUDEZ_VERSION_MINOR, CUDEZ_VERSION_PATCH);
    fprintf(f, "pipeline,stage,store_hint,M,N,K,alpha,beta,launch_ok,max_abs_err,mismatches,verdict\n");

    /* stage, store_hint, warps_per_block, name. v8/v9 need 16 warps; the rest 4. */
    struct { int stage, hint, warps; const char *name; } P[] = {
        {0,0,4,"streaming"}, {1,0,4,"v3"}, {2,0,4,"v4"}, {2,1,4,"v4h"},
        {3,0,4,"v5"}, {3,1,4,"v5h"}, {4,0,4,"v6"}, {5,0,4,"v7"}, {6,0,16,"v8"},
        {7,0,16,"v9"}, {8,0,16,"v10"}
    };
    int nP = (int)(sizeof P / sizeof P[0]);
    /* all shapes are multiples of 128 in M,N and 64 in K so EVERY pipeline
       (incl. v8's 128x128/BK=32 contract) is admissible -- a rejection here is
       therefore a real defect, not an expected contract miss. */
    struct { int M, N, K; } S[] = {
        {128,128,128}, {128,128,192}, {256,128,128}, {128,256,128},
        {256,256,128}, {384,256,256}, {256,384,192}, {512,512,256}
    };
    int nS = (int)(sizeof S / sizeof S[0]);
    struct { float a, b; } AB[] = { {1.0f, 0.0f}, {2.0f, 1.0f} };

    int total = 0, npass = 0, nfail = 0, nrej = 0, nskip = 0;
    for (si = 0; si < nS; si++) {
        int M = S[si].M, N = S[si].N, K = S[si].K, m, n, k;
        __half *Ah = (__half*)malloc(sizeof(__half) * (size_t)M * K);
        __half *Bh = (__half*)malloc(sizeof(__half) * (size_t)K * N);
        float  *Cf = (float*)malloc(sizeof(float) * (size_t)M * N);
        float  *raw = (float*)malloc(sizeof(float) * (size_t)M * N);
        float  *Dref = (float*)malloc(sizeof(float) * (size_t)M * N);
        float  *Dg = (float*)malloc(sizeof(float) * (size_t)M * N);
        for (k = 0; k < M * K; k++) Ah[k] = __float2half((float)rnd_range(-4, 4));
        for (k = 0; k < K * N; k++) Bh[k] = __float2half((float)rnd_range(-4, 4));
        for (k = 0; k < M * N; k++) Cf[k] = (float)rnd_range(-4, 4);
        /* expensive A*B computed ONCE per shape; alpha/beta applied cheaply below */
        for (m = 0; m < M; m++)
            for (n = 0; n < N; n++) {
                float acc = 0.0f;
                for (k = 0; k < K; k++) acc += __half2float(Ah[m*K+k]) * __half2float(Bh[k*N+n]);
                raw[m*N+n] = acc;
            }
        cudez_buffer dA = cudez_buffer_write(&cz, Ah, sizeof(__half) * (size_t)M * K);
        cudez_buffer dB = cudez_buffer_write(&cz, Bh, sizeof(__half) * (size_t)K * N);
        cudez_buffer dC = cudez_buffer_write(&cz, Cf, sizeof(float) * (size_t)M * N);

        for (abi = 0; abi < 2; abi++) {
            float al = AB[abi].a, be = AB[abi].b;
            for (k = 0; k < M * N; k++) Dref[k] = al * raw[k] + be * Cf[k];
            for (pi = 0; pi < nP; pi++) {
                cudez_mma_config cfg = cudez_mma_defaults(CUDEZ_MMA_F16);
                cudez_mma_kernel mm;
                cfg.smem_stage = P[pi].stage; cfg.store_hint = P[pi].hint;
                total++;
                if (P[pi].stage >= 2 && !sm80) {
                    debug_row(f, P[pi].name, P[pi].stage, P[pi].hint, M, N, K, al, be,
                              0, -1.0, 0, "SKIP_SM80"); nskip++; continue;
                }
                if (cudez_try_mma_build(&cz, &cfg, "dbg", &mm) != CUDA_SUCCESS) {
                    debug_row(f, P[pi].name, P[pi].stage, P[pi].hint, M, N, K, al, be,
                              0, -1.0, 0, "BUILD_FAIL"); nfail++; continue;
                }
                {
                cudez_buffer dD = cudez_buffer_new(&cz, sizeof(float) * (size_t)M * N);
                cudez_mma_args a; memset(&a, 0, sizeof a);
                a.A = dA.ptr; a.B = dB.ptr; a.C = dC.ptr; a.D = dD.ptr;
                a.M = M; a.N = N; a.K = K; a.alpha = al; a.beta = be;
                a.warps_per_block = P[pi].warps;
                if (cudez_try_mma_launch(&cz, &mm, &a) != CUDA_SUCCESS) {
                    debug_row(f, P[pi].name, P[pi].stage, P[pi].hint, M, N, K, al, be,
                              0, -1.0, 0, "LAUNCH_REJECT"); nrej++;
                    cudez_buffer_free(&cz, dD); continue;
                }
                cudez_finish(&cz);
                cudez_read(&cz, dD, Dg, sizeof(float) * (size_t)M * N);
                {
                double maxe = 0.0; long mism = 0;
                for (k = 0; k < M * N; k++) {
                    double d = fabs((double)Dg[k] - (double)Dref[k]);
                    if (d > maxe) maxe = d;
                    if (d > 0.5) mism++;
                }
                if (maxe <= 0.5) { debug_row(f, P[pi].name, P[pi].stage, P[pi].hint, M, N, K,
                                             al, be, 1, maxe, mism, "PASS"); npass++; }
                else            { debug_row(f, P[pi].name, P[pi].stage, P[pi].hint, M, N, K,
                                             al, be, 1, maxe, mism, "FAIL"); nfail++; }
                }
                cudez_buffer_free(&cz, dD);
                }
            }
        }
        cudez_buffer_free(&cz, dA); cudez_buffer_free(&cz, dB); cudez_buffer_free(&cz, dC);
        free(Ah); free(Bh); free(Cf); free(raw); free(Dref); free(Dg);
    }
    fclose(f);
    printf("\ndebug sweep: %d cases -> %d PASS, %d FAIL, %d LAUNCH_REJECT, %d skipped\n",
           total, npass, nfail, nrej, nskip);
    printf("  wrote %s  (inspect any FAIL / nonzero max_abs_err / LAUNCH_REJECT)\n", csv);
    cudez_teardown(&cz);
    return (nfail || nrej) ? 1 : 0;
    }
}

/* ------------------------------------------------------------ emit --------
 * `./cudez_test emit` -- absorbed from the former standalone emit.c.
 * GPU-free: dumps the generated CUDA source for each pipeline/dtype via the
 * public cudez_mma_source() introspection path -- exactly what NVRTC would
 * compile -- so a reviewer can diff kernels without a GPU or CUDA toolkit. */
static void emit_one_(cudez_mma_dtype dt, int stage, const char *fn) {
    cudez_mma_config cfg = cudez_mma_defaults(dt);
    static char src[200000];
    cfg.smem_stage = stage;
    if (!cudez_mma_source(&cfg, "gemm", src, sizeof src)) {
        fprintf(stderr, "  emit FAILED: dt=%d stage=%d\n", (int)dt, stage); return;
    }
    { FILE *f = fopen(fn, "w");
      if (f) { fputs(src, f); fclose(f); printf("  %-18s %6zu B\n", fn, strlen(src)); } }
}
static void emit_one2_(cudez_mma_dtype dt, int stage, int hint, int sparse, const char *fn) {
    cudez_mma_config cfg = cudez_mma_defaults(dt);
    static char src[200000];
    cfg.smem_stage = stage; cfg.store_hint = hint; cfg.sparse = sparse;
    if (!cudez_mma_source(&cfg, "gemm", src, sizeof src)) {
        fprintf(stderr, "  emit FAILED: dt=%d stage=%d hint=%d sp=%d\n", (int)dt, stage, hint, sparse); return;
    }
    { FILE *f = fopen(fn, "w");
      if (f) { fputs(src, f); fclose(f); printf("  %-18s %6zu B\n", fn, strlen(src)); } }
}
/* Validate a config against the validator with a synthetic sm_86 device --
   the gap this closes: emit calls cudez_mma_source() which BYPASSES the
   validator, so a generator/validator disagreement (e.g. the store_hint=1
   INT8-rung-2 config that the validator still rejected) sailed through every
   sandbox gate and aborted on first silicon contact. Now every config emit
   exercises must also pass validation, GPU-free. */
static int emit_validate_(cudez_mma_dtype dt, int stage, int hint, int sparse, const char *what) {
    cudez cz; cudez_mma_config cfg; char eb[256];
    memset(&cz, 0, sizeof cz); cz.cc_major = 8; cz.cc_minor = 6;   /* synthetic sm_86 */
    cfg = cudez_mma_defaults(dt);
    cfg.smem_stage = stage; cfg.store_hint = hint; cfg.sparse = sparse;
    if (!cudez_mma_cfg_valid_(&cz, &cfg, eb, sizeof eb)) {
        printf("  VALIDATOR REJECTS %s: %s\n", what, eb);
        return 1;
    }
    return 0;
}
static int emit_expect_bad_ = 0;
static int emit_main(void) {
    int vbad = 0;
    puts("validator gate (synthetic sm_86):");
    vbad += emit_validate_(CUDEZ_MMA_F16,  7, 0, 0, "f16 v9");
    vbad += emit_validate_(CUDEZ_MMA_F16,  8, 0, 0, "f16 v10");
    vbad += emit_validate_(CUDEZ_MMA_BF16, 8, 0, 0, "bf16 v10");
    vbad += emit_validate_(CUDEZ_MMA_INT8, 5, 0, 0, "int8 pipeline r1");
    vbad += emit_validate_(CUDEZ_MMA_INT8, 5, 1, 0, "int8 pipeline r2 (store_hint=1)");
    vbad += emit_validate_(CUDEZ_MMA_TF32, 5, 0, 0, "tf32 pipeline");
    vbad += emit_validate_(CUDEZ_MMA_TF32, 7, 0, 0, "tf32 RING");
    vbad += emit_validate_(CUDEZ_MMA_INT4, 5, 0, 0, "int4 pipeline");
    vbad += emit_validate_(CUDEZ_MMA_F16,  5, 0, 1, "2:4 sparse pipeline");
    vbad += emit_validate_(CUDEZ_MMA_F16,  7, 0, 1, "2:4 sparse RING");
    /* dispatcher pick-table assertions (pure logic, GPU-free) */
    { struct { cudez_mma_dtype dt; int sp, M, N, K, want_stage; } P[] = {
        { CUDEZ_MMA_F16,  0, 4096, 4096, 4096, 7 }, { CUDEZ_MMA_F16, 0, 1024, 1024, 1024, 5 },
        { CUDEZ_MMA_F16,  0, 2048, 2048, 2048, 7 }, { CUDEZ_MMA_F16, 0,   96,   96,  96, 0 },
        { CUDEZ_MMA_F16, 0,   64,   64,  96, 0 },  /* BUG-1 pin: K=96 is 32 mod 64 -- v6's contract rejects it; must stream */
        { CUDEZ_MMA_BF16, 0, 4096, 4096, 4096, 7 }, { CUDEZ_MMA_TF32, 0, 1024, 1024, 1024, 5 },
        { CUDEZ_MMA_TF32, 0, 4096, 4096, 4096, 7 },
        { CUDEZ_MMA_INT8, 0, 2048, 2048, 2048, 5 }, { CUDEZ_MMA_INT4, 0, 1024, 1024, 1024, 5 },
        { CUDEZ_MMA_INT4, 0, 1024, 1024, 1088, 0 }, { CUDEZ_MMA_F16,  1, 2048, 2048, 2048, 7 },
        { CUDEZ_MMA_F16,  1, 2112, 2112, 2048, 5 } };  /* 2112 %% 128 != 0 -> falls to v7-class */
      size_t pi; int pbad = 0;
      for (pi = 0; pi < sizeof P / sizeof P[0]; pi++) {
          cudez_mma_config pc = cudez_mma_pick(P[pi].dt, P[pi].sp, P[pi].M, P[pi].N, P[pi].K);
          if (pc.smem_stage != P[pi].want_stage) {
              printf("  PICK WRONG: dt=%d sp=%d %dx%dx%d -> stage %d (want %d)\n",
                     (int)P[pi].dt, P[pi].sp, P[pi].M, P[pi].N, P[pi].K, pc.smem_stage, P[pi].want_stage);
              pbad++;
          }
      }
      if (pbad) vbad += pbad; else puts("  dispatcher pick-table: all correct");
    }
    if (vbad) { printf("*** %d validator/generator disagreements -- fix before silicon ***\n", vbad); return 1; }
    puts("  all pipeline configs validate");
    puts("emitting generated kernels (GPU-free):");
#define CUDEZ_EMIT_EXPECT_(fn, tok) do { \
        FILE *ef_ = fopen(fn, "r"); char eb_[200000]; size_t en_; \
        if (ef_) { en_ = fread(eb_, 1, sizeof eb_ - 1, ef_); eb_[en_] = 0; fclose(ef_); \
            if (!strstr(eb_, tok)) { \
                printf("  EMIT WRONG KERNEL: %s lacks '%s' -- dispatch order bug\n", fn, tok); \
                emit_expect_bad_++; } } \
        else { printf("  EMIT MISSING FILE: %s (expectation cannot run)\n", fn); \
               emit_expect_bad_++; } } while (0)
    emit_one_(CUDEZ_MMA_F16,  1, "gen_v3.cu");
    emit_one_(CUDEZ_MMA_F16,  2, "gen_v4.cu");
    emit_one_(CUDEZ_MMA_F16,  3, "gen_v5.cu");
    emit_one_(CUDEZ_MMA_F16,  4, "gen_v6.cu");
    emit_one_(CUDEZ_MMA_F16,  5, "gen_v7.cu");
    emit_one_(CUDEZ_MMA_F16,  6, "gen_v8.cu");
    emit_one_(CUDEZ_MMA_F16,  7, "gen_v9.cu");
    emit_one_(CUDEZ_MMA_BF16, 4, "gen_v6_bf16.cu");
    emit_one_(CUDEZ_MMA_BF16, 5, "gen_v7_bf16.cu");
    emit_one_(CUDEZ_MMA_BF16, 6, "gen_v8_bf16.cu");
    emit_one_(CUDEZ_MMA_F16,  8, "gen_v10.cu");
    emit_one_(CUDEZ_MMA_BF16, 7, "gen_v9_bf16.cu");
    emit_one_(CUDEZ_MMA_BF16, 8, "gen_v10_bf16.cu");
    emit_one_(CUDEZ_MMA_F16,  0, "gen_stream.cu");   /* 1.0.1: streaming dense was never emitted */
    emit_one2_(CUDEZ_MMA_F16, 0, 0, 1, "gen_sparse.cu"); /* streaming sparse likewise */
    emit_one_(CUDEZ_MMA_INT8, 0, "gen_i8.cu");
    emit_one_(CUDEZ_MMA_INT8, 5, "gen_i8_v7.cu");
    emit_one2_(CUDEZ_MMA_INT8, 5, 1, 0, "gen_i8_v7r2.cu");
    emit_one2_(CUDEZ_MMA_TF32, 5, 0, 0, "gen_tf32_v7.cu");
    emit_one2_(CUDEZ_MMA_INT4, 5, 0, 0, "gen_i4_v7.cu");
    emit_one2_(CUDEZ_MMA_F16,  5, 0, 1, "gen_sp_v7.cu");
    emit_one2_(CUDEZ_MMA_F16,  7, 0, 1, "gen_sp_v9.cu");
    emit_one2_(CUDEZ_MMA_TF32, 7, 0, 0, "gen_tf32_v9.cu");

    emit_one_(CUDEZ_MMA_INT4, 0, "gen_i4.cu");
    /* mechanical kernel-identity gate: each emitted file must contain the mma
       opcode (and conversion, where applicable) that identifies ITS kernel.
       This is the check whose absence let the TF32@7 dispatch-order bug emit
       the F16 v9 kernel unnoticed -- the human eyeball is not a gate. */
    CUDEZ_EMIT_EXPECT_("gen_tf32_v9.cu", "mma.sync.aligned.m16n8k8.row.col.f32.tf32");
    CUDEZ_EMIT_EXPECT_("gen_tf32_v9.cu", "cvt.rna.tf32.f32");
    CUDEZ_EMIT_EXPECT_("gen_tf32_v7.cu", "mma.sync.aligned.m16n8k8.row.col.f32.tf32");
    CUDEZ_EMIT_EXPECT_("gen_sp_v9.cu",   "mma.sp.sync.aligned.m16n8k32");
    CUDEZ_EMIT_EXPECT_("gen_sp_v7.cu",   "mma.sp.sync.aligned.m16n8k32");
    CUDEZ_EMIT_EXPECT_("gen_i8_v7.cu",   "m16n8k32.row.col.s32.s8");
    CUDEZ_EMIT_EXPECT_("gen_i8_v7r2.cu", "m16n8k32.row.col.s32.s8");
    CUDEZ_EMIT_EXPECT_("gen_i4_v7.cu",   "m16n8k64.row.col.s32.s4");
    CUDEZ_EMIT_EXPECT_("gen_v9.cu",      "m16n8k16.row.col.f32.f16");
    CUDEZ_EMIT_EXPECT_("gen_v10.cu",     "m16n8k16.row.col.f32.f16");
    /* BUG-A regression pins (1.0.1): streaming kernels must index in 64-bit;
       the 6 GB reference GPU can never catch a 2^31 element-offset overflow. */
    CUDEZ_EMIT_EXPECT_("gen_stream.cu", "(long long)row0 * K");
    CUDEZ_EMIT_EXPECT_("gen_stream.cu", "(long long)k0 * N");
    CUDEZ_EMIT_EXPECT_("gen_stream.cu", "(long long)row0 * N");
    CUDEZ_EMIT_EXPECT_("gen_i8.cu",     "(long long)(trow + grp) * K");
    CUDEZ_EMIT_EXPECT_("gen_i8.cu",     "(long long)row0 * N");
    CUDEZ_EMIT_EXPECT_("gen_i4.cu",     "(long long)(trow + grp) * Kb");
    CUDEZ_EMIT_EXPECT_("gen_sparse.cu", "(long long)row0 * Kc");
    if (emit_expect_bad_) { printf("*** %d wrong-kernel emissions ***\n", emit_expect_bad_); return 1; }
    puts("  kernel-identity gate: all opcodes present");
    return 0;
}

/* ------------------------------------------------------------ retarget ----
 * `./cudez_test retarget` -- absorbed from the former test_retarget.c.
 * Host unit test for A-3: cudez_strreplace_all_ / cudez_bf16_retarget_ must
 * REPORT truncation (return 0) rather than silently emit a half-retargeted
 * kernel. Pure host, no GPU. */
#define RT_CHECK(cond, msg) do { \
    if (cond) { printf("  ok   : %s\n", msg); } \
    else      { printf("  FAIL : %s\n", msg); fails++; } } while (0)
static int retarget_main(void) {
    int fails = 0;
    char buf[512];

    /* 1. Ample room: growth applied fully, returns 1. */
    strcpy(buf, "__half x; __half y;");
    RT_CHECK(cudez_strreplace_all_(buf, sizeof buf, "__half", "__nv_bfloat16") == 1,
          "ample buffer -> returns 1 (success)");
    RT_CHECK(strcmp(buf, "__nv_bfloat16 x; __nv_bfloat16 y;") == 0,
          "ample buffer -> both occurrences replaced");
    RT_CHECK(strstr(buf, "__half") == NULL, "ample buffer -> no leftover __half");

    /* 2. Buffer exactly too small for the +7B/occurrence growth: returns 0,
          and does NOT write past cap. Cap chosen 1 byte short of the grown len. */
    {
        char tight[24];                 /* "__half a;" = 9 chars + NUL = 10 */
        size_t cap;
        strcpy(tight, "__half a;");     /* one replace grows 9->16 (+NUL 17) */
        cap = 16;                       /* one short of 17 -> must refuse */
        RT_CHECK(cudez_strreplace_all_(tight, cap, "__half", "__nv_bfloat16") == 0,
              "too-small buffer -> returns 0 (truncation reported)");
    }

    /* 3. bf16 retarget on a buffer too small for the full body: returns 0. */
    {
        char small[40];
        strcpy(small, "#include <cuda_fp16.h>\n__half z;");
        RT_CHECK(cudez_bf16_retarget_(small, sizeof small) == 0,
              "bf16_retarget tiny buffer -> returns 0 (build would fail loudly)");
    }

    /* 4. bf16 retarget with room: returns 1, all needles applied. */
    {
        char ok[256];
        strcpy(ok, "#include <cuda_fp16.h>\n__half a; mma .f32.f16.f16.f32 b;");
        RT_CHECK(cudez_bf16_retarget_(ok, sizeof ok) == 1,
              "bf16_retarget ample buffer -> returns 1");
        RT_CHECK(strstr(ok, "__nv_bfloat16") && strstr(ok, ".f32.bf16.bf16.f32") &&
              strstr(ok, "cuda_bf16.h") && strstr(ok, "__half") == NULL,
              "bf16_retarget ample buffer -> all tokens retargeted, none left");
    }

    printf(fails ? "\nRETARGET CONTRACT: %d FAIL\n" : "\nRETARGET CONTRACT: ALL PASS\n", fails);
    return fails ? 1 : 0;
}
#undef RT_CHECK

int main(int argc, char **argv) {
    if (argc < 2) { top_usage(argv[0]); return 1; }
    if (!strcmp(argv[1], "verify")) return verify_main(argc - 1, argv + 1);
    if (!strcmp(argv[1], "debug"))  return debug_main(argc - 1, argv + 1);
    if (!strcmp(argv[1], "smoke"))  return smoke_main(argc - 1, argv + 1);
    if (!strcmp(argv[1], "bench"))  return bench_main(argc - 1, argv + 1);
    if (!strcmp(argv[1], "emit"))   return emit_main();
    if (!strcmp(argv[1], "retarget")) return retarget_main();
    if (!strcmp(argv[1], "all")) {
        int rc;
        rc = retarget_main();          /* host-only, instant, no GPU needed */
        if (rc) { printf("\n`all` stopped: retarget contract failed\n"); return rc; }
        /* verify with the default/env incdir; device+flags go to smoke/bench */
        { char *vargv[2]; vargv[0] = argv[0];
          vargv[1] = getenv("CUDEZ_NVRTC_INCLUDE") ? getenv("CUDEZ_NVRTC_INCLUDE") : (char *)"/usr/include";
          rc = verify_main(2, vargv); }
        if (rc) { printf("\n`all` stopped: verify failed\n"); return rc; }
        rc = smoke_main(argc - 1, argv + 1);
        if (rc) { printf("\n`all` stopped: smoke not green -- no bench numbers mean anything\n"); return rc; }
        return bench_main(argc - 1, argv + 1);
    }
    if (!strcmp(argv[1], "--help") || !strcmp(argv[1], "-h")) { top_usage(argv[0]); return 0; }
    printf("unknown subcommand '%s'\n", argv[1]);
    top_usage(argv[0]);
    return 1;
}
